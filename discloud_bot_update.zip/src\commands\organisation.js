const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { organizationPanelEmbed } = require('../utils/embeds');

module.exports = [
  {
    data: new SlashCommandBuilder()
      .setName('organisation')
      .setDescription('🏢 & ⚔️ Gestion et panneau de création de Gangs & Entreprises RP')
      .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
      .addSubcommand(sub =>
        sub
          .setName('setup')
          .setDescription('Déployer le Portail de Création d\'Organisations (Gangs/Entreprises) dans ce salon')
      ),

    async execute(interaction) {
      const subcommand = interaction.options.getSubcommand();

      if (subcommand === 'setup') {
        await interaction.deferReply({ ephemeral: true });

        const panelData = organizationPanelEmbed();
        await interaction.channel.send(panelData);

        await interaction.editReply({
          content: `✅ **Portail de Création d'Organisations (Gangs & Entreprises) déployé avec succès** dans ${interaction.channel} !`
        });
      }
    }
  }
];
