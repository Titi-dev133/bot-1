const { ChannelType, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const config = require('../../config.json');
const db = require('../database/db');

/**
 * Finds or creates the #alerte-raid channel in the guild.
 */
async function getAlerteRaidChannel(guild) {
  if (!guild || !guild.channels) return null;

  try {
    let targetChannel = guild.channels.cache.find(c =>
      c.type === ChannelType.GuildText &&
      (c.name.toLowerCase() === 'alerte-raid' || c.name.toLowerCase() === 'alertes-raid' || c.name.toLowerCase() === 'raid-alert')
    );

    if (targetChannel) return targetChannel;

    // Create automatically if missing
    try {
      targetChannel = await guild.channels.create({
        name: 'alerte-raid',
        type: ChannelType.GuildType ? ChannelType.GuildText : 0,
        topic: '🚨 Salon d\'alerte d\'urgence et pings automatiques en cas de raid sur le serveur'
      });
      console.log(`✅ Salon #alerte-raid créé automatiquement sur ${guild.name}`);
      return targetChannel;
    } catch (createErr) {
      console.error(`⚠️ Impossible de créer automatiquement le salon #alerte-raid:`, createErr.message);
      return null;
    }
  } catch (error) {
    console.error(`⚠️ Erreur lors de la recherche du salon alerte-raid:`, error);
    return null;
  }
}

/**
 * Finds or resolves the primary audit log channel for the guild.
 * Prioritizes the salon named 'log-serveur'.
 */
async function getAuditLogsChannel(guild) {
  if (!guild || !guild.channels) return null;

  try {
    let targetChannel = guild.channels.cache.find(c => 
      c.type === ChannelType.GuildText && 
      (c.name.toLowerCase() === 'log-serveur' || c.name.toLowerCase() === 'logs-serveur')
    );

    if (targetChannel) return targetChannel;

    const configChannelId = config.channels?.serverLogs || config.channels?.moderationLogs || config.channels?.auditLogs;
    if (configChannelId && configChannelId !== 'ID_SALON_LOGS_MODERATION') {
      targetChannel = guild.channels.cache.get(configChannelId);
      if (targetChannel) return targetChannel;
    }

    try {
      const dbConfig = await db.getWelcomeConfig(guild.id);
      if (dbConfig?.securityLogChannelId) {
        targetChannel = guild.channels.cache.get(dbConfig.securityLogChannelId);
        if (targetChannel) return targetChannel;
      }
    } catch (dbErr) {}

    targetChannel = guild.channels.cache.find(c => 
      c.type === ChannelType.GuildText && (
        c.name.toLowerCase().includes('log-serveur') ||
        c.name.toLowerCase().includes('audit') ||
        c.name.toLowerCase().includes('log-moderation') ||
        c.name.toLowerCase().includes('logs-moderation') ||
        c.name.toLowerCase() === 'logs'
      )
    );

    return targetChannel || null;
  } catch (error) {
    console.error(`⚠️ Erreur lors de la recherche du salon log-serveur sur ${guild.name}:`, error);
    return null;
  }
}

/**
 * Safely sends an audit embed to the guild's log-serveur channel.
 */
async function sendAuditLog(guild, embed) {
  if (!guild || !embed) return;

  try {
    const channel = await getAuditLogsChannel(guild);
    if (!channel) return;

    const botMember = guild.members.me;
    if (botMember && !channel.permissionsFor(botMember).has([PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.EmbedLinks])) {
      console.warn(`⚠️ Permissions insuffisantes pour envoyer le log d'audit dans #${channel.name} (${guild.name})`);
      return;
    }

    let embedToSend = embed;
    if (!(embed instanceof EmbedBuilder)) {
      const eb = new EmbedBuilder();
      if (embed.title) eb.setTitle(embed.title);
      if (embed.description) eb.setDescription(embed.description);
      if (embed.color) {
        try { eb.setColor(embed.color); } catch (e) { eb.setColor('#1E88E5'); }
      } else {
        eb.setColor('#1E88E5');
      }
      if (embed.fields && embed.fields.length > 0) eb.addFields(embed.fields);
      if (embed.footer) eb.setFooter(typeof embed.footer === 'string' ? { text: embed.footer } : embed.footer);
      if (embed.thumbnail) eb.setThumbnail(embed.thumbnail);
      eb.setTimestamp(embed.timestamp || new Date());
      embedToSend = eb;
    }

    await channel.send({ embeds: [embedToSend] });
  } catch (error) {
    console.error(`❌ Erreur lors de l'envoi du log d'audit sur ${guild.name}:`, error.message);
  }
}


/**
 * Triggers a full raid emergency alert pinging @everyone in #alerte-raid.
 */
async function triggerRaidAlert(guild, { reason, details, joinCount = 0, isTest = false, user = null }) {
  if (!guild) return;

  try {
    const alerteChannel = await getAlerteRaidChannel(guild);

    const embed = new EmbedBuilder()
      .setTitle(isTest ? '🧪 TEST DE SYSTÈME : SIMULATION D\'ALERTE RAID' : '🚨 ALERTE CRITIQUE : RAID DÉTECTÉ EN COURS !')
      .setColor(isTest ? '#FB8C00' : '#E53935')
      .setThumbnail('https://i.imgur.com/8QG4m3b.png')
      .setDescription(
        isTest
          ? `⚠️ **CECIE EST UNE SIMULATION DE TEST.**\nLe système de détection d'alerte et les pings dans ${alerteChannel || '#alerte-raid'} fonctionnent correctement !`
          : `⚠️ **UNE ATTAQUE / VAGUE DE RAID A ÉTÉ DÉTECTÉE SUR LE SERVEUR !**\nLe bot a réagi automatiquement pour sécuriser le serveur.`
      )
      .addFields(
        { name: '📌 Motif de l\'Alerte', value: `\`${reason}\``, inline: true },
        { name: '👥 Arrivées / Déclencheurs', value: `\`${joinCount > 0 ? `${joinCount} arrivées simultanées` : 'N/A'}\``, inline: true },
        { name: '🔒 Statut du Lockdown', value: '🚨 **MODE LOCKDOWN ACTIVÉ AUTOMATIQUEMENT**', inline: false },
        { name: '📝 Explication & Détails', value: `\`\`\`${details || 'Aucun détail supplémentaire'}\`\`\``, inline: false }
      )
      .setFooter({ text: 'Système d\'Alerte d\'Urgence • Hamburg RP' })
      .setTimestamp();

    if (user) {
      embed.addFields({ name: '👮 Initié par', value: `<@${user.id}> (\`${user.tag}\`)`, inline: true });
    }

    // Send Ping alert in #alerte-raid
    if (alerteChannel) {
      const pingText = isTest
        ? `🧪 **[TEST ALERTE RAID]** Notification de contrôle envoyée aux administrateurs.`
        : `@everyone 🚨 **ALERTE RAID EN COURS SUR LE SERVEUR !** 🚨`;

      await alerteChannel.send({
        content: pingText,
        embeds: [embed]
      });
    }

    // Also send audit log in #log-serveur
    const auditEmbed = {
      title: isTest ? '🧪 LOG AUDIT : TEST D\'ALERTE RAID ÉMIS' : '🚨 LOG AUDIT : ALERTE RAID ÉMISE ET SALON NOTIFIÉ',
      color: isTest ? '#FB8C00' : '#E53935',
      fields: [
        { name: '📢 Salon notifié', value: alerteChannel ? `${alerteChannel}` : 'Inconnu', inline: true },
        { name: '📌 Raison', value: `\`${reason}\``, inline: true },
        { name: '📝 Détails', value: details, inline: false }
      ],
      timestamp: new Date()
    };

    await sendAuditLog(guild, auditEmbed);

  } catch (error) {
    console.error(`❌ Erreur lors du déclenchement de l'alerte raid sur ${guild.name}:`, error);
  }
}

module.exports = {
  getAuditLogsChannel,
  getAlerteRaidChannel,
  sendAuditLog,
  triggerRaidAlert
};
