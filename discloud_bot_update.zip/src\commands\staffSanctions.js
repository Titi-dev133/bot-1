const { SlashCommandBuilder, PermissionFlagsBits, ChannelType, MessageFlags } = require('discord.js');
const { staffSanctionDashboardEmbed, staffSanctionCardEmbed, sanctionAuditLogEmbed } = require('../utils/embeds');
const db = require('../database/db');
const config = require('../../config.json');

module.exports = [
  {
    data: new SlashCommandBuilder()
      .setName('staff-sanction')
      .setDescription('Système de gestion des sanctions disciplinaires pour l\'équipe Staff (Haute Direction).')
      .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
      .addSubcommand(sub =>
        sub.setName('dashboard')
           .setDescription('Publie le panneau interactif de gestion des sanctions staff.')
      )
      .addSubcommand(sub =>
        sub.setName('ajouter')
           .setDescription('Ajouter une sanction disciplinaire sur un membre du staff.')
           .addUserOption(opt => opt.setName('staff').setDescription('Membre du staff ciblé').setRequired(true))
           .addStringOption(opt => opt.setName('sanction').setDescription('Type de sanction (ex: Warn Staff, Blâme 1/3, Demotion)').setRequired(true))
           .addStringOption(opt => opt.setName('details').setDescription('Explication et motif de la sanction').setRequired(true))
      )
      .addSubcommand(sub =>
        sub.setName('casier')
           .setDescription('Consulter l\'historique disciplinaire d\'un membre du staff.')
           .addUserOption(opt => opt.setName('staff').setDescription('Membre du staff ciblé').setRequired(true))
      )
      .addSubcommand(sub =>
        sub.setName('retirer')
           .setDescription('Retirer une sanction ou réinitialiser le dossier d\'un membre du staff.')
           .addUserOption(opt => opt.setName('staff').setDescription('Membre du staff ciblé').setRequired(true))
           .addStringOption(opt => opt.setName('cible').setDescription('Numéro de la sanction (ex: 1) ou "tout"').setRequired(true))
      ),

    async execute(interaction) {
      const subcommand = interaction.options.getSubcommand();
      const { guild, channel, user } = interaction;

      // Subcommand 1: dashboard
      if (subcommand === 'dashboard') {
        const payload = staffSanctionDashboardEmbed();
        await channel.send(payload);

        return interaction.reply({
          content: `✅ **Panneau du Dashboard Sanctions Staff publié dans ${channel} !**`,
          flags: MessageFlags.Ephemeral
        });
      }

      // Subcommand 2: ajouter
      if (subcommand === 'ajouter') {
        await interaction.deferReply({ flags: MessageFlags.Ephemeral });
        const staffUser = interaction.options.getUser('staff');
        const sanctionType = interaction.options.getString('sanction').trim();
        const details = interaction.options.getString('details').trim();

        await db.addStaffSanctionRecord(
          guild.id,
          staffUser.tag || staffUser.username,
          staffUser.id,
          user.id,
          sanctionType,
          details
        );

        const history = await db.getStaffSanctionsHistory(staffUser.id);

        let staffSanctionChannel = guild.channels.cache.find(
          c => c.type === ChannelType.GuildText && (
            c.name.toLowerCase() === 'sanction-staff' ||
            c.name.toLowerCase() === 'sanctions-staff' ||
            c.name.toLowerCase().includes('sanction-staff')
          )
        );

        if (!staffSanctionChannel) {
          try {
            staffSanctionChannel = await guild.channels.create({
              name: 'sanction-staff',
              type: ChannelType.GuildText,
              topic: 'Dossiers disciplinaires des membres de l\'équipe Staff'
            });
          } catch (e) {
            staffSanctionChannel = channel;
          }
        }

        const cardEmbed = staffSanctionCardEmbed({
          staffUser,
          sanctionsList: history
        });

        const existingCard = await db.getStaffSanctionCard(guild.id, staffUser.id);
        let updatedMessage = null;

        if (existingCard) {
          try {
            const existingMsg = await staffSanctionChannel.messages.fetch(existingCard.messageId).catch(() => null);
            if (existingMsg) {
              updatedMessage = await existingMsg.edit({ embeds: [cardEmbed] });
            }
          } catch (err) {}
        }

        if (!updatedMessage) {
          const newMsg = await staffSanctionChannel.send({ embeds: [cardEmbed] });
          await db.saveStaffSanctionCard(guild.id, staffUser.id, staffSanctionChannel.id, newMsg.id);
        }

        // Log
        let staffLogChannel = guild.channels.cache.find(c => c.name.toLowerCase() === 'log-sanction-staff');
        if (staffLogChannel) {
          const logEmbed = sanctionAuditLogEmbed({
            title: '👑 LOG : NOUVELLE SANCTION STAFF',
            target: `${staffUser.tag} (<@${staffUser.id}>)`,
            moderator: `<@${user.id}> (${user.tag})`,
            sanctionType,
            details,
            color: config.colors.police || '#0D47A1'
          });
          staffLogChannel.send({ embeds: [logEmbed] }).catch(() => {});
        }

        return interaction.editReply({
          content: `✅ **Sanction Staff enregistrée avec succès !**\n\n` +
            `👤 **Staff** : ${staffUser} (\`${staffUser.tag}\`)\n` +
            `🚨 **Sanction** : \`${sanctionType}\`\n` +
            `💬 **Dossier mis à jour dans** : ${staffSanctionChannel} (Total: **${history.length}** sanction(s))`
        });
      }

      // Subcommand 3: casier
      if (subcommand === 'casier') {
        await interaction.deferReply({ flags: MessageFlags.Ephemeral });
        const staffUser = interaction.options.getUser('staff');

        const history = await db.getStaffSanctionsHistory(staffUser.id);
        if (!history || history.length === 0) {
          return interaction.editReply({
            content: `ℹ️ Aucun dossier disciplinaire staff trouvé pour ${staffUser}.`
          });
        }

        const cardEmbed = staffSanctionCardEmbed({
          staffUser,
          sanctionsList: history
        });

        return interaction.editReply({ embeds: [cardEmbed] });
      }

      // Subcommand 4: retirer
      if (subcommand === 'retirer') {
        await interaction.deferReply({ flags: MessageFlags.Ephemeral });
        const staffUser = interaction.options.getUser('staff');
        const targetStr = interaction.options.getString('cible').trim().toLowerCase();

        const history = await db.getStaffSanctionsHistory(staffUser.id);
        if (!history || history.length === 0) {
          return interaction.editReply({
            content: `❌ Aucune sanction staff à supprimer pour ${staffUser}.`
          });
        }

        let staffSanctionChannel = guild.channels.cache.find(c => c.name.toLowerCase() === 'sanction-staff');

        if (targetStr === 'tout' || targetStr === 'all' || targetStr === '*') {
          await db.clearStaffSanctions(staffUser.id);

          const existingCard = await db.getStaffSanctionCard(guild.id, staffUser.id);
          if (existingCard && staffSanctionChannel) {
            try {
              const msg = await staffSanctionChannel.messages.fetch(existingCard.messageId).catch(() => null);
              if (msg) await msg.delete().catch(() => {});
            } catch (e) {}
            await db.deleteStaffSanctionCard(guild.id, staffUser.id);
          }

          let staffLogChannel = guild.channels.cache.find(c => c.name.toLowerCase() === 'log-sanction-staff');
          if (staffLogChannel) {
            const logEmbed = sanctionAuditLogEmbed({
              title: '🗑️ LOG : SANCTIONS STAFF PURGÉES',
              target: `${staffUser.tag} (<@${staffUser.id}>)`,
              moderator: `<@${user.id}> (${user.tag})`,
              sanctionType: 'Effacement total du dossier staff',
              details: 'L\'administrateur a réinitialisé le casier disciplinaire staff.',
              color: config.colors.warning
            });
            staffLogChannel.send({ embeds: [logEmbed] }).catch(() => {});
          }

          return interaction.editReply({
            content: `🗑️ **Toutes les sanctions staff de ${staffUser} ont été effacées !**`
          });
        }

        const idx = parseInt(targetStr, 10) - 1;
        if (isNaN(idx) || idx < 0 || idx >= history.length) {
          return interaction.editReply({
            content: `⚠️ Numéro invalide. Le membre staff a **${history.length}** sanction(s). Spécifiez entre \`1\` et \`${history.length}\`, ou \`tout\`.`
          });
        }

        const targetSanction = history[idx];
        await db.removeStaffSanctionRecord(targetSanction.id);

        const remainingHistory = await db.getStaffSanctionsHistory(staffUser.id);

        const existingCard = await db.getStaffSanctionCard(guild.id, staffUser.id);
        if (existingCard && staffSanctionChannel) {
          try {
            const msg = await staffSanctionChannel.messages.fetch(existingCard.messageId).catch(() => null);
            if (msg) {
              if (remainingHistory.length === 0) {
                await msg.delete().catch(() => {});
                await db.deleteStaffSanctionCard(guild.id, staffUser.id);
              } else {
                const cardEmbed = staffSanctionCardEmbed({
                  staffUser,
                  sanctionsList: remainingHistory
                });
                await msg.edit({ embeds: [cardEmbed] });
              }
            }
          } catch (e) {}
        }

        let staffLogChannel = guild.channels.cache.find(c => c.name.toLowerCase() === 'log-sanction-staff');
        if (staffLogChannel) {
          const logEmbed = sanctionAuditLogEmbed({
            title: '🗑️ LOG : SANCTION STAFF RETIRÉE',
            target: `${staffUser.tag} (<@${staffUser.id}>)`,
            moderator: `<@${user.id}> (${user.tag})`,
            sanctionType: `Suppression Sanction Staff #${idx + 1}`,
            details: `Suppression de la sanction: ${targetSanction.sanctionType}`,
            color: config.colors.warning
          });
          staffLogChannel.send({ embeds: [logEmbed] }).catch(() => {});
        }

        return interaction.editReply({
          content: `🗑️ **Sanction Staff #${idx + 1} retirée pour ${staffUser} !** (${remainingHistory.length} sanction(s) restante(s))`
        });
      }
    }
  }
];
