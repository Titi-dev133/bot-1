const { EmbedBuilder, AuditLogEvent } = require('discord.js');
const { sendAuditLog } = require('../utils/auditLogger');
const config = require('../../config.json');

module.exports = {
  name: 'guildBanAdd',
  async execute(ban) {
    try {
      if (!ban.guild) return;

      const embed = new EmbedBuilder()
        .setTitle('🔨 LOG AUDIT : MEMBRE BANNIE DU SERVEUR')
        .setColor(config.colors?.danger || '#E53935')
        .setThumbnail(ban.user.displayAvatarURL({ dynamic: true }))
        .addFields(
          { name: '👤 Utilisateur banni', value: `<@${ban.user.id}> (\`${ban.user.tag}\` | \`ID: ${ban.user.id}\`)`, inline: false },
          { name: '📝 Raison du ban', value: `\`\`\`${ban.reason || 'Aucune raison spécifiée'}\`\`\``, inline: false }
        )
        .setFooter({ text: `User ID: ${ban.user.id} • Hamburg RP` })
        .setTimestamp();

      try {
        const fetchedLogs = await ban.guild.fetchAuditLogs({
          limit: 1,
          type: AuditLogEvent.MemberBanAdd,
        });
        const auditEntry = fetchedLogs.entries.first();
        if (auditEntry && auditEntry.target.id === ban.user.id && (Date.now() - auditEntry.createdTimestamp) < 5000) {
          embed.addFields({ name: '👮 Banni par', value: `<@${auditEntry.executor.id}> (\`${auditEntry.executor.tag}\`)`, inline: false });
        }
      } catch (e) {}

      await sendAuditLog(ban.guild, embed);
    } catch (error) {
      console.error('❌ Erreur dans l\'événement guildBanAdd:', error);
    }
  }
};
