const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const db = require('../database/db');
const { createEmbed } = require('../utils/embeds');
const { createServiceDashboard, createRobloxDashboard, create911Dashboard, createPoliceDashboard, createFireDashboard, createHarsDashboard, createTvDashboard } = require('../utils/dashboards');
const config = require('../../config.json');

module.exports = [
  // 1. /dashboard-all (Déploie TOUS les dashboards permanents)
  {
    data: new SlashCommandBuilder()
      .setName('dashboard-all')
      .setDescription('Déployer tous les panneaux interactifs permanents dans ce salon.')
      .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
    async execute(interaction) {
      await interaction.reply({ content: '🚀 **Installation des Dashboards permanents dans ce salon...**' });

      const d1 = createServiceDashboard();
      const d2 = createRobloxDashboard();
      const d3 = create911Dashboard();
      const d4 = createPoliceDashboard();
      const d5 = createFireDashboard();
      const d6 = createHarsDashboard();
      const d7 = createTvDashboard();

      await interaction.channel.send(d1);
      await interaction.channel.send(d2);
      await interaction.channel.send(d3);
      await interaction.channel.send(d4);
      await interaction.channel.send(d5);
      await interaction.channel.send(d6);
      await interaction.channel.send(d7);
    }
  },

  // 2. /dashboard-service
  {
    data: new SlashCommandBuilder()
      .setName('dashboard-service')
      .setDescription('Déployer le Dashboard permanent de prise de service.')
      .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
    async execute(interaction) {
      const d1 = createServiceDashboard();
      await interaction.reply({ content: '🚀 **Installation du Dashboard de Prise de Service...**' });
      await interaction.channel.send(d1);
    }
  },

  // 3. /dashboard-911
  {
    data: new SlashCommandBuilder()
      .setName('dashboard-911')
      .setDescription('Déployer la Centrale 911 d\'Urgences permanente.')
      .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
    async execute(interaction) {
      const d2 = create911Dashboard();
      await interaction.reply({ content: '🚀 **Installation du Dashboard 911...**' });
      await interaction.channel.send(d2);
    }
  },

  // 4. /dashboard-police
  {
    data: new SlashCommandBuilder()
      .setName('dashboard-police')
      .setDescription('Déployer le Terminal Police & Justice permanent.')
      .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
    async execute(interaction) {
      const d3 = createPoliceDashboard();
      await interaction.reply({ content: '🚀 **Installation du Terminal Police...**' });
      await interaction.channel.send(d3);
    }
  },

  // 4b. /dashboard-pompier
  {
    data: new SlashCommandBuilder()
      .setName('dashboard-pompier')
      .setDescription('Déployer la Centrale Sapeurs-Pompiers (Feuerwehr).')
      .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
    async execute(interaction) {
      const d = createFireDashboard();
      await interaction.reply({ content: '🚀 **Installation de la Centrale Sapeurs-Pompiers...**' });
      await interaction.channel.send(d);
    }
  },

  // 4c. /dashboard-hars
  {
    data: new SlashCommandBuilder()
      .setName('dashboard-hars')
      .setDescription('Déployer le Terminal HARS & ADAC Dépannage/Secours.')
      .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
    async execute(interaction) {
      const d = createHarsDashboard();
      await interaction.reply({ content: '🚀 **Installation du Terminal HARS & ADAC...**' });
      await interaction.channel.send(d);
    }
  },

  // 4d. /dashboard-tv
  {
    data: new SlashCommandBuilder()
      .setName('dashboard-tv')
      .setDescription('Déployer la Centrale Télévision & Médias (Hamburg News / TV RP).')
      .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
    async execute(interaction) {
      const d = createTvDashboard();
      await interaction.reply({ content: '🚀 **Installation de la Centrale Médias & Télévision...**' });
      await interaction.channel.send(d);
    }
  },

  // 5. /panneau-service
  {
    data: new SlashCommandBuilder()
      .setName('panneau-service')
      .setDescription('Déploie le panneau fixe permanent de prise de service.')
      .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
    async execute(interaction) {
      const d1 = createServiceDashboard();
      await interaction.reply({ content: '🚀 **Déploiement du panneau de service...**' });
      await interaction.channel.send(d1);
    }
  },

  // 6. /prise-de-service
  {
    data: new SlashCommandBuilder()
      .setName('prise-de-service')
      .setDescription('Prendre votre service RP.')
      .addStringOption(option =>
        option.setName('service')
          .setDescription('Votre faction / service')
          .setRequired(true)
          .addChoices(
            { name: '🚓 Polizei Hamburg (Police)', value: 'police' },
            { name: '🚒 Feuerwehr (Pompiers)', value: 'fire' },
            { name: '🚑 Rettungsdienst (EMS / Ambulance)', value: 'ems' },
            { name: '🛞 ADAC (Dépannage)', value: 'adac' }
          )
      ),
    async execute(interaction) {
      const serviceChoice = interaction.options.getString('service');
      const userId = interaction.user.id;
      const guildId = interaction.guild.id;

      const result = await db.startService(userId, guildId, serviceChoice);
      if (!result.success) {
        return interaction.reply({
          embeds: [createEmbed({ title: '⚠️ Prise de Service Impossible', description: result.message, color: config.colors.warning })],
          ephemeral: true
        });
      }

      const factionData = config.factions[serviceChoice] || { name: serviceChoice.toUpperCase(), emoji: '🚨' };

      const embed = createEmbed({
        title: `${factionData.emoji} PRISE DE SERVICE`,
        description: `**${interaction.user.tag}** a pris son service chez **${factionData.name}**.\n\n⏰ Début : <t:${Math.floor(result.startTime / 1000)}:F>`,
        color: config.colors.success
      });

      await interaction.reply({ embeds: [embed] });
    }
  },

  // 7. /fin-de-service
  {
    data: new SlashCommandBuilder()
      .setName('fin-de-service')
      .setDescription('Terminer votre service RP et enregistrer vos heures.'),
    async execute(interaction) {
      const userId = interaction.user.id;
      const result = await db.stopService(userId);

      if (!result.success) {
        return interaction.reply({
          embeds: [createEmbed({ title: '⚠️ Fin de Service Impossible', description: result.message, color: config.colors.warning })],
          ephemeral: true
        });
      }

      const hours = Math.floor(result.durationMinutes / 60);
      const mins = result.durationMinutes % 60;
      const durationStr = `${hours > 0 ? `${hours}h ` : ''}${mins}min`;

      const embed = createEmbed({
        title: '🔴 FIN DE SERVICE',
        description: `**${interaction.user.tag}** a terminé son service.\n\n⏱️ Temps total : **${durationStr}**\n📅 Début : <t:${Math.floor(result.startTime / 1000)}:t> | Fin : <t:${Math.floor(result.endTime / 1000)}:t>`,
        color: config.colors.danger
      });

      await interaction.reply({ embeds: [embed] });
    }
  },

  // 8. /service-stats
  {
    data: new SlashCommandBuilder()
      .setName('service-stats')
      .setDescription('Afficher vos statistiques ou celles d\'un agent.')
      .addUserOption(option => option.setName('membre').setDescription('Agent à consulter')),
    async execute(interaction) {
      const targetUser = interaction.options.getUser('membre') || interaction.user;
      const data = await db.getServiceStats(targetUser.id);

      const totalMins = data.stats ? data.stats.totalMinutes : 0;
      const shiftCount = data.stats ? data.stats.shiftCount : 0;
      const hours = Math.floor(totalMins / 60);
      const mins = totalMins % 60;

      const embed = createEmbed({
        title: `📊 Statistiques de Service • ${targetUser.username}`,
        description: `⏱️ **Temps Total Cumulé** : **${hours}h ${mins}min**\n🚓 **Services Effectués** : **${shiftCount}**`,
        color: config.colors.primary,
        thumbnail: targetUser.displayAvatarURL({ dynamic: true })
      });

      await interaction.reply({ embeds: [embed] });
    }
  },

  // 9. /service-leaderboard
  {
    data: new SlashCommandBuilder()
      .setName('service-leaderboard')
      .setDescription('Classement des agents les plus actifs du serveur.'),
    async execute(interaction) {
      const leaderboard = await db.getServiceLeaderboard(10);
      if (!leaderboard || leaderboard.length === 0) {
        return interaction.reply({ content: 'Aucune donnée de service enregistrée pour le moment.', ephemeral: true });
      }

      let desc = '';
      for (let i = 0; i < leaderboard.length; i++) {
        const item = leaderboard[i];
        const user = await interaction.client.users.fetch(item.userId).catch(() => null);
        const userName = user ? user.tag : `Utilisateur (${item.userId})`;
        const hours = Math.floor(item.totalMinutes / 60);
        const mins = item.totalMinutes % 60;

        const medal = i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : '🔹';
        desc += `${medal} **#${i + 1}** ${userName} — **${hours}h ${mins}m** (${item.shiftCount} services)\n`;
      }

      const embed = createEmbed({
        title: '🏆 CLASSEMENT DES MEILLEURS AGENTS',
        description: desc,
        color: config.colors.gold
      });

      await interaction.reply({ embeds: [embed] });
    }
  },

  // 10. /patrouille-creer
  {
    data: new SlashCommandBuilder()
      .setName('patrouille-creer')
      .setDescription('Former une nouvelle unité de patrouille.')
      .addStringOption(opt => opt.setName('nom').setDescription('Nom de l\'unité (ex: Adam-1)').setRequired(true))
      .addStringOption(opt => opt.setName('vehicule').setDescription('Véhicule utilisé (ex: Audi RS6 Polizei)').setRequired(true)),
    async execute(interaction) {
      const name = interaction.options.getString('nom');
      const vehicle = interaction.options.getString('vehicule');
      await db.createPatrol(name, vehicle, interaction.user.id);

      const embed = createEmbed({
        title: `🚘 NOUVELLE PATROUILLE : ${name.toUpperCase()}`,
        description: `L'unité **${name}** a été créée par <@${interaction.user.id}>.\n\n🚔 **Véhicule** : ${vehicle}\n👥 **Chef** : <@${interaction.user.id}>`,
        color: config.colors.police
      });

      await interaction.reply({ embeds: [embed] });
    }
  },

  // 11. /patrouille-liste
  {
    data: new SlashCommandBuilder()
      .setName('patrouille-liste')
      .setDescription('Afficher la liste des unités de patrouille en cours.'),
    async execute(interaction) {
      const patrols = await db.getActivePatrols();
      if (!patrols || patrols.length === 0) {
        return interaction.reply({ content: 'Aucune patrouille active actuellement à Hamburg.', ephemeral: true });
      }

      let desc = '';
      for (const p of patrols) {
        const members = JSON.parse(p.members || '[]');
        const membersMentions = members.map(m => `<@${m}>`).join(', ');
        desc += `🔹 **${p.name}** | 🚘 ${p.vehicle} | Chef: <@${p.leaderId}>\n👥 **Équipage** : ${membersMentions}\n\n`;
      }

      const embed = createEmbed({
        title: '🚓 UNITES DE PATROUILLE ACTIVES EN VILLE',
        description: desc,
        color: config.colors.police
      });

      await interaction.reply({ embeds: [embed] });
    }
  }
];
