const { SlashCommandBuilder, PermissionFlagsBits, ChannelType, MessageFlags } = require('discord.js');
const { createEmbed, verificationPanelEmbed, welcomeEmbed, leaveEmbed } = require('../utils/embeds');
const db = require('../database/db');
const config = require('../../config.json');

module.exports = [
  // 1. /verification
  {
    data: new SlashCommandBuilder()
      .setName('verification')
      .setDescription('Gestion et configuration du système de vérification et d\'accueil.')
      .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
      .addSubcommand(sub =>
        sub.setName('panneau')
           .setDescription('Envoie le panneau interactif de vérification dans le salon actuel.')
      )
      .addSubcommand(sub =>
        sub.setName('roles')
           .setDescription('Configure le rôle Non-Vérifié (à l\'arrivée) et le rôle Membre (après vérification).')
           .addRoleOption(opt => opt.setName('unverified').setDescription('Rôle attribué à l\'arrivée (accès restreint)').setRequired(true))
           .addRoleOption(opt => opt.setName('membre').setDescription('Rôle attribué une fois la vérification réussie').setRequired(true))
      )
      .addSubcommand(sub =>
        sub.setName('salons')
           .setDescription('Configure les salons de bienvenue, départ et logs de sécurité.')
           .addChannelOption(opt => opt.setName('bienvenue').setDescription('Salon des arrivées').addChannelTypes(ChannelType.GuildText).setRequired(false))
           .addChannelOption(opt => opt.setName('depart').setDescription('Salon des départs').addChannelTypes(ChannelType.GuildText).setRequired(false))
           .addChannelOption(opt => opt.setName('logs-securite').setDescription('Salon des logs de sécurité').addChannelTypes(ChannelType.GuildText).setRequired(false))
      )
      .addSubcommand(sub =>
        sub.setName('config')
           .setDescription('Affiche la configuration actuelle du système de vérification.')
      )
      .addSubcommand(sub =>
        sub.setName('test-arrivee')
           .setDescription('Simule un message de bienvenue.')
      )
      .addSubcommand(sub =>
        sub.setName('test-depart')
           .setDescription('Simule un message de départ.')
      ),

    async execute(interaction) {
      const subcommand = interaction.options.getSubcommand();
      const { guild, channel } = interaction;

      // Subcommand 1: panneau
      if (subcommand === 'panneau') {
        const payload = verificationPanelEmbed();
        await channel.send(payload);

        // Update DB verify channel
        await db.updateWelcomeConfig(guild.id, { verifyChannelId: channel.id });

        return interaction.reply({
          content: `✅ **Panneau de vérification publié dans ${channel} !** Ce salon a été configuré comme salon officiel de vérification.`,
          flags: MessageFlags.Ephemeral
        });
      }

      // Subcommand 2: roles
      if (subcommand === 'roles') {
        const unverifiedRole = interaction.options.getRole('unverified');
        const membreRole = interaction.options.getRole('membre');

        await db.updateWelcomeConfig(guild.id, {
          unverifiedRoleId: unverifiedRole.id,
          verifiedRoleId: membreRole.id
        });

        const embed = createEmbed({
          title: '⚙️ CONFIGURATION DES RÔLES MISE À JOUR',
          description: `Les rôles du système de vérification ont été configurés :\n\n` +
            `🔒 **Rôle Non-Vérifié (Unverified)** : ${unverifiedRole} (\`${unverifiedRole.id}\`)\n` +
            `✅ **Rôle Membre (Vérifié)** : ${membreRole} (\`${membreRole.id}\`)`,
          color: config.colors.success
        });

        return interaction.reply({ embeds: [embed] });
      }

      // Subcommand 3: salons
      if (subcommand === 'salons') {
        const welcomeChannel = interaction.options.getChannel('bienvenue');
        const leaveChannel = interaction.options.getChannel('depart');
        const logsChannel = interaction.options.getChannel('logs-securite');

        const updates = {};
        if (welcomeChannel) updates.welcomeChannelId = welcomeChannel.id;
        if (leaveChannel) updates.leaveChannelId = leaveChannel.id;
        if (logsChannel) updates.securityLogChannelId = logsChannel.id;

        if (Object.keys(updates).length === 0) {
          return interaction.reply({
            content: '⚠️ Veuillez préciser au moins un salon à configurer.',
            flags: MessageFlags.Ephemeral
          });
        }

        await db.updateWelcomeConfig(guild.id, updates);

        const embed = createEmbed({
          title: '⚙️ CONFIGURATION DES SALONS MISE À JOUR',
          description: `Les salons du système ont été enregistrés :\n\n` +
            `🎉 **Salon Bienvenue** : ${welcomeChannel ? welcomeChannel : 'Non modifié'}\n` +
            `👋 **Salon Départ** : ${leaveChannel ? leaveChannel : 'Non modifié'}\n` +
            `🛡️ **Logs Sécurité** : ${logsChannel ? logsChannel : 'Non modifié'}`,
          color: config.colors.success
        });

        return interaction.reply({ embeds: [embed] });
      }

      // Subcommand 4: config
      if (subcommand === 'config') {
        const current = await db.getWelcomeConfig(guild.id);

        const welcomeCh = current?.welcomeChannelId ? guild.channels.cache.get(current.welcomeChannelId) : 'Non configuré';
        const leaveCh = current?.leaveChannelId ? guild.channels.cache.get(current.leaveChannelId) : 'Non configuré';
        const verifyCh = current?.verifyChannelId ? guild.channels.cache.get(current.verifyChannelId) : 'Non configuré';
        const logsCh = current?.securityLogChannelId ? guild.channels.cache.get(current.securityLogChannelId) : 'Non configuré';

        const unverifiedR = current?.unverifiedRoleId ? guild.roles.cache.get(current.unverifiedRoleId) : 'Non configuré';
        const verifiedR = current?.verifiedRoleId ? guild.roles.cache.get(current.verifiedRoleId) : 'Non configuré';

        const embed = createEmbed({
          title: `🛡️ CONFIGURATION DE VÉRIFICATION • ${guild.name}`,
          description: `Voici le paramétrage actuel du système d'arrivée, départ et vérification :\n\n` +
            `📌 **SALONS :**\n` +
            `• **Vérification** : ${verifyCh}\n` +
            `• **Bienvenue** : ${welcomeCh}\n` +
            `• **Départ** : ${leaveCh}\n` +
            `• **Logs Sécurité** : ${logsCh}\n\n` +
            `📌 **RÔLES :**\n` +
            `• **Non-Vérifié (Unverified)** : ${unverifiedR}\n` +
            `• **Membre (Verified)** : ${verifiedR}\n\n` +
            `📌 **SÉCURITÉ ANTI-ALT :**\n` +
            `• **Âge minimum du compte Discord** : \`${current?.minAccountAgeDays || 7} jours\`\n` +
            `• **Détection Double Compte Roblox** : \`Activée (Vérification SQLite Database)\``,
          color: config.colors.primary
        });

        return interaction.reply({ embeds: [embed] });
      }

      // Subcommand 5: test-arrivee
      if (subcommand === 'test-arrivee') {
        const current = await db.getWelcomeConfig(guild.id);
        const welcomeChannelId = current?.welcomeChannelId || config.channels?.welcome;
        const targetChannel = welcomeChannelId ? guild.channels.cache.get(welcomeChannelId) : channel;

        const fakeRoblox = {
          id: '1567113',
          name: 'BuildermanTest',
          displayName: 'Builderman (Test)',
          avatarUrl: 'https://i.imgur.com/8QG4m3b.png'
        };

        const embed = welcomeEmbed(interaction.member, guild.memberCount, fakeRoblox);
        await targetChannel.send({ content: `🎉 [TEST] Bienvenue à ${interaction.member} !`, embeds: [embed] });

        return interaction.reply({
          content: `✅ Test d'arrivée envoyé dans ${targetChannel} !`,
          flags: MessageFlags.Ephemeral
        });
      }

      // Subcommand 6: test-depart
      if (subcommand === 'test-depart') {
        const current = await db.getWelcomeConfig(guild.id);
        const leaveChannelId = current?.leaveChannelId || config.channels?.leave;
        const targetChannel = leaveChannelId ? guild.channels.cache.get(leaveChannelId) : channel;

        const embed = leaveEmbed(interaction.member, guild.memberCount - 1);
        await targetChannel.send({ embeds: [embed] });

        return interaction.reply({
          content: `✅ Test de départ envoyé dans ${targetChannel} !`,
          flags: MessageFlags.Ephemeral
        });
      }
    }
  }
];
