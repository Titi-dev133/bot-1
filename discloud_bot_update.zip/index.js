const fs = require('fs');
const path = require('path');

console.log("🔍 [Wispbyte Auto-Finder] Recherche automatique du dossier src/index.js...");

function findSrcIndex(dirPath, depth = 0) {
  if (depth > 4) return null;
  try {
    const entries = fs.readdirSync(dirPath, { withFileTypes: true });
    for (const entry of entries) {
      const fullPath = path.join(dirPath, entry.name);
      if (entry.isDirectory() && !entry.name.startsWith('.') && entry.name !== 'node_modules') {
        if (entry.name.toLowerCase() === 'src') {
          const target = path.join(fullPath, 'index.js');
          if (fs.existsSync(target)) return target;
        }
        const sub = findSrcIndex(fullPath, depth + 1);
        if (sub) return sub;
      }
    }
  } catch (err) { }
  return null;
}

// 1. Check direct
const rootSrc = path.join(__dirname, 'src', 'index.js');
let targetFile = fs.existsSync(rootSrc) ? rootSrc : findSrcIndex(__dirname);

if (targetFile) {
  console.log(`✅ [Wispbyte Auto-Finder] Fichier chargé avec succès depuis : ${targetFile}`);
  require(targetFile);
} else {
  console.error("❌ [Wispbyte Auto-Finder] Impossible de trouver src/index.js.");
  console.error("📂 Fichiers et dossiers présents dans /home/container/ :");
  try {
    console.log(fs.readdirSync(__dirname));
  } catch (e) { }
}
