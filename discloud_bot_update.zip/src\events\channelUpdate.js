const { EmbedBuilder, AuditLogEvent } = require('discord.js');
const { sendAuditLog } = require('../utils/auditLogger');

module.exports = {
  name: 'channelUpdate',
  async execute(oldChannel, newChannel) {
    try {
      if (!newChannel.guild) return;

      const changes = [];
      if (oldChannel.name !== newChannel.name) {
        changes.push(`• **Nom** : \`#${oldChannel.name}\` ➔ \`#${newChannel.name}\``);
      }
      if (oldChannel.topic !== newChannel.topic) {
        changes.push(`• **Sujet / Topic** : \`${oldChannel.topic || 'Aucun'}\` ➔ \`${newChannel.topic || 'Aucun'}\``);
      }
      if (oldChannel.nsfw !== newChannel.nsfw) {
        changes.push(`• **NSFW** : \`${oldChannel.nsfw ? 'Oui' : 'Non'}\` ➔ \`${newChannel.nsfw ? 'Oui' : 'Non'}\``);
      }

      if (changes.length === 0) return;

      const embed = new EmbedBuilder()
        .setTitle('📺 LOG AUDIT : MODIFICATION D\'UN SALON')
        .setColor('#FB8C00')
        .addFields(
          { name: '📍 Salon', value: `${newChannel} (\`#${newChannel.name}\` | \`ID: ${newChannel.id}\`)`, inline: false },
          { name: '📝 Modifications', value: changes.join('\n'), inline: false }
        )
        .setFooter({ text: `Channel ID: ${newChannel.id} • Hamburg RP` })
        .setTimestamp();

      try {
        const fetchedLogs = await newChannel.guild.fetchAuditLogs({
          limit: 1,
          type: AuditLogEvent.ChannelUpdate,
        });
        const auditEntry = fetchedLogs.entries.first();
        if (auditEntry && auditEntry.target.id === newChannel.id && (Date.now() - auditEntry.createdTimestamp) < 5000) {
          embed.addFields({ name: '👮 Modifié par', value: `<@${auditEntry.executor.id}> (\`${auditEntry.executor.tag}\`)`, inline: false });
        }
      } catch (e) {}

      await sendAuditLog(newChannel.guild, embed);
    } catch (error) {
      console.error('❌ Erreur dans l\'événement channelUpdate:', error);
    }
  }
};
