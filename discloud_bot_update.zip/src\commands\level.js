const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder, MessageFlags } = require('discord.js');
const db = require('../database/db');
const { createEmbed } = require('../utils/embeds');
const { createXpLeaderboardEmbed } = require('../utils/xpDashboardScheduler');
const config = require('../../config.json');

function generateProgressBar(current, max, length = 10) {
  const percentage = Math.min(1, Math.max(0, current / max));
  const filledLength = Math.round(length * percentage);
  const emptyLength = length - filledLength;
  return '█'.repeat(filledLength) + '░'.repeat(emptyLength);
}

module.exports = [
  // 1. /dashboard-levels (Déploie le Tableau de Statistiques permanent mis à jour toutes les 5 min)
  {
    data: new SlashCommandBuilder()
      .setName('dashboard-levels')
      .setDescription('Déployer le Tableau de Statistiques & Niveaux (Mise à jour automatique 5 min).')
      .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
    async execute(interaction) {
      await interaction.reply({ content: '🚀 **Installation du Tableau de Statistiques & Niveaux XP...**', flags: MessageFlags.Ephemeral });
      const embed = await createXpLeaderboardEmbed(interaction.guild);
      const msg = await interaction.channel.send({ embeds: [embed] });
      await db.saveXpDashboardRecord(interaction.guild.id, interaction.channel.id, msg.id);
    }
  },

  // 2. /rank (Consulter son niveau ou celui d'un membre)
  {
    data: new SlashCommandBuilder()
      .setName('rank')
      .setDescription('Consulter votre niveau, votre XP et votre progression (Confidentiel).')
      .addUserOption(opt => opt.setName('membre').setDescription('Le membre à consulter (optionnel)').setRequired(false)),
    async execute(interaction) {
      const targetUser = interaction.options.getUser('membre') || interaction.user;
      const levelInfo = await db.getUserLevelInfo(targetUser.id);
      const topList = await db.getTopXPLeaderboard(100);

      const rankIndex = topList.findIndex(u => u.userId === targetUser.id);
      const rankStr = rankIndex !== -1 ? `#${rankIndex + 1}` : 'Non classé';

      const progressBar = generateProgressBar(levelInfo.xp, levelInfo.nextLevelXP, 10);

      const embed = createEmbed({
        title: `⭐ PROFIL DE NIVEAU • ${targetUser.username}`,
        description:
          `🎖️ **Niveau Actuel** : \`Niveau ${levelInfo.level || 1}\`\n` +
          `🏆 **Rang Classement** : \`${rankStr}\`\n` +
          `💬 **Messages Envoyés** : \`${levelInfo.messageCount || 0} msgs\`\n\n` +
          `📊 **Progression XP** : \`${levelInfo.xp} / ${levelInfo.nextLevelXP} XP\`\n` +
          `[ **${progressBar}** ]\n\n` +
          `📌 *Gagnez de l'XP en discutant activement dans les salons du serveur !*`,
        color: '#9C27B0',
        thumbnail: targetUser.displayAvatarURL({ dynamic: true })
      });

      await interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
    }
  },

  // 3. /top-xp (Afficher le Top 10 du serveur)
  {
    data: new SlashCommandBuilder()
      .setName('top-xp')
      .setDescription('Afficher le Classement Top 10 des membres les plus actifs (Confidentiel).'),
    async execute(interaction) {
      const embed = await createXpLeaderboardEmbed(interaction.guild);
      await interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
    }
  }
];
