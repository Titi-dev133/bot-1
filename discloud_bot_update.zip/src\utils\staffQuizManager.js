const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, MessageFlags, ChannelType } = require('discord.js');

const db = require('../database/db');
const { sendAuditLog } = require('./auditLogger');
const { staffCandidateCardEmbed } = require('./embeds');

// Map globale des sessions de quiz actives dans Discord (userId -> session)
const activeDiscordQuizzes = new Map();

// 20 Questions pour l'Examen Staff Hamburg RP
const QUIZ_QUESTIONS = [
  { id: 1, title: 'Identité RP / Pseudo Roblox / Âge', prompt: 'Présentez votre pseudo Roblox, votre prénom/pseudo RP et votre âge.' },
  { id: 2, title: 'Disponibilités & Heures de jeu', prompt: 'Quelles sont vos disponibilités par semaine pour modérer sur Aubagne RP Officiel ?' },
  { id: 3, title: 'Motivations', prompt: 'Pourquoi souhaitez-vous intégrer l\'équipe Staff d\'Aubagne RP Officiel ?' },

  { id: 4, title: '3 Qualités & 3 Défauts', prompt: 'Citez vos 3 principales qualités et 3 défauts en tant que modérateur RP.' },
  { id: 5, title: 'Expériences passées', prompt: 'Avez-vous déjà été staff sur d\'autres serveurs Roblox ou Discord ? Précisez.' },
  { id: 6, title: 'Cas 1 - Mass RDM & Freekill au Spawn', prompt: 'Un joueur tue 5 personnes en masse au spawn Polizei. Quelle est votre procédure exacte ?' },
  { id: 7, title: 'Cas 2 - Insultes HRP & Trolling Staff en Ticket', prompt: 'Un joueur vous insulte violemment et troll dans un ticket support. Comment réagissez-vous ?' },
  { id: 8, title: 'Cas 3 - Refus d\'arrêter & Combat Log face Polizei', prompt: 'Un citoyen refuse de s\'arrêter puis se déconnecte (Combat Log) lors d\'une arrestation. Sanction ?' },
  { id: 9, title: 'Cas 4 - NoPainRP & Conduite HRP sur Voie Ferrée', prompt: 'Un suspect roule à 200 km/h sur les rails de train après un accident grave sans jouer son PainRP. Sanction ?' },
  { id: 10, title: 'Cas 5 - Non-respect du FearRP', prompt: 'Un joueur s\'enfuit à pied alors que 3 policiers le braquent à bout portant avec des armes lourdes. Sanction ?' },
  { id: 11, title: 'Cas 6 - Streamhack & Usurpation RP', prompt: 'Un joueur suit le stream d\'un administrateur pour le tuer en jeu et usurper son identité. Sanction ?' },
  { id: 12, title: 'Cas 7 - Abus de Pouvoir d\'un Modérateur', prompt: 'Que faites-vous si vous vous apercevez qu\'un autre modérateur fait du favoritisme à ses amis ?' },
  { id: 13, title: 'Cas 8 - Metagaming via Vocal Discord', prompt: 'Deux joueurs s\'échangent des infos en vocal Discord privé pour éviter une patrouille. Sanction ?' },
  { id: 14, title: 'Cas 9 - Non-respect des règles de Braquage & NLR', prompt: 'Un citoyen braque la banque seul sans annonce et revient sur les lieux 2 min après sa mort. Sanctions ?' },
  { id: 15, title: 'Cas 10 - Menaces de Dox & Harcèlement', prompt: 'Un joueur menace de divulguer l\'adresse IP d\'un membre de la communauté. Quelle décision immédiate prenez-vous ?' },
  { id: 16, title: 'Procédure complète de Warn', prompt: 'Expliquez étape par étape la procédure pour avertir (warn) un joueur sur le serveur.' },
  { id: 17, title: 'Hiérarchie des Sanctions (Mute/Kick/Ban)', prompt: 'Définissez la différence entre un Mute, un Kick, un Tempban et un Perma ban.' },
  { id: 18, title: 'Contestation de Sanction en Ticket', prompt: 'Comment gérez-vous un joueur enragé qui conteste un ban avec mauvaise foi ?' },
  { id: 19, title: 'Erreur de Modération', prompt: 'Si vous vous rendez compte que vous avez sanctionné la mauvaise personne par erreur, que faites-vous ?' },
  { id: 20, title: 'Message final & Engagement', prompt: 'Dernier mot pour convaincre l\'Administration de valider votre candidature Staff.' }
];

/**
 * Démarre le test de recrutement Staff 100% par réponse directe dans le Chat Discord
 */
async function startDiscordStaffQuiz({ interaction, user, channel, guild }) {
  if (activeDiscordQuizzes.has(user.id)) {
    return interaction.reply({
      content: '❌ Un test de recrutement est déjà en cours dans ce salon ! Répondez directement dans le chat.',
      flags: MessageFlags.Ephemeral
    });
  }

  const session = {
    userId: user.id,
    userTag: user.tag || user.username,
    guildId: guild.id,
    channelId: channel.id,
    currentIndex: 0,
    answers: {},
    timer: null,
    currentMsg: null,
    messagesToDelete: [],
    startTime: Date.now()
  };

  activeDiscordQuizzes.set(user.id, session);

  await interaction.reply({
    content: `🟢 **Lancement de l'Examen Staff Aubagne RP Officiel (20 Questions) !**\nVous écrirez vos réponses **directement dans ce salon chat** comme une conversation normale. Vous avez **15 secondes par question**.\n\nLe test démarre ci-dessous dans 3 secondes...`
  });


  const initMsg = await interaction.fetchReply().catch(() => null);
  if (initMsg) session.messagesToDelete.push(initMsg);


  setTimeout(() => {
    sendNextQuestion({ guild, user, channel });
  }, 3000);
}

/**
 * Envoie la question suivante dans le salon chat
 */
async function sendNextQuestion({ guild, user, channel }) {
  const session = activeDiscordQuizzes.get(user.id);
  if (!session) return;

  if (session.timer) {
    clearTimeout(session.timer);
    session.timer = null;
  }

  const index = session.currentIndex;

  if (index >= QUIZ_QUESTIONS.length) {
    return finishDiscordStaffQuiz({ guild, user, channel });
  }

  const q = QUIZ_QUESTIONS[index];

  const embed = new EmbedBuilder()
    .setTitle(`📋 EXAMEN STAFF AUBAGNE RP OFFICIEL • QUESTION ${q.id} / 20`)

    .setDescription(
      `**${q.title}**\n\n` +
      `📌 **Question :** ${q.prompt}\n\n` +
      `⏱️ **Temps imparti : 15 secondes !**\n` +
      `💬 *Tapez directement votre réponse ci-dessous dans le chat et appuyez sur Entrée.*`
    )
    .setColor('#3B82F6')
    .setFooter({ text: `Question ${q.id}/20 • Candidat : ${session.userTag}` })
    .setTimestamp();

  try {
    const msg = await channel.send({
      content: `<@${user.id}> ❓ **Question ${q.id}/20** (15 secondes restantes) :`,
      embeds: [embed]
    });

    session.currentMsg = msg;
    session.messagesToDelete.push(msg);

    // Timer de 15 secondes pour cette question
    session.timer = setTimeout(async () => {
      session.answers[`sq_${q.id}`] = '❌ Pas de réponse (Temps de 15s écoulé)';

      try {
        const timeoutEmbed = new EmbedBuilder()
          .setTitle(`⏰ TEMPS ÉCOULÉ (15s) • QUESTION ${q.id} / 20`)
          .setDescription(`**${q.title}**\n\n❌ *Vous n'avez pas répondu dans les 15 secondes. Question sautée.*`)
          .setColor('#EF4444');

        await msg.edit({ content: `<@${user.id}> ⏰ **Temps écoulé pour la Question ${q.id} !**`, embeds: [timeoutEmbed] }).catch(() => {});
      } catch (e) {}

      session.currentIndex += 1;
      sendNextQuestion({ guild, user, channel });
    }, 15000);
  } catch (err) {
    console.error('Erreur envoi question quiz Discord:', err);
  }
}

/**
 * Traite les réponses envoyées DIRECTEMENT DANS LE CHAT DISCORD
 */
async function handleQuizChatMessage(message) {
  if (!message || message.author.bot) return false;

  const session = activeDiscordQuizzes.get(message.author.id);
  if (!session || message.channel.id !== session.channelId) return false;

  const qIndex = session.currentIndex;
  if (qIndex >= QUIZ_QUESTIONS.length) return false;

  const q = QUIZ_QUESTIONS[qIndex];
  const answerText = message.content.trim();

  if (!answerText) return false;

  // Enregistrer le message de réponse du membre pour le supprimer à la fin
  session.messagesToDelete.push(message);

  // Enregistrer la réponse
  session.answers[`sq_${q.id}`] = answerText;

  // Annuler le timer de 15s
  if (session.timer) {
    clearTimeout(session.timer);
    session.timer = null;
  }

  // Ajouter une réaction de validation rapide
  await message.react('✅').catch(() => {});

  session.currentIndex += 1;

  setTimeout(() => {
    sendNextQuestion({ guild: message.guild, user: message.author, channel: message.channel });
  }, 1000);

  return true;
}

/**
 * Finalise l'examen 20 questions dans Discord, nettoie le salon et envoie les résultats
 */
async function finishDiscordStaffQuiz({ guild, user, channel }) {
  const session = activeDiscordQuizzes.get(user.id);
  if (!session) return;

  if (session.timer) {
    clearTimeout(session.timer);
    session.timer = null;
  }

  activeDiscordQuizzes.delete(user.id);

  const answers = session.answers;

  // Calcul du score d'Auto-Correction (sur 20)
  let score = 0;
  QUIZ_QUESTIONS.forEach(q => {
    const ans = answers[`sq_${q.id}`] || '';
    if (ans && !ans.includes('Pas de réponse (Temps de 15s écoulé)') && ans.length >= 3) {
      score += 1;
    }
  });

  // Enregistrement dans la DB SQLite
  const testId = await db.createStaffTestRecord({
    guildId: guild.id,
    userId: user.id,
    userTag: user.tag || user.username,
    robloxUsername: answers['sq_1'] || user.username,
    age: 0,
    availability: answers['sq_2'] || 'N/A',
    experience: answers['sq_5'] || 'N/A',
    case1: answers['sq_6'] || 'N/A',
    case2: answers['sq_7'] || 'N/A',
    case3: answers['sq_8'] || 'N/A',
    answersJson: answers
  });

  const testData = await db.getStaffTestRecord(testId);

  // 1. Publication de la copie finale dans le salon ticket du candidat
  const embeds = [];
  let currentEmbed = new EmbedBuilder()
    .setTitle(`🎉 COPIE D'EXAMEN STAFF TERMINÉ (20 QUESTIONS) • CANDIDATURE #${testId}`)
    .setDescription(
      `Félicitations <@${user.id}> ! Vous avez répondu aux 20 questions de l'examen.\n\n` +
      `📊 **Note d'Auto-Correction :** \`${score} / 20\` ${score >= 12 ? '✅ (Score Validé)' : '⚠️ (Score Inférieur)'}\n` +
      `Voici votre copie complète transmise à la Haute-Direction :`
    )
    .setColor(score >= 12 ? '#10B981' : '#F59E0B')
    .setTimestamp();

  QUIZ_QUESTIONS.forEach(q => {
    let ans = answers[`sq_${q.id}`] || 'N/A';
    if (ans.length > 900) ans = ans.substring(0, 900) + '...';

    if (currentEmbed.data.fields && currentEmbed.data.fields.length >= 5) {
      embeds.push(currentEmbed);
      currentEmbed = new EmbedBuilder()
        .setTitle(`📋 SUITE DES RÉPONSES (Q${q.id} à Q20)`)
        .setColor(score >= 12 ? '#10B981' : '#F59E0B');
    }

    currentEmbed.addFields({
      name: `Q${q.id}: ${q.title}`,
      value: ans,
      inline: false
    });
  });

  embeds.push(currentEmbed);

  for (let i = 0; i < embeds.length; i++) {
    const isLast = i === embeds.length - 1;
    const components = isLast ? [
      new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId(`btn_staff_quiz_accept_${testId}`)
          .setLabel('Accepter Candidature')
          .setEmoji('🟢')
          .setStyle(ButtonStyle.Success),
        new ButtonBuilder()
          .setCustomId(`btn_staff_quiz_reject_${testId}`)
          .setLabel('Refuser Candidature')
          .setEmoji('🔴')
          .setStyle(ButtonStyle.Danger),
        new ButtonBuilder()
          .setCustomId(`btn_staff_quiz_interview_${testId}`)
          .setLabel('Convoquer Oral')
          .setEmoji('🎤')
          .setStyle(ButtonStyle.Primary)
      )
    ] : [];

    await channel.send({ embeds: [embeds[i]], components }).catch(err => console.error('Erreur envoi copie ticket embed:', err));
  }


  // 2. SUPPRESSION AUTOMATIQUE DE TOUTES LES QUESTIONS ET RÉPONSES INTERMÉDIAIRES
  if (channel && session.messagesToDelete && session.messagesToDelete.length > 0) {
    try {
      await channel.bulkDelete(session.messagesToDelete).catch(async () => {
        for (const msg of session.messagesToDelete) {
          await msg.delete().catch(() => {});
        }
      });
    } catch (e) {
      console.error('Erreur lors de la suppression des messages intermédiaires du quiz:', e);
    }
  }



  // Audit Log
  const auditEmbed = {
    title: '🟢 LOG AUDIT : NOUVEL EXAMEN STAFF SOUMIS DANS CHAT DISCORD',
    color: '#10B981',
    fields: [
      { name: '👤 Candidat', value: `<@${user.id}> (\`${user.tag || user.username}\`)`, inline: true },
      { name: '📊 Note obtenue', value: `\`${score} / 20\``, inline: true },
      { name: '🆔 Candidature ID', value: `\`#${testId}\``, inline: true }
    ],
    timestamp: new Date()
  };
  await sendAuditLog(guild, auditEmbed);
}

module.exports = {
  startDiscordStaffQuiz,
  handleQuizChatMessage
};
