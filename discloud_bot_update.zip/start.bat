@echo off
echo ==============================================
echo   Demarrage du Bot Discord Emergency Hamburg RP
echo ==============================================
npm start
pause
npm start
npm start
