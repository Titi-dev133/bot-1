const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const db = require('../database/db');
const { createEmbed } = require('../utils/embeds');
const { createPoliceDashboard } = require('../utils/dashboards');
const config = require('../../config.json');

module.exports = [
  // 1. /wanted
  {
    data: new SlashCommandBuilder()
      .setName('wanted')
      .setDescription('Placer un suspect ou citoyen en avis de recherche.')
      .addStringOption(opt => opt.setName('citoyen').setDescription('Nom RP ou mention Discord du criminel').setRequired(true))
      .addStringOption(opt => opt.setName('motif').setDescription('Motif de l\'avis de recherche').setRequired(true))
      .addIntegerOption(opt =>
        opt.setName('danger')
          .setDescription('Niveau de danger (1 = Faible, 5 = Extrêmement Dangereux / Armé)')
          .setRequired(true)
          .setMinValue(1)
          .setMaxValue(5)
      )
      .addIntegerOption(opt => opt.setName('amende').setDescription('Montant de la prime ou amende').setRequired(false)),
    async execute(interaction) {
      const targetName = interaction.options.getString('citoyen');
      const reason = interaction.options.getString('motif');
      const danger = interaction.options.getInteger('danger');
      const bounty = interaction.options.getInteger('amende') || 0;

      const stars = '⭐'.repeat(danger);
      await db.addWanted(targetName, null, reason, danger, bounty, interaction.user.id);

      const embed = createEmbed({
        title: '🚨 POLIZEI HAMBURG • AVIS DE RECHERCHE (WANTED)',
        description: `Un avis de recherche a été émis par l'officier <@${interaction.user.id}>.\n\n` +
          `👤 **Individu Recherché** : **${targetName}**\n` +
          `⚠️ **Niveau de Danger** : ${stars} (${danger}/5)\n` +
          `📝 **Motif** : ${reason}\n` +
          `💰 **Prime / Amende associée** : ${bounty > 0 ? `${bounty} ${config.currencySymbol}` : 'Non spécifié'}`,
        color: config.colors.danger,
        thumbnail: 'https://i.imgur.com/2X8K7lZ.png'
      });

      await interaction.reply({ embeds: [embed] });
    }
  },

  // 2. /unwanted
  {
    data: new SlashCommandBuilder()
      .setName('unwanted')
      .setDescription('Retirer un individu de la liste des avis de recherche.')
      .addStringOption(opt => opt.setName('citoyen').setDescription('Nom du criminel à retirer').setRequired(true)),
    async execute(interaction) {
      const targetName = interaction.options.getString('citoyen');
      const success = await db.removeWanted(targetName);

      if (!success) {
        return interaction.reply({
          content: `❌ Aucun avis de recherche actif trouvé pour **${targetName}**.`,
          ephemeral: true
        });
      }

      const embed = createEmbed({
        title: '✅ POLIZEI HAMBURG • AVIS DE RECHERCHE CLÔTURÉ',
        description: `L'individu **${targetName}** n'est plus recherché par les forces de l'ordre.\n*Dossier clôturé par l'officier <@${interaction.user.id}>.*`,
        color: config.colors.success
      });

      await interaction.reply({ embeds: [embed] });
    }
  },

  // 3. /wanted-liste
  {
    data: new SlashCommandBuilder()
      .setName('wanted-liste')
      .setDescription('Consulter la liste en temps réel des individus recherchés.'),
    async execute(interaction) {
      const list = await db.getWantedList();
      if (!list || list.length === 0) {
        return interaction.reply({
          embeds: [createEmbed({
            title: '📜 POLIZEI HAMBURG • INDIVIDUS RECHERCHÉS',
            description: '✅ Aucun avis de recherche actif actuellement à Hamburg. La ville est calme !',
            color: config.colors.success
          })]
        });
      }

      let desc = '';
      for (const w of list) {
        const stars = '⭐'.repeat(w.dangerLevel);
        desc += `🔴 **${w.targetName}** (${stars})\n📝 *Motif* : ${w.reason} | 💰 Prime : ${w.fineAmount} ${config.currencySymbol}\n👮 Officer : <@${w.officerId}> — <t:${Math.floor(w.createdAt / 1000)}:R>\n\n`;
      }

      const embed = createEmbed({
        title: '🚨 POLIZEI HAMBURG • LISTE DES RECHERCHÉS (WANTED LIST)',
        description: desc,
        color: config.colors.danger
      });

      await interaction.reply({ embeds: [embed] });
    }
  },

  // 4. /amende
  {
    data: new SlashCommandBuilder()
      .setName('amende')
      .setDescription('Délivrer une contravention RP à un citoyen.')
      .addStringOption(opt => opt.setName('citoyen').setDescription('Nom RP ou mention Discord').setRequired(true))
      .addIntegerOption(opt => opt.setName('montant').setDescription('Montant de l\'amende (€)').setRequired(true))
      .addStringOption(opt => opt.setName('motif').setDescription('Motif de l\'amende').setRequired(true)),
    async execute(interaction) {
      const targetName = interaction.options.getString('citoyen');
      const amount = interaction.options.getInteger('montant');
      const reason = interaction.options.getString('motif');

      await db.addFine(targetName, null, amount, reason, interaction.user.id);

      const embed = createEmbed({
        title: '📜 CONTRAVENTION POLICE HAMBURG',
        description: `Une amende administrative a été délivrée par <@${interaction.user.id}>.\n\n` +
          `👤 **Destinataire** : **${targetName}**\n` +
          `💵 **Montant à payer** : **${amount} ${config.currencySymbol}**\n` +
          `📝 **Motif** : ${reason}`,
        color: config.colors.warning
      });

      await interaction.reply({ embeds: [embed] });
    }
  },

  // 5. /casier
  {
    data: new SlashCommandBuilder()
      .setName('casier')
      .setDescription('Consulter l\'historique judiciaire et contraventions d\'un citoyen.')
      .addStringOption(opt => opt.setName('citoyen').setDescription('Nom du citoyen').setRequired(true)),
    async execute(interaction) {
      const targetName = interaction.options.getString('citoyen');
      const fines = await db.getFinesHistory(targetName);

      if (!fines || fines.length === 0) {
        return interaction.reply({
          embeds: [createEmbed({
            title: `📁 CASIER JUDICIAIRE • ${targetName}`,
            description: `✅ Le casier judiciaire de **${targetName}** est vierge. Aucune amende enregistrée.`,
            color: config.colors.success
          })]
        });
      }

      let total = 0;
      let desc = '';
      for (const f of fines) {
        total += f.amount;
        desc += `📌 **${f.amount} ${config.currencySymbol}** — Motif: *${f.reason}* (<t:${Math.floor(f.createdAt / 1000)}:d> par <@${f.officerId}>)\n`;
      }

      const embed = createEmbed({
        title: `📁 CASIER JUDICIAIRE • ${targetName}`,
        description: `**Montant total d'amendes enregistrées : ${total} ${config.currencySymbol}**\n\n${desc}`,
        color: config.colors.danger
      });

      await interaction.reply({ embeds: [embed] });
    }
  },

  // 6. /fourriere
  {
    data: new SlashCommandBuilder()
      .setName('fourriere')
      .setDescription('Placer un véhicule en fourrière (Police / ADAC).')
      .addStringOption(opt => opt.setName('vehicule').setDescription('Modèle du véhicule (ex: Mercedes E-Class)').setRequired(true))
      .addStringOption(opt => opt.setName('plaque').setDescription('Plaque d\'immatriculation').setRequired(true))
      .addStringOption(opt => opt.setName('proprietaire').setDescription('Nom du propriétaire').setRequired(true))
      .addStringOption(opt => opt.setName('motif').setDescription('Motif de mise en fourrière').setRequired(true))
      .addIntegerOption(opt => opt.setName('frais').setDescription('Frais de sortie (€)').setRequired(true)),
    async execute(interaction) {
      const vehicle = interaction.options.getString('vehicule');
      const plate = interaction.options.getString('plaque');
      const owner = interaction.options.getString('proprietaire');
      const reason = interaction.options.getString('motif');
      const fee = interaction.options.getInteger('frais');

      const embed = createEmbed({
        title: '🛞 AVIS DE MISE EN FOURRIERE (ADAC / POLIZEI)',
        description: `Un véhicule a été saisi et transféré à la fourrière centrale.\n\n` +
          `🚘 **Véhicule** : ${vehicle}\n` +
          `🔢 **Plaque** : \`${plate.toUpperCase()}\`\n` +
          `👤 **Propriétaire** : ${owner}\n` +
          `📝 **Motif** : ${reason}\n` +
          `💶 **Frais de libération** : **${fee} ${config.currencySymbol}**\n` +
          `👮 Agent : <@${interaction.user.id}>`,
        color: config.colors.adac
      });

      await interaction.reply({ embeds: [embed] });
    }
  }
];
