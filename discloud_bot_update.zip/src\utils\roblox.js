/**
 * Helper to fetch Roblox User data using Roblox Web API
 */
async function fetchRobloxUser(usernameOrId) {
  try {
    // 1. Check if input is direct numeric User ID
    if (/^\d+$/.test(usernameOrId.trim())) {
      const id = usernameOrId.trim();
      const res = await fetch(`https://users.roblox.com/v1/users/${id}`);
      if (res.ok) {
        const data = await res.json();
        return {
          id: data.id,
          name: data.name,
          displayName: data.displayName,
          profileUrl: `https://www.roblox.com/users/${data.id}/profile`,
          avatarUrl: `https://www.roblox.com/headshot-thumbnail/image?userId=${data.id}&width=420&height=420&format=png`
        };
      }
    }

    // 2. Otherwise search by username
    const res = await fetch('https://users.roblox.com/v1/usernames/users', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        usernames: [usernameOrId.trim()],
        excludeBannedUsers: false
      })
    });

    if (res.ok) {
      const json = await res.json();
      if (json.data && json.data.length > 0) {
        const user = json.data[0];
        return {
          id: user.id,
          name: user.name,
          displayName: user.displayName,
          profileUrl: `https://www.roblox.com/users/${user.id}/profile`,
          avatarUrl: `https://www.roblox.com/headshot-thumbnail/image?userId=${user.id}&width=420&height=420&format=png`
        };
      }
    }

    return null;
  } catch (error) {
    console.error('Erreur lors de la recherche Roblox:', error);
    return null;
  }
}

module.exports = {
  fetchRobloxUser
};
