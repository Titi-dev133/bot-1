const { SlashCommandBuilder } = require('discord.js');
const { createEmbed } = require('../utils/embeds');
const config = require('../../config.json');

module.exports = [
  // 1. /darkweb
  {
    data: new SlashCommandBuilder()
      .setName('darkweb')
      .setDescription('Publier une annonce anonyme cryptée sur le Darkweb.')
      .addStringOption(opt => opt.setName('message').setDescription('Message anonyme').setRequired(true)),
    async execute(interaction) {
      const msg = interaction.options.getString('message');

      const embed = createEmbed({
        title: '🌐 DARKWEB HAMBURG • ANNONCE CRYPTÉE',
        description: `\`\`\`${msg}\`\`\`\n*🔒 Identité masquée — IP Tor Anonymisée*`,
        color: config.colors.darkweb,
        thumbnail: 'https://i.imgur.com/8QG4m3b.png'
      });

      await interaction.reply({ content: '✅ Message envoyé de manière anonyme sur le Darkweb.', ephemeral: true });
      await interaction.channel.send({ embeds: [embed] });
    }
  },

  // 2. /braquage
  {
    data: new SlashCommandBuilder()
      .setName('braquage')
      .setDescription('Signalement d\'un braquage en cours.')
      .addStringOption(opt =>
        opt.setName('lieu')
          .setDescription('Lieu du braquage')
          .setRequired(true)
          .addChoices(
            { name: '🏦 Banque Centrale de Hamburg', value: 'Banque Centrale de Hamburg' },
            { name: '💎 Bijouterie de la Ville', value: 'Bijouterie Centrale' },
            { name: '🔫 Armurerie Municipale', value: 'Armurerie' },
            { name: '⛽ Station Service ADAC', value: 'Station Service' }
          )
      ),
    async execute(interaction) {
      const location = interaction.options.getString('lieu');

      const embed = createEmbed({
        title: '🚨 ALARME SILENCIEUSE • BRAQUAGE EN COURS',
        description: `⚠️ Une alarme de braquage s'est déclenchée !\n\n📍 **Lieu** : **${location}**\n🚓 **Toutes les unités de Police (Polizei) sont demandées immédiatement sur les lieux !**`,
        color: config.colors.danger
      });

      await interaction.reply({ content: '@everyone 🚨 ALERTE BRAQUAGE !', embeds: [embed] });
    }
  },

  // 3. /prise-otage
  {
    data: new SlashCommandBuilder()
      .setName('prise-otage')
      .setDescription('Transmettre les revendications lors d\'une prise d\'otage.')
      .addStringOption(opt => opt.setName('lieu').setDescription('Localisation des otages').setRequired(true))
      .addIntegerOption(opt => opt.setName('nombre_otages').setDescription('Nombre d\'otages retenus').setRequired(true))
      .addStringOption(opt => opt.setName('revendications').setDescription('Demandes / Rançon').setRequired(true)),
    async execute(interaction) {
      const location = interaction.options.getString('lieu');
      const hostageCount = interaction.options.getInteger('nombre_otages');
      const demands = interaction.options.getString('revendications');

      const embed = createEmbed({
        title: '⚠️ ALERTE MAXIMALE • PRISE D\'OTAGE EN COURS',
        description: `Des individus armés ont pris des otages !\n\n` +
          `📍 **Lieu** : ${location}\n` +
          `👥 **Nombre d'otages** : **${hostageCount} personne(s)**\n` +
          `💰 **Exigences & Revendications** :\n\`\`\`${demands}\`\`\`\n` +
          `👮 *Negociateur de la Police attendu sur fréquence sécurisée.*`,
        color: config.colors.danger
      });

      await interaction.reply({ embeds: [embed] });
    }
  }
];
