const { SlashCommandBuilder, PermissionFlagsBits, ChannelType, MessageFlags } = require('discord.js');
const { createEmbed, sanctionDashboardEmbed, playerSanctionCardEmbed } = require('../utils/embeds');
const { fetchRobloxUser } = require('../utils/roblox');
const db = require('../database/db');
const config = require('../../config.json');

async function resolvePlayerInfo(query, client) {
  if (!query) return { robloxUser: null, discordUser: null };
  const cleanQuery = query.trim();

  let discordId = cleanQuery.replace(/[^0-9]/g, '');
  let discordUser = null;
  let robloxUser = null;

  if (discordId.length >= 17) {
    discordUser = await client.users.fetch(discordId).catch(() => null);
    if (discordUser) {
      const verification = await db.getVerification(discordUser.id);
      if (verification && verification.robloxUsername) {
        robloxUser = await fetchRobloxUser(verification.robloxUsername) || {
          id: verification.robloxId || verification.robloxUsername,
          name: verification.robloxUsername,
          displayName: verification.robloxUsername,
          avatarUrl: 'https://i.imgur.com/8QG4m3b.png'
        };
      }
    }
  }

  if (!robloxUser) {
    robloxUser = await fetchRobloxUser(cleanQuery);
  }

  if (!robloxUser) {
    robloxUser = {
      id: cleanQuery,
      name: cleanQuery,
      displayName: cleanQuery,
      avatarUrl: 'https://i.imgur.com/8QG4m3b.png'
    };
  }

  if (!discordUser && robloxUser.id) {
    const linkedDiscordId = await db.isRobloxLinkedToAnotherDiscord(robloxUser.id, '0');
    if (linkedDiscordId) {
      discordUser = await client.users.fetch(linkedDiscordId).catch(() => null);
    }
  }

  return { robloxUser, discordUser };
}

module.exports = [
  {
    data: new SlashCommandBuilder()
      .setName('sanction')
      .setDescription('Système de gestion et rapport de sanctions pour l\'équipe de modération.')
      .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
      .addSubcommand(sub =>
        sub.setName('dashboard')
           .setDescription('Publie le panneau interactif du dashboard de modération dans le salon actuel.')
      )
      .addSubcommand(sub =>
        sub.setName('ajouter')
           .setDescription('Ajouter un rapport de sanction sur un joueur (Pseudo Roblox ou Mention Discord).')
           .addStringOption(opt => opt.setName('pseudo').setDescription('Pseudo Roblox ou Mention/ID Discord').setRequired(true))
           .addStringOption(opt => opt.setName('sanction').setDescription('Intitulé de la sanction (ex: Ban 3j, Warn)').setRequired(true))
           .addStringOption(opt => opt.setName('details').setDescription('Explication et motif précis').setRequired(true))
      )
      .addSubcommand(sub =>
        sub.setName('casier')
           .setDescription('Consulter l\'historique des sanctions d\'un joueur.')
           .addStringOption(opt => opt.setName('joueur').setDescription('Pseudo Roblox, Mention Discord ou User ID').setRequired(true))
      )
      .addSubcommand(sub =>
        sub.setName('retirer')
           .setDescription('Retirer une sanction ou réinitialiser le dossier d\'un joueur.')
           .addStringOption(opt => opt.setName('joueur').setDescription('Pseudo Roblox ou Mention/ID Discord').setRequired(true))
           .addStringOption(opt => opt.setName('cible').setDescription('Numéro de la sanction (ex: 1) ou "tout"').setRequired(true))
      ),

    async execute(interaction) {
      const subcommand = interaction.options.getSubcommand();
      const { guild, channel, user } = interaction;

      // Subcommand 1: dashboard
      if (subcommand === 'dashboard') {
        const payload = sanctionDashboardEmbed();
        await channel.send(payload);

        return interaction.reply({
          content: `✅ **Panneau du Dashboard de Sanctions publié dans ${channel} !**`,
          flags: MessageFlags.Ephemeral
        });
      }

      // Subcommand 2: ajouter
      if (subcommand === 'ajouter') {
        await interaction.deferReply({ flags: MessageFlags.Ephemeral });
        const rawInput = interaction.options.getString('pseudo').trim();
        const sanctionType = interaction.options.getString('sanction').trim();
        const details = interaction.options.getString('details').trim();

        // Unified resolution (Roblox + Discord)
        const { robloxUser, discordUser } = await resolvePlayerInfo(rawInput, interaction.client);
        const linkedDiscordId = discordUser ? discordUser.id : null;

        // Save sanction in SQLite
        await db.addSanctionRecord(
          guild.id,
          robloxUser.name,
          robloxUser.id,
          linkedDiscordId,
          user.id,
          sanctionType,
          details
        );

        // Fetch complete history for this player
        const history = await db.getPlayerSanctionsHistory(robloxUser.id || robloxUser.name);

        // Find target channel #sanction-joueur
        let sanctionChannel = guild.channels.cache.find(
          c => c.type === ChannelType.GuildText && (
            c.name.toLowerCase() === 'sanction-joueur' ||
            c.name.toLowerCase() === 'sanctions-joueur' ||
            c.name.toLowerCase() === 'sanction-joueurs' ||
            c.name.toLowerCase() === 'sanctions-joueurs' ||
            c.name.toLowerCase().includes('sanction')
          )
        );

        if (!sanctionChannel) {
          try {
            sanctionChannel = await guild.channels.create({
              name: 'sanction-joueur',
              type: ChannelType.GuildText,
              topic: 'Dossiers disciplinaires et sanctions des joueurs'
            });
          } catch (e) {
            sanctionChannel = channel;
          }
        }

        // Check existing card in DB
        const cardEmbed = playerSanctionCardEmbed({
          robloxUser,
          sanctionsList: history,
          discordUser
        });

        const existingCard = await db.getPlayerSanctionCard(guild.id, robloxUser.id || robloxUser.name);
        let updatedMessage = null;

        if (existingCard) {
          try {
            const existingMsg = await sanctionChannel.messages.fetch(existingCard.messageId).catch(() => null);
            if (existingMsg) {
              updatedMessage = await existingMsg.edit({ embeds: [cardEmbed] });
            }
          } catch (err) {
            console.error('Erreur mise à jour dossier sanction:', err);
          }
        }

        if (!updatedMessage) {
          const newMsg = await sanctionChannel.send({ embeds: [cardEmbed] });
          await db.savePlayerSanctionCard(guild.id, robloxUser.id || robloxUser.name, sanctionChannel.id, newMsg.id);
        }

        return interaction.editReply({
          content: `✅ **Sanction enregistrée avec succès !**\n\n` +
            `👤 **Joueur** : **${robloxUser.displayName}** (@${robloxUser.name})\n` +
            `💬 **Compte Discord** : ${discordUser ? `<@${discordUser.id}>` : 'Non associé'}\n` +
            `🚨 **Sanction** : \`${sanctionType}\`\n` +
            `💬 **Dossier mis à jour dans** : ${sanctionChannel} (Total: **${history.length}** sanction(s))`
        });
      }

      // Subcommand 3: casier
      if (subcommand === 'casier') {
        await interaction.deferReply({ flags: MessageFlags.Ephemeral });
        const targetQuery = interaction.options.getString('joueur').trim();

        const { robloxUser, discordUser } = await resolvePlayerInfo(targetQuery, interaction.client);
        const history = await db.getPlayerSanctionsHistory(robloxUser.id || targetQuery);

        if (!history || history.length === 0) {
          return interaction.editReply({
            content: `ℹ️ Aucun dossier ou sanction trouvé pour **${robloxUser.displayName}** (\`${targetQuery}\`).`
          });
        }

        const cardEmbed = playerSanctionCardEmbed({
          robloxUser,
          sanctionsList: history,
          discordUser
        });

        return interaction.editReply({ embeds: [cardEmbed] });
      }

      // Subcommand 4: retirer
      if (subcommand === 'retirer') {
        await interaction.deferReply({ flags: MessageFlags.Ephemeral });
        const rawInput = interaction.options.getString('joueur').trim();
        const targetStr = interaction.options.getString('cible').trim().toLowerCase();

        const { robloxUser, discordUser } = await resolvePlayerInfo(rawInput, interaction.client);
        const history = await db.getPlayerSanctionsHistory(robloxUser.id || rawInput);

        if (!history || history.length === 0) {
          return interaction.editReply({
            content: `❌ Aucune sanction trouvée pour **${robloxUser.displayName}**.`
          });
        }

        let sanctionChannel = guild.channels.cache.find(
          c => c.type === ChannelType.GuildText && (
            c.name.toLowerCase() === 'sanction-joueur' ||
            c.name.toLowerCase() === 'sanctions-joueur' ||
            c.name.toLowerCase().includes('sanction')
          )
        );

        if (targetStr === 'tout' || targetStr === 'all' || targetStr === '*') {
          await db.clearPlayerSanctions(robloxUser.id || robloxUsername);

          const existingCard = await db.getPlayerSanctionCard(guild.id, robloxUser.id || robloxUsername);
          if (existingCard && sanctionChannel) {
            try {
              const msg = await sanctionChannel.messages.fetch(existingCard.messageId).catch(() => null);
              if (msg) await msg.delete().catch(() => {});
            } catch (e) {}
            await db.deletePlayerSanctionCard(guild.id, robloxUser.id || robloxUsername);
          }

          return interaction.editReply({
            content: `🗑️ **Toutes les sanctions de ${robloxUser.displayName} (@${robloxUser.name}) ont été effacées !** Son dossier a été réinitialisé.`
          });
        }

        const idx = parseInt(targetStr, 10) - 1;
        if (isNaN(idx) || idx < 0 || idx >= history.length) {
          return interaction.editReply({
            content: `⚠️ Numéro de sanction invalide. Le joueur a **${history.length}** sanction(s). Spécifiez un chiffre entre \`1\` et \`${history.length}\`, ou \`tout\`.`
          });
        }

        const targetSanction = history[idx];
        await db.removeSanctionRecord(targetSanction.id);

        const remainingHistory = await db.getPlayerSanctionsHistory(robloxUser.id || robloxUsername);

        const existingCard = await db.getPlayerSanctionCard(guild.id, robloxUser.id || robloxUsername);
        if (existingCard && sanctionChannel) {
          try {
            const msg = await sanctionChannel.messages.fetch(existingCard.messageId).catch(() => null);
            if (msg) {
              if (remainingHistory.length === 0) {
                await msg.delete().catch(() => {});
                await db.deletePlayerSanctionCard(guild.id, robloxUser.id || robloxUsername);
              } else {
                const linkedDiscordId = await db.isRobloxLinkedToAnotherDiscord(robloxUser.id, '0');
                const discordUser = linkedDiscordId ? await interaction.client.users.fetch(linkedDiscordId).catch(() => null) : null;
                const cardEmbed = playerSanctionCardEmbed({
                  robloxUser,
                  sanctionsList: remainingHistory,
                  discordUser
                });
                await msg.edit({ embeds: [cardEmbed] });
              }
            }
          } catch (e) {}
        }

        return interaction.editReply({
          content: `🗑️ **Sanction #${idx + 1} retirée pour ${robloxUser.displayName} !** (${remainingHistory.length} sanction(s) restante(s))`
        });
      }
    }
  }
];
