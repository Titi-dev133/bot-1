require('dotenv').config();
const { REST, Routes } = require('discord.js');

const serviceCommands = require('./commands/service');
const dispatchCommands = require('./commands/dispatch');
const policeCommands = require('./commands/police');
const identityCommands = require('./commands/identity');
const illegalCommands = require('./commands/illegal');
const announcementCommands = require('./commands/announcements');
const moderationCommands = require('./commands/moderation');
const verificationCommands = require('./commands/verification');
const sanctionsCommands = require('./commands/sanctions');
const staffSanctionsCommands = require('./commands/staffSanctions');
const staffServiceCommands = require('./commands/staffService');
const staffRankCommands = require('./commands/staffRank');
const staffAbsenceCommands = require('./commands/staffAbsence');
const staffReviewCommands = require('./commands/staffReview');
const suggestionCommands = require('./commands/suggestions');
const giveawayCommands = require('./commands/giveaway');
const antiraidCommands = require('./commands/antiraid');
const backupCommands = require('./commands/backup');
const recrutementCommands = require('./commands/recrutement');
const partenariatCommands = require('./commands/partenariat');
const organisationCommands = require('./commands/organisation');
const economyCommands = require('./commands/economy');
const levelCommands = require('./commands/level');
const lookupCommands = require('./commands/lookup');

const allModules = [
  ...serviceCommands,
  ...dispatchCommands,
  ...policeCommands,
  ...identityCommands,
  ...illegalCommands,
  ...announcementCommands,
  ...moderationCommands,
  ...verificationCommands,
  ...sanctionsCommands,
  ...staffSanctionsCommands,
  ...staffServiceCommands,
  ...staffRankCommands,
  ...staffAbsenceCommands,
  ...staffReviewCommands,
  ...suggestionCommands,
  ...giveawayCommands,
  ...antiraidCommands,
  ...backupCommands,
  ...recrutementCommands,
  ...partenariatCommands,
  ...organisationCommands,
  ...economyCommands,
  ...levelCommands,
  ...lookupCommands
];






const commandsJSON = allModules.map(cmd => cmd.data.toJSON());

const token = process.env.DISCORD_TOKEN;
const clientId = process.env.CLIENT_ID;
const guildId = process.env.GUILD_ID;

if (!token || token === 'ENTRER_VOTRE_TOKEN_ICI') {
  console.error('❌ ERREUR: Le DISCORD_TOKEN n\'est pas défini dans le fichier .env !');
  process.exit(1);
}

if (!clientId || clientId === 'ENTRER_VOTRE_CLIENT_ID_ICI') {
  console.error('❌ ERREUR: Le CLIENT_ID n\'est pas défini dans le fichier .env !');
  process.exit(1);
}

const rest = new REST({ version: '10' }).setToken(token);

(async () => {
  try {
    console.log(`⏳ Début de l'enregistrement de ${commandsJSON.length} commandes Slash...`);

    if (guildId && guildId !== 'ENTRER_VOTRE_GUILD_ID_ICI') {
      // 1. Clear global commands to ensure no duplicate global entries exist
      await rest.put(Routes.applicationCommands(clientId), { body: [] });
      console.log('🧹 Purge des commandes globales effectuée.');

      // 2. Deploy Guild commands for instant availability
      await rest.put(
        Routes.applicationGuildCommands(clientId, guildId),
        { body: commandsJSON }
      );
      console.log(`✅ ${commandsJSON.length} commandes enregistrées instantanément sur le serveur (Guild ID: ${guildId}) !`);
    } else {
      // Global registration
      await rest.put(
        Routes.applicationCommands(clientId),
        { body: commandsJSON }
      );
      console.log(`✅ ${commandsJSON.length} commandes enregistrées au niveau mondial (Global Application Commands) !`);
    }
  } catch (error) {
    console.error('❌ Erreur lors de l\'enregistrement des commandes Slash:', error);
  }
})();
