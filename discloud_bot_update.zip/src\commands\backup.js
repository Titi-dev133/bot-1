const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const db = require('../database/db');
const { createFullBackup, restoreFullBackup } = require('../utils/backupManager');
const { backupListEmbed, antiRaidDashboardEmbed } = require('../utils/embeds');
const { sendAuditLog } = require('../utils/auditLogger');

module.exports = [
  {
    data: new SlashCommandBuilder()
      .setName('backup')
      .setDescription('💾 Gestion des sauvegardes automatiques et manuelles du serveur et de la base de données')
      .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
      .addSubcommand(sub =>
        sub
          .setName('create')
          .setDescription('Déclencher immédiatement une sauvegarde complète (Database SQLite + Structure Discord)')
      )
      .addSubcommand(sub =>
        sub
          .setName('list')
          .setDescription('Afficher la liste des sauvegardes archivées')
      )
      .addSubcommand(sub =>
        sub
          .setName('restore')
          .setDescription('Restaurer la structure du serveur (salons, catégories, rôles) à partir d\'une sauvegarde')
          .addStringOption(opt =>
            opt
              .setName('file')
              .setDescription('Nom du fichier JSON (ex: server_layout_...json) ou "latest" pour la dernière sauvegarde')
              .setRequired(true)
          )
      ),

    async execute(interaction) {
      const subcommand = interaction.options.getSubcommand();
      const guildId = interaction.guild.id;

      if (subcommand === 'create') {
        await interaction.deferReply({ ephemeral: true });

        const result = await createFullBackup(interaction.guild, interaction.user);

        if (result.success) {
          // Update Anti-Raid dashboard if present
          const cfg = await db.getAntiRaidConfig(guildId);
          const lastBackup = await db.getLastBackup(guildId);
          const dbPanel = await db.getAntiRaidDashboard(guildId);
          if (dbPanel) {
            try {
              const ch = await interaction.guild.channels.fetch(dbPanel.channelId);
              if (ch) {
                const msg = await ch.messages.fetch(dbPanel.messageId);
                if (msg) {
                  await msg.edit(antiRaidDashboardEmbed(cfg, lastBackup));
                }
              }
            } catch (e) {}
          }

          // Audit log
          const auditEmbed = {
            title: '💾 LOG AUDIT : SAUVEGARDE EFFECTUÉE',
            color: '#43A047',
            fields: [
              { name: '👮 Demandé par', value: `<@${interaction.user.id}> (\`${interaction.user.tag}\`)`, inline: true },
              { name: '📂 Nom du Backup', value: `\`${result.backupName}\``, inline: true },
              { name: '📁 Fichiers', value: `• DB: \`${result.dbFile}\`\n• Layout: \`${result.layoutFile}\``, inline: false }
            ],
            timestamp: new Date()
          };
          await sendAuditLog(interaction.guild, auditEmbed);

          await interaction.editReply({
            content: `✅ **Sauvegarde complète effectuée avec succès !**\n` +
                     `• **Nom** : \`${result.backupName}\`\n` +
                     `• **Fichier DB** : \`${result.dbFile}\`\n` +
                     `• **Structure Discord JSON** : \`${result.layoutFile}\``
          });
        } else {
          await interaction.editReply({
            content: `❌ **Erreur lors de la création de la sauvegarde :** ${result.error}`
          });
        }
      } else if (subcommand === 'list') {
        const backups = await db.getBackupsHistory(guildId, 10);
        const embed = backupListEmbed(backups);
        await interaction.reply({ embeds: [embed], ephemeral: true });
      } else if (subcommand === 'restore') {
        await interaction.deferReply({ ephemeral: true });
        const fileInput = interaction.options.getString('file');

        const result = await restoreFullBackup(interaction.guild, fileInput);

        if (result.success) {
          const auditEmbed = {
            title: '🔄 LOG AUDIT : RESTAURATION DE SAUVEGARDE EFFECTUÉE',
            color: '#1E88E5',
            fields: [
              { name: '👮 Exécuté par', value: `<@${interaction.user.id}> (\`${interaction.user.tag}\`)`, inline: true },
              { name: '📁 Fichier Layout', value: `\`${result.layoutFile}\``, inline: true },
              { name: '📊 Résultat', value: `• Rôles créés : **${result.rolesCreated}** / ${result.totalSavedRoles}\n• Catégories créées : **${result.categoriesCreated}**\n• Salons créés : **${result.channelsCreated}** / ${result.totalSavedChannels}`, inline: false }
            ],
            timestamp: new Date()
          };
          await sendAuditLog(interaction.guild, auditEmbed);

          await interaction.editReply({
            content: `✅ **Restauration du serveur terminée avec succès !**\n` +
                     `• **Fichier source** : \`${result.layoutFile}\`\n` +
                     `• **Rôles créés** : **${result.rolesCreated}**\n` +
                     `• **Catégories créées** : **${result.categoriesCreated}**\n` +
                     `• **Salons créés** : **${result.channelsCreated}**`
          });
        } else {
          await interaction.editReply({
            content: `❌ **Erreur lors de la restauration :** ${result.error}`
          });
        }
      }
    }
  }
];

