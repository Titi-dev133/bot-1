const { ActivityType, REST, Routes } = require('discord.js');
const { initGiveawayScheduler } = require('../utils/giveawayManager');
const serviceCommands = require('../commands/service');
const dispatchCommands = require('../commands/dispatch');
const policeCommands = require('../commands/police');
const identityCommands = require('../commands/identity');
const illegalCommands = require('../commands/illegal');
const announcementCommands = require('../commands/announcements');
const moderationCommands = require('../commands/moderation');
const verificationCommands = require('../commands/verification');
const sanctionsCommands = require('../commands/sanctions');
const staffSanctionsCommands = require('../commands/staffSanctions');
const staffServiceCommands = require('../commands/staffService');
const staffRankCommands = require('../commands/staffRank');
const staffAbsenceCommands = require('../commands/staffAbsence');

const staffReviewCommands = require('../commands/staffReview');
const suggestionCommands = require('../commands/suggestions');
const giveawayCommands = require('../commands/giveaway');
const antiraidCommands = require('../commands/antiraid');
const backupCommands = require('../commands/backup');
const recrutementCommands = require('../commands/recrutement');
const partenariatCommands = require('../commands/partenariat');
const organisationCommands = require('../commands/organisation');
const economyCommands = require('../commands/economy');
const levelCommands = require('../commands/level');
const lookupCommands = require('../commands/lookup');
const { initXpDashboardScheduler } = require('../utils/xpDashboardScheduler');

const allModules = [
  ...serviceCommands,
  ...dispatchCommands,
  ...policeCommands,
  ...identityCommands,
  ...illegalCommands,
  ...announcementCommands,
  ...moderationCommands,
  ...verificationCommands,
  ...sanctionsCommands,
  ...staffSanctionsCommands,
  ...staffServiceCommands,
  ...staffRankCommands,
  ...staffAbsenceCommands,
  ...staffReviewCommands,
  ...suggestionCommands,
  ...giveawayCommands,
  ...antiraidCommands,
  ...backupCommands,
  ...recrutementCommands,
  ...partenariatCommands,
  ...organisationCommands,
  ...economyCommands,
  ...levelCommands,
  ...lookupCommands
];



const commandsJSON = allModules.map(cmd => cmd.data.toJSON());

module.exports = {
  name: 'ready',
  once: true,
  async execute(client) {
    console.log(`\n==============================================`);
    console.log(`🤖 BOT DISCORD EN LIGNE AVEC SUCCÈS !`);
    console.log(`👤 Connecté sous : ${client.user.tag}`);
    console.log(`🆔 ID Bot : ${client.user.id}`);
    console.log(`🏠 Serveurs actifs : ${client.guilds.cache.size}`);
    console.log(`==============================================\n`);

    // Dynamic Activity
    client.user.setActivity('Emergency Hamburg RP | /911', { type: ActivityType.Watching });

    // Initialize Giveaway Scheduler & XP Dashboard Scheduler (5-Min Auto-Update)
    initGiveawayScheduler(client);
    initXpDashboardScheduler(client);

    console.log(`⚡ ${client.commands.size} commandes Slash chargées et prêtes à être exécutées.`);
  }
};
