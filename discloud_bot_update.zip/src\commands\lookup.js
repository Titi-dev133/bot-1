const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder, MessageFlags } = require('discord.js');
const db = require('../database/db');
const { createEmbed } = require('../utils/embeds');
const { createLookupDashboard } = require('../utils/dashboards');
const { fetchRobloxUser } = require('../utils/roblox');
const config = require('../../config.json');

async function performPlayerLookup({ guild, query }) {
  const cleanQuery = query.replace(/[<@!>]/g, '').trim();

  // 1. Recherche par membre Discord dans le serveur (ID ou Pseudo)
  let discordMember = null;
  if (/^\d{17,20}$/.test(cleanQuery)) {
    discordMember = await guild.members.fetch(cleanQuery).catch(() => null);
  }

  if (!discordMember) {
    const fetched = await guild.members.fetch({ query: cleanQuery, limit: 5 }).catch(() => null);
    if (fetched && fetched.size > 0) {
      discordMember = fetched.first();
    }
  }

  if (!discordMember) {
    discordMember = guild.members.cache.find(m =>
      m.user.username.toLowerCase() === cleanQuery.toLowerCase() ||
      m.user.tag.toLowerCase() === cleanQuery.toLowerCase() ||
      (m.nickname && m.nickname.toLowerCase() === cleanQuery.toLowerCase())
    );
  }

  // 2. Recherche du profil SQLite par ID Discord
  let profile = null;
  if (discordMember) {
    profile = await db.getProfileByDiscord(discordMember.id);
  }

  // 3. Recherche par pseudo/ID Roblox dans la BDD SQLite si profil non trouvé
  if (!profile) {
    profile = await db.getProfileByRoblox(cleanQuery);
    if (profile && profile.userId && !discordMember) {
      discordMember = await guild.members.fetch(profile.userId).catch(() => null);
    }
  }

  // 4. Recherche via l'API Roblox officielle
  let robloxUser = null;
  if (profile && (profile.robloxUsername || profile.robloxId)) {
    robloxUser = await fetchRobloxUser(profile.robloxUsername || profile.robloxId);
  }

  if (!robloxUser) {
    robloxUser = await fetchRobloxUser(cleanQuery);
    if (robloxUser && robloxUser.id && !profile) {
      profile = await db.getProfileByRoblox(robloxUser.name);
      if (profile && profile.userId && !discordMember) {
        discordMember = await guild.members.fetch(profile.userId).catch(() => null);
      }
    }
  }

  if (!profile && !robloxUser && !discordMember) {
    return {
      found: false,
      embed: createEmbed({
        title: '🔍 RECHERCHE DE JOUEUR • INTROUVABLE',
        description: `❌ Aucune correspondance trouvée pour **"${query}"**.\nLe joueur n'a pas encore lié son compte Roblox ou n'existe pas sur le serveur.`,
        color: config.colors.danger
      })
    };
  }

  const targetDiscordTag = discordMember
    ? `<@${discordMember.id}> (\`${discordMember.user.tag}\` | \`ID: ${discordMember.id}\`)`
    : (profile && profile.userId ? `<@${profile.userId}> (\`ID: ${profile.userId}\`)` : '🔴 Non lié sur ce serveur Discord');

  const robloxName = robloxUser ? robloxUser.name : (profile && profile.robloxUsername ? profile.robloxUsername : '🔴 Non lié');
  const robloxId = robloxUser ? robloxUser.id : (profile && profile.robloxId ? profile.robloxId : 'N/A');
  const robloxLink = robloxId !== 'N/A' ? `[${robloxName}](https://www.roblox.com/users/${robloxId}/profile)` : `\`${robloxName}\``;
  const avatarUrl = robloxUser && robloxUser.avatarUrl ? robloxUser.avatarUrl : (discordMember ? discordMember.user.displayAvatarURL({ dynamic: true }) : null);

  const bankBal = profile && profile.bankBalance !== undefined ? `${profile.bankBalance.toLocaleString('fr-FR')} €` : '10 000 €';
  const jobName = profile && profile.job ? profile.job : 'Citoyen / Chômeur';

  const embed = createEmbed({
    title: `🔍 CORRESPONDANCE DE JOUEUR • DISCORD ↔ ROBLOX`,
    description: `Résultats pour la recherche : **"${query}"**\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`,
    color: '#3498DB',
    thumbnail: avatarUrl,
    fields: [
      { name: '👤 Compte Discord', value: targetDiscordTag, inline: false },
      { name: '🎮 Compte Roblox Lié', value: `🎮 **Pseudo Roblox** : ${robloxLink}\n🆔 **Roblox ID** : \`${robloxId}\``, inline: false },
      { name: '💳 Solde Bancaire RP', value: `\`${bankBal}\``, inline: true },
      { name: '💼 Métier RP', value: `\`${jobName}\``, inline: true }
    ],
    footer: 'Aubagne RP Officiel • Système de Recherche Discord ↔ Roblox'
  });

  return { found: true, embed };
}

module.exports = [
  // 1. /dashboard-lookup (Déploie le Panneau permanent de Recherche)
  {
    data: new SlashCommandBuilder()
      .setName('dashboard-lookup')
      .setDescription('Déployer le Panneau permanent de Recherche Joueur (Discord <-> Roblox).')
      .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
    async execute(interaction) {
      const dashboard = createLookupDashboard();
      await interaction.reply({ content: '🚀 **Installation du Dashboard de Recherche...**', flags: MessageFlags.Ephemeral });
      await interaction.channel.send(dashboard);
    }
  },

  // 2. /lookup (ou /chercher-joueur)
  {
    data: new SlashCommandBuilder()
      .setName('lookup')
      .setDescription('Rechercher la correspondance entre un pseudo Discord et Roblox (Confidentiel).')
      .addStringOption(opt =>
        opt.setName('recherche')
          .setDescription('Pseudo Discord, mention @User, ID Discord OU pseudo Roblox')
          .setRequired(true)
      ),
    async execute(interaction) {
      const query = interaction.options.getString('recherche');
      const result = await performPlayerLookup({ guild: interaction.guild, query });
      await interaction.reply({ embeds: [result.embed], flags: MessageFlags.Ephemeral });
    }
  }
];

module.exports.performPlayerLookup = performPlayerLookup;
