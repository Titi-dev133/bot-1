const { EmbedBuilder } = require('discord.js');

/**
 * AI Assistant for Staff Ticket Responses
 */
function generateAITicketGuidance({ category, ticketOpener, staffUser }) {
  const templates = {
    'Recrutement staff': {
      color: '#5865F2',
      title: '🤖 Assistant IA • Guide Recrutement Staff',
      analysis: `Le candidat <@${ticketOpener.id}> a ouvert une candidature pour intégrer l'équipe Staff d'Aubagne / Hamburg RP.`,
      checklist: [
        '✔️ Âge minimum RP/HRP respecté (14+ ans recommandé)',
        '✔️ Micro de bonne qualité & maturité prouvée',
        '✔️ Aucun avertissement lourd récent dans son dossier (/warnings)',
        '✔️ Disponibilités régulières les soirs et week-ends'
      ],
      replyTemplate:
        `Bonjour <@${ticketOpener.id}>, merci pour l'intérêt que tu portes au serveur !\n\n` +
        `Pour poursuivre ta candidature staff, merci de répondre aux questions suivantes :\n` +
        `1. Quel est ton âge HRP et tes disponibilités par semaine ?\n` +
        `2. As-tu déjà été staff sur un serveur Roblox RP ? Si oui, lequel ?\n` +
        `3. Que ferais-tu si deux joueurs s'insultent en HRP pendant un contrôle de police ?\n\n` +
        `Un responsable prendra ensuite le relais pour un vocal d'entretien.`
    },

    'Demande de partenariat': {
      color: '#FEE75C',
      title: '🤖 Assistant IA • Guide Partenariat',
      analysis: `Le serveur partenaire <@${ticketOpener.id}> souhaite effectuer une demande de partenariat.`,
      checklist: [
        '✔️ Nombre minimum de membres actifs sur leur Discord (ex: +200 membres)',
        '✔️ Thématique compatible (Roblox, RP, Gaming)',
        '✔️ Mention @everyone / @here réciproque convenue',
        '✔️ Texte et lien d\'invitation valides et sans expiration'
      ],
      replyTemplate:
        `Bonjour <@${ticketOpener.id}> !\n\n` +
        `Merci pour ton intérêt envers un partenariat avec notre communauté.\n` +
        `Peux-tu nous transmettre :\n` +
        `- Le lien permanent de votre serveur Discord\n` +
        `- Votre texte de présentation complet\n` +
        `- Le nombre de membres actifs sur votre serveur\n\n` +
        `Notre responsable Partenariats étudiera votre demande rapidement.`
    },

    'Création de gang': {
      color: '#EB459E',
      title: '🤖 Assistant IA • Guide Création de Gang / Orga',
      analysis: `L'individu <@${ticketOpener.id}> demande l'officialisation d'une organisation criminelle ou gang.`,
      checklist: [
        '✔️ Liste d\'au moins 4 à 6 membres fondateurs actifs',
        '✔️ Lore / Histoire du gang cohérente avec le RP de la ville',
        '✔️ Couleur, véhicules et quartier général définis',
        '✔️ Approbation par la Gestion Illégale Staff'
      ],
      replyTemplate:
        `Bonjour <@${ticketOpener.id}>,\n\n` +
        `Pour faire valider ton projet de Gang / Organisation Criminelle, merci de fournir :\n` +
        `1. Nom du Gang & Couleur officielle\n` +
        `2. Lore / Histoire du gang (ex: origine, activités)\n` +
        `3. Liste des Pseudos Discord & Roblox des membres fondateurs\n` +
        `4. Localisation souhaitée pour votre QG\n\n` +
        `La Gestion Illégale étudiera ton dossier sous 24h.`
    },

    'Création d\'entreprise': {
      color: '#57F287',
      title: '🤖 Assistant IA • Guide Création d\'Entreprise',
      analysis: `Le citoyen <@${ticketOpener.id}> souhaite ouvrir un commerce / entreprise privée en ville.`,
      checklist: [
        '✔️ Business Plan & catalogue de tarifs d\'entreprise',
        '✔️ Minimum 2 employés déclarés',
        '✔️ Solde bancaire RP suffisant pour l\'achat de licence commerciale (/banque)',
        '✔️ Validation par la Mairie / Gestion Entreprises'
      ],
      replyTemplate:
        `Bonjour <@${ticketOpener.id}>,\n\n` +
        `Félicitations pour ton initiative entrepreneuriale !\n` +
        `Merci de nous fournir les éléments suivants :\n` +
        `- Nom et domaine de l'entreprise (ex: Concessionnaire, Bar, Sécurité, Taxi)\n` +
        `- Grille tarifaire des services/produits proposés\n` +
        `- Liste de vos employés au lancement\n\n` +
        `Un responsable Mairie / Entreprises reviendra vers toi.`
    },

    'Report un staff': {
      color: '#ED4245',
      title: '🤖 Assistant IA • Guide Plainte / Report Staff',
      analysis: `Une réclamation à l'encontre d'un membre de l'équipe modération a été déposée par <@${ticketOpener.id}>.`,
      checklist: [
        '⚠️ Traitement réservé EXCLUSIVEMENT à la Haute Direction / Fondateurs',
        '✔️ Preuve vidéo obligatoire (Medal/YouTube/Outplayed) avec horodatage',
        '✔️ Explication factuelle et courtoise de la scène sans insultes'
      ],
      replyTemplate:
        `Bonjour <@${ticketOpener.id}>,\n\n` +
        `Ce ticket a été transféré à la **Haute Direction / Responsables Staff**.\n` +
        `Afin de traiter ta plainte de manière équitable, merci de fournir :\n` +
        `- Le pseudo du staff concerné\n` +
        `- L'heure précise de la scène RP\n` +
        `- Le lien d'une vidéo complète retraçant la scène sans montage\n\n` +
        `La direction étudiera les logs et la vidéo.`
    },

    'Report un joueur': {
      color: '#E67E22',
      title: '🤖 Assistant IA • Guide Report Joueur HRP/Freetill',
      analysis: `Signalement d'une infraction aux règles RP par le joueur <@${ticketOpener.id}>.`,
      checklist: [
        '✔️ Rec vidéo ou captures d\'écran des logs',
        '✔️ Identification du suspect (Nom RP ou Pseudo Roblox)',
        '✔️ Infraction constatée (Freetill, No RP, Metagaming, Powergaming, Fear RP)'
      ],
      replyTemplate:
        `Bonjour <@${ticketOpener.id}>,\n\n` +
        `Pour sanctionner une infraction au règlement, nous avons besoin de billes concrètes.\n` +
        `Merci de transmettre :\n` +
        `1. Pseudo Roblox ou Nom RP du joueur fautif\n` +
        `2. Règle enfreinte (ex: HRP, Freeshoot, Fear RP)\n` +
        `3. Preuve vidéo / Screenshot\n\n` +
        `Un modérateur appliquera les sanctions nécessaires.`
    },

    'Autres': {
      color: '#95A5A6',
      title: '🤖 Assistant IA • Guide Assistance Générale',
      analysis: `Demande d'information générale ou problème technique par <@${ticketOpener.id}>.`,
      checklist: [
        '✔️ Vérifier si le problème concerne la liaison Roblox (/link-roblox)',
        '✔️ Vérifier l\'état du serveur Roblox ou Discord'
      ],
      replyTemplate:
        `Bonjour <@${ticketOpener.id}>,\n\n` +
        `Comment pouvons-nous t'aider aujourd'hui ? Merci d'expliquer ton problème le plus précisément possible afin qu'un membre du staff t'apporte la réponse adaptée.`
    }
  };

  const data = templates[category] || templates['Autres'];

  const embed = new EmbedBuilder()
    .setTitle(data.title)
    .setColor(data.color)
    .setDescription(
      `**💡 Analyse Automatique de la Demande :**\n${data.analysis}\n\n` +
      `**⚠️ Checklist à Vérifier par le Staff (<@${staffUser.id}>) :**\n` +
      data.checklist.join('\n') + '\n\n' +
      `**📝 Modèle de Réponse Recommandé à Copier/Coller :**\n\`\`\`${data.replyTemplate}\`\`\``
    )
    .setFooter({ text: 'Assistant IA Staff • Adaptable selon le contexte' })
    .setTimestamp();

  return embed;
}

module.exports = {
  generateAITicketGuidance
};
