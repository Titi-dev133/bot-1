const { EmbedBuilder } = require('discord.js');
const config = require('../../config.json');

module.exports = {
  name: 'voiceStateUpdate',
  async execute(oldState, newState) {
    try {
      const member = newState.member || oldState.member;
      if (!member || member.user.bot) return;

      const guild = newState.guild || oldState.guild;
      const oldChannel = oldState.channel;
      const newChannel = newState.channel;

      const isOldSleep = oldChannel && (oldChannel.name.toLowerCase().includes('sleep') || oldChannel.name.toLowerCase().includes('nuit') || oldChannel.name.toLowerCase().includes('dormir'));
      const isNewSleep = newChannel && (newChannel.name.toLowerCase().includes('sleep') || newChannel.name.toLowerCase().includes('nuit') || newChannel.name.toLowerCase().includes('dormir'));

      // 1. Entrée dans le vocal Sleepcall
      if (!isOldSleep && isNewSleep) {
        // Trouver ou créer le rôle "🌙 Sleep Mode (AFK)"
        let sleepRole = guild.roles.cache.find(r => r.name.toLowerCase().includes('sleep mode') || r.name.toLowerCase().includes('sleepcall'));

        if (!sleepRole) {
          try {
            sleepRole = await guild.roles.create({
              name: '🌙 Sleep Mode (AFK)',
              color: '#4A148C',
              reason: 'Système automatique Sleepcall AFK'
            });
          } catch (e) {
            console.error('Impossible de créer le rôle Sleep Mode:', e);
          }
        }

        if (sleepRole && !member.roles.cache.has(sleepRole.id)) {
          await member.roles.add(sleepRole).catch(() => {});
        }

        // Envoi d'un message privé d'information au membre
        try {
          await member.send({
            embeds: [
              new EmbedBuilder()
                .setTitle('🌙 MODE SLEEPCALL ACTIVÉ • AUBAGNE RP')
                .setDescription(
                  `Vous êtes maintenant connecté(e) dans le salon vocal **${newChannel.name}** !\n\n` +
                  `💤 **Mode Nuit / AFK Activé** : Le rôle \`🌙 Sleep Mode (AFK)\` vous a été automatiquement attribué.\n` +
                  `🔕 Vos pings et notifications du serveur sont suspendus afin de garantir votre tranquillité pendant votre sommeil.\n\n` +
                  `☀️ Dès que vous quitterez ce salon vocal, vos pings et notifications seront pleinement restaurés !`
                )
                .setColor('#7B1FA2')
                .setFooter({ text: 'Aubagne RP Officiel • Système Sleepcall AFK' })
                .setTimestamp()
            ]
          });
        } catch (dmErr) {
          // Ignorer si les MP sont fermés
        }
      }

      // 2. Sortie du vocal Sleepcall
      if (isOldSleep && !isNewSleep) {
        const sleepRole = guild.roles.cache.find(r => r.name.toLowerCase().includes('sleep mode') || r.name.toLowerCase().includes('sleepcall'));

        if (sleepRole && member.roles.cache.has(sleepRole.id)) {
          await member.roles.remove(sleepRole).catch(() => {});
        }

        // Notification DM de sortie du mode Nuit
        try {
          await member.send({
            embeds: [
              new EmbedBuilder()
                .setTitle('☀️ MODE SLEEPCALL DÉSACTIVÉ • AUBAGNE RP')
                .setDescription(
                  `Vous avez quitté le salon vocal Sleepcall.\n\n` +
                  `🔔 **Mode Normal Réactivé** : Le rôle \`🌙 Sleep Mode (AFK)\` vous a été retiré.\n` +
                  `📩 Vos pings, notifications et accès aux salons du serveur sont de nouveau pleinement actifs !`
                )
                .setColor('#FBC02D')
                .setFooter({ text: 'Aubagne RP Officiel • Système Sleepcall AFK' })
                .setTimestamp()
            ]
          });
        } catch (dmErr) {
          // Ignorer si les MP sont fermés
        }
      }
    } catch (error) {
      console.error('❌ Erreur dans l\'événement voiceStateUpdate (Sleepcall):', error);
    }
  }
};
