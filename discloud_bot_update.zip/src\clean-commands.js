require('dotenv').config();
const { REST, Routes } = require('discord.js');

const token = process.env.DISCORD_TOKEN;
const clientId = process.env.CLIENT_ID;
const guildId = process.env.GUILD_ID;

if (!token || token === 'ENTRER_VOTRE_TOKEN_ICI') {
  console.error('❌ ERREUR: Le DISCORD_TOKEN n\'est pas défini dans le fichier .env !');
  process.exit(1);
}

if (!clientId || clientId === 'ENTRER_VOTRE_CLIENT_ID_ICI') {
  console.error('❌ ERREUR: Le CLIENT_ID n\'est pas défini dans le fichier .env !');
  process.exit(1);
}

const rest = new REST({ version: '10' }).setToken(token);

(async () => {
  try {
    console.log('🧹 Nettoyage des commandes en double...');

    // 1. Fetch Global Commands
    const globalCmds = await rest.get(Routes.applicationCommands(clientId));
    console.log(`📡 Commandes globales actuellement enregistrées : ${globalCmds.length}`);

    // 2. Clear Global Commands if Guild mode is active, or clear all global commands to eliminate duplicates
    if (globalCmds.length > 0) {
      console.log('🗑️ Suppression de toutes les commandes globales pour supprimer les doublons...');
      await rest.put(Routes.applicationCommands(clientId), { body: [] });
      console.log('✅ Toutes les commandes globales ont été supprimées avec succès !');
    }

    if (guildId && guildId !== 'ENTRER_VOTRE_GUILD_ID_ICI') {
      const guildCmds = await rest.get(Routes.applicationGuildCommands(clientId, guildId));
      console.log(`🏠 Commandes de serveur (${guildId}) actuellement enregistrées : ${guildCmds.length}`);
    }

    console.log('\n✨ Nettoyage terminé ! Relancez les commandes avec deploy-commands.js ou redémarrez le bot.');
  } catch (error) {
    console.error('❌ Erreur lors du nettoyage des commandes :', error);
  }
})();
