const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const db = require('../database/db');
const { createEmbed } = require('../utils/embeds');
const { createRobloxDashboard } = require('../utils/dashboards');
const { fetchRobloxUser } = require('../utils/roblox');
const config = require('../../config.json');

module.exports = [
  // 1. /dashboard-roblox
  {
    data: new SlashCommandBuilder()
      .setName('dashboard-roblox')
      .setDescription('Déployer le panneau PERMANENT de liaison et vérification des comptes Roblox.')
      .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
    async execute(interaction) {
      const d = createRobloxDashboard();
      await interaction.reply(d);
    }
  },

  // 2. /link-roblox
  {
    data: new SlashCommandBuilder()
      .setName('link-roblox')
      .setDescription('Lier votre compte Roblox à votre profil Discord.')
      .addStringOption(opt => opt.setName('pseudo').setDescription('Votre nom d\'utilisateur Roblox ou User ID').setRequired(true)),
    async execute(interaction) {
      await interaction.deferReply({ ephemeral: false });
      const query = interaction.options.getString('pseudo');

      const robloxUser = await fetchRobloxUser(query);
      if (!robloxUser) {
        return interaction.editReply({
          content: `❌ Impossible de trouver un compte Roblox avec le pseudo ou l'ID **"${query}"**.`
        });
      }

      await db.linkRobloxAccount(interaction.user.id, robloxUser.name, robloxUser.id, robloxUser.displayName);

      const embed = createEmbed({
        title: '🎮 COMPTE ROBLOX LIÉ AVEC SUCCÈS !',
        description: `Le membre <@${interaction.user.id}> a lié son compte Roblox :\n\n` +
          `👤 **Pseudo Roblox** : **[${robloxUser.name}](${robloxUser.profileUrl})**\n` +
          `🏷️ **Nom d'affichage** : ${robloxUser.displayName}\n` +
          `🆔 **Roblox ID** : \`${robloxUser.id}\``,
        color: config.colors.success,
        thumbnail: robloxUser.avatarUrl
      });

      await interaction.editReply({ embeds: [embed] });
    }
  },

  // 3. /rp-id
  {
    data: new SlashCommandBuilder()
      .setName('rp-id')
      .setDescription('Consulter la carte d\'identité RP d\'un citoyen.')
      .addUserOption(opt => opt.setName('membre').setDescription('Membre à consulter')),
    async execute(interaction) {
      const target = interaction.options.getUser('membre') || interaction.user;
      const profile = await db.getProfile(target.id);

      const robloxStr = profile.robloxUsername
        ? `[${profile.robloxUsername} (ID: ${profile.robloxId})](https://www.roblox.com/users/${profile.robloxId}/profile)`
        : '❌ Non lié (`/link-roblox`)';

      const embed = createEmbed({
        title: '🪪 CARTE D\'IDENTITÉ RP • VILLE DE HAMBURG',
        description: `Identité officielle enregistrée dans les registres de la Mairie.\n\n` +
          `👤 **Nom RP** : **${profile.lastName.toUpperCase()}**\n` +
          `👤 **Prénom RP** : **${profile.firstName}**\n` +
          `🎂 **Âge** : ${profile.age} ans\n` +
          `💼 **Profession** : ${profile.job}\n` +
          `🎮 **Compte Roblox** : ${robloxStr}\n` +
          `🚗 **Permis** : ${profile.licenses}\n` +
          `🏦 **Solde Banque RP** : **${profile.bankBalance} ${config.currencySymbol}**`,
        color: config.colors.primary,
        thumbnail: target.displayAvatarURL({ dynamic: true })
      });

      await interaction.reply({ embeds: [embed] });
    }
  },

  // 4. /config-id
  {
    data: new SlashCommandBuilder()
      .setName('config-id')
      .setDescription('Définir ou mettre à jour votre carte d\'identité RP.')
      .addStringOption(opt => opt.setName('nom').setDescription('Votre nom de famille RP').setRequired(true))
      .addStringOption(opt => opt.setName('prenom').setDescription('Votre prénom RP').setRequired(true))
      .addIntegerOption(opt => opt.setName('age').setDescription('Votre âge RP').setRequired(true).setMinValue(16).setMaxValue(90))
      .addStringOption(opt => opt.setName('emploi').setDescription('Votre métier principal dans Hamburg').setRequired(true)),
    async execute(interaction) {
      const lastName = interaction.options.getString('nom');
      const firstName = interaction.options.getString('prenom');
      const age = interaction.options.getInteger('age');
      const job = interaction.options.getString('emploi');

      await db.updateProfile(interaction.user.id, lastName, firstName, age, job);

      const embed = createEmbed({
        title: '✅ IDENTITÉ RP MISE À JOUR',
        description: `Votre profil RP a été mis à jour avec succès.\n\n` +
          `👤 **Nom complet** : ${firstName} ${lastName.toUpperCase()}\n` +
          `🎂 **Âge** : ${age} ans\n` +
          `💼 **Métier** : ${job}`,
        color: config.colors.success
      });

      await interaction.reply({ embeds: [embed] });
    }
  },

  // 5. /banque
  {
    data: new SlashCommandBuilder()
      .setName('banque')
      .setDescription('Gérer votre compte bancaire RP (Solde, Virement).')
      .addStringOption(opt =>
        opt.setName('action')
          .setDescription('Action à exécuter')
          .setRequired(true)
          .addChoices(
            { name: '🏦 Consulter mon solde', value: 'solde' },
            { name: '💸 Effectuer un virement RP', value: 'virement' }
          )
      )
      .addIntegerOption(opt => opt.setName('montant').setDescription('Montant du virement (€)').setRequired(false))
      .addUserOption(opt => opt.setName('destinataire').setDescription('Bénéficiaire du virement').setRequired(false)),
    async execute(interaction) {
      const action = interaction.options.getString('action');

      if (action === 'solde') {
        const profile = await db.getProfile(interaction.user.id);
        return interaction.reply({
          embeds: [createEmbed({
            title: '🏦 HAMBURG VOLKSBANK • RELEVÉ DE COMPTE',
            description: `Bienvenue M./Mme <@${interaction.user.id}>.\n\n💰 **Solde disponible sur votre compte** : **${profile.bankBalance} ${config.currencySymbol}**`,
            color: config.colors.primary
          })]
        });
      }

      if (action === 'virement') {
        const amount = interaction.options.getInteger('montant');
        const targetUser = interaction.options.getUser('destinataire');

        if (!amount || amount <= 0 || !targetUser) {
          return interaction.reply({ content: '❌ Veuillez spécifier un montant valide et un destinataire.', ephemeral: true });
        }

        const sender = await db.getProfile(interaction.user.id);
        if (sender.bankBalance < amount) {
          return interaction.reply({ content: `❌ Solde insuffisant ! Vous possédez **${sender.bankBalance} ${config.currencySymbol}**.`, ephemeral: true });
        }

        await db.updateBank(interaction.user.id, -amount);
        await db.updateBank(targetUser.id, amount);

        const embed = createEmbed({
          title: '💸 VIREMENT BANCAIRE EFFECTUÉ',
          description: `Un virement de **${amount} ${config.currencySymbol}** a été transmis avec succès.\n\n` +
            `📤 **Émetteur** : <@${interaction.user.id}>\n` +
            `📥 **Bénéficiaire** : <@${targetUser.id}>`,
          color: config.colors.success
        });

        await interaction.reply({ embeds: [embed] });
      }
    }
  }
];
