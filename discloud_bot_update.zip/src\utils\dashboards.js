const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, StringSelectMenuBuilder, StringSelectMenuOptionBuilder } = require('discord.js');
const db = require('../database/db');
const config = require('../../config.json');

/**
 * 1. Dashboard Support & Tickets (Fidèle à l'image fournie par l'utilisateur)
 */
async function createSupportTicketDashboard() {
  const stats = await db.getTicketStats();

  const embed = new EmbedBuilder()
    .setTitle('🏷️ Support')
    .setDescription('Notre équipe support est là pour t\'aider !\nOuvre un ticket et nous te répondrons dans les plus brefs délais.')
    .setColor('#5865F2')
    .setThumbnail('https://i.imgur.com/8QG4m3b.png')
    .addFields(
      {
        name: 'Motifs disponibles',
        value:
          ' Recrutement staff\n' +
          ' Demande de partenariat\n' +
          ' Création de gang\n' +
          ' Création d\'entreprise\n' +
          ' Report un staff\n' +
          ' Report un joueur\n' +
          ' Autres',
        inline: false
      },
      {
        name: 'Statistiques',
        value:
          ` Motifs disponibles — 7\n` +
          ` Tickets ouverts — ${stats.openCount}\n` +
          ` Tickets fermés — ${stats.closedCount}`,
        inline: false
      },
      {
        name: 'Ouvrir un ticket',
        value: ' Sélectionne un motif ci-dessous pour ouvrir un ticket.',
        inline: false
      }
    )
    .setFooter({ text: 'Aubagne RP • Centre Support & Recrutement' })
    .setTimestamp();

  const selectMenu = new StringSelectMenuBuilder()
    .setCustomId('select_ticket_category')
    .setPlaceholder('Sélectionner le motif de votre demande...')
    .addOptions(
      new StringSelectMenuOptionBuilder()
        .setLabel('Recrutement staff')
        .setDescription('Cliquer pour ouvrir un ticket')
        .setValue('Recrutement staff')
        .setEmoji('📝'),
      new StringSelectMenuOptionBuilder()
        .setLabel('Demande de partenariat')
        .setDescription('Cliquer pour ouvrir un ticket')
        .setValue('Demande de partenariat')
        .setEmoji('🤝'),
      new StringSelectMenuOptionBuilder()
        .setLabel('Création de gang')
        .setDescription('Cliquer pour ouvrir un ticket')
        .setValue('Création de gang')
        .setEmoji('🔫'),
      new StringSelectMenuOptionBuilder()
        .setLabel('Création d\'entreprise')
        .setDescription('Cliquer pour ouvrir un ticket')
        .setValue('Création d\'entreprise')
        .setEmoji('💼'),
      new StringSelectMenuOptionBuilder()
        .setLabel('Report un staff')
        .setDescription('Cliquer pour ouvrir un ticket')
        .setValue('Report un staff')
        .setEmoji('⚠️'),
      new StringSelectMenuOptionBuilder()
        .setLabel('Report un joueur')
        .setDescription('Cliquer pour ouvrir un ticket')
        .setValue('Report un joueur')
        .setEmoji('🚫'),
      new StringSelectMenuOptionBuilder()
        .setLabel('Autres')
        .setDescription('Cliquer pour ouvrir un ticket')
        .setValue('Autres')
        .setEmoji('❓')
    );

  const row = new ActionRowBuilder().addComponents(selectMenu);
  return { embeds: [embed], components: [row] };
}

/**
 * 2. Interface à boutons à l'intérieur d'un ticket ouvert (Bouton Assistant IA retiré car l'IA répond directement)
 */
function createTicketChannelInterface(user, category) {
  const isRecruitment = category && category.toLowerCase().includes('recrutement');

  const embed = new EmbedBuilder()
    .setTitle(`📩 TICKET OUVERT • ${category.toUpperCase()}`)
    .setDescription(
      `Bienvenue <@${user.id}> dans votre espace d'assistance privé.\n\n` +
      `📌 **Motif** : \`${category}\`\n` +
      `👤 **Demandeur** : <@${user.id}>\n` +
      `⏳ **Statut** : En attente de prise en charge par un membre du staff.\n\n` +
      (isRecruitment ? `📋 **IMPORTANT :** Cliquez sur le bouton vert **"Passer le test"** ci-dessous pour démarrer l'examen de 20 questions en direct (15 secondes par question) !\n\n` : '') +
      `🤖 *L'Assistant IA répond directement à vos questions ci-dessous.*`
    )
    .setColor('#5865F2')
    .setFooter({ text: 'Système de Ticket • Aubagne RP' })
    .setTimestamp();

  const components = [];

  if (isRecruitment) {
    const rowRecruitment = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('start_discord_staff_quiz')
        .setLabel('Passer le test (20 Questions - 15s/Q)')
        .setEmoji('📋')
        .setStyle(ButtonStyle.Success)
    );
    components.push(rowRecruitment);
  }

  const rowStandard = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('ticket_claim').setLabel('Prendre en charge').setEmoji('✋').setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId('ticket_transcript').setLabel('Transcrire').setEmoji('📋').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('ticket_close').setLabel('Fermer le ticket').setEmoji('🔒').setStyle(ButtonStyle.Danger)
  );
  components.push(rowStandard);

  return { embeds: [embed], components };
}


/**
 * 3. Dashboard Service (Bus, Camionneur, Police, Pompiers, EMS, ADAC)
 */
function createServiceDashboard() {
  const embed = new EmbedBuilder()
    .setTitle('🚨 DASHBOARD GÉNÉRAL • AUBAGNE RP OFFICIEL')
    .setDescription(
      'Bienvenue sur le centre de contrôle interactif de la ville d\'**Aubagne RP**.\n\n' +
      'Cliquez sur les boutons ci-dessous pour gérer votre service RP, accumuler votre salaire et consulter votre profil !\n\n' +
      '🚌 **Bus (1.2x)** | 🚚 **Camionneur (1.2x)** | 🚓 **Police (1.2x)** | 🚒 **Pompiers (1.0x)** | 🚑 **EMS (1.2x)** | 🛞 **ADAC (1.3x)**\n\n' +
      '🔴 **Fin de Service** : Clôturer votre service et recevoir votre **salaire bancaire direct** !\n' +
      '📊 **Mes Stats** : Voir vos heures de service cumulées\n' +
      '🏆 **Classement** : Top 10 des agents les plus actifs'
    )
    .setColor(config.colors.police)
    .setThumbnail('https://i.imgur.com/8QG4m3b.png')
    .setFooter({ text: 'Aubagne RP Officiel • Prise de Service & Salaires' })
    .setTimestamp();

  const row1 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('service_bus').setLabel('Bus (1.2x)').setEmoji('🚌').setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId('service_camion').setLabel('Camionneur (1.2x)').setEmoji('🚚').setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId('service_police').setLabel('Police (1.2x)').setEmoji('🚓').setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId('service_fire').setLabel('Pompiers (1x)').setEmoji('🚒').setStyle(ButtonStyle.Danger),
    new ButtonBuilder().setCustomId('service_ems').setLabel('EMS (1.2x)').setEmoji('🚑').setStyle(ButtonStyle.Success)
  );

  const row2 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('service_adac').setLabel('ADAC (1.3x)').setEmoji('🛞').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('service_stop').setLabel('Fin de Service & Paie').setEmoji('🔴').setStyle(ButtonStyle.Danger),
    new ButtonBuilder().setCustomId('btn_my_stats').setLabel('Mes Stats').setEmoji('📊').setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId('btn_leaderboard').setLabel('Leaderboard').setEmoji('🏆').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('btn_my_id').setLabel('Carte ID RP').setEmoji('🪪').setStyle(ButtonStyle.Success)
  );

  return { embeds: [embed], components: [row1, row2] };
}

/**
 * 3b. Dashboard Casino & Mini-Jeux d'Argent (#commande-bot)
 */
function createGamesDashboard() {
  const embed = new EmbedBuilder()
    .setTitle('🎰 CASINO & MINI-JEUX D\'ARGENT • AUBAGNE RP OFFICIEL')
    .setDescription(
      `Bienvenue sur le centre de mini-jeux interactifs de **Aubagne RP Officiel** !\n\n` +
      `Gagnez de l'argent virtuel en jouant aux mini-jeux ci-dessous. **Toutes vos actions et gains sont 100% confidentiels et visibles uniquement par vous !**\n\n` +
      `🎰 **Machine à sous** : Misez votre argent et tentez le Jackpot x5 !\n` +
      `🪙 **Pile ou Face** : Misez sur Pile ou Face et doublez votre mise !\n` +
      `💼 **Travailler** : Effectuez un petit boulot pour gagner entre 50€ et 200€ (Toutes les heures)\n` +
      `🎁 **Récompense 24h** : Réclamez votre bonus quotidien de 500€ !\n` +
      `💳 **Mon Solde** : Consultez votre solde bancaire et vos statistiques.`
    )
    .setColor('#F1C40F')
    .setThumbnail('https://i.imgur.com/8QG4m3b.png')
    .setFooter({ text: 'Aubagne RP • Mini-Jeux Confidentiels (Éphémères)' })
    .setTimestamp();

  const row1 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('btn_game_slots_prompt').setLabel('Machine à sous').setEmoji('🎰').setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId('btn_game_coinflip_prompt').setLabel('Pile ou Face').setEmoji('🪙').setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId('btn_game_work').setLabel('Travailler (1h)').setEmoji('💼').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('btn_game_daily').setLabel('Bonus 24h').setEmoji('🎁').setStyle(ButtonStyle.Danger),
    new ButtonBuilder().setCustomId('btn_game_balance').setLabel('Mon Solde').setEmoji('💳').setStyle(ButtonStyle.Primary)
  );

  return { embeds: [embed], components: [row1] };
}


/**
 * 4. Dashboard Roblox Verification & Link
 */
function createRobloxDashboard() {
  const embed = new EmbedBuilder()
    .setTitle('🎮 VÉRIFICATION & LIAISON COMPTE ROBLOX')
    .setDescription(
      'Associez votre compte Roblox avec votre profil Discord pour le serveur **Emergency Hamburg RP** !\n\n' +
      '👉 Cliquez sur **🔗 Lier mon Compte Roblox** et entrez votre **Nom d\'utilisateur Roblox**.\n\n' +
      '✅ Votre pseudo Roblox apparaîtra sur votre carte d\'identité RP et vos fiches de service.'
    )
    .setColor(config.colors.roblox || '#E2231A')
    .setThumbnail('https://i.imgur.com/8QG4m3b.png')
    .setFooter({ text: 'Emergency Hamburg RP • Liaison Roblox' })
    .setTimestamp();

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('btn_link_roblox_prompt').setLabel('Lier mon Compte Roblox').setEmoji('🔗').setStyle(ButtonStyle.Danger),
    new ButtonBuilder().setCustomId('btn_view_roblox').setLabel('Voir mon Compte Lié').setEmoji('👤').setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId('btn_unlink_roblox').setLabel('Délier mon Compte').setEmoji('❌').setStyle(ButtonStyle.Secondary)
  );

  return { embeds: [embed], components: [row] };
}

/**
 * 5. Dashboard 911 & Urgences
 */
function create911Dashboard() {
  const embed = new EmbedBuilder()
    .setTitle('📞 CENTRALE D\'URGENCE 911 & RADIO')
    .setDescription(
      'Besoin des secours ou d\'envoyer une alerte en ville ?\n\n' +
      'Cliquez sur le service concerné pour ouvrir un formulaire d\'urgence instantané.\n\n' +
      '🚓 **911 Police** | 🚒 **911 Pompiers** | 🚑 **911 EMS** | 🛞 **911 ADAC**\n' +
      '⚠️ **Code 10-33** : Alerte urgence critique sur la fréquence'
    )
    .setColor(config.colors.danger)
    .setThumbnail('https://i.imgur.com/2X8K7lZ.png')
    .setFooter({ text: 'Hamburg RP • Centrale Urgences' })
    .setTimestamp();

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('btn_911_police').setLabel('Urgence Police').setEmoji('🚓').setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId('btn_911_fire').setLabel('Urgence Pompiers').setEmoji('🚒').setStyle(ButtonStyle.Danger),
    new ButtonBuilder().setCustomId('btn_911_ems').setLabel('Urgence EMS').setEmoji('🚑').setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId('btn_911_adac').setLabel('Urgence ADAC').setEmoji('🛞').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('btn_radio_1033').setLabel('Alerte 10-33').setEmoji('⚠️').setStyle(ButtonStyle.Danger)
  );

  return { embeds: [embed], components: [row] };
}

/**
 * 6. Dashboard Police & Justice
 */
function createPoliceDashboard() {
  const embed = new EmbedBuilder()
    .setTitle('⚖️ TERMINAL POLICE & JUSTICE • HAMBURG')
    .setDescription(
      'Panneau réservé aux forces de l\'ordre et services de justice pour la gestion criminelle.\n\n' +
      '🚨 **Placer en Wanted** : Formulaire pour avis de recherche\n' +
      '📜 **Liste Recherchés** : Consulter les criminels en fuite\n' +
      '💵 **Délivrer Amende** : Formulaire pour amende RP\n' +
      '📁 **Consulter Casier** : Historique d\'un citoyen\n' +
      '🛞 **Fourrière** : Déclarer un véhicule saisi\n' +
      '🌐 **Darkweb Anonyme** : Publication réseau illégal'
    )
    .setColor(config.colors.police)
    .setFooter({ text: 'Hamburg RP • Terminal Police' })
    .setTimestamp();

  const row1 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('btn_police_wanted').setLabel('Avis de Recherche').setEmoji('🚨').setStyle(ButtonStyle.Danger),
    new ButtonBuilder().setCustomId('btn_police_unwanted').setLabel('Retirer Wanted').setEmoji('✅').setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId('btn_police_wanted_list').setLabel('Liste Wanted').setEmoji('📜').setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId('btn_police_amende').setLabel('Donner Amende').setEmoji('💵').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('btn_police_casier').setLabel('Consulter Casier').setEmoji('📁').setStyle(ButtonStyle.Secondary)
  );

  const row2 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('btn_police_fourriere').setLabel('Fourrière ADAC').setEmoji('🛞').setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId('btn_darkweb_post').setLabel('Poster Darkweb').setEmoji('🌐').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('btn_braquage_alert').setLabel('Alerte Braquage').setEmoji('🏦').setStyle(ButtonStyle.Danger),
    new ButtonBuilder().setCustomId('btn_joint_dispatch').setLabel('Radio Inter-Services').setEmoji('📡').setStyle(ButtonStyle.Primary)
  );

  return { embeds: [embed], components: [row1, row2] };
}

/**
 * 7. Dashboard Demande de Modérateur / Assistance Staff
 */
function createModRequestDashboard() {
  const embed = new EmbedBuilder()
    .setTitle('🛡️ DEMANDE DE MODÉRATEUR • ASSISTANCE STAFF')
    .setDescription(
      'Besoin de l\'intervention d\'un modérateur ou membre du staff en jeu ou sur Discord ?\n\n' +
      '👉 Cliquez sur **🛡️ Demander un Modérateur** ci-dessous pour transmettre votre alerte aux équipes en service.\n\n' +
      '📌 **Important** : Votre demande sera envoyée directement dans le salon de modération dédié avec vos informations RP et votre motif.'
    )
    .setColor('#ED4245')
    .setThumbnail('https://i.imgur.com/8QG4m3b.png')
    .setFooter({ text: 'Aubagne RP • Centrale d\'Appel Modération' })
    .setTimestamp();

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('btn_request_modo_prompt')
      .setLabel('Demander un Modérateur')
      .setEmoji('🛡️')
      .setStyle(ButtonStyle.Danger)
  );

  return { embeds: [embed], components: [row] };
}

/**
 * 8. Dashboard Pompiers / Feuerwehr
 */
function createFireDashboard() {
  const embed = new EmbedBuilder()
    .setTitle('🚒 CENTRALE DES SAPEURS-POMPIERS • FEUERWEHR')
    .setDescription(
      'Panneau de contrôle et gestion des interventions incendie, risques chimiques et secours de la ville.\n\n' +
      '📝 **Rapport d\'Intervention** : Fiche de fin d\'intervention\n' +
      '🔥 **Alerte Incendie Majeur** : Code Rouge Incendie/Accident\n' +
      '⛽ **Essence / Carburant Route** : Épandage d\'absorbant & dépollution\n' +
      '📦 **Objets / Chargement Tombé** : Évacuation d\'obstacle de camion\n' +
      '🧯 **Inspection Sécurité** : Vérification d\'établissement\n' +
      '🚑 **Renfort EMS** : Demande d\'ambulance médicale\n' +
      '📡 **Radio Inter-Services** : Opérations conjointes (Police, Pompiers, HARS)'
    )
    .setColor(config.colors.fire || '#D32F2F')
    .setThumbnail('https://i.imgur.com/8QG4m3b.png')
    .setFooter({ text: 'Aubagne RP • Terminal Sapeurs-Pompiers' })
    .setTimestamp();

  const row1 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('btn_fire_report').setLabel('Rapport Intervention').setEmoji('📝').setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId('btn_fire_alert').setLabel('Alerte Incendie').setEmoji('🔥').setStyle(ButtonStyle.Danger),
    new ButtonBuilder().setCustomId('btn_fire_inspection').setLabel('Inspection Sécurité').setEmoji('🧯').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('btn_fire_ems').setLabel('Renfort EMS').setEmoji('🚑').setStyle(ButtonStyle.Success)
  );

  const row2 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('btn_fire_fuel').setLabel('Essence / Carburant Route').setEmoji('⛽').setStyle(ButtonStyle.Danger),
    new ButtonBuilder().setCustomId('btn_fire_debris').setLabel('Objets / Chargement Tombé').setEmoji('📦').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('btn_joint_dispatch').setLabel('Radio Inter-Services').setEmoji('📡').setStyle(ButtonStyle.Primary)
  );

  return { embeds: [embed], components: [row1, row2] };
}

/**
 * 9. Dashboard HARS / ADAC / Dépannage & Secours
 */
function createHarsDashboard() {
  const embed = new EmbedBuilder()
    .setTitle('🛠️ TERMINAL HARS & ADAC • DÉPANNAGE & SECOURS')
    .setDescription(
      'Panneau de contrôle et gestion des opérations d\'assistance routière, infrastructure et secours HARS/ADAC.\n\n' +
      '🛞 **Rapport de Dépannage** : Intervention mécanique & remorquage\n' +
      '🛠️ **Demande Remorquage** : Évacuation d\'urgence de véhicule\n' +
      '🚦 **Feux Tricolores Cassés** : Signalement & réparation de feux tricolores\n' +
      '🚂 **Barrières Train / PN Cassées** : Panne/Casse des barrières de sécurité du train\n' +
      '🚑 **Fiche Soins EMS** : Fiche médicale d\'admission citoyen\n' +
      '🚨 **Alerte Voie Bloquée** : Balisage d\'accident & zone dangereuse\n' +
      '📡 **Radio Inter-Services** : Opérations conjointes (Police, Pompiers, HARS)'
    )
    .setColor(config.colors.adac || '#F57C00')
    .setThumbnail('https://i.imgur.com/8QG4m3b.png')
    .setFooter({ text: 'Aubagne RP • Terminal HARS & ADAC' })
    .setTimestamp();

  const row1 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('btn_hars_report').setLabel('Rapport Dépannage').setEmoji('🛞').setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId('btn_hars_tow').setLabel('Demande Remorquage').setEmoji('🛠️').setStyle(ButtonStyle.Danger),
    new ButtonBuilder().setCustomId('btn_hars_medical').setLabel('Fiche Soins EMS').setEmoji('🚑').setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId('btn_hars_hazard').setLabel('Alerte Voie Bloquée').setEmoji('🚨').setStyle(ButtonStyle.Secondary)
  );

  const row2 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('btn_hars_traffic_light').setLabel('Feux Tricolores Cassés').setEmoji('🚦').setStyle(ButtonStyle.Danger),
    new ButtonBuilder().setCustomId('btn_hars_train_barrier').setLabel('Barrières Train Cassées').setEmoji('🚂').setStyle(ButtonStyle.Danger),
    new ButtonBuilder().setCustomId('btn_joint_dispatch').setLabel('Radio Inter-Services').setEmoji('📡').setStyle(ButtonStyle.Primary)
  );

  return { embeds: [embed], components: [row1, row2] };
}

/**
 * 10. Dashboard Télévision & Médias (Hamburg News / TV RP)
 */
function createTvDashboard() {
  const embed = new EmbedBuilder()
    .setTitle('📺 HAMBURG NEWS • CENTRALE MÉDIAS & JOURNAL TÉLÉVISÉ')
    .setDescription(
      'Panneau officiel de la rédaction et chaîne d\'information de la ville.\n\n' +
      '🔴 **Flash Info Urgent** : Diffuser un direct d\'information prioritaire\n' +
      '📺 **Publier Journal / Reportage** : Rédiger et diffuser une édition d\'actualités\n' +
      '🎤 **Demande d\'Interview** : Solliciter un entretien avec une personnalité RP\n' +
      '📸 **Appel à Témoins** : Rechercher des informations ou témoignages citoyens'
    )
    .setColor('#9C27B0')
    .setThumbnail('https://i.imgur.com/8QG4m3b.png')
    .setFooter({ text: 'Aubagne RP • Hamburg TV & Journal RP' })
    .setTimestamp();

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('btn_tv_breaking').setLabel('Flash Info Urgent').setEmoji('🔴').setStyle(ButtonStyle.Danger),
    new ButtonBuilder().setCustomId('btn_tv_news').setLabel('Publier Reportage').setEmoji('📺').setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId('btn_tv_interview').setLabel('Demande Interview').setEmoji('🎤').setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId('btn_tv_witness').setLabel('Appel à Témoins').setEmoji('📸').setStyle(ButtonStyle.Secondary)
  );

  return { embeds: [embed], components: [row] };
}

/**
 * 12. Dashboard de Recherche & Correspondance Joueur (Discord <-> Roblox)
 */
function createLookupDashboard() {
  const embed = new EmbedBuilder()
    .setTitle('🔍 RECHERCHE DE JOUEUR • DISCORD ↔ ROBLOX')
    .setDescription(
      `Bienvenue sur le centre de recherche d'identité d'**Aubagne RP Officiel** !\n\n` +
      `Saisissez un **pseudo Discord**, une **mention**, un **ID Discord** OU un **pseudo Roblox** pour connaître immédiatement la correspondance du joueur !\n\n` +
      `📌 **Exemples de recherche :**\n` +
      `• Entrez \`@Citoyen\` ou \`123456789\` ➔ Affiche son compte Roblox lié\n` +
      `• Entrez \`RobloxUser123\` ➔ Affiche le membre Discord correspondant\n\n` +
      `🔒 *Toutes vos recherches sont 100% confidentielles et visibles uniquement par vous !*`
    )
    .setColor('#3498DB')
    .setThumbnail('https://i.imgur.com/8QG4m3b.png')
    .setFooter({ text: 'Aubagne RP Officiel • Système de Recherche Discord ↔ Roblox' })
    .setTimestamp();

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('btn_lookup_prompt')
      .setLabel('Rechercher un Joueur')
      .setEmoji('🔍')
      .setStyle(ButtonStyle.Primary)
  );

  return { embeds: [embed], components: [row] };
}

module.exports = {
  createSupportTicketDashboard,
  createTicketChannelInterface,
  createServiceDashboard,
  createRobloxDashboard,
  create911Dashboard,
  createPoliceDashboard,
  createModRequestDashboard,
  createFireDashboard,
  createHarsDashboard,
  createTvDashboard,
  createGamesDashboard,
  createLookupDashboard
};


