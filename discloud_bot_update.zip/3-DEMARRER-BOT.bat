@echo off
title Demarrage du Bot Discord
echo ======================================================
echo   3. Demarrage du Bot Discord Emergency Hamburg RP
echo ======================================================
call npm start
echo.
pause
