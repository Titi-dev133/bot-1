const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const db = require('../database/db');
const { antiRaidDashboardEmbed } = require('../utils/embeds');
const { sendAuditLog, triggerRaidAlert } = require('../utils/auditLogger');

module.exports = [
  {
    data: new SlashCommandBuilder()
      .setName('antiraid')
      .setDescription('🛡️ Panneau de configuration et contrôle Anti-Raid / Sécurité du serveur')
      .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
      .addSubcommand(sub =>
        sub
          .setName('setup')
          .setDescription('Déployer le Panneau de Sécurité Anti-Raid et Backup dans ce salon')
      )
      .addSubcommand(sub =>
        sub
          .setName('status')
          .setDescription('Consulter l\'état actuel de la sécurité et des protections Anti-Raid')
      )
      .addSubcommand(sub =>
        sub
          .setName('lockdown')
          .setDescription('Activer ou désactiver immédiatement le mode Lockdown (Verrouillage d\'urgence)')
          .addStringOption(opt =>
            opt
              .setName('mode')
              .setDescription('Activer (on) ou Désactiver (off) le Lockdown')
              .setRequired(true)
              .addChoices(
                { name: '🔒 Activer Lockdown (Verrouiller le serveur)', value: 'on' },
                { name: '🔓 Désactiver Lockdown (Déverrouiller le serveur)', value: 'off' }
              )
          )
      )
      .addSubcommand(sub =>
        sub
          .setName('test')
          .setDescription('🧪 Simuler une alerte de raid pour tester le salon #alerte-raid et les pings')
      ),

    async execute(interaction) {
      const subcommand = interaction.options.getSubcommand();
      const guildId = interaction.guild.id;

      if (subcommand === 'setup') {
        await interaction.deferReply({ ephemeral: true });

        const cfg = await db.getAntiRaidConfig(guildId);
        const lastBackup = await db.getLastBackup(guildId);
        const panelData = antiRaidDashboardEmbed(cfg, lastBackup);

        const msg = await interaction.channel.send(panelData);
        await db.saveAntiRaidDashboard(guildId, interaction.channel.id, msg.id);

        await interaction.editReply({
          content: `✅ **Panneau Anti-Raid & Sécurité déployé avec succès** dans ${interaction.channel} !`
        });
      } else if (subcommand === 'status') {
        const cfg = await db.getAntiRaidConfig(guildId);
        const lastBackup = await db.getLastBackup(guildId);
        const panelData = antiRaidDashboardEmbed(cfg, lastBackup);

        await interaction.reply({ embeds: panelData.embeds, ephemeral: true });
      } else if (subcommand === 'lockdown') {
        const mode = interaction.options.getString('mode');
        const isLockdown = mode === 'on';

        await db.updateAntiRaidConfig(guildId, { lockdown: isLockdown ? 1 : 0 });

        const cfg = await db.getAntiRaidConfig(guildId);
        const lastBackup = await db.getLastBackup(guildId);

        // Update active dashboard if any
        const dbPanel = await db.getAntiRaidDashboard(guildId);
        if (dbPanel) {
          try {
            const ch = await interaction.guild.channels.fetch(dbPanel.channelId);
            if (ch) {
              const msg = await ch.messages.fetch(dbPanel.messageId);
              if (msg) {
                await msg.edit(antiRaidDashboardEmbed(cfg, lastBackup));
              }
            }
          } catch (e) {}
        }

        // Audit Log
        const auditEmbed = {
          title: isLockdown ? '🚨 LOG AUDIT SÉCURITÉ : MODE LOCKDOWN ACTIVÉ' : '🔓 LOG AUDIT SÉCURITÉ : MODE LOCKDOWN DÉSACTIVÉ',
          color: isLockdown ? '#E53935' : '#43A047',
          fields: [
            { name: '👮 Administrateur', value: `<@${interaction.user.id}> (\`${interaction.user.tag}\`)`, inline: true },
            { name: '📌 Statut', value: isLockdown ? '🔒 **Serveur Verrouillé** (Nouvelles arrivées bloquées)' : '🔓 **Serveur Déverrouillé**', inline: true }
          ],
          timestamp: new Date()
        };

        await sendAuditLog(interaction.guild, auditEmbed);

        await interaction.reply({
          content: isLockdown
            ? `🚨 **MODE LOCKDOWN ACTIVÉ !** Toutes les nouvelles arrivées sont désormais immédiatement bloquées.`
            : `🔓 **MODE LOCKDOWN DÉSACTIVÉ !** Le serveur accepte à nouveau les nouveaux arrivants.`
        });
      } else if (subcommand === 'test') {
        await interaction.deferReply({ ephemeral: true });

        await triggerRaidAlert(interaction.guild, {
          reason: '🧪 Simulation / Test Alerte Raid',
          details: `Test manuel de vérification du système d'alerte émis par l'administrateur <@${interaction.user.id}>.\nLe salon #alerte-raid et le log dans #log-serveur ont été mis à jour avec succès.`,
          joinCount: 5,
          isTest: true,
          user: interaction.user
        });

        await interaction.editReply({
          content: `🧪 **Test d'alerte de raid émis avec succès !**\nConsultez le salon **#alerte-raid** et **#log-serveur** pour vérifier la notification.`
        });
      }
    }
  }
];
