const { SlashCommandBuilder, PermissionFlagsBits, ChannelType, MessageFlags } = require('discord.js');
const { staffServiceDashboardEmbed, staffLeaderboardEmbed, formatMsDuration } = require('../utils/embeds');
const db = require('../database/db');

module.exports = [
  {
    data: new SlashCommandBuilder()
      .setName('service-staff')
      .setDescription('Système de prise de service et de classement pour l\'équipe de Modération.')
      .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
      .addSubcommand(sub =>
        sub.setName('dashboard')
           .setDescription('Publie le panneau interactif de Prise de Service Staff dans ce salon.')
      )
      .addSubcommand(sub =>
        sub.setName('classement-panel')
           .setDescription('Publie le classement auto-rafraîchissant des heures de modération.')
      )
      .addSubcommand(sub =>
        sub.setName('stats')
           .setDescription('Consulter les heures de modération d\'un membre de l\'équipe staff.')
           .addUserOption(opt => opt.setName('staff').setDescription('Membre du staff ciblé').setRequired(false))
      ),

    async execute(interaction) {
      const subcommand = interaction.options.getSubcommand();
      const { guild, channel, user } = interaction;

      // Subcommand 1: dashboard
      if (subcommand === 'dashboard') {
        const activeServices = await db.getAllActiveStaffServices(guild.id);
        const payload = staffServiceDashboardEmbed(activeServices.length);
        await channel.send(payload);

        return interaction.reply({
          content: `✅ **Panneau de Prise de Service Staff publié dans ${channel} !**`,
          flags: MessageFlags.Ephemeral
        });
      }

      // Subcommand 2: classement-panel
      if (subcommand === 'classement-panel') {
        await interaction.deferReply({ flags: MessageFlags.Ephemeral });

        const leaderboardData = await db.getStaffServiceLeaderboard(guild.id, 10);
        const embed = staffLeaderboardEmbed(leaderboardData);

        const newMsg = await channel.send({ embeds: [embed] });
        await db.saveStaffLeaderboardConfig(guild.id, channel.id, newMsg.id);

        return interaction.editReply({
          content: `🏆 **Message de classement auto-rafraîchissant configuré avec succès dans ${channel} !** Il se mettra à jour à chaque fin de service staff.`
        });
      }

      // Subcommand 3: stats
      if (subcommand === 'stats') {
        await interaction.deferReply({ flags: MessageFlags.Ephemeral });
        const targetUser = interaction.options.getUser('staff') || user;

        const stats = await db.getStaffServiceStats(guild.id, targetUser.id);
        const activeSession = await db.getActiveStaffService(guild.id, targetUser.id);

        let currentStatus = '🔴 Hors service';
        if (activeSession) {
          currentStatus = activeSession.status === 'active' ? '🟢 En service' : '☕ En pause';
        }

        return interaction.editReply({
          content: `📊 **Statistiques de Modération Staff — ${targetUser.username}**\n\n` +
            `👤 **Membre** : ${targetUser} (\`${targetUser.id}\`)\n` +
            `📌 **Statut actuel** : ${currentStatus}\n` +
            `⏱️ **Temps Total de Modération** : \`${formatMsDuration(stats.totalTimeMs)}\`\n` +
            `🔢 **Nombre de Gardes** : \`${stats.totalShifts}\``
        });
      }
    }
  }
];
