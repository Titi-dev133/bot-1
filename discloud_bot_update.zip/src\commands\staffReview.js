const { SlashCommandBuilder, PermissionFlagsBits, ChannelType, MessageFlags } = require('discord.js');
const { staffReviewDashboardEmbed, staffReviewCardEmbed, staffReviewDeletionLogEmbed } = require('../utils/embeds');
const db = require('../database/db');

module.exports = [
  {
    data: new SlashCommandBuilder()
      .setName('avis-staff')
      .setDescription('Système de dashboard d\'avis et de notation pour l\'équipe de modération.')
      .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
      .addSubcommand(sub =>
        sub.setName('dashboard')
           .setDescription('Publie le panneau d\'Avis Staff dans ce salon (avec le bouton "Donner un avis").')
      )
      .addSubcommand(sub =>
        sub.setName('stats')
           .setDescription('Consulter la moyenne des notes et la liste des avis reçus par le staff.')
           .addUserOption(opt =>
             opt.setName('staff')
                .setDescription('Membre du staff à consulter (optionnel)')
                .setRequired(false)
           )
      )
      .addSubcommand(sub =>
        sub.setName('supprimer')
           .setDescription('Supprimer un ou plusieurs avis sur un membre du staff.')
           .addStringOption(opt =>
             opt.setName('staff')
                .setDescription('Membre du staff (Mention / Pseudo / ID)')
                .setRequired(true)
           )
           .addStringOption(opt =>
             opt.setName('numero')
                .setDescription('Numéro de l\'avis à supprimer (ex: 1, 2) ou "tout"')
                .setRequired(true)
           )
      ),

    async execute(interaction) {
      const subcommand = interaction.options.getSubcommand();
      const { guild, channel, user, member } = interaction;

      // 1. Subcommand: dashboard
      if (subcommand === 'dashboard') {
        const payload = staffReviewDashboardEmbed();
        await channel.send(payload);

        return interaction.reply({
          content: `✅ **Panneau d'Avis Staff publié avec succès dans ${channel} !**`,
          flags: MessageFlags.Ephemeral
        });
      }

      // 2. Subcommand: stats
      if (subcommand === 'stats') {
        await interaction.deferReply({ flags: MessageFlags.Ephemeral });

        const targetUser = interaction.options.getUser('staff');
        const targetId = targetUser ? targetUser.id : null;

        const stats = await db.getStaffReviewStats(guild.id, targetId);
        const reviews = await db.getStaffReviews(guild.id, targetId);

        let ratingStars = '⭐'.repeat(Math.round(stats.avgRating)) + '☆'.repeat(5 - Math.round(stats.avgRating));

        let responseText = `📊 **Statistiques des Avis Staff — ${targetUser ? targetUser.username : 'Général'}**\n\n` +
          `⭐ **Note Moyenne** : **${stats.avgRating} / 5** (${ratingStars})\n` +
          `📝 **Nombre Total d'Avis** : \`${stats.totalReviews}\` avis enregistrés\n\n`;

        if (reviews.length > 0) {
          responseText += `📜 **Derniers avis reçus (max 5) :**\n`;
          const recent = reviews.slice(0, 5);
          recent.forEach((r, idx) => {
            const stars = '⭐'.repeat(r.rating) + '☆'.repeat(5 - r.rating);
            const author = r.isAnonymous ? '🕵️ *Anonyme*' : `<@${r.authorId}>`;
            const staff = r.staffUserId ? `<@${r.staffUserId}>` : `\`${r.staffQuery}\``;
            responseText += `**${idx + 1}.** Pour ${staff} — Note: ${stars} (${r.rating}/5) par ${author}\n` +
              `💬 *" ${r.comment} "*\n\n`;
          });
        } else {
          responseText += `*Aucun avis n'a été soumis pour le moment.*`;
        }

        return interaction.editReply({ content: responseText });
      }

      // 3. Subcommand: supprimer
      if (subcommand === 'supprimer') {
        await interaction.deferReply({ flags: MessageFlags.Ephemeral });

        // Check Ping Fondation Role
        const hasFondationRole = member && (
          member.permissions.has(PermissionFlagsBits.Administrator) ||
          member.roles.cache.some(r =>
            r.name.toLowerCase() === 'ping fondation' ||
            r.name.toLowerCase() === 'fondation' ||
            r.name.toLowerCase().includes('ping fondation')
          )
        );

        if (!hasFondationRole) {
          return interaction.editReply({
            content: '❌ **Permission refusée !** Seuls les membres possédant le rôle **Ping Fondation** sont autorisés à supprimer un avis staff.'
          });
        }

        const staffQuery = interaction.options.getString('staff').trim();
        const targetStr = interaction.options.getString('numero').trim().toLowerCase();

        const reviews = await db.getStaffReviews(guild.id, staffQuery);

        if (!reviews || reviews.length === 0) {
          return interaction.editReply({
            content: `❌ Aucun avis trouvé à supprimer pour **${staffQuery}**.`
          });
        }

        const staffKey = reviews[0].staffUserId || staffQuery.toLowerCase();
        const staffUserId = reviews[0].staffUserId;
        const staffUser = staffUserId ? await interaction.client.users.fetch(staffUserId).catch(() => null) : null;

        let logChannel = guild.channels.cache.find(
          c => c.type === ChannelType.GuildText && (
            c.name.toLowerCase() === 'log-avis-staff' ||
            c.name.toLowerCase() === 'logs-avis-staff' ||
            c.name.toLowerCase().includes('log-avis')
          )
        );

        let igLogChannel = guild.channels.cache.find(
          c => c.type === ChannelType.GuildText && (
            c.name.toLowerCase() === 'log-serveur-ig' ||
            c.name.toLowerCase() === 'logs-serveur-ig' ||
            c.name.toLowerCase().includes('log-serveur-ig')
          )
        );

        if (!igLogChannel) {
          try {
            const category = guild.channels.cache.find(c => c.type === ChannelType.GuildCategory && c.name.toLowerCase().includes('log'));
            igLogChannel = await guild.channels.create({
              name: 'log-serveur-ig',
              type: ChannelType.GuildText,
              parent: category ? category.id : undefined,
              topic: 'Logs d\'audit et de suppressions sur le serveur IG'
            });
          } catch (e) {}
        }

        if (targetStr === 'tout' || targetStr === 'all' || targetStr === '*') {
          await db.clearStaffReviews(guild.id, staffKey);

          const existingCard = await db.getStaffReviewCard(guild.id, staffKey);
          if (existingCard && logChannel) {
            try {
              const msg = await logChannel.messages.fetch(existingCard.messageId).catch(() => null);
              if (msg) await msg.delete().catch(() => {});
            } catch (e) {}
            await db.deleteStaffReviewCard(guild.id, staffKey);
          }

          if (igLogChannel) {
            const auditEmbed = staffReviewDeletionLogEmbed({
              executorUser: user,
              staffUser,
              staffQuery,
              actionType: 'Purger / Effacer tous les avis staff',
              details: `Réinitialisation complète du dossier d'avis (${reviews.length} avis effacés).`
            });
            igLogChannel.send({ embeds: [auditEmbed] }).catch(() => {});
          }

          return interaction.editReply({
            content: `🗑️ **Tous les avis sur ${staffUser ? `<@${staffUser.id}>` : `\`${staffQuery}\``} ont été effacés avec succès !** La fiche du modérateur a été réinitialisée.`
          });
        }

        const idx = parseInt(targetStr, 10) - 1;
        if (isNaN(idx) || idx < 0 || idx >= reviews.length) {
          return interaction.editReply({
            content: `⚠️ Numéro d'avis invalide. Ce modérateur a **${reviews.length}** avis. Spécifiez un nombre entre \`1\` et \`${reviews.length}\`, ou \`tout\`.`
          });
        }

        const targetReview = reviews[idx];
        await db.removeStaffReviewRecord(targetReview.id);

        const remainingReviews = await db.getStaffReviews(guild.id, staffKey);
        const remainingStats = await db.getStaffReviewStats(guild.id, staffKey);

        const existingCard = await db.getStaffReviewCard(guild.id, staffKey);
        if (existingCard && logChannel) {
          if (remainingReviews.length > 0) {
            const cardEmbed = staffReviewCardEmbed({
              staffUser,
              staffQuery,
              reviewsList: remainingReviews,
              stats: remainingStats
            });
            try {
              const msg = await logChannel.messages.fetch(existingCard.messageId).catch(() => null);
              if (msg) await msg.edit({ embeds: [cardEmbed] });
            } catch (e) {}
          } else {
            try {
              const msg = await logChannel.messages.fetch(existingCard.messageId).catch(() => null);
              if (msg) await msg.delete().catch(() => {});
            } catch (e) {}
            await db.deleteStaffReviewCard(guild.id, staffKey);
          }
        }

        if (igLogChannel) {
          const stars = '⭐'.repeat(targetReview.rating) + '☆'.repeat(5 - targetReview.rating);
          const authorInfo = targetReview.isAnonymous ? `🕵️ Anonyme (ID: ${targetReview.authorId})` : `<@${targetReview.authorId}>`;
          const auditEmbed = staffReviewDeletionLogEmbed({
            executorUser: user,
            staffUser,
            staffQuery,
            actionType: `Suppression de l'avis #${idx + 1}`,
            details: `Note: ${stars} (${targetReview.rating}/5)\nAuteur: ${authorInfo}\nCommentaire: "${targetReview.comment}"`
          });
          igLogChannel.send({ embeds: [auditEmbed] }).catch(() => {});
        }

        return interaction.editReply({
          content: `🗑️ **L'avis #${idx + 1} sur ${staffUser ? `<@${staffUser.id}>` : `\`${staffQuery}\``} a été supprimé !** (Avis restants: **${remainingReviews.length}**)`
        });
      }
    }
  }
];
