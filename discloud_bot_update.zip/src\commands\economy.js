const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder, MessageFlags } = require('discord.js');
const db = require('../database/db');
const { createEmbed } = require('../utils/embeds');
const { createGamesDashboard } = require('../utils/dashboards');
const config = require('../../config.json');

module.exports = [
  // 1. /dashboard-jeux (Déploie le Panneau permanent du Casino et Mini-Jeux dans #commande-bot)
  {
    data: new SlashCommandBuilder()
      .setName('dashboard-jeux')
      .setDescription('Déployer le Panneau permanent de Jeux & Casino dans ce salon.')
      .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
    async execute(interaction) {
      const dashboard = createGamesDashboard();
      await interaction.reply({ content: '🚀 **Installation du Dashboard de Casino & Mini-Jeux...**', flags: MessageFlags.Ephemeral });
      await interaction.channel.send(dashboard);
    }
  },

  // 2. /commandes (Afficher toutes les commandes pour les joueurs)
  {
    data: new SlashCommandBuilder()
      .setName('commandes')
      .setDescription('Afficher la liste complète des commandes du serveur Aubagne RP Officiel (Confidentiel).'),
    async execute(interaction) {
      const embed = new EmbedBuilder()
        .setTitle('📜 CATALOGUE DES COMMANDES • AUBAGNE RP OFFICIEL')
        .setDescription(
          `Voici la liste complète des commandes disponibles pour tous les citoyens et agents d'**Aubagne RP Officiel** !\n\n` +
          `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`
        )
        .setColor('#5865F2')
        .addFields(
          {
            name: '🎮 ÉCONOMIE & JEUX CASINO (#commande-bot)',
            value:
              `🔹 \`/solde\` — Consulter votre solde bancaire (Éphémère)\n` +
              `🔹 \`/work\` — Effectuer un travail de 10 min (Gain 450 €)\n` +
              `🔹 \`/daily\` — Réclamer votre prime quotidienne (500 € / 24h)\n` +
              `🔹 \`/slots [mise]\` — Machine à sous Casino (Jackpot x5)\n` +
              `🔹 \`/coinflip [mise] [choix]\` — Parier sur Pile ou Face (x2)\n` +
              `🔹 \`/roulette [mise] [couleur]\` — Parier à la Roulette (x2 / Vert x14)\n` +
              `🔹 \`/virement [membre] [montant]\` — Virement bancaire à un citoyen`,
            inline: false
          },
          {
            name: '🚓 PRISE DE SERVICE & METIERS RP (Paie toutes les 10 min)',
            value:
              `🔹 \`/prise-de-service [métier]\` — Prendre son service (Bus, Camion, Police, Pompiers, EMS, ADAC)\n` +
              `🔹 \`/fin-de-service\` — Clôturer son service et recevoir son salaire\n` +
              `🔹 \`/service-stats\` — Consulter ses heures de service cumulées\n` +
              `🔹 \`/service-leaderboard\` — Afficher le Top 10 des agents les plus actifs\n` +
              `🔹 \`/patrouille-creer [nom] [véhicule]\` — Former une unité de patrouille\n` +
              `🔹 \`/patrouille-liste\` — Afficher la liste des patrouilles en ville`,
            inline: false
          },
          {
            name: '🪪 IDENTITÉ RP & COMPTE ROBLOX',
            value:
              `🔹 \`/carte-identite\` — Afficher sa carte d'identité RP officielle\n` +
              `🔹 \`/creer-profil [nom] [prénom] [âge]\` — Créer ou modifier son profil RP\n` +
              `🔹 \`/link-roblox [pseudo]\` — Lier son compte Roblox au serveur`,
            inline: false
          },
          {
            name: '🚨 911 & URGENCES',
            value:
              `🔹 \`/911 [localisation] [raison]\` — Lancer un appel d'urgence aux services de secours`,
            inline: false
          },
          {
            name: '💡 SUGGESTIONS & AUTRES',
            value:
              `🔹 \`/suggestion [titre] [détails]\` — Proposer une idée d'amélioration pour le serveur`,
            inline: false
          }
        )
        .setFooter({ text: 'Aubagne RP Officiel • Guide des Commandes' })
        .setTimestamp();

      await interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
    }
  },

  // 3. /panel-commandes (Déployer le panneau fixe d'affichage des commandes dans un salon)
  {
    data: new SlashCommandBuilder()
      .setName('panel-commandes')
      .setDescription('Déployer le panneau fixe d\'affichage des commandes dans ce salon.')
      .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
    async execute(interaction) {
      const embed = new EmbedBuilder()
        .setTitle('📜 CATALOGUE DES COMMANDES • AUBAGNE RP OFFICIEL')
        .setDescription(
          `Bienvenue sur le guide officiel des commandes d'**Aubagne RP Officiel** !\n\n` +
          `Consultez la liste des commandes ci-dessous ou utilisez le Dashboard interactif dans **#commande-bot**.`
        )
        .setColor('#5865F2')
        .setThumbnail('https://i.imgur.com/8QG4m3b.png')
        .addFields(
          {
            name: '🎮 ÉCONOMIE & JEUX CASINO (#commande-bot)',
            value:
              `🔹 \`/solde\` — Consulter votre solde bancaire en privé\n` +
              `🔹 \`/work\` — Travailler pour gagner 450€ (Toutes les 10 minutes)\n` +
              `🔹 \`/daily\` — Réclamer la prime quotidienne de 500€\n` +
              `🔹 \`/slots [mise]\` — Machine à sous (Gain x2 à x5)\n` +
              `🔹 \`/coinflip [mise] [choix]\` — Jeu du Pile ou Face (Gain x2)\n` +
              `🔹 \`/roulette [mise] [couleur]\` — Roulette Casino (Rouge/Noir x2, Vert x14)\n` +
              `🔹 \`/virement [membre] [montant]\` — Transfert d'argent entre citoyens`,
            inline: false
          },
          {
            name: '🚓 PRISE DE SERVICE & SALAIRES METIERS (Paie toutes les 10 min)',
            value:
              `🔹 \`/prise-de-service\` — Prendre son service RP\n` +
              `🔹 \`/fin-de-service\` — Fin de service & virement automatique de la paie\n` +
              `🔹 \`/service-stats\` — Voir vos heures de service cumulées\n` +
              `🔹 \`/service-leaderboard\` — Voir les agents les plus actifs`,
            inline: false
          },
          {
            name: '🪪 PROFIL RP & ROBLOX',
            value:
              `🔹 \`/carte-identite\` — Consulter sa carte ID\n` +
              `🔹 \`/link-roblox [pseudo]\` — Lier son compte Roblox`,
            inline: false
          }
        )
        .setFooter({ text: 'Aubagne RP Officiel • Centre des Commandes' })
        .setTimestamp();

      await interaction.reply({ content: '🚀 **Installation du Panneau des Commandes...**', flags: MessageFlags.Ephemeral });
      await interaction.channel.send({ embeds: [embed] });
    }
  },

  // 4. /solde (Consulter son compte en banque)
  {
    data: new SlashCommandBuilder()
      .setName('solde')
      .setDescription('Consulter votre solde bancaire et vos statistiques d\'économie (Confidentiel).'),
    async execute(interaction) {
      const userId = interaction.user.id;
      const balance = await db.getUserBalance(userId);

      const embed = createEmbed({
        title: `💳 COMPTE BANCAIRE • ${interaction.user.username}`,
        description:
          `💰 **Solde Bancaire Actuel** : \`${balance.toLocaleString('fr-FR')} €\`\n\n` +
          `📌 *Votre solde est mis à jour automatiquement lors de la fin de vos services RP et de vos victoires aux mini-jeux.*`,
        color: config.colors.gold,
        thumbnail: interaction.user.displayAvatarURL({ dynamic: true })
      });

      await interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
    }
  },

  // 5. /work (Travailler pour gagner 450€ - 10 min de cooldown)
  {
    data: new SlashCommandBuilder()
      .setName('work')
      .setDescription('Effectuer une mission de travail civile pour gagner 450€ (Toutes les 10 min).'),
    async execute(interaction) {
      const userId = interaction.user.id;
      const cooldown = await db.getCooldown(userId, 'work');

      if (cooldown > 0) {
        const minsLeft = Math.ceil(cooldown / 60000);
        return interaction.reply({
          content: `⏳ **Vous êtes fatigué(e) !** Vous devez attendre encore **${minsLeft} minute(s)** avant de pouvoir travailler à nouveau.`,
          flags: MessageFlags.Ephemeral
        });
      }

      const jobs = [
        'Livreur de pizzas pour le restaurant d\'Aubagne',
        'Nettoyeur de rues au centre-ville d\'Aubagne',
        'Mécanicien assistant au garage municipal',
        'Jardinier pour les parcs publics d\'Aubagne',
        'Caissier pour le supermarché local'
      ];

      const chosenJob = jobs[Math.floor(Math.random() * jobs.length)];
      const reward = 450; // 450€ toutes les 10 mins

      await db.addMoney(userId, reward);
      await db.setCooldown(userId, 'work', 600000); // 10 min
      const newBal = await db.getUserBalance(userId);

      const embed = createEmbed({
        title: '💼 MISSION DE TRAVAIL TERMINÉE',
        description:
          `🛠️ **Travail effectué** : ${chosenJob}\n` +
          `💵 **Salaire perçu** : \`+${reward} €\` (Tarif 10 min)\n\n` +
          `💰 **Nouveau Solde Bancaire** : \`${newBal.toLocaleString('fr-FR')} €\``,
        color: config.colors.success
      });

      await interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
    }
  },

  // 6. /daily (Récompense quotidienne de 500€ - 24h de cooldown)
  {
    data: new SlashCommandBuilder()
      .setName('daily')
      .setDescription('Réclamer votre récompense financière quotidienne de 500€ (Toutes les 24h).'),
    async execute(interaction) {
      const userId = interaction.user.id;
      const cooldown = await db.getCooldown(userId, 'daily');

      if (cooldown > 0) {
        const hoursLeft = Math.floor(cooldown / 3600000);
        const minsLeft = Math.ceil((cooldown % 3600000) / 60000);
        return interaction.reply({
          content: `⏳ **Déjà réclamé !** Revenez dans **${hoursLeft}h ${minsLeft}min** pour votre prochaine récompense quotidienne.`,
          flags: MessageFlags.Ephemeral
        });
      }

      const reward = 500;
      await db.addMoney(userId, reward);
      await db.setCooldown(userId, 'daily', 86400000); // 24h
      const newBal = await db.getUserBalance(userId);

      const embed = createEmbed({
        title: '🎁 RÉCOMPENSE QUOTIDIENNE VALIDÉE',
        description:
          `🎉 Vous avez réclamé votre bonus quotidien de **${reward} €** !\n\n` +
          `💰 **Nouveau Solde Bancaire** : \`${newBal.toLocaleString('fr-FR')} €\``,
        color: config.colors.gold
      });

      await interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
    }
  },

  // 7. /slots (Machine à sous)
  {
    data: new SlashCommandBuilder()
      .setName('slots')
      .setDescription('Miser de l\'argent sur la Machine à Sous du Casino (Jackpot x5 !).')
      .addIntegerOption(opt => opt.setName('mise').setDescription('Montant de votre mise en euros').setRequired(true).setMinValue(10)),
    async execute(interaction) {
      const userId = interaction.user.id;
      const bet = interaction.options.getInteger('mise');
      const balance = await db.getUserBalance(userId);

      if (balance < bet) {
        return interaction.reply({
          content: `❌ **Solde Insuffisant !** Vous possédez actuellement **${balance} €**, vous ne pouvez pas miser **${bet} €**.`,
          flags: MessageFlags.Ephemeral
        });
      }

      await db.removeMoney(userId, bet);

      const symbols = ['🍒', '🍋', '🍇', '💎', '7️⃣'];
      const slot1 = symbols[Math.floor(Math.random() * symbols.length)];
      const slot2 = symbols[Math.floor(Math.random() * symbols.length)];
      const slot3 = symbols[Math.floor(Math.random() * symbols.length)];

      let winAmount = 0;
      let multiplier = 0;

      if (slot1 === slot2 && slot2 === slot3) {
        multiplier = 5;
        winAmount = bet * multiplier;
      } else if (slot1 === slot2 || slot2 === slot3 || slot1 === slot3) {
        multiplier = 2;
        winAmount = bet * multiplier;
      }

      if (winAmount > 0) {
        await db.addMoney(userId, winAmount);
      }

      const newBal = await db.getUserBalance(userId);
      const isWin = winAmount > 0;

      const embed = createEmbed({
        title: '🎰 MACHINE À SOUS • CASINO',
        description:
          `🎰 [ **${slot1}** | **${slot2}** | **${slot3}** ] 🎰\n\n` +
          (isWin
            ? `🎉 **GAGNÉ !** ${multiplier === 5 ? '💥 **JACKPOT x5 !**' : '✨ **COMBINAISON DOUBLE x2 !**'}\n💵 Gain : **+${winAmount} €**`
            : `❌ **PERDU !** Vous avez perdu votre mise de **${bet} €**.\nRéessayez !`) +
          `\n\n💰 **Nouveau Solde** : \`${newBal.toLocaleString('fr-FR')} €\``,
        color: isWin ? config.colors.success : config.colors.danger
      });

      await interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
    }
  },

  // 8. /coinflip (Pile ou Face)
  {
    data: new SlashCommandBuilder()
      .setName('coinflip')
      .setDescription('Miser sur Pile ou Face et tenter de doubler votre mise.')
      .addIntegerOption(opt => opt.setName('mise').setDescription('Montant à miser').setRequired(true).setMinValue(10))
      .addStringOption(opt =>
        opt.setName('choix')
          .setDescription('Votre prédiction')
          .setRequired(true)
          .addChoices({ name: '🪙 Pile', value: 'pile' }, { name: '🪙 Face', value: 'face' })
      ),
    async execute(interaction) {
      const userId = interaction.user.id;
      const bet = interaction.options.getInteger('mise');
      const choice = interaction.options.getString('choix');
      const balance = await db.getUserBalance(userId);

      if (balance < bet) {
        return interaction.reply({
          content: `❌ **Solde Insuffisant !** Votre solde est de **${balance} €**.`,
          flags: MessageFlags.Ephemeral
        });
      }

      await db.removeMoney(userId, bet);

      const result = Math.random() < 0.5 ? 'pile' : 'face';
      const isWin = choice === result;

      if (isWin) {
        await db.addMoney(userId, bet * 2);
      }

      const newBal = await db.getUserBalance(userId);

      const embed = createEmbed({
        title: '🪙 PILE OU FACE • CASINO',
        description:
          `🪙 La pièce s'est arrêtée sur : **${result.toUpperCase()}** !\n\n` +
          (isWin
            ? `🎉 **EXCELLENT !** Votre prédiction était correcte !\n💵 Gain perçu : **+${bet * 2} €** (+${bet}€ de bénéfice)`
            : `❌ **PERDU !** Vous avez parié sur ${choice.toUpperCase()} et la pièce est tombée sur ${result.toUpperCase()}.\nMise perdue : **${bet} €**`) +
          `\n\n💰 **Nouveau Solde** : \`${newBal.toLocaleString('fr-FR')} €\``,
        color: isWin ? config.colors.success : config.colors.danger
      });

      await interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
    }
  },

  // 9. /roulette (Roulette du Casino)
  {
    data: new SlashCommandBuilder()
      .setName('roulette')
      .setDescription('Miser à la Roulette du Casino sur une Couleur.')
      .addIntegerOption(opt => opt.setName('mise').setDescription('Montant de votre pari').setRequired(true).setMinValue(10))
      .addStringOption(opt =>
        opt.setName('couleur')
          .setDescription('Couleur choisie (Rouge, Noir ou Vert)')
          .setRequired(true)
          .addChoices(
            { name: '🔴 Rouge (Gain x2)', value: 'rouge' },
            { name: '⚫ Noir (Gain x2)', value: 'noir' },
            { name: '🟢 Vert / Zero (Gain x14)', value: 'vert' }
          )
      ),
    async execute(interaction) {
      const userId = interaction.user.id;
      const bet = interaction.options.getInteger('mise');
      const chosenColor = interaction.options.getString('couleur');
      const balance = await db.getUserBalance(userId);

      if (balance < bet) {
        return interaction.reply({
          content: `❌ **Solde Insuffisant !** Votre solde est de **${balance} €**.`,
          flags: MessageFlags.Ephemeral
        });
      }

      await db.removeMoney(userId, bet);

      // Tire un nombre de 0 à 36
      const number = Math.floor(Math.random() * 37);
      let landedColor = 'noir';
      if (number === 0) {
        landedColor = 'vert';
      } else if ([1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36].includes(number)) {
        landedColor = 'rouge';
      }

      const isWin = chosenColor === landedColor;
      let winAmount = 0;

      if (isWin) {
        const mult = landedColor === 'vert' ? 14 : 2;
        winAmount = bet * mult;
        await db.addMoney(userId, winAmount);
      }

      const newBal = await db.getUserBalance(userId);
      const colorEmoji = landedColor === 'rouge' ? '🔴' : landedColor === 'noir' ? '⚫' : '🟢';

      const embed = createEmbed({
        title: '🎡 ROULETTE DU CASINO',
        description:
          `🎡 La bille s'est arrêtée sur le numéro **${number}** (${colorEmoji} ${landedColor.toUpperCase()}) !\n\n` +
          (isWin
            ? `🎉 **VICTOIRE !** Vous aviez misé sur le ${chosenColor.toUpperCase()} !\n💵 Gain total : **+${winAmount} €**`
            : `❌ **PERDU !** La bille est tombée sur le ${colorEmoji} ${landedColor.toUpperCase()}.\nMise perdue : **${bet} €**`) +
          `\n\n💰 **Nouveau Solde** : \`${newBal.toLocaleString('fr-FR')} €\``,
        color: isWin ? config.colors.success : config.colors.danger
      });

      await interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
    }
  },

  // 10. /virement (Faire un transfert bancaire à un citoyen)
  {
    data: new SlashCommandBuilder()
      .setName('virement')
      .setDescription('Effectuer un virement bancaire vers un autre citoyen d\'Aubagne RP.')
      .addUserOption(opt => opt.setName('beneficiaire').setDescription('Membre destinataire du virement').setRequired(true))
      .addIntegerOption(opt => opt.setName('montant').setDescription('Montant en euros à transférer').setRequired(true).setMinValue(1)),
    async execute(interaction) {
      const senderId = interaction.user.id;
      const targetUser = interaction.options.getUser('beneficiaire');
      const amount = interaction.options.getInteger('montant');

      if (targetUser.bot || targetUser.id === senderId) {
        return interaction.reply({
          content: '❌ Vous ne pouvez pas effectuer un virement à vous-même ou à un bot.',
          flags: MessageFlags.Ephemeral
        });
      }

      const senderBal = await db.getUserBalance(senderId);
      if (senderBal < amount) {
        return interaction.reply({
          content: `❌ **Solde Insuffisant !** Vous possédez **${senderBal} €** et ne pouvez pas transférer **${amount} €**.`,
          flags: MessageFlags.Ephemeral
        });
      }

      await db.removeMoney(senderId, amount);
      await db.addMoney(targetUser.id, amount);

      const newSenderBal = await db.getUserBalance(senderId);

      const embed = createEmbed({
        title: '💸 VIREMENT BANCAIRE EFFECTUÉ',
        description:
          `✅ Vous avez transféré **${amount.toLocaleString('fr-FR')} €** à <@${targetUser.id}>.\n\n` +
          `💰 **Votre Nouveau Solde** : \`${newSenderBal.toLocaleString('fr-FR')} €\``,
        color: config.colors.success
      });

      await interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
    }
  },

  // 11. /give-argent (Owner / Fondateur Uniquement)
  {
    data: new SlashCommandBuilder()
      .setName('give-argent')
      .setDescription('(Fondateur / Owner Uniquement) Créditer de l\'argent à un joueur.')
      .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
      .addUserOption(opt => opt.setName('membre').setDescription('Le joueur destinataire').setRequired(true))
      .addIntegerOption(opt => opt.setName('montant').setDescription('Le montant en euros').setRequired(true).setMinValue(1)),
    async execute(interaction) {
      const { member, guild, user } = interaction;
      const isServerOwner = guild.ownerId === user.id;
      const isFondateurRole = member.roles.cache.some(r => {
        const name = r.name.toLowerCase();
        return name.includes('fondateur') || name.includes('owner') || name.includes('co-owner');
      });

      if (!isServerOwner && !isFondateurRole && !member.permissions.has(PermissionFlagsBits.Administrator)) {
        return interaction.reply({
          content: '❌ **Accès Refusé !** Seuls les **Fondateurs / Owners** du serveur peuvent utiliser cette commande.',
          flags: MessageFlags.Ephemeral
        });
      }

      const targetUser = interaction.options.getUser('membre');
      const amount = interaction.options.getInteger('montant');

      await db.addMoney(targetUser.id, amount);
      const newBal = await db.getUserBalance(targetUser.id);

      const embed = createEmbed({
        title: '👑 GIVE D\'ARGENT FONDATEUR • SUCCÈS',
        description:
          `👑 **Action Fondateur par** : <@${user.id}>\n` +
          `👤 **Destinataire** : <@${targetUser.id}> (\`${targetUser.tag}\`)\n` +
          `💵 **Montant Ajouté** : **+${amount.toLocaleString('fr-FR')} €**\n\n` +
          `💰 **Nouveau Solde du Joueur** : \`${newBal.toLocaleString('fr-FR')} €\``,
        color: config.colors.gold
      });

      await interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
    }
  }
];

