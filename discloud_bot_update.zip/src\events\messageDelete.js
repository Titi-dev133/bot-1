const { EmbedBuilder, AuditLogEvent } = require('discord.js');
const { sendAuditLog } = require('../utils/auditLogger');
const config = require('../../config.json');

module.exports = {
  name: 'messageDelete',
  async execute(message) {
    try {
      if (!message.guild) return;

      // Ignore bot messages if configured or desired
      if (message.author?.bot) return;

      const embed = new EmbedBuilder()
        .setTitle('🗑️ LOG AUDIT : MESSAGE SUPPRIMÉ')
        .setColor(config.colors?.danger || '#E53935')
        .setTimestamp();

      if (message.author) {
        embed.setAuthor({
          name: `${message.author.tag} (${message.author.id})`,
          iconURL: message.author.displayAvatarURL({ dynamic: true })
        });
        embed.addFields(
          { name: '👤 Auteur du message', value: `<@${message.author.id}> (\`${message.author.tag}\` | \`ID: ${message.author.id}\`)`, inline: true }
        );
      } else {
        embed.addFields(
          { name: '👤 Auteur du message', value: '*Auteur inconnu (Message non mis en cache)*', inline: true }
        );
      }

      embed.addFields(
        { name: '📍 Salon', value: `${message.channel} (\`#${message.channel.name}\` | \`ID: ${message.channel.id}\`)`, inline: true }
      );

      // Attempt to fetch executor from Guild Audit Logs
      try {
        const fetchedLogs = await message.guild.fetchAuditLogs({
          limit: 1,
          type: AuditLogEvent.MessageDelete,
        });
        const deletionLog = fetchedLogs.entries.first();
        if (deletionLog) {
          const { executor, target } = deletionLog;
          if (target.id === message.author?.id && (Date.now() - deletionLog.createdTimestamp) < 5000) {
            embed.addFields({ name: '👮 Supprimé par', value: `<@${executor.id}> (\`${executor.tag}\`)`, inline: true });
          }
        }
      } catch (auditErr) {
        // Audit log permission missing or failed
      }

      // Content
      let contentStr = message.content;
      if (!contentStr || contentStr.trim().length === 0) {
        contentStr = '*[Aucun contenu texte (image ou embed)]*';
      } else if (contentStr.length > 1024) {
        contentStr = contentStr.substring(0, 1020) + '...';
      }

      embed.addFields({
        name: '📝 Contenu du message supprimé',
        value: `\`\`\`${contentStr}\`\`\``,
        inline: false
      });

      // Attachments info
      if (message.attachments && message.attachments.size > 0) {
        const attachmentNames = message.attachments.map(att => `• [${att.name}](${att.url})`).join('\n');
        embed.addFields({
          name: `📎 Fichier(s) joint(s) (${message.attachments.size})`,
          value: attachmentNames.substring(0, 1024),
          inline: false
        });
      }

      embed.setFooter({ text: `Message ID: ${message.id} • Hamburg RP` });

      await sendAuditLog(message.guild, embed);
    } catch (error) {
      console.error('❌ Erreur dans l\'événement messageDelete:', error);
    }
  }
};
