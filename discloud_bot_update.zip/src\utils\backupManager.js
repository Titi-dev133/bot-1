const fs = require('fs');
const path = require('path');
const db = require('../database/db');

const backupDir = path.join(__dirname, '../../backups');

// Ensure backups directory exists
if (!fs.existsSync(backupDir)) {
  fs.mkdirSync(backupDir, { recursive: true });
}

/**
 * Creates a full backup:
 * 1. Copies database.sqlite -> ./backups/db_backup_<timestamp>.sqlite
 * 2. Exports Guild structure (roles, channels) -> ./backups/server_layout_<timestamp>.json
 * 3. Records entry in SQLite DB
 */
async function createFullBackup(guild, creatorUser = 'System') {
  try {
    const timestampStr = new Date().toISOString().replace(/[:.]/g, '-');
    const dbSource = path.join(__dirname, '../../database.sqlite');
    const dbTargetName = `db_backup_${timestampStr}.sqlite`;
    const dbTargetPath = path.join(backupDir, dbTargetName);

    // 1. Copy SQLite Database
    if (fs.existsSync(dbSource)) {
      fs.copyFileSync(dbSource, dbTargetPath);
    }

    // 2. Export Guild structure if provided
    let layoutTargetName = null;
    let layoutData = null;
    if (guild) {
      layoutTargetName = `server_layout_${timestampStr}.json`;
      const layoutPath = path.join(backupDir, layoutTargetName);

      const rolesData = guild.roles.cache.map(r => ({
        id: r.id,
        name: r.name,
        color: r.hexColor,
        hoist: r.hoist,
        position: r.position,
        permissionsBitfield: r.permissions.bitfield.toString(),
        permissionsList: r.permissions.toArray(),
        mentionable: r.mentionable,
        managed: r.managed
      }));

      const channelsData = guild.channels.cache.map(c => {
        const overwrites = [];
        if (c.permissionOverwrites && c.permissionOverwrites.cache) {
          c.permissionOverwrites.cache.forEach(po => {
            overwrites.push({
              id: po.id,
              type: po.type, // 0 = Role, 1 = Member
              allow: po.allow.bitfield.toString(),
              deny: po.deny.bitfield.toString(),
              allowList: po.allow.toArray(),
              denyList: po.deny.toArray()
            });
          });
        }

        return {
          id: c.id,
          name: c.name,
          type: c.type,
          parentId: c.parentId,
          position: c.position,
          nsfw: c.nsfw || false,
          topic: c.topic || null,
          rateLimitPerUser: c.rateLimitPerUser || 0,
          permissionOverwrites: overwrites
        };
      });


      layoutData = {
        guildId: guild.id,
        guildName: guild.name,
        memberCount: guild.memberCount,
        createdAt: Date.now(),
        rolesCount: rolesData.length,
        channelsCount: channelsData.length,
        roles: rolesData,
        channels: channelsData
      };

      fs.writeFileSync(layoutPath, JSON.stringify(layoutData, null, 2), 'utf8');
    }

    // 3. Record in DB
    const creatorId = typeof creatorUser === 'object' ? (creatorUser.tag || creatorUser.username || creatorUser.id) : creatorUser;
    const guildId = guild ? guild.id : 'GLOBAL';
    const details = `DB: ${dbTargetName}${layoutTargetName ? ` | Layout: ${layoutTargetName}` : ''}`;

    await db.addBackupRecord(
      guildId,
      `Backup_${timestampStr}`,
      'FULL_SQLITE_JSON',
      dbTargetPath,
      creatorId,
      details
    );

    return {
      success: true,
      backupName: `Backup_${timestampStr}`,
      dbFile: dbTargetName,
      layoutFile: layoutTargetName,
      createdAt: Date.now()
    };
  } catch (error) {
    console.error('❌ Erreur lors de la création de la sauvegarde:', error);
    return { success: false, error: error.message };
  }
}

/**
 * Initializes auto-backup timer every 24 hours.
 */
function initAutoBackupScheduler(client) {
  // Run once per day (24h = 86,400,000 ms)
  const TWENTY_FOUR_HOURS = 24 * 60 * 60 * 1000;
  
  setInterval(async () => {
    try {
      console.log('🔄 Sauvegarde automatique de la base de données et des serveurs...');
      const guilds = client.guilds.cache.values();
      for (const guild of guilds) {
        await createFullBackup(guild, 'Auto-Scheduler (24h)');
      }
      console.log('✅ Sauvegarde automatique quotidienne terminée avec succès.');
    } catch (err) {
      console.error('❌ Erreur lors du scheduler de sauvegarde automatique:', err);
    }
  }, TWENTY_FOUR_HOURS);
}

/**
 * Restores Guild structure (roles, categories, channels) from a layout JSON file.
 */
async function restoreFullBackup(guild, targetInput) {
  try {
    if (!fs.existsSync(backupDir)) {
      return { success: false, error: 'Le dossier des sauvegardes (./backups/) n\'existe pas.' };
    }

    const files = fs.readdirSync(backupDir);
    let layoutFile = files.find(f => f.toLowerCase() === targetInput.toLowerCase() && f.endsWith('.json'));

    if (!layoutFile) {
      layoutFile = files.find(f => f.endsWith('.json') && f.toLowerCase().includes(targetInput.toLowerCase()));
    }

    if (!layoutFile) {
      if (targetInput.toLowerCase() === 'latest' || targetInput.toLowerCase() === 'derniere' || targetInput.toLowerCase() === 'dernière') {
        const jsonFiles = files.filter(f => f.endsWith('.json')).sort().reverse();
        if (jsonFiles.length > 0) layoutFile = jsonFiles[0];
      }
    }

    if (!layoutFile) {
      return {
        success: false,
        error: `Fichier de sauvegarde introuvable pour "${targetInput}". Tapez \`/backup list\` pour voir la liste.`
      };
    }

    const layoutPath = path.join(backupDir, layoutFile);
    const rawData = fs.readFileSync(layoutPath, 'utf8');
    const layoutData = JSON.parse(rawData);

    let rolesCreated = 0;
    let channelsCreated = 0;
    let categoriesCreated = 0;

    const roleIdMap = new Map();
    if (guild.roles.everyone) {
      const savedEveryone = (layoutData.roles || []).find(r => r.name === '@everyone');
      if (savedEveryone) {
        roleIdMap.set(savedEveryone.id, guild.roles.everyone.id);
      }
    }

    // 1. Restore/Map Roles
    const savedRoles = layoutData.roles || [];
    for (const rData of savedRoles) {
      if (rData.name === '@everyone' || rData.managed) continue;

      let existingRole = guild.roles.cache.find(r => r.name === rData.name);
      if (existingRole) {
        roleIdMap.set(rData.id, existingRole.id);
      } else {
        try {
          const newRole = await guild.roles.create({
            name: rData.name,
            color: rData.color,
            hoist: rData.hoist,
            mentionable: rData.mentionable,
            permissions: BigInt(rData.permissionsBitfield || '0'),
            reason: 'Restauration de sauvegarde Discord'
          });
          roleIdMap.set(rData.id, newRole.id);
          rolesCreated++;
        } catch (e) {
          console.error(`Erreur création rôle ${rData.name}:`, e);
        }
      }
    }

    // 2. Restore Categories (type === 4)
    const categoryIdMap = new Map();
    const savedChannels = layoutData.channels || [];
    const savedCategories = savedChannels.filter(c => c.type === 4);
    const savedNonCategories = savedChannels.filter(c => c.type !== 4);

    for (const catData of savedCategories) {
      let existingCat = guild.channels.cache.find(c => c.type === 4 && c.name === catData.name);
      if (existingCat) {
        categoryIdMap.set(catData.id, existingCat.id);
      } else {
        try {
          const newCat = await guild.channels.create({
            name: catData.name,
            type: 4,
            position: catData.position,
            reason: 'Restauration de sauvegarde Discord'
          });
          categoryIdMap.set(catData.id, newCat.id);
          categoriesCreated++;
        } catch (e) {
          console.error(`Erreur création catégorie ${catData.name}:`, e);
        }
      }
    }

    // 3. Restore channels
    for (const chData of savedNonCategories) {
      const parentId = chData.parentId ? (categoryIdMap.get(chData.parentId) || null) : null;
      let existingCh = guild.channels.cache.find(c => c.type !== 4 && c.name === chData.name && (parentId ? c.parentId === parentId : true));

      if (!existingCh) {
        const overwrites = [];
        if (Array.isArray(chData.permissionOverwrites)) {
          for (const po of chData.permissionOverwrites) {
            const mappedTargetId = roleIdMap.get(po.id) || po.id;
            try {
              overwrites.push({
                id: mappedTargetId,
                type: po.type,
                allow: BigInt(po.allow || '0'),
                deny: BigInt(po.deny || '0')
              });
            } catch (e) {}
          }
        }

        try {
          await guild.channels.create({
            name: chData.name,
            type: chData.type,
            parent: parentId,
            topic: chData.topic || undefined,
            nsfw: chData.nsfw || false,
            rateLimitPerUser: chData.rateLimitPerUser || 0,
            permissionOverwrites: overwrites,
            reason: 'Restauration de sauvegarde Discord'
          });
          channelsCreated++;
        } catch (e) {
          console.error(`Erreur création salon ${chData.name}:`, e);
        }
      }
    }

    return {
      success: true,
      layoutFile,
      rolesCreated,
      categoriesCreated,
      channelsCreated,
      totalSavedChannels: savedChannels.length,
      totalSavedRoles: savedRoles.length
    };
  } catch (err) {
    console.error('❌ Erreur lors de la restauration de la sauvegarde:', err);
    return { success: false, error: err.message };
  }
}

module.exports = {
  createFullBackup,
  restoreFullBackup,
  initAutoBackupScheduler
};

