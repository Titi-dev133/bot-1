const { EmbedBuilder, AuditLogEvent } = require('discord.js');
const { sendAuditLog } = require('../utils/auditLogger');
const config = require('../../config.json');

module.exports = {
  name: 'channelCreate',
  async execute(channel) {
    try {
      if (!channel.guild) return;

      const embed = new EmbedBuilder()
        .setTitle('📺 LOG AUDIT : CRÉATION D\'UN SALON')
        .setColor(config.colors?.success || '#43A047')
        .addFields(
          { name: '📍 Salon créé', value: `${channel} (\`#${channel.name}\` | \`ID: ${channel.id}\`)`, inline: false },
          { name: '📁 Type', value: `\`${channel.type}\``, inline: true },
          { name: '📂 Catégorie', value: channel.parent ? `\`${channel.parent.name}\`` : '*Aucune*', inline: true }
        )
        .setFooter({ text: `Channel ID: ${channel.id} • Hamburg RP` })
        .setTimestamp();

      try {
        const fetchedLogs = await channel.guild.fetchAuditLogs({
          limit: 1,
          type: AuditLogEvent.ChannelCreate,
        });
        const auditEntry = fetchedLogs.entries.first();
        if (auditEntry && auditEntry.target.id === channel.id && (Date.now() - auditEntry.createdTimestamp) < 5000) {
          embed.addFields({ name: '👮 Créé par', value: `<@${auditEntry.executor.id}> (\`${auditEntry.executor.tag}\`)`, inline: false });
        }
      } catch (e) {}

      await sendAuditLog(channel.guild, embed);
    } catch (error) {
      console.error('❌ Erreur dans l\'événement channelCreate:', error);
    }
  }
};
