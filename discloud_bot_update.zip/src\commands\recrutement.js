const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { staffRecruitmentPanelEmbed } = require('../utils/embeds');

module.exports = [
  {
    data: new SlashCommandBuilder()
      .setName('recrutement')
      .setDescription('📋 Gestion et panneau de recrutement Staff RP')
      .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
      .addSubcommand(sub =>
        sub
          .setName('setup')
          .setDescription('Déployer le Portail de Recrutement Staff dans ce salon')
      ),

    async execute(interaction) {
      const subcommand = interaction.options.getSubcommand();

      if (subcommand === 'setup') {
        await interaction.deferReply({ ephemeral: true });

        const panelData = staffRecruitmentPanelEmbed();
        await interaction.channel.send(panelData);

        await interaction.editReply({
          content: `✅ **Portail de Recrutement Staff déployé avec succès** dans ${interaction.channel} !`
        });
      }
    }
  }
];
