@echo off
title Installation des dependances du Bot
echo ======================================================
echo   1. Installation des dependances du Bot (npm install)
echo ======================================================
call npm install
echo.
echo ======================================================
echo   Installation terminee avec succes !
echo ======================================================
pause
