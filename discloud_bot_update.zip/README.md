# 🇩🇪 Bot Discord RP Emergency Hamburg (Roblox)

Bienvenue sur le projet officiel du **Bot Discord Emergency Hamburg RP**. Ce bot contient plus de 30 commandes Slash (`/`), un système complet de prise de service avec sauvegarde d'heures en base de données SQLite, une centrale radio 911, des avis de recherche avec prime, des casiers judiciaires, un système bancaire et d'identité RP.

---

## ❓ Pourquoi votre bot ne répondait pas auparavant ?

Pour qu'un bot Discord fonctionne sur votre serveur, **3 éléments indispensables doivent être réunis** :
1. **Le code du bot doit tourner** : Un bot n'est pas "magique", c'est un programme informatique qui doit s'exécuter sur votre PC ou un serveur 24/7.
2. **Le Bot Token doit être configuré** : C'est le mot de passe secret qui relie ce code à votre application Discord.
3. **Les Intents Privilégiés doivent être activés** sur le [Discord Developer Portal](https://discord.com/developers/applications).

---

## 🚀 Guide de Configuration Pas-à-Pas (En 5 minutes)

### Étape 1 : Récupérer vos identifiants sur Discord
1. Rendez-vous sur le **[Discord Developer Portal](https://discord.com/developers/applications)**.
2. Cliquez sur votre application / bot.
3. **Récupérer le Client ID** : Dans l'onglet **General Information**, copiez le `APPLICATION ID` (ou Client ID).
4. **Récupérer le Token** : Dans l'onglet **Bot**, cliquez sur **Reset Token** puis copiez le jeton secret (ne le donnez à personne !).

### Étape 2 : Activer les Intents Privilégiés (TRÈS IMPORTANT ⚠️)
Dans l'onglet **Bot** du Developer Portal, descendez jusqu'à la section **Privileged Gateway Intents** et **activez les 3 options** :
- ✅ **PRESENCE INTENT**
- ✅ **SERVER MEMBERS INTENT**
- ✅ **MESSAGE CONTENT INTENT**
*(N'oubliez pas de cliquer sur "Save Changes" en bas).*

### Étape 3 : Inviter le Bot sur votre serveur Discord
1. Allez dans l'onglet **OAuth2** > **URL Generator**.
2. Dans **Scopes**, cochez :
   - ✅ `bot`
   - ✅ `applications.commands`
3. Dans **Bot Permissions**, cochez :
   - ✅ `Administrator` (ou *Send Messages*, *Embed Links*, *Manage Roles*, *Manage Channels*).
4. Copiez l'URL générée en bas et collez-la dans votre navigateur pour inviter le bot sur votre serveur.

### Étape 4 : Configurer le fichier `.env`
Ouvrez le fichier `.env` qui se trouve dans le dossier du bot et remplacez les valeurs :
```env
DISCORD_TOKEN=Votre_Token_Recupere_A_LEtape_1
CLIENT_ID=Votre_Client_ID_Recupere_A_LEtape_1
GUILD_ID=ID_De_Votre_Serveur_Discord
```
*(Pour obtenir l'ID de votre serveur Discord : Activer le mode Développeur dans les paramètres Discord > Clic droit sur le nom de votre serveur > Copier l'identifiant du serveur).*

### Étape 5 : Enregistrer les commandes & Lancer le bot !
Sur Windows, vous pouvez simplement :
1. Double-cliquer sur `deploy.bat` (ou faire la commande `npm run deploy` dans le terminal) pour enregistrer toutes les commandes `/` auprès de Discord.
2. Double-cliquer sur `start.bat` (ou faire `npm start` dans le terminal) pour démarrer le bot !

Votre bot sera immédiatement **EN LIGNE** et utilisable sur Discord ! 🎉

---

## 📜 Liste Complète des Commandes Slash (`/`)

### 🚨 1. Prise de Service & Patrouilles
- `/panneau-service` *(Admin)* : Envoie le panneau fixe avec boutons interactifs (Police, Pompiers, EMS, ADAC).
- `/prise-de-service` `[service]` : Prendre son service dans une faction.
- `/fin-de-service` : Clôturer son service et calculer automatiquement le temps effectué.
- `/pause-service` : Mettre son service en pause.
- `/service-stats` `[membre]` : Afficher l'historique d'heures et de patrouilles.
- `/service-leaderboard` : Afficher le classement des agents les plus actifs.
- `/patrouille-creer` `[nom]` `[véhicule]` : Former une unité de patrouille (ex: *Adam-12*).
- `/patrouille-liste` : Afficher la liste des patrouilles actives.

### 📟 2. Centrale Radio & Urgences 911
- `/911` `[service]` `[lieu]` `[description]` : Envoyer une alerte d'urgence avec bouton de prise en charge pour les agents.
- `/10-code` `[code]` `[précision]` : Envoyer un code radio (10-4, 10-20, 10-33 Alerte critique, 10-80 Poursuite, 10-99 Officier en danger).
- `/radio-dispatch` `[message]` : Diffuser une alerte prioritaire depuis la centrale.

### ⚖️ 3. Police, Avis de Recherche & Fourrière
- `/wanted` `[citoyen]` `[motif]` `[danger]` `[amende]` : Ajouter un criminel en avis de recherche (1 à 5 étoiles).
- `/unwanted` `[citoyen]` : Retirer un citoyen de la liste des recherchés.
- `/wanted-liste` : Afficher la liste des individus recherchés en ville.
- `/amende` `[citoyen]` `[montant]` `[motif]` : Délivrer une contravention enregistrée dans le casier.
- `/casier` `[citoyen]` : Consulter le casier judiciaire et l'historique d'amendes.
- `/fourriere` `[véhicule]` `[plaque]` `[propriétaire]` `[motif]` `[frais]` : Placer un véhicule à la fourrière ADAC/Police.

### 🪪 4. Identité RP & Économie Virtuelle
- `/rp-id` `[membre]` : Afficher la carte d'identité RP (Nom, Métier, Solde banque, Permis).
- `/config-id` `[nom]` `[prénom]` `[âge]` `[emploi]` : Mettre à jour sa carte d'identité RP.
- `/banque` `[action]` `[montant]` `[destinataire]` : Consulter son solde ou faire un virement bancaire RP.

### 💣 5. Criminalité & Underground
- `/darkweb` `[message]` : Publier une annonce anonyme et cryptée sur le réseau illégal.
- `/braquage` `[lieu]` : Déclencher l'alarme de braquage (Banque, Bijouterie, Armurerie).
- `/prise-otage` `[lieu]` `[nb_otages]` `[demandes]` : Transmettre les revendications d'une prise d'otage.

### 📢 6. Annonces Officiel, Codes d'Urgence & Météo
- `/annonce-rp` `[type]` `[titre]` `[message]` : Créer une annonce officielle (Mairie, Police, Pompiers, Presse).
- `/code-rouge` `[motif]` : Déclencher le Code Rouge (État d'urgence général dans la ville).
- `/code-vert` : Fin du Code Rouge.
- `/meteo-rp` `[temps]` : Modifier ou consulter la météo actuelle d'Hamburg.

### 🛡️ 7. Modération & Staff
- `/bot-status` : Latence, Uptime et performances du bot.
- `/clear` `[nombre]` : Purger des messages dans le salon.
- `/warn` / `/warnings` / `/unwarn` : Gestion du dossier disciplinaire des membres.
- `/kick` / `/ban` : Expulser ou bannir un membre du serveur.
- `/ticket-setup` : Installer le panneau de support / recrutement.
