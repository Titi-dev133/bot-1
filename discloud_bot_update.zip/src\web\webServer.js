const http = require('http');
const url = require('url');
const crypto = require('crypto');
const { EmbedBuilder, ChannelType, PermissionFlagsBits, ActionRowBuilder, ButtonBuilder, ButtonStyle, MessageFlags } = require('discord.js');
const db = require('../database/db');
const { sendAuditLog } = require('../utils/auditLogger');
const { staffCandidateCardEmbed } = require('../utils/embeds');

const PORT = process.env.PORT || 3000;
const webQuizSessions = new Map(); // token -> session object

/**
 * Créer une nouvelle session de test web sécurisée
 */
function createQuizSession({ client, guild, user, channel }) {
  const token = crypto.randomBytes(16).toString('hex');
  const session = {
    token,
    guildId: guild.id,
    userId: user.id,
    userTag: user.tag || user.username,
    channelId: channel.id,
    expiresAt: Date.now() + 20 * 60 * 1000, // 20 minutes max
    warnings: 0,
    status: 'ACTIVE'
  };
  webQuizSessions.set(token, session);
  return session;
}

/**
 * Récupère ou réinitialise dynamiquement une session pour éviter toute invalidation lors d'un redémarrage
 */
function getOrCreateQuizSession(token) {
  if (!token) token = 'test-session';
  let session = webQuizSessions.get(token);
  if (!session) {
    session = {
      token,
      guildId: '1354114824505917602',
      userId: '1538811900291317821',
      userTag: 'tintin_06130',
      channelId: null,
      expiresAt: Date.now() + 2 * 60 * 60 * 1000,
      warnings: 0,
      status: 'ACTIVE'
    };
    webQuizSessions.set(token, session);
  }
  return session;
}

/**
 * Démarrer le serveur HTTP d'Anti-Triche Web
 */
function startWebServer(client) {
  const server = http.createServer(async (req, res) => {
    const parsedUrl = url.parse(req.url, true);
    const pathname = parsedUrl.pathname;

    // CORS Headers
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

    if (req.method === 'OPTIONS') {
      res.writeHead(200);
      return res.end();
    }

    // --- API POST /api/quiz/warning ---
    if (pathname === '/api/quiz/warning' && req.method === 'POST') {
      let body = '';
      req.on('data', chunk => body += chunk);
      req.on('end', async () => {
        try {
          const data = JSON.parse(body);
          const session = getOrCreateQuizSession(data.token);

          session.warnings += 1;
          const remaining = Math.max(0, 3 - session.warnings);

          res.writeHead(200, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ warnings: session.warnings, remaining }));
        } catch (e) {
          res.writeHead(500, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ error: e.message }));
        }
      });
      return;
    }

    // --- API POST /api/quiz/fail (3 Avertissements dépassés) ---
    if (pathname === '/api/quiz/fail' && req.method === 'POST') {
      let body = '';
      req.on('data', chunk => body += chunk);
      req.on('end', async () => {
        try {
          const data = JSON.parse(body);
          const session = getOrCreateQuizSession(data.token);

          session.status = 'FAILED';
          const reason = data.reason || 'Dépassement du nombre d\'avertissements anti-triche (3/3)';

          if (session.guildId) {
            const guild = await client.guilds.fetch(session.guildId).catch(() => null);
            if (guild) {
              const auditEmbed = {
                title: '🚨 LOG AUDIT : EXAMEN STAFF ANNULÉ (TENTATIVE DE TRICHE DÉTECTÉE SUR LE SITE WEB)',
                color: '#E53935',
                fields: [
                  { name: '👤 Candidat', value: `<@${session.userId}> (\`${session.userTag}\`)`, inline: true },
                  { name: '📌 Motif Anti-Triche', value: `\`${reason}\``, inline: true },
                  { name: '⚠️ Avertissements accumulés', value: `\`${session.warnings} / 3\``, inline: true }
                ],
                timestamp: new Date()
              };
              await sendAuditLog(guild, auditEmbed);

              if (session.channelId) {
                const channel = await guild.channels.fetch(session.channelId).catch(() => null);
                if (channel) {
                  await channel.send({
                    content: `🚨 **TENTATIVE DE TRICHE DÉTECTÉE SUR LE PORTAIL WEB !**\nMotif : \`${reason}\`\nLe salon ticket va automatiquement être supprimé dans 5 secondes et vous êtes bloqué(e) 24h.`
                  }).catch(() => {});

                  setTimeout(async () => {
                    await channel.delete().catch(() => {});
                  }, 5000);
                }
              }
            }
          }

          res.writeHead(200, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ success: true }));
        } catch (e) {
          res.writeHead(500, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ error: e.message }));
        }
      });
      return;
    }

    // --- API POST /api/quiz/submit (Soumission réussie des 20 questions) ---
    if (pathname === '/api/quiz/submit' && req.method === 'POST') {
      let body = '';
      req.on('data', chunk => body += chunk);
      req.on('end', async () => {
        try {
          const data = JSON.parse(body);
          const session = getOrCreateQuizSession(data.token);

          session.status = 'SUBMITTED';
          const answers = data.answers || {};

          const guild = await client.guilds.fetch(session.guildId).catch(() => null);
          const user = await client.users.fetch(session.userId).catch(() => null);

          if (guild && user) {
            // Enregistrement dans la DB SQLite
            const testId = await db.createStaffTestRecord({
              guildId: guild.id,
              userId: user.id,
              userTag: user.tag || user.username,
              robloxUsername: answers['sq_1'] || user.username,
              age: 0,
              availability: answers['sq_2'] || 'N/A',
              experience: answers['sq_5'] || 'N/A',
              case1: answers['sq_6'] || 'N/A',
              case2: answers['sq_7'] || 'N/A',
              case3: answers['sq_8'] || 'N/A',
              answersJson: answers
            });

            const testData = await db.getStaffTestRecord(testId);

            // 1. Envoi de la carte dans le salon de direction #recrutement-staff
            let targetChannel = guild.channels.cache.find(
              c => c.type === ChannelType.GuildText && (
                c.name.toLowerCase() === 'recrutement-staff' ||
                c.name.toLowerCase() === 'candidatures-staff' ||
                c.name.toLowerCase().includes('recrutement')
              )
            );

            if (targetChannel) {
              const cardData = staffCandidateCardEmbed({ testData, candidateUser: user, reviewerUser: null });
              const sentMsg = await targetChannel.send(cardData);
              await db.updateStaffTestStatus(testId, 'PENDING', null, null, targetChannel.id, sentMsg.id);
            }

            // 2. Publication des réponses DANS LE SALON TICKET du membre (Demande de l'utilisateur)
            if (session.channelId) {
              const ticketChannel = await guild.channels.fetch(session.channelId).catch(() => null);
              if (ticketChannel) {
                const ticketEmbed = new EmbedBuilder()
                  .setTitle(`📋 VOS RÉPONSES À L'EXAMEN STAFF (20 QUESTIONS) • CANDIDATURE #${testId}`)
                  .setDescription(`Voici la copie complète transmise à la Haute-Direction par <@${user.id}> :`)
                  .setColor('#2ECC71')
                  .addFields(
                    {
                      name: '📌 PROFIL & MOTIVATIONS (Q1 - Q5)',
                      value: `**1. Identité:** ${answers['sq_1'] || 'N/A'}\n` +
                             `**2. Disponibilités:** ${answers['sq_2'] || 'N/A'}\n` +
                             `**3. Motivations:** ${answers['sq_3'] || 'N/A'}\n` +
                             `**4. Qualités & Défauts:** ${answers['sq_4'] || 'N/A'}\n` +
                             `**5. Expériences:** ${answers['sq_5'] || 'N/A'}`,
                      inline: false
                    },
                    {
                      name: '⚖️ CAS PRATIQUES RP (Q6 - Q10)',
                      value: `**6. Mass RDM/Freekill:** ${answers['sq_6'] || 'N/A'}\n` +
                             `**7. Insultes HRP:** ${answers['sq_7'] || 'N/A'}\n` +
                             `**8. Combat Log:** ${answers['sq_8'] || 'N/A'}\n` +
                             `**9. NoPainRP:** ${answers['sq_9'] || 'N/A'}\n` +
                             `**10. FearRP:** ${answers['sq_10'] || 'N/A'}`,
                      inline: false
                    },
                    {
                      name: '🚨 CAS PRATIQUES AVANCÉS (Q11 - Q15)',
                      value: `**11. Streamhack:** ${answers['sq_11'] || 'N/A'}\n` +
                             `**12. Abus de Pouvoir:** ${answers['sq_12'] || 'N/A'}\n` +
                             `**13. Metagaming:** ${answers['sq_13'] || 'N/A'}\n` +
                             `**14. Braquages/NLR:** ${answers['sq_14'] || 'N/A'}\n` +
                             `**15. Dox:** ${answers['sq_15'] || 'N/A'}`,
                      inline: false
                    },
                    {
                      name: '📜 RÈGLEMENT & SANCTIONS (Q16 - Q20)',
                      value: `**16. Procédure Warn:** ${answers['sq_16'] || 'N/A'}\n` +
                             `**17. Sanctions:** ${answers['sq_17'] || 'N/A'}\n` +
                             `**18. Contestations:** ${answers['sq_18'] || 'N/A'}\n` +
                             `**19. Erreur Staff:** ${answers['sq_19'] || 'N/A'}\n` +
                             `**20. Mot de la Fin:** ${answers['sq_20'] || 'N/A'}`,
                      inline: false
                    }
                  )
                  .setFooter({ text: 'Candidature Validée avec Succès • Hamburg RP' })
                  .setTimestamp();

                await ticketChannel.send({ embeds: [ticketEmbed] }).catch(() => {});
              }
            }
          }

          res.writeHead(200, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ success: true }));
        } catch (e) {
          res.writeHead(500, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ error: e.message }));
        }
      });
      return;
    }

    // --- API GET /api/service/active ---
    if (pathname === '/api/service/active' && req.method === 'GET') {
      try {
        const activeServices = await db.getAllActiveServices();
        const enriched = await Promise.all(activeServices.map(async s => {
          const user = await client.users.fetch(s.userId).catch(() => null);
          return {
            id: s.id,
            userId: s.userId,
            userTag: user ? (user.tag || user.username) : `Agent (${s.userId})`,
            avatarUrl: user ? user.displayAvatarURL({ dynamic: true }) : 'https://i.imgur.com/8QG4m3b.png',
            faction: s.faction,
            startTime: s.startTime,
            status: s.status
          };
        }));
        res.writeHead(200, { 'Content-Type': 'application/json' });
        return res.end(JSON.stringify(enriched));
      } catch (e) {
        res.writeHead(500, { 'Content-Type': 'application/json' });
        return res.end(JSON.stringify({ error: e.message }));
      }
    }

    // --- API GET /api/service/leaderboard ---
    if (pathname === '/api/service/leaderboard' && req.method === 'GET') {
      try {
        const leaderboard = await db.getServiceLeaderboard(10);
        const enriched = await Promise.all(leaderboard.map(async item => {
          const user = await client.users.fetch(item.userId).catch(() => null);
          return {
            userId: item.userId,
            userTag: user ? (user.tag || user.username) : `Agent (${item.userId})`,
            totalMinutes: item.totalMinutes,
            shiftCount: item.shiftCount
          };
        }));
        res.writeHead(200, { 'Content-Type': 'application/json' });
        return res.end(JSON.stringify(enriched));
      } catch (e) {
        res.writeHead(500, { 'Content-Type': 'application/json' });
        return res.end(JSON.stringify({ error: e.message }));
      }
    }

    // --- GET /service & /dashboard Page Web Dashboard Service ---
    if (pathname === '/service' || pathname === '/dashboard' || pathname === '/') {
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
      return res.end(getServiceDashboardHtmlPage());
    }

    // --- GET /quiz Page Web Anti-Triche ---
    if (pathname === '/quiz') {
      const token = parsedUrl.query.token;
      const session = getOrCreateQuizSession(token);

      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
      return res.end(getQuizHtmlPage(session));
    }



    res.writeHead(404);
    res.end('Not found');
  });

  server.listen(PORT, () => {
    console.log(`🌐 Serveur Web Anti-Triche en ligne sur le port ${PORT} ! (http://localhost:${PORT})`);
  });
}

/**
 * Génère la page Web HTML5/CSS3/JS avec détecteur de souris & anti-triche
 */
function getQuizHtmlPage(session) {
  return `
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Examen Staff Anti-Triche • Hamburg RP</title>
  <style>
    :root {
      --bg: #0b0f19;
      --card-bg: #151c2c;
      --border: #232f48;
      --accent: #3b82f6;
      --accent-hover: #2563eb;
      --danger: #ef4444;
      --warning: #f59e0b;
      --success: #10b981;
      --text: #f1f5f9;
      --subtext: #94a3b8;
    }

    * { box-sizing: border-box; user-select: none; -webkit-user-select: none; }

    body {
      background-color: var(--bg);
      color: var(--text);
      font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      margin: 0;
      padding: 40px 20px;
      min-height: 100vh;
      display: block;
    }

    .container {
      width: 100%;
      max-width: 900px;
      margin: 0 auto;
      background: var(--card-bg);
      border: 1px solid var(--border);
      border-radius: 20px;
      padding: 35px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.7);
      position: relative;
    }


    .header {
      text-align: center;
      border-bottom: 1px solid var(--border);
      padding-bottom: 20px;
      margin-bottom: 25px;
    }

    .header h1 {
      margin: 0;
      font-size: 24px;
      color: #60a5fa;
      letter-spacing: -0.5px;
    }

    .header p {
      color: var(--subtext);
      font-size: 14px;
      margin-top: 5px;
    }

    .anti-cheat-bar {
      display: flex;
      justify-content: space-between;
      align-items: center;
      background: rgba(239, 68, 68, 0.1);
      border: 1px solid rgba(239, 68, 68, 0.3);
      padding: 12px 20px;
      border-radius: 12px;
      margin-bottom: 25px;
    }

    .warning-badge {
      background: var(--warning);
      color: #000;
      font-weight: 700;
      padding: 4px 10px;
      border-radius: 20px;
      font-size: 13px;
    }

    .question-group {
      margin-bottom: 25px;
      background: #1a233a;
      padding: 20px;
      border-radius: 14px;
      border: 1px solid #283654;
    }

    .question-title {
      font-size: 15px;
      font-weight: 600;
      color: #e2e8f0;
      margin-bottom: 10px;
      display: flex;
      align-items: center;
      gap: 10px;
    }

    .q-num {
      background: var(--accent);
      color: #fff;
      font-size: 12px;
      font-weight: 700;
      padding: 2px 8px;
      border-radius: 6px;
    }

    textarea, input[type="text"] {
      width: 100%;
      background: #0f172a;
      border: 1px solid #334155;
      color: #fff;
      padding: 12px;
      border-radius: 10px;
      font-family: inherit;
      font-size: 14px;
      resize: vertical;
      outline: none;
      transition: border-color 0.2s;
      user-select: text;
      -webkit-user-select: text;
    }

    textarea:focus, input[type="text"]:focus {
      border-color: var(--accent);
    }

    .btn-submit {
      width: 100%;
      background: linear-gradient(135deg, #3b82f6, #1d4ed8);
      color: #fff;
      font-size: 16px;
      font-weight: 700;
      padding: 16px;
      border: none;
      border-radius: 12px;
      cursor: pointer;
      transition: transform 0.2s, background 0.2s;
    }

    .btn-submit:hover {
      transform: translateY(-2px);
      background: linear-gradient(135deg, #2563eb, #1e40af);
    }

    /* Modal Overlay pour Avertissements */
    .modal-overlay {
      display: none;
      position: fixed;
      top: 0; left: 0; width: 100%; height: 100%;
      background: rgba(0, 0, 0, 0.85);
      backdrop-filter: blur(8px);
      z-index: 9999;
      justify-content: center;
      align-items: center;
    }

    .modal-box {
      background: #1e293b;
      border: 2px solid var(--danger);
      border-radius: 20px;
      padding: 35px;
      text-align: center;
      max-width: 450px;
      box-shadow: 0 0 40px rgba(239, 68, 68, 0.4);
    }

    .modal-box h2 { color: var(--danger); margin-top: 0; }
    .modal-box p { color: #cbd5e1; font-size: 15px; }

    .btn-ack {
      background: var(--danger);
      color: #fff;
      font-weight: 700;
      padding: 12px 25px;
      border: none;
      border-radius: 10px;
      cursor: pointer;
      margin-top: 15px;
    }
  </style>
</head>
<body>

  <div class="container" id="quizContainer">
    <div class="header">
      <h1>📋 EXAMEN STAFF HAMBURG RP (20 QUESTIONS)</h1>
      <p>Candidat : <strong>${session.userTag}</strong> • Session Sécurisée Anti-Triche</p>
    </div>

    <div class="anti-cheat-bar" style="background: rgba(59, 130, 246, 0.1); border-color: rgba(59, 130, 246, 0.3);">
      <span>⏱️ <strong>TEMPS RESTANT : <span id="quizTimer" style="color: #60a5fa; font-weight: 800; font-size: 16px;">05:00</span></strong></span>
      <span class="warning-badge" id="warningBadge">Avertissements : 0 / 3</span>
    </div>

    <form id="quizForm">
      <!-- 20 QUESTIONS FORM -->

      <div class="question-group">
        <div class="question-title"><span class="q-num">Q1</span> 1/20: Identité RP / Pseudo Roblox / Âge</div>
        <input type="text" name="sq_1" placeholder="ex: Patrick_25 (Patou) | 16 ans" required>
      </div>

      <div class="question-group">
        <div class="question-title"><span class="q-num">Q2</span> 2/20: Disponibilités & Heures de jeu par semaine</div>
        <input type="text" name="sq_2" placeholder="ex: 15 heures par semaine" required>
      </div>

      <div class="question-group">
        <div class="question-title"><span class="q-num">Q3</span> 3/20: Pourquoi postuler chez Emergency Hamburg RP ?</div>
        <textarea name="sq_3" rows="3" placeholder="Vos motivations principales..." required></textarea>
      </div>

      <div class="question-group">
        <div class="question-title"><span class="q-num">Q4</span> 4/20: Vos 3 qualités & 3 défauts en modération RP</div>
        <textarea name="sq_4" rows="3" placeholder="Soyez honnête et précis..." required></textarea>
      </div>

      <div class="question-group">
        <div class="question-title"><span class="q-num">Q5</span> 5/20: Vos expériences passées en modération RP</div>
        <textarea name="sq_5" rows="3" placeholder="Serveurs Roblox/Discord déjà gérés..." required></textarea>
      </div>

      <div class="question-group">
        <div class="question-title"><span class="q-num">Q6</span> 6/20: Cas 1 - Mass RDM & Freekill au spawn</div>
        <textarea name="sq_6" rows="3" placeholder="Votre procédure étape par étape..." required></textarea>
      </div>

      <div class="question-group">
        <div class="question-title"><span class="q-num">Q7</span> 7/20: Cas 2 - Insultes HRP & Trolling du staff en ticket</div>
        <textarea name="sq_7" rows="3" placeholder="Réaction et sanction..." required></textarea>
      </div>

      <div class="question-group">
        <div class="question-title"><span class="q-num">Q8</span> 8/20: Cas 3 - Refus d'arrêter & Combat Log face Polizei</div>
        <textarea name="sq_8" rows="3" placeholder="Sanction et procédure du dossier..." required></textarea>
      </div>

      <div class="question-group">
        <div class="question-title"><span class="q-num">Q9</span> 9/20: Cas 4 - NoPainRP & Conduite HRP extrême</div>
        <textarea name="sq_9" rows="3" placeholder="Sanction pour conduite HRP sur voie ferrée..." required></textarea>
      </div>

      <div class="question-group">
        <div class="question-title"><span class="q-num">Q10</span> 10/20: Cas 5 - FearRP face à 3 policiers armés</div>
        <textarea name="sq_10" rows="3" placeholder="Analyse du non-respect du FearRP..." required></textarea>
      </div>

      <div class="question-group">
        <div class="question-title"><span class="q-num">Q11</span> 11/20: Cas 6 - Streamhack & Usurpation d'identité RP</div>
        <textarea name="sq_11" rows="3" placeholder="Procédure d'intervention..." required></textarea>
      </div>

      <div class="question-group">
        <div class="question-title"><span class="q-num">Q12</span> 12/20: Cas 7 - Abus de pouvoir / Favoritisme d'un modérateur</div>
        <textarea name="sq_12" rows="3" placeholder="Que faites-vous si vous constatez un abus..." required></textarea>
      </div>

      <div class="question-group">
        <div class="question-title"><span class="q-num">Q13</span> 13/20: Cas 8 - Metagaming via Vocal Discord / Radio HRP</div>
        <textarea name="sq_13" rows="3" placeholder="Procédure et preuves à exiger..." required></textarea>
      </div>

      <div class="question-group">
        <div class="question-title"><span class="q-num">Q14</span> 14/20: Cas 9 - Non-respect des règles de Braquage & NLR</div>
        <textarea name="sq_14" rows="3" placeholder="Non-respect de la New Life Rule..." required></textarea>
      </div>

      <div class="question-group">
        <div class="question-title"><span class="q-num">Q15</span> 15/20: Cas 10 - Provocations HRP & Menaces de Dox</div>
        <textarea name="sq_15" rows="3" placeholder="Gestion de cas d'insultes et menaces graves..." required></textarea>
      </div>

      <div class="question-group">
        <div class="question-title"><span class="q-num">Q16</span> 16/20: Procédure complète de délivrance d'un Warn RP</div>
        <textarea name="sq_16" rows="3" placeholder="Mise en forme et avertissement..." required></textarea>
      </div>

      <div class="question-group">
        <div class="question-title"><span class="q-num">Q17</span> 17/20: Différence entre Mute, Kick, Tempban & Perma</div>
        <textarea name="sq_17" rows="3" placeholder="Hiérarchie et utilité des sanctions..." required></textarea>
      </div>

      <div class="question-group">
        <div class="question-title"><span class="q-num">Q18</span> 18/20: Que faire si un joueur conteste sa sanction en ticket ?</div>
        <textarea name="sq_18" rows="3" placeholder="Attitude et gestion du calme..." required></textarea>
      </div>

      <div class="question-group">
        <div class="question-title"><span class="q-num">Q19</span> 19/20: Comment réagir si vous commettez une erreur de sanction ?</div>
        <textarea name="sq_19" rows="3" placeholder="Erreur de ban / correction..." required></textarea>
      </div>

      <div class="question-group">
        <div class="question-title"><span class="q-num">Q20</span> 20/20: Message final & Remarques pour la Haute-Direction</div>
        <textarea name="sq_20" rows="3" placeholder="Dernier mot pour convaincre l'Administration..." required></textarea>
      </div>

      <button type="submit" class="btn-submit" id="submitBtn">🚀 VALIDER & TRANSMETTRE MES 20 RÉPONSES</button>
    </form>
  </div>

  <!-- AVERTISSEMENT MODAL OVERLAY -->
  <div class="modal-overlay" id="warningModal">
    <div class="modal-box">
      <h2>⚠️ TENTATIVE DE TRICHE DÉTECTÉE</h2>
      <p id="modalMsg">Vous avez quitté la fenêtre de test ou changé d'onglet !</p>
      <p><strong>Avertissement : <span id="modalWarnCount">1</span> / 3</strong></p>
      <p style="font-size: 12px; color: #ef4444;">Au 3ème avertissement, votre salon ticket Discord sera immédiatement supprimé.</p>
      <button type="button" class="btn-ack" style="cursor: pointer; position: relative; z-index: 10000;" onclick="closeWarningModal()">REVENIR À L'EXAMEN</button>
    </div>
  </div>

  <script>
    (function() {
      const TOKEN = "${session.token}";
      let warningCount = 0;
      let isSubmitting = false;
      let antiCheatActive = true;
      let lastWarningTime = 0;
      let totalSeconds = 300; // 5 Minutes (300s)

      // Compte à rebours global 5 minutes
      const timerInterval = setInterval(() => {
        if (isSubmitting) return;
        totalSeconds--;
        const mins = String(Math.floor(totalSeconds / 60)).padStart(2, '0');
        const secs = String(totalSeconds % 60).padStart(2, '0');
        const el = document.getElementById('quizTimer');
        if (el) el.innerText = mins + ':' + secs;

        if (totalSeconds <= 0) {
          clearInterval(timerInterval);
          isSubmitting = true;
          const container = document.getElementById('quizContainer');
          if (container) {
            container.innerHTML = '<div style="text-align:center; padding:50px;"><h1 style="color:#ef4444;">⏱️ TEMPS ÉCOULÉ (5 MIN) & TICKET SUPPRIMÉ</h1><p>Vous avez dépassé le temps maximal de 5 minutes. Votre salon ticket Discord est en cours de suppression.</p></div>';
          }
          fetch('/api/quiz/fail', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ token: TOKEN, reason: 'Temps global de 5 minutes écoulé' })
          });
        }
      }, 1000);

      // 1. Protection Anti-Copier/Coller & Clic Droit & Screenshot
      document.addEventListener('contextmenu', e => e.preventDefault());
      document.addEventListener('copy', e => { e.preventDefault(); if (navigator.clipboard) navigator.clipboard.writeText('Capture interdite.'); });
      document.addEventListener('cut', e => e.preventDefault());

      document.addEventListener('keyup', e => {
        if (e.key === 'PrintScreen' || e.keyCode === 44 || e.key === 'Meta') {
          if (navigator.clipboard) navigator.clipboard.writeText('Capture interdite.');
          triggerAntiCheatWarning('Touche Capture d\'Écran / Windows détectée');
        }
      });

      document.addEventListener('keydown', e => {
        if (e.key === 'F12' || e.key === 'Meta' || (e.ctrlKey && e.shiftKey) || (e.altKey && e.key === 'Tab')) {
          e.preventDefault();
          triggerAntiCheatWarning('Tentative de changement de fenêtre / inspecteur / capture');
        }
      });

      // 2. Floutage instantané en cas de perte de focus
      function applyScreenBlur() {
        if (antiCheatActive && !isSubmitting) {
          const container = document.getElementById('quizContainer');
          if (container) container.style.opacity = '0';
        }
      }

      function removeScreenBlur() {
        const container = document.getElementById('quizContainer');
        if (container) container.style.opacity = '1';
      }

      // 3. Détecteur Hyper-Strict Anti-Triche
      function triggerAntiCheatWarning(reason) {
        if (!antiCheatActive || isSubmitting) return;

        const now = Date.now();
        if (now - lastWarningTime < 1000) return;
        lastWarningTime = now;

        warningCount++;
        const badge = document.getElementById('warningBadge');
        if (badge) badge.innerText = 'Avertissements : ' + warningCount + ' / 3';

        fetch('/api/quiz/warning', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ token: TOKEN })
        });

        if (warningCount >= 3) {
          isSubmitting = true;
          clearInterval(timerInterval);
          const container = document.getElementById('quizContainer');
          if (container) {
            container.innerHTML = '<div style="text-align:center; padding:50px;"><h1 style="color:#ef4444;">💥 EXAMEN ANNULÉ & TICKET SUPPRIMÉ</h1><p>Vous avez dépassé les 3 avertissements anti-triche (Changement d\'onglet / Gemini / Windows / Capture). Votre salon ticket Discord est en cours de suppression.</p></div>';
          }
          fetch('/api/quiz/fail', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ token: TOKEN, reason: reason })
          });
        } else {
          const modalMsg = document.getElementById('modalMsg');
          if (modalMsg) modalMsg.innerText = 'Motif : ' + reason;
          const modalWarn = document.getElementById('modalWarnCount');
          if (modalWarn) modalWarn.innerText = warningCount;
          const modal = document.getElementById('warningModal');
          if (modal) modal.style.display = 'flex';
        }
      }

      // 4. ÉCOUTEURS PERTE DE FOCUS / BLUR / VISIBILITY / LEAVE
      window.addEventListener('blur', () => {
        triggerAntiCheatWarning('Perte de focus (Passage sur Google / Gemini / Discord / Autre fenêtre / Capture)');
      });

      document.addEventListener('visibilitychange', () => {
        if (document.hidden) {
          triggerAntiCheatWarning('Changement d\'onglet ou minimisation du navigateur');
        }
      });

      document.addEventListener('mouseleave', () => {
        triggerAntiCheatWarning('Curseur de souris sorti de la fenêtre d\'examen');
      });

      setInterval(() => {
        if (antiCheatActive && !isSubmitting && !document.hasFocus()) {
          triggerAntiCheatWarning('Fenêtre d\'examen inactive (Focus perdu)');
        }
      }, 300);

      window.closeWarningModal = function() {
        const modal = document.getElementById('warningModal');
        if (modal) modal.style.display = 'none';
      };

      // 5. Soumission du Formulaire
      const form = document.getElementById('quizForm');
      if (form) {
        form.addEventListener('submit', async e => {
          e.preventDefault();
          if (isSubmitting) return;

          isSubmitting = true;
          clearInterval(timerInterval);
          const btn = document.getElementById('submitBtn');
          if (btn) {
            btn.innerText = '⏳ Transmission des réponses...';
            btn.disabled = true;
          }

          const formData = new FormData(e.target);
          const answers = {};
          formData.forEach((val, key) => answers[key] = val);

          try {
            const res = await fetch('/api/quiz/submit', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ token: TOKEN, answers })
            });

            const json = await res.json();
            if (json.success) {
              const container = document.getElementById('quizContainer');
              if (container) {
                container.innerHTML = '<div style="text-align:center; padding:50px;"><h1 style="color:#10b981;">🎉 EXAMEN TRANSMIS AVEC SUCCÈS !</h1><p>Vos 20 réponses ont été enregistrées et transmises dans votre salon ticket Discord ainsi qu\'à la Haute Direction.</p><p style="color:#94a3b8;">Vous pouvez fermer cette page et retourner sur Discord.</p></div>';
              }
            } else {
              alert('Erreur: ' + (json.error || 'Impossible de transmettre les réponses.'));
              isSubmitting = false;
              if (btn) btn.disabled = false;
            }
          } catch (err) {
            alert('Erreur de connexion au serveur.');
            isSubmitting = false;
            if (btn) btn.disabled = false;
          }
        });
      }
    })();
  </script>


</body>
</html>
  `;
}

/**
 * Génère la page Web HTML5/CSS3/JS de Dashboard de Prise de Service
 */
function getServiceDashboardHtmlPage() {
  return `
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dashboard Prise de Service • Hamburg RP</title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
  <style>
    :root {
      --bg: #0b0f19;
      --card-bg: #151c2c;
      --card-border: rgba(255, 255, 255, 0.08);
      --accent-blue: #3b82f6;
      --accent-police: #2563eb;
      --accent-fire: #ef4444;
      --accent-ems: #10b981;
      --accent-adac: #f59e0b;
      --accent-bus: #8b5cf6;
      --text: #f8fafc;
      --subtext: #94a3b8;
    }
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      background-color: var(--bg);
      color: var(--text);
      font-family: 'Inter', sans-serif;
      min-height: 100vh;
      padding: 30px 20px;
    }
    .container {
      max-width: 1200px;
      margin: 0 auto;
    }
    .header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding-bottom: 25px;
      border-bottom: 1px solid var(--card-border);
      margin-bottom: 30px;
    }
    .header-title {
      display: flex;
      align-items: center;
      gap: 15px;
    }
    .header-title h1 {
      font-size: 26px;
      font-weight: 800;
      background: linear-gradient(135deg, #60a5fa, #a855f7);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
    }
    .live-badge {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      background: rgba(16, 185, 129, 0.15);
      border: 1px solid rgba(16, 185, 129, 0.4);
      color: #34d399;
      padding: 6px 14px;
      border-radius: 20px;
      font-size: 13px;
      font-weight: 600;
    }
    .pulse-dot {
      width: 8px; height: 8px;
      background: #34d399;
      border-radius: 50%;
      box-shadow: 0 0 10px #34d399;
      animation: pulse 1.5s infinite;
    }
    @keyframes pulse {
      0% { transform: scale(0.95); box-shadow: 0 0 0 0 rgba(52, 211, 153, 0.7); }
      70% { transform: scale(1); box-shadow: 0 0 0 10px rgba(52, 211, 153, 0); }
      100% { transform: scale(0.95); box-shadow: 0 0 0 0 rgba(52, 211, 153, 0); }
    }
    .stats-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
      gap: 20px;
      margin-bottom: 35px;
    }
    .stat-card {
      background: var(--card-bg);
      border: 1px solid var(--card-border);
      border-radius: 16px;
      padding: 22px;
      display: flex;
      align-items: center;
      gap: 18px;
      transition: transform 0.2s;
    }
    .stat-card:hover { transform: translateY(-3px); }
    .stat-icon {
      width: 50px; height: 50px;
      border-radius: 14px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 24px;
    }
    .stat-val { font-size: 24px; font-weight: 800; color: #fff; }
    .stat-label { font-size: 13px; color: var(--subtext); margin-top: 2px; }

    .nav-tabs {
      display: flex;
      gap: 12px;
      margin-bottom: 25px;
    }
    .tab-btn {
      background: var(--card-bg);
      border: 1px solid var(--card-border);
      color: var(--subtext);
      padding: 12px 24px;
      border-radius: 12px;
      font-weight: 600;
      font-size: 14px;
      cursor: pointer;
      transition: all 0.2s;
    }
    .tab-btn.active {
      background: var(--accent-blue);
      color: #fff;
      border-color: var(--accent-blue);
    }
    .content-section { display: none; }
    .content-section.active { display: block; }

    .units-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(340px, 1fr));
      gap: 20px;
    }
    .unit-card {
      background: var(--card-bg);
      border: 1px solid var(--card-border);
      border-radius: 18px;
      padding: 24px;
      position: relative;
      overflow: hidden;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
    }
    .unit-card::before {
      content: '';
      position: absolute;
      top: 0; left: 0; width: 5px; height: 100%;
    }
    .unit-card.police::before { background: var(--accent-police); }
    .unit-card.fire::before, .unit-card.pompiers::before { background: var(--accent-fire); }
    .unit-card.ems::before { background: var(--accent-ems); }
    .unit-card.adac::before { background: var(--accent-adac); }
    .unit-card.bus::before, .unit-card.camion::before { background: var(--accent-bus); }

    .unit-header {
      display: flex;
      align-items: center;
      gap: 14px;
      margin-bottom: 16px;
    }
    .unit-avatar {
      width: 48px; height: 48px;
      border-radius: 50%;
      border: 2px solid var(--card-border);
      object-fit: cover;
    }
    .unit-user-name { font-size: 16px; font-weight: 700; color: #fff; }
    .unit-faction-badge {
      display: inline-block;
      font-size: 11px;
      font-weight: 700;
      padding: 3px 8px;
      border-radius: 6px;
      text-transform: uppercase;
      margin-top: 4px;
    }
    .badge-police { background: rgba(37, 99, 235, 0.2); color: #60a5fa; }
    .badge-fire, .badge-pompiers { background: rgba(239, 68, 68, 0.2); color: #f87171; }
    .badge-ems { background: rgba(16, 185, 129, 0.2); color: #34d399; }
    .badge-adac { background: rgba(245, 158, 11, 0.2); color: #fbbf24; }
    .badge-bus, .badge-camion { background: rgba(139, 92, 246, 0.2); color: #c084fc; }

    .unit-timer {
      background: rgba(0, 0, 0, 0.3);
      padding: 12px;
      border-radius: 10px;
      font-family: monospace;
      font-size: 18px;
      font-weight: 700;
      color: #60a5fa;
      text-align: center;
      margin-top: 10px;
    }

    .leaderboard-table {
      width: 100%;
      border-collapse: separate;
      border-spacing: 0 10px;
    }
    .leaderboard-table th {
      text-align: left;
      padding: 12px 20px;
      color: var(--subtext);
      font-size: 13px;
      font-weight: 600;
      text-transform: uppercase;
    }
    .leaderboard-table tr.row-item {
      background: var(--card-bg);
      border: 1px solid var(--card-border);
    }
    .leaderboard-table td {
      padding: 16px 20px;
    }
    .leaderboard-table tr.row-item td:first-child {
      border-top-left-radius: 14px;
      border-bottom-left-radius: 14px;
    }
    .leaderboard-table tr.row-item td:last-child {
      border-top-right-radius: 14px;
      border-bottom-right-radius: 14px;
    }
    .rank-medal { font-size: 20px; font-weight: 800; width: 40px; text-align: center; }

    .empty-msg {
      text-align: center;
      padding: 50px;
      color: var(--subtext);
      background: var(--card-bg);
      border-radius: 18px;
      border: 1px dashed var(--card-border);
      grid-column: 1 / -1;
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <div class="header-title">
        <h1>🚨 DASHBOARD PRISE DE SERVICE RP</h1>
        <div class="live-badge"><div class="pulse-dot"></div> EN DIRECT</div>
      </div>
      <div style="color: var(--subtext); font-size: 14px;">Emergency Hamburg RP</div>
    </div>

    <!-- STATS SUMMARY GRID -->
    <div class="stats-grid">
      <div class="stat-card">
        <div class="stat-icon" style="background: rgba(37, 99, 235, 0.2); color: #60a5fa;">🚓</div>
        <div>
          <div class="stat-val" id="countPolice">0</div>
          <div class="stat-label">Polizei Hamburg</div>
        </div>
      </div>
      <div class="stat-card">
        <div class="stat-icon" style="background: rgba(239, 68, 68, 0.2); color: #f87171;">🚒</div>
        <div>
          <div class="stat-val" id="countFire">0</div>
          <div class="stat-label">Feuerwehr Pompiers</div>
        </div>
      </div>
      <div class="stat-card">
        <div class="stat-icon" style="background: rgba(16, 185, 129, 0.2); color: #34d399;">🚑</div>
        <div>
          <div class="stat-val" id="countEms">0</div>
          <div class="stat-label">Rettungsdienst EMS</div>
        </div>
      </div>
      <div class="stat-card">
        <div class="stat-icon" style="background: rgba(245, 158, 11, 0.2); color: #fbbf24;">🛞</div>
        <div>
          <div class="stat-val" id="countAdac">0</div>
          <div class="stat-label">ADAC Dépannage</div>
        </div>
      </div>
    </div>

    <!-- NAVIGATION TABS -->
    <div class="nav-tabs">
      <button class="tab-btn active" onclick="switchTab(this, 'active')">🟢 Services Actifs (<span id="totalActiveCount">0</span>)</button>
      <button class="tab-btn" onclick="switchTab(this, 'leaderboard')">🏆 Top Agents (Leaderboard)</button>
    </div>

    <!-- TAB 1: ACTIVE UNITS -->
    <div id="tab-active" class="content-section active">
      <div class="units-grid" id="unitsGrid">
        <div class="empty-msg">Chargement des unités en service...</div>
      </div>
    </div>

    <!-- TAB 2: LEADERBOARD -->
    <div id="tab-leaderboard" class="content-section">
      <table class="leaderboard-table">
        <thead>
          <tr>
            <th>Rang</th>
            <th>Agent</th>
            <th>Services Effectués</th>
            <th>Temps Total Cumulé</th>
          </tr>
        </thead>
        <tbody id="leaderboardBody">
          <tr><td colspan="4" class="empty-msg">Chargement du classement...</td></tr>
        </tbody>
      </table>
    </div>
  </div>

  <script>
    function switchTab(btn, tabName) {
      document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
      document.querySelectorAll('.content-section').forEach(sec => sec.classList.remove('active'));
      btn.classList.add('active');
      document.getElementById('tab-' + tabName).classList.add('active');
    }

    function formatDuration(startTime) {
      const diffMs = Date.now() - startTime;
      const totalSecs = Math.max(0, Math.floor(diffMs / 1000));
      const hours = String(Math.floor(totalSecs / 3600)).padStart(2, '0');
      const mins = String(Math.floor((totalSecs % 3600) / 60)).padStart(2, '0');
      const secs = String(totalSecs % 60).padStart(2, '0');
      return hours + ':' + mins + ':' + secs;
    }

    async function loadActiveServices() {
      try {
        const res = await fetch('/api/service/active');
        const data = await res.json();

        document.getElementById('totalActiveCount').innerText = data.length;

        let police = 0, fire = 0, ems = 0, adac = 0;
        data.forEach(s => {
          const f = (s.faction || '').toLowerCase();
          if (f === 'police') police++;
          else if (f === 'fire' || f === 'pompiers') fire++;
          else if (f === 'ems') ems++;
          else if (f === 'adac') adac++;
        });

        document.getElementById('countPolice').innerText = police;
        document.getElementById('countFire').innerText = fire;
        document.getElementById('countEms').innerText = ems;
        document.getElementById('countAdac').innerText = adac;

        const grid = document.getElementById('unitsGrid');
        if (!data || data.length === 0) {
          grid.innerHTML = '<div class="empty-msg">🚨 Aucun agent actuellement en service en ville.</div>';
          return;
        }

        const icons = { police: '🚓', fire: '🚒', pompiers: '🚒', ems: '🚑', adac: '🛞', bus: '🚌', camion: '🚚' };

        grid.innerHTML = data.map(function(s) {
          var factionIcon = icons[s.faction] || '🚨';
          var factionUpper = (s.faction || '').toUpperCase();
          var startTimeStr = new Date(s.startTime).toLocaleTimeString('fr-FR');
          var userTagStr = s.userTag || s.userId;
          var avatar = s.avatarUrl || 'https://i.imgur.com/8QG4m3b.png';
          return '<div class="unit-card ' + s.faction + '">' +
            '<div class="unit-header">' +
              '<img class="unit-avatar" src="' + avatar + '" alt="Avatar">' +
              '<div>' +
                '<div class="unit-user-name">' + userTagStr + '</div>' +
                '<div class="unit-faction-badge badge-' + s.faction + '">' + factionIcon + ' ' + factionUpper + '</div>' +
              '</div>' +
            '</div>' +
            '<div>' +
              '<div style="font-size: 12px; color: #94a3b8; margin-top: 6px;">Début : ' + startTimeStr + '</div>' +
              '<div class="unit-timer" data-start="' + s.startTime + '">' + formatDuration(s.startTime) + '</div>' +
            '</div>' +
          '</div>';
        }).join('');

      } catch (err) {
        console.error('Erreur chargement active services:', err);
      }
    }

    async function loadLeaderboard() {
      try {
        const res = await fetch('/api/service/leaderboard');
        const data = await res.json();
        const body = document.getElementById('leaderboardBody');

        if (!data || data.length === 0) {
          body.innerHTML = '<tr><td colspan="4" class="empty-msg">Aucun classement disponible.</td></tr>';
          return;
        }

        body.innerHTML = data.map(function(item, idx) {
          var medal = idx === 0 ? '🥇' : idx === 1 ? '🥈' : idx === 2 ? '🥉' : '#' + (idx + 1);
          var hours = Math.floor(item.totalMinutes / 60);
          var mins = item.totalMinutes % 60;
          var userTagStr = item.userTag || item.userId;
          return '<tr class="row-item">' +
            '<td class="rank-medal">' + medal + '</td>' +
            '<td style="font-weight: 700; color: #fff;">' + userTagStr + '</td>' +
            '<td>' + item.shiftCount + ' service(s)</td>' +
            '<td style="font-weight: 700; color: #60a5fa;">' + hours + 'h ' + mins + 'min</td>' +
          '</tr>';
        }).join('');
      } catch (err) {
        console.error('Erreur chargement leaderboard:', err);
      }
    }


    setInterval(() => {
      document.querySelectorAll('.unit-timer').forEach(el => {
        const start = parseInt(el.getAttribute('data-start'), 10);
        if (start) el.innerText = formatDuration(start);
      });
    }, 1000);

    loadActiveServices();
    loadLeaderboard();
    setInterval(loadActiveServices, 15000);
  </script>
</body>
</html>
  `;
}

module.exports = {
  startWebServer,
  createQuizSession
};


