require('dotenv').config();
const { Client, GatewayIntentBits, Partials, Collection } = require('discord.js');
const db = require('./database/db');

// Error protection to keep bot 24/7 online
process.on('unhandledRejection', (reason, promise) => {
  console.error('⚠️ Warning (Unhandled Rejection):', reason);
});

process.on('uncaughtException', (error) => {
  console.error('⚠️ Warning (Uncaught Exception):', error);
});

// Command modules
const serviceCommands = require('./commands/service');
const dispatchCommands = require('./commands/dispatch');
const policeCommands = require('./commands/police');
const identityCommands = require('./commands/identity');
const illegalCommands = require('./commands/illegal');
const announcementCommands = require('./commands/announcements');
const moderationCommands = require('./commands/moderation');
const verificationCommands = require('./commands/verification');
const sanctionsCommands = require('./commands/sanctions');
const staffSanctionsCommands = require('./commands/staffSanctions');
const staffServiceCommands = require('./commands/staffService');
const staffRankCommands = require('./commands/staffRank');
const staffAbsenceCommands = require('./commands/staffAbsence');
const staffReviewCommands = require('./commands/staffReview');
const suggestionCommands = require('./commands/suggestions');
const giveawayCommands = require('./commands/giveaway');
const antiraidCommands = require('./commands/antiraid');
const backupCommands = require('./commands/backup');
const recrutementCommands = require('./commands/recrutement');
const partenariatCommands = require('./commands/partenariat');
const organisationCommands = require('./commands/organisation');
const economyCommands = require('./commands/economy');
const levelCommands = require('./commands/level');
const lookupCommands = require('./commands/lookup');
const { initAutoBackupScheduler } = require('./utils/backupManager');

// Event modules
const readyEvent = require('./events/ready');
const interactionEvent = require('./events/interactionCreate');
const messageEvent = require('./events/messageCreate');
const guildMemberAddEvent = require('./events/guildMemberAdd');
const guildMemberRemoveEvent = require('./events/guildMemberRemove');
const voiceStateUpdateEvent = require('./events/voiceStateUpdate');

// Audit Log Events
const messageDeleteEvent = require('./events/messageDelete');
const messageUpdateEvent = require('./events/messageUpdate');
const guildMemberUpdateEvent = require('./events/guildMemberUpdate');
const roleCreateEvent = require('./events/roleCreate');
const roleDeleteEvent = require('./events/roleDelete');
const roleUpdateEvent = require('./events/roleUpdate');
const channelCreateEvent = require('./events/channelCreate');
const channelDeleteEvent = require('./events/channelDelete');
const channelUpdateEvent = require('./events/channelUpdate');
const guildBanAddEvent = require('./events/guildBanAdd');
const guildBanRemoveEvent = require('./events/guildBanRemove');

// Create Client with required Intents & Partials
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.GuildModeration,
    GatewayIntentBits.GuildVoiceStates
  ],
  partials: [
    Partials.Message,
    Partials.Channel,
    Partials.GuildMember,
    Partials.User
  ]
});



client.commands = new Collection();

const allModules = [
  ...serviceCommands,
  ...dispatchCommands,
  ...policeCommands,
  ...identityCommands,
  ...illegalCommands,
  ...announcementCommands,
  ...moderationCommands,
  ...verificationCommands,
  ...sanctionsCommands,
  ...staffSanctionsCommands,
  ...staffServiceCommands,
  ...staffRankCommands,
  ...staffAbsenceCommands,
  ...staffReviewCommands,
  ...suggestionCommands,
  ...giveawayCommands,
  ...antiraidCommands,
  ...backupCommands,
  ...recrutementCommands,
  ...partenariatCommands,
  ...organisationCommands,
  ...economyCommands,
  ...levelCommands,
  ...lookupCommands
];




for (const cmd of allModules) {
  client.commands.set(cmd.data.name, cmd);
}

// Core Events
client.once(readyEvent.name, (...args) => readyEvent.execute(...args));
client.on(interactionEvent.name, (...args) => interactionEvent.execute(...args));
client.on(messageEvent.name, (...args) => messageEvent.execute(...args));
client.on(guildMemberAddEvent.name, (...args) => guildMemberAddEvent.execute(...args));
client.on(guildMemberRemoveEvent.name, (...args) => guildMemberRemoveEvent.execute(...args));
client.on(voiceStateUpdateEvent.name, (...args) => voiceStateUpdateEvent.execute(...args));


// Audit Events
client.on(messageDeleteEvent.name, (...args) => messageDeleteEvent.execute(...args));
client.on(messageUpdateEvent.name, (...args) => messageUpdateEvent.execute(...args));
client.on(guildMemberUpdateEvent.name, (...args) => guildMemberUpdateEvent.execute(...args));
client.on(roleCreateEvent.name, (...args) => roleCreateEvent.execute(...args));
client.on(roleDeleteEvent.name, (...args) => roleDeleteEvent.execute(...args));
client.on(roleUpdateEvent.name, (...args) => roleUpdateEvent.execute(...args));
client.on(channelCreateEvent.name, (...args) => channelCreateEvent.execute(...args));
client.on(channelDeleteEvent.name, (...args) => channelDeleteEvent.execute(...args));
client.on(channelUpdateEvent.name, (...args) => channelUpdateEvent.execute(...args));
client.on(guildBanAddEvent.name, (...args) => guildBanAddEvent.execute(...args));
client.on(guildBanRemoveEvent.name, (...args) => guildBanRemoveEvent.execute(...args));

const { startWebServer } = require('./web/webServer');

(async () => {
  try {
    await db.initDatabase();

    // Start 24h Auto-Backup Scheduler
    initAutoBackupScheduler(client);

    const token = process.env.DISCORD_TOKEN;
    if (!token || token === 'ENTRER_VOTRE_TOKEN_ICI') {
      console.error('\n❌ ERREUR DE DÉMARRAGE : Le DISCORD_TOKEN n\'a pas encore été configuré dans le fichier .env !');
      process.exit(1);
    }

    await client.login(token);

    // Start Web Anti-Cheat Portal
    startWebServer(client);
  } catch (error) {
    console.error('❌ Erreur lors de l\'initialisation ou de la connexion du bot:', error);
  }
})();



