const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { createEmbed } = require('../utils/embeds');
const config = require('../../config.json');

module.exports = [
  // 1. /annonce-rp
  {
    data: new SlashCommandBuilder()
      .setName('annonce-rp')
      .setDescription('Publier une annonce officielle avec style.')
      .addStringOption(opt =>
        opt.setName('type')
          .setDescription('Entité émettrice')
          .setRequired(true)
          .addChoices(
            { name: '🏛️ Mairie de Hamburg', value: 'Mairie de Hamburg' },
            { name: '🚓 Polizei Hamburg', value: 'Polizei Hamburg' },
            { name: '🚒 Feuerwehr (Pompiers)', value: 'Feuerwehr Hamburg' },
            { name: '📰 Hamburg News (Presse)', value: 'Hamburg News' }
          )
      )
      .addStringOption(opt => opt.setName('titre').setDescription('Titre de l\'annonce').setRequired(true))
      .addStringOption(opt => opt.setName('message').setDescription('Contenu de l\'annonce').setRequired(true)),
    async execute(interaction) {
      const type = interaction.options.getString('type');
      const title = interaction.options.getString('titre');
      const msg = interaction.options.getString('message');

      const embed = createEmbed({
        title: `📢 ANNONCE OFFICIELLE • ${type.toUpperCase()}`,
        description: `### ${title}\n\n${msg}\n\n*Publié par <@${interaction.user.id}>*`,
        color: config.colors.primary
      });

      await interaction.reply({ embeds: [embed] });
    }
  },

  // 2. /code-rouge
  {
    data: new SlashCommandBuilder()
      .setName('code-rouge')
      .setDescription('Déclencher le Code Rouge (État d\'urgence général).')
      .addStringOption(opt => opt.setName('motif').setDescription('Raison de l\'état d\'urgence').setRequired(true))
      .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),
    async execute(interaction) {
      const reason = interaction.options.getString('motif');

      const embed = createEmbed({
        title: '🚨🚨 CODE ROUGE ENCLENCHÉ • ÉTAT D\'URGENCE GENERAL 🚨🚨',
        description: `La Mairie et le Haut Commandement de la Police ont déclaré le **CODE ROUGE** dans toute la ville de Hamburg !\n\n` +
          `📝 **Motif** : **${reason}**\n\n` +
          `⚠️ **CONSIGNES DE SÉCURITÉ** :\n` +
          `1. Tous les citoyens doivent rester à leur domicile ou s'abriter.\n` +
          `2. Les forces de l'ordre ont l'autorisation d'effectuer des contrôles d'urgence.\n` +
          `3. Tout citoyen armé ou suspect dans la rue sera interpellé immédiatement.`,
        color: config.colors.danger
      });

      await interaction.reply({ content: '@everyone 🚨 CODE ROUGE !', embeds: [embed] });
    }
  },

  // 3. /code-vert
  {
    data: new SlashCommandBuilder()
      .setName('code-vert')
      .setDescription('Fin de l\'état d\'urgence / Retour à la normale.')
      .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),
    async execute(interaction) {
      const embed = createEmbed({
        title: '🟢 CODE VERT • RETOUR AU CALME',
        description: `Le **Code Rouge** est levé. La situation dans la ville de Hamburg est à nouveau sous contrôle.\n\nMerci à toutes les unités pour leur intervention !`,
        color: config.colors.success
      });

      await interaction.reply({ embeds: [embed] });
    }
  },

  // 4. /meteo-rp
  {
    data: new SlashCommandBuilder()
      .setName('meteo-rp')
      .setDescription('Consulter ou définir la météo actuelle dans Hamburg.')
      .addStringOption(opt =>
        opt.setName('temps')
          .setDescription('Conditions météo (Laissez vide pour consulter)')
          .setRequired(false)
          .addChoices(
            { name: '☀️ Ensoleillé (Grand Soleil)', value: '☀️ Grand Soleil (22°C)' },
            { name: '🌧️ Pluie Battante & Orage', value: '🌧️ Pluie Battante & Brouillard (12°C)' },
            { name: '🌫️ Brouillard Épais', value: '🌫️ Brouillard Épais (Visibilité Réduite 15m)' },
            { name: '❄️ Chute de Neige & Verglas', value: '❄️ Neige & Chaussée Glissante (-2°C)' }
          )
      ),
    async execute(interaction) {
      const weather = interaction.options.getString('temps');

      if (!weather) {
        return interaction.reply({
          embeds: [createEmbed({
            title: '🌤️ BULLETIN MÉTÉO HAMBURG',
            description: `Conditions météo actuelles : **☀️ Grand Soleil (21°C)**\n*Routes sèches, conditions optimales pour la circulation.*`,
            color: config.colors.primary
          })]
        });
      }

      const embed = createEmbed({
        title: '🌤️ CHANGEMENT DE MÉTÉO EN VILLE',
        description: `Le bulletin météo officiel de Hamburg a été mis à jour par la station météo :\n\n👉 **Nouvelles conditions** : **${weather}**`,
        color: config.colors.primary
      });

      await interaction.reply({ embeds: [embed] });
    }
  }
];
