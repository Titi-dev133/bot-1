const { EmbedBuilder, AuditLogEvent } = require('discord.js');
const { sendAuditLog } = require('../utils/auditLogger');
const config = require('../../config.json');

module.exports = {
  name: 'roleCreate',
  async execute(role) {
    try {
      if (!role.guild) return;

      const embed = new EmbedBuilder()
        .setTitle('⚙️ LOG AUDIT : CRÉATION D\'UN RÔLE')
        .setColor(role.hexColor !== '#000000' ? role.hexColor : (config.colors?.success || '#43A047'))
        .addFields(
          { name: '🏷️ Rôle créé', value: `<@&${role.id}> (\`${role.name}\` | \`ID: ${role.id}\`)`, inline: false },
          { name: '🎨 Couleur', value: `\`${role.hexColor}\``, inline: true },
          { name: '📌 Position', value: `\`${role.position}\``, inline: true },
          { name: '🔔 Mentionnable', value: role.mentionable ? 'Oui' : 'Non', inline: true }
        )
        .setFooter({ text: `Role ID: ${role.id} • Hamburg RP` })
        .setTimestamp();

      try {
        const fetchedLogs = await role.guild.fetchAuditLogs({
          limit: 1,
          type: AuditLogEvent.RoleCreate,
        });
        const auditEntry = fetchedLogs.entries.first();
        if (auditEntry && auditEntry.target.id === role.id && (Date.now() - auditEntry.createdTimestamp) < 5000) {
          embed.addFields({ name: '👮 Créé par', value: `<@${auditEntry.executor.id}> (\`${auditEntry.executor.tag}\`)`, inline: false });
        }
      } catch (e) {}

      await sendAuditLog(role.guild, embed);
    } catch (error) {
      console.error('❌ Erreur dans l\'événement roleCreate:', error);
    }
  }
};
