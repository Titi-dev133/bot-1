const { SlashCommandBuilder } = require('discord.js');
const { dispatch911Embed, createEmbed } = require('../utils/embeds');
const config = require('../../config.json');

let callCounter = 100;

module.exports = [
  // 1. /911 ou /appel-urgence
  {
    data: new SlashCommandBuilder()
      .setName('911')
      .setDescription('Déclencher un appel d\'urgence 911 vers les forces de l\'ordre / secours.')
      .addStringOption(opt =>
        opt.setName('service')
          .setDescription('Service sollicité')
          .setRequired(true)
          .addChoices(
            { name: '🚓 Police (Polizei)', value: 'police' },
            { name: '🚒 Pompiers (Feuerwehr)', value: 'fire' },
            { name: '🚑 Secours Médicaux (EMS)', value: 'ems' },
            { name: '🛞 Dépannage (ADAC)', value: 'adac' }
          )
      )
      .addStringOption(opt => opt.setName('lieu').setDescription('Localisation précise dans Hamburg').setRequired(true))
      .addStringOption(opt => opt.setName('description').setDescription('Description détaillée de l\'urgence').setRequired(true)),
    async execute(interaction) {
      const service = interaction.options.getString('service');
      const location = interaction.options.getString('lieu');
      const description = interaction.options.getString('description');
      callCounter++;

      const dispatchPayload = dispatch911Embed({
        caller: `${interaction.user} (${interaction.user.tag})`,
        service,
        location,
        description,
        callId: callCounter
      });

      await interaction.reply({
        content: `✅ Votre appel 911 **#${callCounter}** a été transmis à la centrale d'urgence. Des unités vont être dépêchées sur place.`,
        ephemeral: true
      });

      // Send to current channel or dispatch channel
      await interaction.channel.send(dispatchPayload);
    }
  },

  // 2. /10-code
  {
    data: new SlashCommandBuilder()
      .setName('10-code')
      .setDescription('Transmettre un code radio officiel 10-XX sur la fréquence.')
      .addStringOption(opt =>
        opt.setName('code')
          .setDescription('Code radio 10')
          .setRequired(true)
          .addChoices(
            { name: '10-4 : Affirmatif / Compris', value: '10-4 : Affirmatif / Message reçu.' },
            { name: '10-20 : Demande de Localisation', value: '10-20 : Quelle est votre position ?' },
            { name: '10-33 : ALERTE URGENCE CRITIQUE (Message Prioritaire)', value: '10-33 : URGENCE CRITIQUE - Transmissions arrêtées !' },
            { name: '10-80 : Poursuite de véhicule en cours', value: '10-80 : Poursuite à haute vitesse engagée !' },
            { name: '10-97 : Arrivé sur les lieux de l\'intervention', value: '10-97 : Unité sur place.' },
            { name: '10-99 : OFFICIER EN DANGER / A TERRE !', value: '10-99 : AGENT EN DANGER IMMINENT !' }
          )
      )
      .addStringOption(opt => opt.setName('precision').setDescription('Précisions ou position actuelle').setRequired(false)),
    async execute(interaction) {
      const codeChoice = interaction.options.getString('code');
      const precision = interaction.options.getString('precision') || 'Aucune précision';

      const isCritical = codeChoice.includes('10-33') || codeChoice.includes('10-99');

      const embed = createEmbed({
        title: `${isCritical ? '⚠️ RADIO ALERTE PRIORITAIRE' : '📻 TRANSMISSION RADIO'}`,
        description: `**Agent** : <@${interaction.user.id}>\n📢 **Code** : \`${codeChoice}\`\n📍 **Détails / Position** : ${precision}`,
        color: isCritical ? config.colors.danger : config.colors.primary
      });

      await interaction.reply({ embeds: [embed] });
    }
  },

  // 3. /radio-dispatch
  {
    data: new SlashCommandBuilder()
      .setName('radio-dispatch')
      .setDescription('Diffuser une alerte générale depuis la centrale radio.')
      .addStringOption(opt => opt.setName('message').setDescription('Message de la centrale').setRequired(true)),
    async execute(interaction) {
      const msg = interaction.options.getString('message');

      const embed = createEmbed({
        title: '📢 OPERATEUR CENTRALE RADIO • MESSAGE GENERAL',
        description: `\`\`\`${msg}\`\`\`\n*Transmis par l'opérateur de centrale <@${interaction.user.id}>.*`,
        color: config.colors.gold
      });

      await interaction.reply({ embeds: [embed] });
    }
  }
];
