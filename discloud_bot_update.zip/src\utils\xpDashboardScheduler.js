const { EmbedBuilder } = require('discord.js');
const db = require('../database/db');
const config = require('../../config.json');

function generateProgressBar(current, max, length = 10) {
  const percentage = Math.min(1, Math.max(0, current / max));
  const filledLength = Math.round(length * percentage);
  const emptyLength = length - filledLength;
  return '█'.repeat(filledLength) + '░'.repeat(emptyLength);
}

async function createXpLeaderboardEmbed(guild) {
  const topUsers = await db.getTopXPLeaderboard(10);

  let description =
    `Bienvenue sur le **Tableau de Statistiques & Niveaux** d'**Aubagne RP Officiel** !\n` +
    `*Écrivez dans les salons pour gagner de l'XP et grimper au classement !*\n` +
    `🔄 **Mise à jour automatique : Toutes les 5 minutes**\n\n` +
    `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n`;

  if (topUsers.length === 0) {
    description += '`Aucune donnée de niveau disponible pour le moment.`';
  } else {
    for (let i = 0; i < topUsers.length; i++) {
      const u = topUsers[i];
      const medal = i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : `\`#${i + 1}\``;
      const nextXP = db.getRequiredXPForLevel ? db.getRequiredXPForLevel(u.level) : u.level * u.level * 100;
      const progressBar = generateProgressBar(u.xp, nextXP, 8);
      const tag = `<@${u.userId}>`;

      description += `${medal} **${tag}** — **Niveau ${u.level}**\n` +
        `┗ 📊 XP : \`${u.xp} / ${nextXP} XP\` [${progressBar}] • \`${u.messageCount || 0} msgs\`\n\n`;
    }
  }

  return new EmbedBuilder()
    .setTitle('🏆 CLASSEMENT GÉNÉRAL DES NIVEAUX & XP • AUBAGNE RP')
    .setDescription(description)
    .setColor('#9C27B0')
    .setThumbnail('https://i.imgur.com/8QG4m3b.png')
    .setFooter({ text: 'Aubagne RP Officiel • Tableau de Statistiques (Auto-Update 5 min)' })
    .setTimestamp();
}

async function updateAllXpDashboards(client) {
  try {
    const dashboards = await db.getAllXpDashboardsRecords();
    for (const record of dashboards) {
      try {
        const guild = client.guilds.cache.get(record.guildId);
        if (!guild) continue;

        const channel = guild.channels.cache.get(record.channelId);
        if (!channel) continue;

        const message = await channel.messages.fetch(record.messageId).catch(() => null);
        if (!message) continue;

        const embed = await createXpLeaderboardEmbed(guild);
        await message.edit({ embeds: [embed] });
      } catch (err) {
        console.error(`Erreur mise à jour dashboard XP (Guild ${record.guildId}):`, err.message);
      }
    }
  } catch (error) {
    console.error('Erreur globale updateAllXpDashboards:', error);
  }
}

function initXpDashboardScheduler(client) {
  console.log('⏰ Initialisation du Planificateur du Tableau de Statistiques XP (Auto-Update toutes les 5 minutes)...');
  
  // Première mise à jour après 10 secondes
  setTimeout(() => {
    updateAllXpDashboards(client);
  }, 10000);

  // Mise à jour toutes les 5 minutes (300 000 ms)
  setInterval(() => {
    updateAllXpDashboards(client);
  }, 300000);
}

module.exports = {
  createXpLeaderboardEmbed,
  updateAllXpDashboards,
  initXpDashboardScheduler
};
