require('dotenv').config();
const { REST, Routes, Client, GatewayIntentBits } = require('discord.js');

const serviceCommands = require('./commands/service');
const dispatchCommands = require('./commands/dispatch');
const policeCommands = require('./commands/police');
const identityCommands = require('./commands/identity');
const illegalCommands = require('./commands/illegal');
const announcementCommands = require('./commands/announcements');
const moderationCommands = require('./commands/moderation');
const verificationCommands = require('./commands/verification');
const sanctionsCommands = require('./commands/sanctions');
const staffSanctionsCommands = require('./commands/staffSanctions');
const staffServiceCommands = require('./commands/staffService');
const staffRankCommands = require('./commands/staffRank');
const staffAbsenceCommands = require('./commands/staffAbsence');
const staffReviewCommands = require('./commands/staffReview');
const suggestionCommands = require('./commands/suggestions');
const giveawayCommands = require('./commands/giveaway');
const antiraidCommands = require('./commands/antiraid');
const backupCommands = require('./commands/backup');
const recrutementCommands = require('./commands/recrutement');
const partenariatCommands = require('./commands/partenariat');
const organisationCommands = require('./commands/organisation');
const economyCommands = require('./commands/economy');
const levelCommands = require('./commands/level');
const lookupCommands = require('./commands/lookup');

const allModules = [
  ...serviceCommands, ...dispatchCommands, ...policeCommands, ...identityCommands,
  ...illegalCommands, ...announcementCommands, ...moderationCommands, ...verificationCommands,
  ...sanctionsCommands, ...staffSanctionsCommands, ...staffServiceCommands, ...staffRankCommands,
  ...staffAbsenceCommands, ...staffReviewCommands, ...suggestionCommands, ...giveawayCommands,
  ...antiraidCommands, ...backupCommands, ...recrutementCommands, ...partenariatCommands,
  ...organisationCommands, ...economyCommands, ...levelCommands, ...lookupCommands
];

const commandsJSON = allModules.map(cmd => cmd.data.toJSON());

const client = new Client({ intents: [GatewayIntentBits.Guilds] });

client.on('ready', async () => {
  console.log(`🤖 Connecté en tant que ${client.user.tag} (ID: ${client.user.id})`);
  const rest = new REST({ version: '10' }).setToken(process.env.DISCORD_TOKEN);

  try {
    // 1. Purge ALL Global Commands
    console.log('🧹 Purge des commandes GLOBALES...');
    await rest.put(Routes.applicationCommands(client.user.id), { body: [] });
    console.log('✅ Commandes globales purgées !');

    // 2. Purge and Re-deploy on ALL connected Guilds
    for (const [guildId, guild] of client.guilds.cache) {
      console.log(`🧹 Purge des commandes de la guilde "${guild.name}" (${guildId})...`);
      await rest.put(Routes.applicationGuildCommands(client.user.id, guildId), { body: [] });
      console.log(`✅ Guilde "${guild.name}" purgée !`);

      console.log(`🚀 Redéploiement de ${commandsJSON.length} commandes sur "${guild.name}"...`);
      await rest.put(Routes.applicationGuildCommands(client.user.id, guildId), { body: commandsJSON });
      console.log(`✅ Redéploiement terminé sur "${guild.name}" !`);
    }
  } catch (err) {
    console.error('❌ Erreur lors de la réinitialisation :', err);
  } finally {
    client.destroy();
  }
});

client.login(process.env.DISCORD_TOKEN);
