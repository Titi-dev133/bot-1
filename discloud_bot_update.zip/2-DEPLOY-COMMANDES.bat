@echo off
title Deploiement des commandes Slash
echo ======================================================
echo   2. Enregistrement des commandes Slash sur Discord
echo ======================================================
call npm run deploy
echo.
pause
