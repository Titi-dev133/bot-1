const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const db = require('../database/db');
const { processAIConversation } = require('../utils/aiConversational');
const { createEmbed } = require('../utils/embeds');
const { sendAuditLog } = require('../utils/auditLogger');
const { handleQuizChatMessage } = require('../utils/staffQuizManager');
const config = require('../../config.json');

// In-memory spam tracker map: userId -> Array of timestamps
const userSpamTracker = new Map();

module.exports = {
  name: 'messageCreate',
  async execute(message) {
    // Ignore bot messages or DM
    if (message.author.bot || !message.guild) return;

    // --- CONTRÔLE QUIZ STAFF CHAT DIRECT (PRIORITAIRE) ---
    const isQuizHandled = await handleQuizChatMessage(message);
    if (isQuizHandled) return;


    // --- ANTI-SPAM & ANTI-MASS MENTION CHECKS ---
    try {
      const antiRaidConfig = await db.getAntiRaidConfig(message.guild.id);

      if (antiRaidConfig.antiSpam === 1 && message.member && !message.member.permissions.has(PermissionFlagsBits.Administrator)) {
        const userId = message.author.id;
        const now = Date.now();

        // Track user timestamps
        if (!userSpamTracker.has(userId)) {
          userSpamTracker.set(userId, []);
        }

        const timestamps = userSpamTracker.get(userId);
        timestamps.push(now);

        // Keep timestamps within last 5 seconds
        const recentMessages = timestamps.filter(t => (now - t) <= 5000);
        userSpamTracker.set(userId, recentMessages);

        const maxMsgs = antiRaidConfig.maxMessagesPer5Sec || 5;
        const maxPings = antiRaidConfig.maxMentions || 4;

        const totalMentions = message.mentions.users.size + message.mentions.roles.size + (message.mentions.everyone ? 1 : 0);

        // A. Check Mass Mentions
        if (totalMentions >= maxPings) {
          console.warn(`💥 ANTI-MASS MENTION : ${message.author.tag} a fait ${totalMentions} mentions dans un message !`);

          await message.delete().catch(() => {});
          await message.member.timeout(15 * 60 * 1000, 'Anti-Mass Mention System').catch(() => {});

          const logEmbed = {
            title: '💥 ANTI-RAID : MASS MENTION DÉTECTÉ',
            color: '#E53935',
            fields: [
              { name: '👤 Spammer', value: `<@${message.author.id}> (\`${message.author.tag}\`)`, inline: true },
              { name: '📍 Salon', value: `${message.channel}`, inline: true },
              { name: '🔔 Mentions', value: `\`${totalMentions}\` mentions (Seuil max: \`${maxPings}\`)`, inline: false },
              { name: '📌 Sanction', value: '🗑️ Message Supprimé + ⏱️ Mute temporaire (15 mins)', inline: false }
            ],
            timestamp: new Date()
          };
          await sendAuditLog(message.guild, logEmbed);

          const warnMsg = await message.channel.send(`⚠️ <@${message.author.id}> a été mis en sourdine (15 mins) pour **Mentions de Masse / Spam Pings** !`);
          setTimeout(() => warnMsg.delete().catch(() => {}), 10000);
          return;
        }

        // B. Check Message Frequency Spam
        if (recentMessages.length >= maxMsgs) {
          console.warn(`💥 ANTI-SPAM : ${message.author.tag} envoie trop de messages (${recentMessages.length} en 5s) !`);

          await message.delete().catch(() => {});
          await message.member.timeout(10 * 60 * 1000, 'Anti-Spam System').catch(() => {});

          const logEmbed = {
            title: '💥 ANTI-RAID : SPAM RAPIDE DÉTECTÉ',
            color: '#FB8C00',
            fields: [
              { name: '👤 Spammer', value: `<@${message.author.id}> (\`${message.author.tag}\`)`, inline: true },
              { name: '📍 Salon', value: `${message.channel}`, inline: true },
              { name: '⚡ Fréquence', value: `\`${recentMessages.length} msgs / 5 sec\` (Max: \`${maxMsgs}\`)`, inline: false },
              { name: '📌 Sanction', value: '🗑️ Message Supprimé + ⏱️ Mute temporaire (10 mins)', inline: false }
            ],
            timestamp: new Date()
          };
          await sendAuditLog(message.guild, logEmbed);

          const warnMsg = await message.channel.send(`⚠️ <@${message.author.id}> a été mis en sourdine (10 mins) pour **Spam Rapide** !`);
          setTimeout(() => warnMsg.delete().catch(() => {}), 10000);
          return;
        }
      }
    } catch (err) {
      console.error('Erreur lors du contrôle anti-spam messageCreate:', err);
    }

    // --- GESTION XP & LEVELING AUTOMATIQUE ---
    try {
      const cooldownRemaining = await db.getCooldown(message.author.id, 'xp_msg');

      if (cooldownRemaining === 0) {
        // Gain de 15 à 25 XP par message
        const gainedXP = Math.floor(Math.random() * 11) + 15;
        const xpResult = await db.addXP(message.author.id, gainedXP);

        // Cooldown de 60 secondes par membre
        await db.setCooldown(message.author.id, 'xp_msg', 60000);

        if (xpResult.leveledUp) {
          const levelUpEmbed = createEmbed({
            title: '🎉 LEVEL UP ! NOUVEAU NIVEAU ATTEINT',
            description:
              `Bravo <@${message.author.id}> ! Vous venez de passer au **Niveau ${xpResult.level}** !\n\n` +
              `⭐ **Niveau Actuel** : \`Niveau ${xpResult.level}\`\n` +
              `💬 **Messages Envoyés** : \`${xpResult.messageCount}\` msgs\n` +
              `📊 Consultez vos statistiques et le classement avec \`/rank\` et \`/top-xp\` !`,
            color: config.colors.gold,
            thumbnail: message.author.displayAvatarURL({ dynamic: true })
          });
          const msg = await message.channel.send({ content: `🎉 Félicitations <@${message.author.id}> !`, embeds: [levelUpEmbed] });
          setTimeout(() => msg.delete().catch(() => {}), 15000);
        }
      }
    } catch (xpErr) {
      console.error('Erreur attribution XP messageCreate:', xpErr);
    }

    // --- TICKET AI ASSISTANT LOGIC ---

    const channelName = message.channel.name || '';
    if (!channelName.startsWith('ticket-')) return;

    const isBotMentioned = message.mentions.has(message.client.user.id);
    let ticketRecord = await db.getTicketByChannel(message.channel.id);

    const isOpener = ticketRecord && message.author.id === ticketRecord.userId;

    const isOtherStaffMember = !isOpener && message.member && (
      message.member.permissions.has(PermissionFlagsBits.ManageMessages) ||
      message.member.permissions.has(PermissionFlagsBits.Administrator) ||
      message.member.permissions.has(PermissionFlagsBits.ManageChannels)
    );

    if (isOtherStaffMember && (!ticketRecord || ticketRecord.status !== 'CLAIMED')) {
      await db.claimTicketRecord(message.channel.id, message.author.id);
      ticketRecord = await db.getTicketByChannel(message.channel.id);

      try {
        const { ChannelType } = require('discord.js');
        const logChannel = message.guild.channels.cache.find(
          c => c.type === ChannelType.GuildText && (c.name.toLowerCase() === 'log-tickets' || c.name.toLowerCase() === 'logs-tickets' || c.name.toLowerCase().includes('log-ticket'))
        );
        if (logChannel) {
          const logEmbed = createEmbed({
            title: '✋ TICKET PRIS EN CHARGE (Message Staff)',
            description:
              `👮 **Staff** : <@${message.author.id}> (\`${message.author.tag}\`)\n` +
              `👤 **Demandeur** : <@${ticketRecord ? ticketRecord.userId : 'Inconnu'}>\n` +
              `📌 **Motif** : \`${ticketRecord ? ticketRecord.category : 'Assistance'}\`\n` +
              `💬 **Salon** : <#${message.channel.id}> (\`#${message.channel.name}\`)`,
            color: config.colors.warning,
            footer: 'Système de Logs • Aubagne RP'
          });
          logChannel.send({ embeds: [logEmbed] }).catch(() => {});
        }
      } catch (e) {}
    }

    const isClaimed = ticketRecord && ticketRecord.status === 'CLAIMED';

    if ((isClaimed || isOtherStaffMember) && !isBotMentioned) return;

    try {
      await message.channel.sendTyping();

      const category = ticketRecord ? ticketRecord.category : 'Assistance';

      const aiResult = await processAIConversation({
        userMessage: message,
        category,
        conversationHistory: []
      });

      await message.reply({ content: aiResult.response });

      if (aiResult.shouldPingStaff) {
        const staffPing = config.staffPingRole ? `<@&${config.staffPingRole}>` : '@here';

        const escalationEmbed = createEmbed({
          title: '🚨 ASSISTANT IA • APPEL DU STAFF (PING STAFF ALL)',
          description:
            `L'assistant IA a transmis ce ticket à l'équipe Staff d'Aubagne RP !\n\n` +
            `👤 **Demandeur** : <@${message.author.id}>\n` +
            `📌 **Motif** : \`${category}\`\n` +
            `📝 **Raison du transfert** : ${aiResult.reason || 'Demande transmise au staff'}\n\n` +
            `📢 **Alerte Staff** : ${staffPing} — Merci de prendre en charge ce ticket !`,
          color: config.colors.danger
        });

        await message.channel.send({
          content: `${staffPing} 🚨 **Intervention Staff Requise !**`,
          embeds: [escalationEmbed]
        });
      }
    } catch (error) {
      console.error('Erreur lors du traitement IA messageCreate:', error);
    }
  }
};
