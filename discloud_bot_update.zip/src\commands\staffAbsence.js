const { SlashCommandBuilder, MessageFlags } = require('discord.js');
const { staffAbsenceDashboardEmbed, staffAbsenceLogEmbed, staffAbsenceListEmbed } = require('../utils/embeds');
const db = require('../database/db');

module.exports = [
  {
    data: new SlashCommandBuilder()
      .setName('absence-staff')
      .setDescription('Système de déclaration d\'absences et congés pour l\'équipe Staff.')
      .addSubcommand(sub =>
        sub.setName('dashboard')
           .setDescription('Publie le panneau interactif de déclaration d\'absences dans ce salon.')
      )
      .addSubcommand(sub =>
        sub.setName('declarer')
           .setDescription('Déclarer une absence ou un congé.')
           .addStringOption(opt => opt.setName('debut').setDescription('Date de début de l\'absence (ex: Aujourd\'hui ou 20/08/2026)').setRequired(true))
           .addStringOption(opt => opt.setName('fin').setDescription('Date de retour prévue (ex: 27/08/2026)').setRequired(true))
           .addStringOption(opt => opt.setName('motif').setDescription('Motif de l\'absence').setRequired(true))
      )
      .addSubcommand(sub =>
        sub.setName('retour')
           .setDescription('Signaler votre retour et clôturer votre période d\'absence.')
      )
      .addSubcommand(sub =>
        sub.setName('liste')
           .setDescription('Consulter la liste des membres du staff actuellement absents.')
      ),

    async execute(interaction) {
      const subcommand = interaction.options.getSubcommand();
      const { guild, channel, user } = interaction;

      // Subcommand 1: dashboard
      if (subcommand === 'dashboard') {
        const payload = staffAbsenceDashboardEmbed();
        await channel.send(payload);

        return interaction.reply({
          content: `✅ **Panneau du Dashboard d'Absences Staff publié dans ${channel} !**`,
          flags: MessageFlags.Ephemeral
        });
      }

      // Subcommand 2: declarer
      if (subcommand === 'declarer') {
        await interaction.deferReply({ flags: MessageFlags.Ephemeral });
        const startDate = interaction.options.getString('debut').trim();
        const endDate = interaction.options.getString('fin').trim();
        const reason = interaction.options.getString('motif').trim();

        // Save in DB
        await db.addStaffAbsence(
          guild.id,
          user.id,
          user.tag || user.username,
          startDate,
          endDate,
          reason
        );

        // Add "Staff en Absence" role
        let role = guild.roles.cache.find(r => r.name.toLowerCase() === 'staff en absence' || r.name.toLowerCase() === 'staff absent');
        if (!role) {
          try {
            role = await guild.roles.create({
              name: 'Staff en Absence',
              color: '#E67E22',
              reason: 'Rôle automatique pour les modérateurs en absence'
            });
          } catch (e) {}
        }

        if (role) {
          const member = await guild.members.fetch(user.id).catch(() => null);
          if (member) await member.roles.add(role).catch(() => {});
        }

        // Log to #log-absence-staff in LOGS category
        let logChannel = guild.channels.cache.find(c => c.name.toLowerCase() === 'log-absence-staff');
        if (logChannel) {
          const logEmbed = staffAbsenceLogEmbed({
            user,
            actionType: 'declaration',
            startDate,
            endDate,
            reason
          });
          logChannel.send({ embeds: [logEmbed] }).catch(() => {});
        }

        return interaction.editReply({
          content: `📝 **Votre déclaration d'absence a été enregistrée avec succès !**\n\n` +
            `📅 **Période** : Du **${startDate}** au **${endDate}**\n` +
            `💬 **Motif** : ${reason}\n\n` +
            `📌 *Le rôle **Staff en Absence** vous a été attribué et le log a été transmis.*`
        });
      }

      // Subcommand 3: retour
      if (subcommand === 'retour') {
        await interaction.deferReply({ flags: MessageFlags.Ephemeral });

        const activeAbsence = await db.getActiveStaffAbsence(guild.id, user.id);
        if (!activeAbsence) {
          return interaction.editReply({
            content: `ℹ️ **Vous n'avez aucune déclaration d'absence active à clôturer.**`
          });
        }

        await db.endStaffAbsence(guild.id, user.id);

        let role = guild.roles.cache.find(r => r.name.toLowerCase() === 'staff en absence' || r.name.toLowerCase() === 'staff absent');
        if (role) {
          const member = await guild.members.fetch(user.id).catch(() => null);
          if (member) await member.roles.remove(role).catch(() => {});
        }

        let logChannel = guild.channels.cache.find(c => c.name.toLowerCase() === 'log-absence-staff');
        if (logChannel) {
          const logEmbed = staffAbsenceLogEmbed({
            user,
            actionType: 'return'
          });
          logChannel.send({ embeds: [logEmbed] }).catch(() => {});
        }

        return interaction.editReply({
          content: `🏠 **Bon retour parmi nous, <@${user.id}> !**\n\nVotre période d'absence a été clôturée avec succès et votre rôle **Staff en Absence** a été retiré.`
        });
      }

      // Subcommand 4: liste
      if (subcommand === 'liste') {
        await interaction.deferReply({ flags: MessageFlags.Ephemeral });
        const activeAbsences = await db.getAllActiveStaffAbsences(guild.id);
        const embed = staffAbsenceListEmbed(activeAbsences);

        return interaction.editReply({ embeds: [embed] });
      }
    }
  }
];
