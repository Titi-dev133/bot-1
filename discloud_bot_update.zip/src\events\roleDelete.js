const { EmbedBuilder, AuditLogEvent } = require('discord.js');
const { sendAuditLog } = require('../utils/auditLogger');
const config = require('../../config.json');

module.exports = {
  name: 'roleDelete',
  async execute(role) {
    try {
      if (!role.guild) return;

      const embed = new EmbedBuilder()
        .setTitle('🗑️ LOG AUDIT : SUPPRESSION D\'UN RÔLE')
        .setColor(config.colors?.danger || '#E53935')
        .addFields(
          { name: '🏷️ Rôle supprimé', value: `\`${role.name}\` (\`ID: ${role.id}\`)`, inline: false },
          { name: '🎨 Couleur d\'origine', value: `\`${role.hexColor}\``, inline: true }
        )
        .setFooter({ text: `Role ID: ${role.id} • Hamburg RP` })
        .setTimestamp();

      try {
        const fetchedLogs = await role.guild.fetchAuditLogs({
          limit: 1,
          type: AuditLogEvent.RoleDelete,
        });
        const auditEntry = fetchedLogs.entries.first();
        if (auditEntry && (Date.now() - auditEntry.createdTimestamp) < 5000) {
          embed.addFields({ name: '👮 Supprimé par', value: `<@${auditEntry.executor.id}> (\`${auditEntry.executor.tag}\`)`, inline: false });
        }
      } catch (e) {}

      await sendAuditLog(role.guild, embed);
    } catch (error) {
      console.error('❌ Erreur dans l\'événement roleDelete:', error);
    }
  }
};
