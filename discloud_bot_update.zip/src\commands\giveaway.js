const { SlashCommandBuilder, PermissionFlagsBits, ChannelType, MessageFlags } = require('discord.js');
const { giveawayDashboardEmbed, giveawayCardEmbed, giveawayEndedEmbed, giveawayLogEmbed, parseDuration } = require('../utils/embeds');
const { processEndGiveaway, pickRandomWinners } = require('../utils/giveawayManager');
const db = require('../database/db');

module.exports = [
  {
    data: new SlashCommandBuilder()
      .setName('giveaway')
      .setDescription('Système de gestion et création de giveaways / concours.')
      .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
      .addSubcommand(sub =>
        sub.setName('dashboard')
           .setDescription('Publie le panneau de gestion des Giveaways dans ce salon.')
      )
      .addSubcommand(sub =>
        sub.setName('creer')
           .setDescription('Lancer un nouveau giveaway.')
           .addStringOption(opt =>
             opt.setName('prix')
                .setDescription('Gain ou lot à gagner (ex: 100.000€ IG)')
                .setRequired(true)
           )
           .addStringOption(opt =>
             opt.setName('duree')
                .setDescription('Durée du giveaway (ex: 10m, 1h, 24h, 2d)')
                .setRequired(true)
           )
           .addIntegerOption(opt =>
             opt.setName('gagnants')
                .setDescription('Nombre de gagnants (default: 1)')
                .setRequired(false)
           )
           .addChannelOption(opt =>
             opt.setName('salon')
                .setDescription('Salon d\'affichage (default: ce salon)')
                .addChannelTypes(ChannelType.GuildText)
                .setRequired(false)
           )
           .addStringOption(opt =>
             opt.setName('description')
                .setDescription('Conditions ou explications supplémentaires')
                .setRequired(false)
           )
      )
      .addSubcommand(sub =>
        sub.setName('reroll')
           .setDescription('Effectuer un nouveau tirage au sort pour un giveaway.')
           .addStringOption(opt =>
             opt.setName('message_id')
                .setDescription('ID du message (ou ID du giveaway)')
                .setRequired(true)
           )
      )
      .addSubcommand(sub =>
        sub.setName('finir')
           .setDescription('Terminer immédiatement un giveaway actif.')
           .addStringOption(opt =>
             opt.setName('message_id')
                .setDescription('ID du message (ou ID du giveaway)')
                .setRequired(true)
           )
      )
      .addSubcommand(sub =>
        sub.setName('annuler')
           .setDescription('Annuler un giveaway actif.')
           .addStringOption(opt =>
             opt.setName('message_id')
                .setDescription('ID du message (ou ID du giveaway)')
                .setRequired(true)
           )
      ),

    async execute(interaction) {
      const subcommand = interaction.options.getSubcommand();
      const { guild, channel, user } = interaction;

      // 1. Subcommand: dashboard
      if (subcommand === 'dashboard') {
        const oldDash = await db.getGiveawayDashboard(guild.id);
        if (oldDash) {
          try {
            const oldChan = guild.channels.cache.get(oldDash.channelId);
            if (oldChan) {
              const oldMsg = await oldChan.messages.fetch(oldDash.messageId).catch(() => null);
              if (oldMsg) await oldMsg.delete().catch(() => {});
            }
          } catch (e) {}
        }

        const payload = giveawayDashboardEmbed();
        const msg = await channel.send(payload);
        await db.saveGiveawayDashboard(guild.id, channel.id, msg.id);

        return interaction.reply({
          content: `✅ **Panneau de Gestion des Giveaways publié avec succès dans ${channel} !**`,
          flags: MessageFlags.Ephemeral
        });
      }

      // 2. Subcommand: creer
      if (subcommand === 'creer') {
        await interaction.deferReply({ flags: MessageFlags.Ephemeral });

        const prize = interaction.options.getString('prix').trim();
        const durationStr = interaction.options.getString('duree').trim();
        const winnersCount = interaction.options.getInteger('gagnants') || 1;
        const targetChannel = interaction.options.getChannel('salon') || channel;
        const description = interaction.options.getString('description')?.trim() || null;

        const durationMs = parseDuration(durationStr);
        if (!durationMs || durationMs < 5000) {
          return interaction.editReply({
            content: '❌ **Format de durée invalide !** Utilisez un format comme `10m` (10 min), `1h` (1 heure), `24h` (1 jour) ou `2d` (2 jours).'
          });
        }

        const endsAt = Date.now() + durationMs;

        // Draft object for embed card
        const draftGiveaway = {
          id: 'PENDING',
          prize,
          description,
          winnersCount,
          hostId: user.id,
          endsAt,
          createdAt: Date.now()
        };

        const cardPayload = giveawayCardEmbed({ giveaway: draftGiveaway, hostUser: user, participantsCount: 0 });
        const cardMsg = await targetChannel.send(cardPayload);

        // Store in DB
        const giveawayId = await db.createGiveawayRecord(
          guild.id,
          targetChannel.id,
          cardMsg.id,
          prize,
          description,
          winnersCount,
          user.id,
          endsAt
        );

        // Re-edit card with real ID
        const realGiveaway = await db.getGiveawayRecord(giveawayId);
        const realPayload = giveawayCardEmbed({ giveaway: realGiveaway, hostUser: user, participantsCount: 0 });
        await cardMsg.edit(realPayload).catch(() => {});

        return interaction.editReply({
          content: `🎉 **Giveaway lancé avec succès dans ${targetChannel} !**\n🎁 Lot : **${prize}**\n⏳ Fin : <t:${Math.floor(endsAt / 1000)}:R>`
        });
      }

      // 3. Subcommand: reroll
      if (subcommand === 'reroll') {
        await interaction.deferReply({ flags: MessageFlags.Ephemeral });
        const targetMsgId = interaction.options.getString('message_id').trim();

        const giveaway = await db.getGiveawayByMessageRecord(targetMsgId);
        if (!giveaway) {
          return interaction.editReply({ content: `❌ Aucun giveaway trouvé avec l'ID \`${targetMsgId}\`.` });
        }

        let participants = [];
        try { participants = JSON.parse(giveaway.participants || '[]'); } catch (e) {}

        if (participants.length === 0) {
          return interaction.editReply({ content: '❌ Impossible de relancer le tirage : il y a 0 participant enregistré.' });
        }

        const newWinnersIds = pickRandomWinners(participants, giveaway.winnersCount || 1);
        await db.endGiveawayRecord(giveaway.id, newWinnersIds);

        const newWinnerUsers = [];
        for (const id of newWinnersIds) {
          const u = await interaction.client.users.fetch(id).catch(() => null);
          if (u) newWinnerUsers.push(u);
          else newWinnerUsers.push({ id });
        }

        const targetChan = guild.channels.cache.get(giveaway.channelId);
        if (targetChan) {
          const mentions = newWinnersIds.map(w => `<@${w}>`).join(', ');
          await targetChan.send({
            content: `🎲 **REROLL GIVEAWAY !** Nouveau(x) gagnant(s) pour **${giveaway.prize}** : ${mentions} ! Félicitations ! 🎉`
          }).catch(() => {});
        }

        return interaction.editReply({
          content: `🎲 **Reroll effectué avec succès !** Nouveau(x) gagnant(s) : ${newWinnersIds.map(w => `<@${w}>`).join(', ')}`
        });
      }

      // 4. Subcommand: finir
      if (subcommand === 'finir') {
        await interaction.deferReply({ flags: MessageFlags.Ephemeral });
        const targetMsgId = interaction.options.getString('message_id').trim();

        const giveaway = await db.getGiveawayByMessageRecord(targetMsgId);
        if (!giveaway) {
          return interaction.editReply({ content: `❌ Aucun giveaway trouvé avec l'ID \`${targetMsgId}\`.` });
        }

        if (giveaway.ended) {
          return interaction.editReply({ content: '⚠️ Ce giveaway est déjà terminé.' });
        }

        await processEndGiveaway(interaction.client, giveaway);

        return interaction.editReply({
          content: `⚡ **Le giveaway a été terminé immédiatement et le tirage au sort a été effectué !**`
        });
      }

      // 5. Subcommand: annuler
      if (subcommand === 'annuler') {
        await interaction.deferReply({ flags: MessageFlags.Ephemeral });
        const targetMsgId = interaction.options.getString('message_id').trim();

        const giveaway = await db.getGiveawayByMessageRecord(targetMsgId);
        if (!giveaway) {
          return interaction.editReply({ content: `❌ Aucun giveaway trouvé avec l'ID \`${targetMsgId}\`.` });
        }

        await db.endGiveawayRecord(giveaway.id, []);

        const targetChan = guild.channels.cache.get(giveaway.channelId);
        if (targetChan && giveaway.messageId) {
          try {
            const msg = await targetChan.messages.fetch(giveaway.messageId).catch(() => null);
            if (msg) await msg.delete().catch(() => {});
          } catch (e) {}
        }

        return interaction.editReply({
          content: `🚫 **Le giveaway #${giveaway.id} (${giveaway.prize}) a été annulé avec succès.**`
        });
      }
    }
  }
];
