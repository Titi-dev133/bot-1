const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { partnershipPanelEmbed } = require('../utils/embeds');

module.exports = [
  {
    data: new SlashCommandBuilder()
      .setName('partenariat')
      .setDescription('🤝 Gestion et panneau de demandes de partenariat')
      .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
      .addSubcommand(sub =>
        sub
          .setName('setup')
          .setDescription('Déployer le Portail de Demande de Partenariat dans ce salon')
      ),

    async execute(interaction) {
      const subcommand = interaction.options.getSubcommand();

      if (subcommand === 'setup') {
        await interaction.deferReply({ ephemeral: true });

        const panelData = partnershipPanelEmbed();
        await interaction.channel.send(panelData);

        await interaction.editReply({
          content: `✅ **Portail de Demandes de Partenariat déployé avec succès** dans ${interaction.channel} !`
        });
      }
    }
  }
];
