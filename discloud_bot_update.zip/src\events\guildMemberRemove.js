const { leaveEmbed } = require('../utils/embeds');
const db = require('../database/db');
const config = require('../../config.json');

module.exports = {
  name: 'guildMemberRemove',
  async execute(member) {
    try {
      console.log(`📤 Membre parti: ${member.user.tag} (${member.id}) de ${member.guild.name}`);

      const welcomeConfig = await db.getWelcomeConfig(member.guild.id);
      const leaveChannelId = welcomeConfig?.leaveChannelId || config.channels?.leave;

      if (!leaveChannelId) return;

      const leaveChannel = member.guild.channels.cache.get(leaveChannelId);
      if (!leaveChannel) return;

      const embed = leaveEmbed(member, member.guild.memberCount);
      await leaveChannel.send({ embeds: [embed] }).catch(err => {
        console.error('⚠️ Impossible d\'envoyer le message de départ:', err.message);
      });
    } catch (error) {
      console.error('❌ Erreur lors de l\'exécution de guildMemberRemove:', error);
    }
  }
};
