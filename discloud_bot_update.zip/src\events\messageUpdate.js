const { EmbedBuilder } = require('discord.js');
const { sendAuditLog } = require('../utils/auditLogger');
const config = require('../../config.json');

module.exports = {
  name: 'messageUpdate',
  async execute(oldMessage, newMessage) {
    try {
      if (!newMessage.guild) return;

      // Ignore bots
      if (newMessage.author?.bot) return;

      // Ignore if content didn't change (e.g. embed preview loading or pin)
      if (oldMessage.content === newMessage.content) return;

      const embed = new EmbedBuilder()
        .setTitle('✏️ LOG AUDIT : MESSAGE MODIFIÉ')
        .setColor(config.colors?.warning || '#FB8C00')
        .setTimestamp();

      if (newMessage.author) {
        embed.setAuthor({
          name: `${newMessage.author.tag} (${newMessage.author.id})`,
          iconURL: newMessage.author.displayAvatarURL({ dynamic: true })
        });
        embed.addFields(
          { name: '👤 Auteur', value: `<@${newMessage.author.id}> (\`${newMessage.author.tag}\`)`, inline: true }
        );
      }

      embed.addFields(
        { name: '📍 Salon', value: `${newMessage.channel} (\`#${newMessage.channel.name}\`)`, inline: true },
        { name: '🔗 Lien direct', value: `[Aller au message](${newMessage.url})`, inline: true }
      );

      // Format old content
      let oldStr = oldMessage.content || '*[Inconnu ou non mis en cache]*';
      if (oldStr.length > 1000) oldStr = oldStr.substring(0, 995) + '...';

      // Format new content
      let newStr = newMessage.content || '*[Vide]*';
      if (newStr.length > 1000) newStr = newStr.substring(0, 995) + '...';

      embed.addFields(
        { name: '📜 Ancien Contenu', value: `\`\`\`${oldStr}\`\`\``, inline: false },
        { name: '🆕 Nouveau Contenu', value: `\`\`\`${newStr}\`\`\``, inline: false }
      );

      embed.setFooter({ text: `Message ID: ${newMessage.id} • Hamburg RP` });

      await sendAuditLog(newMessage.guild, embed);
    } catch (error) {
      console.error('❌ Erreur dans l\'événement messageUpdate:', error);
    }
  }
};
