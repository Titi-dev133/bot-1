const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');
const config = require('../../config.json');

/**
 * Custom Embed Builder for Hamburg RP
 */
function createEmbed({ title, description, color, fields = [], footer, image, thumbnail }) {
  const embed = new EmbedBuilder()
    .setTitle(title || '🚨 Hamburg Roleplay')
    .setDescription(description || null)
    .setColor(color || config.colors.primary)
    .setTimestamp();

  if (fields && fields.length > 0) {
    embed.addFields(fields);
  }

  if (footer) {
    embed.setFooter({ text: footer });
  } else {
    embed.setFooter({ text: '🇩🇪 Emergency Hamburg RP • Systèmes Officiels' });
  }

  if (image) embed.setImage(image);
  if (thumbnail) embed.setThumbnail(thumbnail);

  return embed;
}

// 1. Service Embed
function servicePanelEmbed() {
  const embed = new EmbedBuilder()
    .setTitle('🚨 CENTRALE D\'ACTION & GESTION DES SERVICES')
    .setDescription(
      'Bienvenue sur le panneau officiel de la ville de **Hamburg**.\n\n' +
      'Veuillez cliquer sur le bouton correspondant à votre faction pour prendre ou quitter votre service RP.\n\n' +
      '🔹 **Polizei Hamburg** : Forces de Police\n' +
      '🔹 **Feuerwehr** : Sapeurs-Pompiers & Secours\n' +
      '🔹 **Rettungsdienst (EMS)** : Médecins & Ambulanciers\n' +
      '🔹 **ADAC** : Dépannage & Assistance Routière\n' +
      '🔹 **Zoll** : Douanes\n\n' +
      '*⚠️ N\'oubliez pas de couper votre service avant de quitter le jeu.*'
    )
    .setColor(config.colors.police)
    .setThumbnail('https://i.imgur.com/8QG4m3b.png')
    .setFooter({ text: 'Hamburg RP • Prise de Service Interactive' })
    .setTimestamp();

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('service_police')
      .setLabel('Police (Polizei)')
      .setEmoji('🚓')
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId('service_fire')
      .setLabel('Pompiers')
      .setEmoji('🚒')
      .setStyle(ButtonStyle.Danger),
    new ButtonBuilder()
      .setCustomId('service_ems')
      .setLabel('EMS / Ambulance')
      .setEmoji('🚑')
      .setStyle(ButtonStyle.Success),
    new ButtonBuilder()
      .setCustomId('service_adac')
      .setLabel('ADAC Dépannage')
      .setEmoji('🛞')
      .setStyle(ButtonStyle.Secondary)
  );

  const row2 = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('service_stop')
      .setLabel('Fin de Service')
      .setEmoji('🔴')
      .setStyle(ButtonStyle.Danger),
    new ButtonBuilder()
      .setCustomId('service_pause')
      .setLabel('Pause Service')
      .setEmoji('⏸️')
      .setStyle(ButtonStyle.Secondary)
  );

  return { embeds: [embed], components: [row, row2] };
}

// 2. 911 Dispatch Embed
function dispatch911Embed({ caller, service, location, description, callId }) {
  const colors = {
    police: config.colors.police,
    fire: config.colors.fire,
    ems: config.colors.ems,
    adac: config.colors.adac
  };

  const embed = new EmbedBuilder()
    .setTitle(`🚨 APPEL D'URGENCE 911 • #${callId}`)
    .setDescription(`Un nouvel appel d'urgence a été transmis à la centrale.`)
    .setColor(colors[service] || config.colors.danger)
    .addFields(
      { name: '👤 Appelant', value: `${caller}`, inline: true },
      { name: '🏢 Service requis', value: `**${service.toUpperCase()}**`, inline: true },
      { name: '📍 Localisation', value: `\`${location}\``, inline: false },
      { name: '📝 Motif / Description', value: `\`\`\`${description}\`\`\``, inline: false },
      { name: '⏳ Statut', value: '🔴 En attente d\'intervention', inline: true }
    )
    .setFooter({ text: 'Centrale Radio Emergency Hamburg 911' })
    .setTimestamp();

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`take_call_${callId}`)
      .setLabel('Prendre l\'appel')
      .setEmoji('✅')
      .setStyle(ButtonStyle.Success),
    new ButtonBuilder()
      .setCustomId(`close_call_${callId}`)
      .setLabel('Clôturer l\'appel')
      .setEmoji('🔒')
      .setStyle(ButtonStyle.Secondary)
  );

  return { embeds: [embed], components: [row] };
}

// 3. Verification Panel Embed
function verificationPanelEmbed() {
  const embed = new EmbedBuilder()
    .setTitle('🛡️ PORTAIL DE VÉRIFICATION & SÉCURITÉ')
    .setDescription(
      'Bienvenue sur le serveur **Emergency Hamburg Roleplay** !\n\n' +
      'Pour accéder à l\'ensemble du serveur et obtenir le rôle **Membre**, vous devez compléter la vérification obligatoire :\n\n' +
      '1️⃣ **Liaison du compte Roblox** (Votre identifiant sera associè à votre profil RP)\n' +
      '2️⃣ **Contrôle Anti-Double Compte & Sécurité** (Détection automatique)\n' +
      '3️⃣ **Acceptation du Règlement** du serveur\n\n' +
      '👇 Cliquez sur le bouton ci-dessous pour démarrer :'
    )
    .setColor(config.colors.primary)
    .setThumbnail('https://i.imgur.com/8QG4m3b.png')
    .setFooter({ text: 'Système Anti-Alt & Liaison Roblox Officielle' })
    .setTimestamp();

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('verify_start')
      .setLabel('S\'identifier & Se Vérifier')
      .setEmoji('🔒')
      .setStyle(ButtonStyle.Success)
  );

  return { embeds: [embed], components: [row] };
}

// 4. Roblox Input Modal
function verificationRobloxModal() {
  const modal = new ModalBuilder()
    .setCustomId('modal_verify_roblox')
    .setTitle('Liaison du Compte Roblox');

  const input = new TextInputBuilder()
    .setCustomId('roblox_username')
    .setLabel('Nom d\'utilisateur ou ID Roblox')
    .setPlaceholder('Ex: Builderman ou 1567113')
    .setStyle(TextInputStyle.Short)
    .setMinLength(2)
    .setMaxLength(50)
    .setRequired(true);

  const row = new ActionRowBuilder().addComponents(input);
  modal.addComponents(row);
  return modal;
}

// 5. Rules Accept Embed
function rulesAcceptEmbed(robloxUser) {
  const embed = new EmbedBuilder()
    .setTitle('📜 RÈGLEMENT OFFICIEL & CONFIRMATION')
    .setDescription(
      `Compte Roblox validé : **${robloxUser.displayName}** (@${robloxUser.name})\n\n` +
      '**Dernière étape :** Veuillez lire et accepter les règles principales du serveur :\n\n' +
      '🔹 **Fair-Play RP :** Le respect du Roleplay (FearRP, FailRP, NoPainRP) est obligatoire.\n' +
      '🔹 **Courtoisie & Respect :** Tout propos haineux, insulte HRP ou harcèlement sera lourdement sanctionné.\n' +
      '🔹 **Compte Unique :** Les doubles comptes Discord / Roblox sont formellement interdits.\n' +
      '🔹 **Utilisation des services :** L\'usage abusif des appels 911 ou des tickets entraînera un bannissement.\n\n' +
      '*En cliquant sur "J\'accepte le Règlement", vous validez ces règles et obtiendrez le rôle Membre.*'
    )
    .setColor(config.colors.gold || '#FFD700')
    .setThumbnail(robloxUser.avatarUrl)
    .setFooter({ text: 'Validation finale du compte' })
    .setTimestamp();

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`verify_accept_rules_${robloxUser.id}`)
      .setLabel('J\'accepte le Règlement')
      .setEmoji('✅')
      .setStyle(ButtonStyle.Success)
  );

  return { embeds: [embed], components: [row], ephemeral: true };
}

// 6. Welcome Embed
function welcomeEmbed(member, memberCount, robloxData) {
  const embed = new EmbedBuilder()
    .setTitle('🎉 NOUVEAU CITOYEN DANS LA VILLE !')
    .setDescription(`Bienvenue à ${member} sur le serveur **Emergency Hamburg Roleplay** !`)
    .setColor(config.colors.success)
    .addFields(
      { name: '👤 Membre Discord', value: `${member.user.tag} (${member})`, inline: true },
      { name: '🎮 Compte Roblox', value: robloxData ? `[${robloxData.displayName} (@${robloxData.name})](https://www.roblox.com/users/${robloxData.id}/profile)` : 'Non renseigné', inline: true },
      { name: '📊 Citoyen N°', value: `\`#${memberCount}\``, inline: true },
      { name: '📅 Compte créé le', value: `<t:${Math.floor(member.user.createdTimestamp / 1000)}:D> (<t:${Math.floor(member.user.createdTimestamp / 1000)}:R>)`, inline: false }
    )
    .setThumbnail(robloxData ? robloxData.avatarUrl : member.user.displayAvatarURL({ dynamic: true }))
    .setFooter({ text: '🇩🇪 Emergency Hamburg RP • Nouvel Arrivant' })
    .setTimestamp();

  return embed;
}

// 7. Leave Embed
function leaveEmbed(member, memberCount) {
  const embed = new EmbedBuilder()
    .setTitle('👋 DÉPART D\'UN CITOYEN')
    .setDescription(`**${member.user.tag}** a quitté la ville d'Hamburg.`)
    .setColor(config.colors.danger)
    .addFields(
      { name: '📊 Citoyens restants', value: `\`${memberCount}\` membres`, inline: true }
    )
    .setThumbnail(member.user.displayAvatarURL({ dynamic: true }))
    .setFooter({ text: 'Emergency Hamburg RP • Départ' })
    .setTimestamp();

  return embed;
}

// 8. Security Log Embed
function securityLogEmbed({ member, robloxData, status, details, color }) {
  const embed = new EmbedBuilder()
    .setTitle('🛡️ AUDIT SÉCURITÉ & VÉRIFICATION')
    .setColor(color || config.colors.primary)
    .addFields(
      { name: '👤 Membre Discord', value: `${member.user.tag} (\`${member.id}\`)`, inline: true },
      { name: '🎮 Compte Roblox', value: robloxData ? `${robloxData.name} (ID: \`${robloxData.id}\`)` : 'N/A', inline: true },
      { name: '📌 Statut Vérification', value: status, inline: false },
      { name: '📝 Détails Audit', value: details || 'Aucune anomalie détectée.', inline: false },
      { name: '📅 Âge Compte Discord', value: `<t:${Math.floor(member.user.createdTimestamp / 1000)}:F>`, inline: false }
    )
    .setFooter({ text: 'Logs de Sécurité Anti-Alt & Roblox' })
    .setTimestamp();

  return embed;
}

// 9. Sanctions Dashboard Embed & Panel
function sanctionDashboardEmbed() {
  const embed = new EmbedBuilder()
    .setTitle('🛡️ DASHBOARD DE MODÉRATION • RAPPORT DE SANCTIONS')
    .setDescription(
      'Bienvenue sur le centre de gestion des sanctions disciplinaires **Emergency Hamburg RP**.\n\n' +
      '📌 **Fonctionnalités :**\n' +
      '• **📝 Ajouter une Sanction** : Enregistrer un avertissement, ban, kick ou blâme.\n' +
      '• **🔍 Consulter un Casier** : Rechercher le dossier d\'un joueur par son pseudo Roblox.\n' +
      '• **🗑️ Retirer une Sanction** : Supprimer une sanction spécifique ou effacer le casier d\'un joueur.\n\n' +
      '💡 *Chaque sanction est automatiquement ajoutée et regroupée dans le dossier du joueur dans le salon #sanction-joueur.*'
    )
    .setColor(config.colors.danger)
    .setThumbnail('https://i.imgur.com/8QG4m3b.png')
    .setFooter({ text: 'Système Disciplinaire Centralisé' })
    .setTimestamp();

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('btn_sanction_add_prompt')
      .setLabel('Ajouter un Rapport')
      .setEmoji('📝')
      .setStyle(ButtonStyle.Danger),
    new ButtonBuilder()
      .setCustomId('btn_sanction_lookup_prompt')
      .setLabel('Consulter Casier')
      .setEmoji('🔍')
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId('btn_sanction_remove_prompt')
      .setLabel('Retirer / Effacer')
      .setEmoji('🗑️')
      .setStyle(ButtonStyle.Secondary)
  );

  return { embeds: [embed], components: [row] };
}

// 10. Sanction Input Modal (Exact UI matching user request)
function sanctionInputModal() {
  const modal = new ModalBuilder()
    .setCustomId('modal_sanction_add')
    .setTitle('Rapport de Sanction');

  const inputUsername = new TextInputBuilder()
    .setCustomId('roblox_username')
    .setLabel('Pseudo @ Roblox')
    .setPlaceholder('ex: Patrick_du_25')
    .setStyle(TextInputStyle.Short)
    .setMinLength(2)
    .setMaxLength(50)
    .setRequired(true);

  const inputSanction = new TextInputBuilder()
    .setCustomId('sanction_type')
    .setLabel('Sanction')
    .setPlaceholder('Ban 3j / Warn...')
    .setStyle(TextInputStyle.Short)
    .setMinLength(2)
    .setMaxLength(100)
    .setRequired(true);

  const inputDetails = new TextInputBuilder()
    .setCustomId('sanction_details')
    .setLabel('Détails de la sanction')
    .setPlaceholder('Expliquez précisément...')
    .setStyle(TextInputStyle.Paragraph)
    .setMinLength(5)
    .setMaxLength(1000)
    .setRequired(true);

  modal.addComponents(
    new ActionRowBuilder().addComponents(inputUsername),
    new ActionRowBuilder().addComponents(inputSanction),
    new ActionRowBuilder().addComponents(inputDetails)
  );

  return modal;
}

// 11. Sanction Lookup Modal
function sanctionLookupModal() {
  const modal = new ModalBuilder()
    .setCustomId('modal_sanction_lookup')
    .setTitle('Consulter un Casier Joueur');

  const input = new TextInputBuilder()
    .setCustomId('target_query')
    .setLabel('Pseudo Roblox ou User ID')
    .setPlaceholder('ex: Patrick_du_25')
    .setStyle(TextInputStyle.Short)
    .setRequired(true);

  modal.addComponents(new ActionRowBuilder().addComponents(input));
  return modal;
}

// 12. Sanction Remove Modal
function sanctionRemoveModal() {
  const modal = new ModalBuilder()
    .setCustomId('modal_sanction_remove')
    .setTitle('Retirer une Sanction');

  const inputUsername = new TextInputBuilder()
    .setCustomId('roblox_username')
    .setLabel('Pseudo Roblox du joueur')
    .setPlaceholder('ex: Patrick_du_25')
    .setStyle(TextInputStyle.Short)
    .setRequired(true);

  const inputTarget = new TextInputBuilder()
    .setCustomId('sanction_num')
    .setLabel('Numéro de sanction (ex: 1, 2) ou "tout"')
    .setPlaceholder('Tapez "1" pour la sanction #1 ou "tout" pour vider le dossier')
    .setStyle(TextInputStyle.Short)
    .setValue('tout')
    .setRequired(true);

  modal.addComponents(
    new ActionRowBuilder().addComponents(inputUsername),
    new ActionRowBuilder().addComponents(inputTarget)
  );

  return modal;
}

// 13. Player Grouped Sanction Card Embed for #sanction-joueur
function playerSanctionCardEmbed({ robloxUser, sanctionsList, discordUser }) {
  const embed = new EmbedBuilder()
    .setTitle(`📁 DOSSIER DISCIPLINAIRE • ${robloxUser ? robloxUser.displayName : 'JOUEUR'}`)
    .setDescription(
      `👤 **Pseudo Roblox** : **[${robloxUser ? robloxUser.name : 'Inconnu'}](https://www.roblox.com/users/${robloxUser ? robloxUser.id : 1}/profile)** (\`ID: ${robloxUser ? robloxUser.id : 'N/A'}\`)\n` +
      `💬 **Compte Discord** : ${discordUser ? `${discordUser} (\`${discordUser.id}\`)` : 'Non associé'}\n` +
      `📊 **Total des Sanctions** : \`${sanctionsList.length}\` sanction(s)\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`
    )
    .setColor(config.colors.danger)
    .setFooter({ text: 'Dossier Unifié Modération • Hamburg RP' })
    .setTimestamp();

  if (robloxUser && robloxUser.avatarUrl) {
    embed.setThumbnail(robloxUser.avatarUrl);
  }

  const fields = [];
  sanctionsList.forEach((s, idx) => {
    fields.push({
      name: `🚨 Sanction #${idx + 1} — ${s.sanctionType}`,
      value: `📝 **Détails / Motif** : ${s.details}\n👮 **Modérateur** : <@${s.moderatorId}>\n📅 **Date** : <t:${Math.floor(s.createdAt / 1000)}:F> (<t:${Math.floor(s.createdAt / 1000)}:R>)`,
      inline: false
    });
  });

  embed.addFields(fields);
  return embed;
}

// 14. Staff Sanctions Dashboard Embed & Panel
function staffSanctionDashboardEmbed() {
  const embed = new EmbedBuilder()
    .setTitle('👑 DASHBOARD HAUTE-DIRECTION • SANCTIONS STAFF')
    .setDescription(
      'Panneau officiel de gestion des sanctions pour l\'équipe de **Modération & Staff**.\n\n' +
      '📌 **Fonctionnalités :**\n' +
      '• **📝 Ajouter Sanction Staff** : Enregistrer un Warn Staff, Blâme (1/3, 2/3, 3/3), Demotion ou Ban Staff.\n' +
      '• **🔍 Consulter Casier Staff** : Afficher le dossier disciplinaire complet d\'un modérateur.\n' +
      '• **🗑️ Retirer Sanction Staff** : Effacer une sanction ou réinitialiser le dossier d\'un membre de l\'équipe.\n\n' +
      '💡 *Chaque action est enregistrée dans #sanction-staff et archivée dans les logs #log-sanction-staff.*'
    )
    .setColor(config.colors.police || '#0D47A1')
    .setThumbnail('https://i.imgur.com/8QG4m3b.png')
    .setFooter({ text: 'Haute Direction • Discipline & Management Staff' })
    .setTimestamp();

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('btn_staff_sanction_add_prompt')
      .setLabel('Ajouter Sanction Staff')
      .setEmoji('📝')
      .setStyle(ButtonStyle.Danger),
    new ButtonBuilder()
      .setCustomId('btn_staff_sanction_lookup_prompt')
      .setLabel('Consulter Casier Staff')
      .setEmoji('🔍')
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId('btn_staff_sanction_remove_prompt')
      .setLabel('Retirer Sanction Staff')
      .setEmoji('🗑️')
      .setStyle(ButtonStyle.Secondary)
  );

  return { embeds: [embed], components: [row] };
}

// 15. Staff Sanction Input Modal
function staffSanctionInputModal() {
  const modal = new ModalBuilder()
    .setCustomId('modal_staff_sanction_add')
    .setTitle('Rapport de Sanction Staff');

  const inputStaff = new TextInputBuilder()
    .setCustomId('staff_target')
    .setLabel('Membre du Staff (Mention / ID / Pseudo)')
    .setPlaceholder('ex: @Modérateur1 ou 123456789')
    .setStyle(TextInputStyle.Short)
    .setRequired(true);

  const inputSanction = new TextInputBuilder()
    .setCustomId('sanction_type')
    .setLabel('Type de Sanction Staff')
    .setPlaceholder('ex: Warn Staff / Blâme 1/3 / Demotion / Kick Staff')
    .setStyle(TextInputStyle.Short)
    .setRequired(true);

  const inputDetails = new TextInputBuilder()
    .setCustomId('sanction_details')
    .setLabel('Motif & Explication détaillée')
    .setPlaceholder('Expliquez la faute de modération ou le manquement...')
    .setStyle(TextInputStyle.Paragraph)
    .setRequired(true);

  modal.addComponents(
    new ActionRowBuilder().addComponents(inputStaff),
    new ActionRowBuilder().addComponents(inputSanction),
    new ActionRowBuilder().addComponents(inputDetails)
  );

  return modal;
}

// 16. Staff Sanction Lookup Modal
function staffSanctionLookupModal() {
  const modal = new ModalBuilder()
    .setCustomId('modal_staff_sanction_lookup')
    .setTitle('Consulter Casier Staff');

  const input = new TextInputBuilder()
    .setCustomId('staff_target')
    .setLabel('Mention / ID / Pseudo du membre Staff')
    .setPlaceholder('ex: @Modérateur1 ou 123456789')
    .setStyle(TextInputStyle.Short)
    .setRequired(true);

  modal.addComponents(new ActionRowBuilder().addComponents(input));
  return modal;
}

// 17. Staff Sanction Remove Modal
function staffSanctionRemoveModal() {
  const modal = new ModalBuilder()
    .setCustomId('modal_staff_sanction_remove')
    .setTitle('Retirer Sanction Staff');

  const inputStaff = new TextInputBuilder()
    .setCustomId('staff_target')
    .setLabel('Membre du Staff (Mention / ID / Pseudo)')
    .setPlaceholder('ex: @Modérateur1 ou 123456789')
    .setStyle(TextInputStyle.Short)
    .setRequired(true);

  const inputTarget = new TextInputBuilder()
    .setCustomId('sanction_num')
    .setLabel('Numéro de sanction (ex: 1, 2) ou "tout"')
    .setPlaceholder('Tapez "1" pour la 1ère ou "tout" pour réinitialiser le dossier')
    .setStyle(TextInputStyle.Short)
    .setValue('tout')
    .setRequired(true);

  modal.addComponents(
    new ActionRowBuilder().addComponents(inputStaff),
    new ActionRowBuilder().addComponents(inputTarget)
  );

  return modal;
}

// 18. Staff Grouped Sanction Card Embed for #sanction-staff
function staffSanctionCardEmbed({ staffUser, sanctionsList }) {
  const embed = new EmbedBuilder()
    .setTitle(`👑 DOSSIER DISCIPLINAIRE STAFF • ${staffUser ? staffUser.username : 'STAFF'}`)
    .setDescription(
      `👤 **Membre du Staff** : ${staffUser ? `${staffUser.tag} (<@${staffUser.id}>)` : 'Inconnu'} (\`ID: ${staffUser ? staffUser.id : 'N/A'}\`)\n` +
      `📊 **Total Sanctions Staff** : \`${sanctionsList.length}\` sanction(s)\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`
    )
    .setColor(config.colors.police || '#0D47A1')
    .setFooter({ text: 'Dossier Haute-Direction Staff • Hamburg RP' })
    .setTimestamp();

  if (staffUser && staffUser.displayAvatarURL) {
    embed.setThumbnail(staffUser.displayAvatarURL({ dynamic: true }));
  }

  const fields = [];
  sanctionsList.forEach((s, idx) => {
    fields.push({
      name: `🚨 Sanction Staff #${idx + 1} — ${s.sanctionType}`,
      value: `📝 **Motif & Détails** : ${s.details}\n👑 **Administrateur** : <@${s.adminId}>\n📅 **Date** : <t:${Math.floor(s.createdAt / 1000)}:F> (<t:${Math.floor(s.createdAt / 1000)}:R>)`,
      inline: false
    });
  });

  embed.addFields(fields);
  return embed;
}

// 19. Universal Sanction Audit Log Embed for #log-sanction-joueur & #log-sanction-staff
function sanctionAuditLogEmbed({ title, target, moderator, sanctionType, details, color }) {
  const embed = new EmbedBuilder()
    .setTitle(title || '📜 LOG D\'AUDIT DISCIPLINAIRE')
    .setColor(color || config.colors.primary)
    .addFields(
      { name: '🎯 Cible / Concerne', value: target, inline: true },
      { name: '👮 Auteur / Émetteur', value: `${moderator}`, inline: true },
      { name: '🚨 Action / Sanction', value: `\`${sanctionType}\``, inline: false },
      { name: '📝 Motif / Détails', value: `\`\`\`${details}\`\`\``, inline: false }
    )
    .setFooter({ text: 'Système d\'Audit & Logs Disciplinaires' })
    .setTimestamp();

  return embed;
}

// Helper formatting function
function formatMsDuration(ms) {
  if (!ms || ms <= 0) return '0h 0m 0s';
  const totalSeconds = Math.floor(ms / 1000);
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;
  if (hours > 0) return `${hours}h ${minutes}m ${seconds}s`;
  return `${minutes}m ${seconds}s`;
}

// 20. Staff Service Shift Dashboard Embed
function staffServiceDashboardEmbed(activeStaffCount = 0) {
  const embed = new EmbedBuilder()
    .setTitle('🛡️ DASHBOARD MODÉRATION • PRISE DE SERVICE STAFF')
    .setDescription(
      'Bienvenue sur le centre de gestion des gardes de modération **Hamburg RP**.\n\n' +
      '📌 **Consignes :**\n' +
      '• **🟢 Prise de Service** : Démarre votre temps de garde et vous attribue le rôle Staff.\n' +
      '• **☕ Pause Staff** : Suspend votre compteur pendant vos pauses.\n' +
      '• **🔴 Fin de Service** : Termine votre garde, enregistre votre durée et met à jour le classement.\n' +
      '• **📊 Mes Stats** : Consultez vos statistiques personnelles de présence.\n\n' +
      `🟢 **Staffs actuellement en service :** \`${activeStaffCount}\` modérateur(s)`
    )
    .setColor(config.colors.police || '#0D47A1')
    .setThumbnail('https://i.imgur.com/8QG4m3b.png')
    .setFooter({ text: 'Gestionnaire de Temps Staff • Hamburg RP' })
    .setTimestamp();

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('btn_staff_service_on')
      .setLabel('Prise de Service')
      .setEmoji('🟢')
      .setStyle(ButtonStyle.Success),
    new ButtonBuilder()
      .setCustomId('btn_staff_service_break')
      .setLabel('Pause Staff')
      .setEmoji('☕')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('btn_staff_service_off')
      .setLabel('Fin de Service')
      .setEmoji('🔴')
      .setStyle(ButtonStyle.Danger),
    new ButtonBuilder()
      .setCustomId('btn_staff_service_stats')
      .setLabel('Mes Stats')
      .setEmoji('📊')
      .setStyle(ButtonStyle.Primary)
  );

  return { embeds: [embed], components: [row] };
}

// 21. Staff Service Log Embed for #log-service-staff
function staffServiceLogEmbed({ user, action, durationMs, totalTimeMs, statusColor }) {
  const embed = new EmbedBuilder()
    .setTitle(`📜 LOG PRISE DE SERVICE STAFF • ${action.toUpperCase()}`)
    .setColor(statusColor || config.colors.primary)
    .addFields(
      { name: '👤 Modérateur Staff', value: `<@${user.id}> (\`${user.tag || user.username}\`)`, inline: true },
      { name: '⚡ Action', value: `\`${action}\``, inline: true }
    )
    .setFooter({ text: 'Traçabilité des Temps Staff • Hamburg RP' })
    .setTimestamp();

  if (durationMs !== undefined && durationMs !== null) {
    embed.addFields({ name: '⏱️ Durée de la session', value: `\`${formatMsDuration(durationMs)}\``, inline: true });
  }

  if (totalTimeMs !== undefined && totalTimeMs !== null) {
    embed.addFields({ name: '📊 Cumul Total Présence', value: `\`${formatMsDuration(totalTimeMs)}\``, inline: true });
  }

  return embed;
}

// 22. Auto-Refreshing Staff Leaderboard Embed for #classement-staff
function staffLeaderboardEmbed(leaderboardData = []) {
  const embed = new EmbedBuilder()
    .setTitle('🏆 CLASSEMENT GÉNÉRAL • HEURES DE MODÉRATION STAFF')
    .setDescription(
      'Voici le classement général **mis à jour automatiquement** des membres de l\'équipe Staff ayant accumulé le plus d\'heures de modération.\n\n' +
      '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━'
    )
    .setColor(config.colors.gold || '#F1C40F')
    .setThumbnail('https://i.imgur.com/8QG4m3b.png')
    .setFooter({ text: 'Mis à jour automatiquement à chaque fin de service' })
    .setTimestamp();

  if (leaderboardData.length === 0) {
    embed.addFields({
      name: '📊 Aucune donnée',
      value: '*Aucun service staff n\'a été clôturé pour le moment.*'
    });
  } else {
    const medals = ['🥇', '🥈', '🥉'];
    let textList = '';

    leaderboardData.forEach((item, index) => {
      const medal = index < 3 ? medals[index] : `**#${index + 1}**`;
      const timeStr = formatMsDuration(item.totalTimeMs);
      textList += `${medal} <@${item.userId}> — **${timeStr}** (\`${item.shiftCount}\` garde(s))\n`;
    });

    embed.addFields({
      name: '👑 TOP 10 MODÉRATEURS LES PLUS ACTIFS',
      value: textList
    });
  }

  return embed;
}

// 23. Staff Rank Up & Promotion Dashboard Embed
function staffRankDashboardEmbed() {
  const embed = new EmbedBuilder()
    .setTitle('👑 DASHBOARD MANAGEMENT • GESTION DES RANKS STAFF')
    .setDescription(
      'Panneau officiel de gestion de la carrière et des grades de l\'équipe de **Modération & Staff**.\n\n' +
      '📌 **Fonctionnalités :**\n' +
      '• **⬆️ Promouvoir / Rank Up** : Accorder une promotion à un membre du staff et mettre à jour son grade.\n' +
      '• **⬇️ Rétrograder / Rank Down** : Ajuster le grade d\'un modérateur en cas de rétrogradation.\n' +
      '• **📜 Historique Ranks** : Consulter la progression et l\'historique des promotions d\'un membre.\n\n' +
      '💡 *Chaque promotion est consignée dans #log-rank-staff et annoncée dans le salon #promotions-staff.*'
    )
    .setColor(config.colors.gold || '#F1C40F')
    .setThumbnail('https://i.imgur.com/8QG4m3b.png')
    .setFooter({ text: 'Haute Direction • Carrière Staff Hamburg RP' })
    .setTimestamp();

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('btn_staff_rank_up_prompt')
      .setLabel('Promouvoir / Rank Up')
      .setEmoji('⬆️')
      .setStyle(ButtonStyle.Success),
    new ButtonBuilder()
      .setCustomId('btn_staff_rank_down_prompt')
      .setLabel('Rétrograder / Rank Down')
      .setEmoji('⬇️')
      .setStyle(ButtonStyle.Danger),
    new ButtonBuilder()
      .setCustomId('btn_staff_rank_history_prompt')
      .setLabel('Historique Ranks')
      .setEmoji('📜')
      .setStyle(ButtonStyle.Primary)
  );

  return { embeds: [embed], components: [row] };
}

// 24. Staff Rank Up & Rank Down Modals
function staffRankModal(actionType = 'promotion') {
  const isUp = actionType === 'promotion';
  const modal = new ModalBuilder()
    .setCustomId(isUp ? 'modal_staff_rank_up' : 'modal_staff_rank_down')
    .setTitle(isUp ? '⬆️ Promouvoir un Modérateur' : '⬇️ Rétrograder un Modérateur');

  const inputStaff = new TextInputBuilder()
    .setCustomId('staff_target')
    .setLabel('Membre du Staff (Mention / ID / Pseudo)')
    .setPlaceholder('ex: @Modérateur1 ou 123456789')
    .setStyle(TextInputStyle.Short)
    .setRequired(true);

  const inputOld = new TextInputBuilder()
    .setCustomId('old_rank')
    .setLabel('Ancien Grade / Rôle')
    .setPlaceholder('ex: Modérateur Test')
    .setStyle(TextInputStyle.Short)
    .setRequired(true);

  const inputNew = new TextInputBuilder()
    .setCustomId('new_rank')
    .setLabel('Nouveau Grade / Rôle')
    .setPlaceholder('ex: Modérateur Confirmé')
    .setStyle(TextInputStyle.Short)
    .setRequired(true);

  const inputReason = new TextInputBuilder()
    .setCustomId('reason')
    .setLabel('Motif / Remarques / Félicitations')
    .setPlaceholder('Expliquez la raison du changement de rank...')
    .setStyle(TextInputStyle.Paragraph)
    .setRequired(true);

  modal.addComponents(
    new ActionRowBuilder().addComponents(inputStaff),
    new ActionRowBuilder().addComponents(inputOld),
    new ActionRowBuilder().addComponents(inputNew),
    new ActionRowBuilder().addComponents(inputReason)
  );

  return modal;
}

// 25. Staff Rank History Lookup Modal
function staffRankLookupModal() {
  const modal = new ModalBuilder()
    .setCustomId('modal_staff_rank_history')
    .setTitle('📜 Historique des Ranks Staff');

  const input = new TextInputBuilder()
    .setCustomId('staff_target')
    .setLabel('Membre du Staff (Mention / ID / Pseudo)')
    .setPlaceholder('ex: @Modérateur1 ou 123456789')
    .setStyle(TextInputStyle.Short)
    .setRequired(true);

  modal.addComponents(new ActionRowBuilder().addComponents(input));
  return modal;
}

// 26. Staff Rank Audit Log Embed for #log-rank-staff
function staffRankLogEmbed({ staffUser, adminUser, actionType, oldRank, newRank, reason }) {
  const isUp = actionType === 'promotion';
  const embed = new EmbedBuilder()
    .setTitle(isUp ? '📜 LOG AUDIT : PROMOTION STAFF (RANK UP)' : '📜 LOG AUDIT : RÉTROGRADATION STAFF (RANK DOWN)')
    .setColor(isUp ? config.colors.success : config.colors.danger)
    .addFields(
      { name: '👤 Modérateur Concerné', value: `<@${staffUser.id}> (\`${staffUser.tag || staffUser.username}\`)`, inline: true },
      { name: '👑 Administrateur', value: `<@${adminUser.id}> (\`${adminUser.tag || adminUser.username}\`)`, inline: true },
      { name: '📊 Évolution de Grade', value: `\`${oldRank}\` ➔ \`${newRank}\``, inline: false },
      { name: '📝 Motif & Explication', value: `\`\`\`${reason}\`\`\``, inline: false }
    )
    .setFooter({ text: 'Audit Management Staff • Hamburg RP' })
    .setTimestamp();

  return embed;
}

// 27. Public Announcement Embed for #promotions-staff
function staffRankAnnouncementEmbed({ staffUser, actionType, oldRank, newRank, reason }) {
  const isUp = actionType === 'promotion';
  const embed = new EmbedBuilder()
    .setTitle(isUp ? '🎉 PROMOTION DANS L\'ÉQUIPE STAFF !' : '⚠️ RÉAJUSTEMENT DE GRADE STAFF')
    .setDescription(
      isUp
        ? `Toutes nos félicitations à <@${staffUser.id}> pour son évolution au sein de l'équipe de modération **Hamburg RP** !\n\n` +
          `🎖️ **Ancien Grade** : \`${oldRank}\`\n` +
          `👑 **Nouveau Grade** : **\`${newRank}\`**\n\n` +
          `📝 **Motif & Remerciements :**\n\`\`\`${reason}\`\`\``
        : `Une mise à jour de grade a été effectuée pour <@${staffUser.id}>.\n\n` +
          `📉 **Ancien Grade** : \`${oldRank}\`\n` +
          `📌 **Nouveau Grade** : **\`${newRank}\`**\n\n` +
          `📝 **Motif :**\n\`\`\`${reason}\`\`\``
    )
    .setColor(isUp ? '#2ECC71' : '#E74C3C')
    .setThumbnail(staffUser.displayAvatarURL ? staffUser.displayAvatarURL({ dynamic: true }) : 'https://i.imgur.com/8QG4m3b.png')
    .setFooter({ text: 'Haute Direction Staff • Hamburg RP' })
    .setTimestamp();

  return embed;
}

// 28. Staff Absence Dashboard Embed
function staffAbsenceDashboardEmbed() {
  const embed = new EmbedBuilder()
    .setTitle('🌴 DASHBOARD STAFF • GESTION DES ABSENCES (LOA)')
    .setDescription(
      'Bienvenue sur le centre officiel de déclaration d\'absence et de congé de l\'équipe **Hamburg RP**.\n\n' +
      '📌 **Consignes :**\n' +
      '• **📝 Déclarer une Absence** : Renseignez la date de début, de fin et la raison de votre absence.\n' +
      '• **🏠 Je suis de Retour** : Cliquez sur ce bouton à votre retour pour réactiver votre statut.\n' +
      '• **🔍 Absences Actives** : Consulter la liste des modérateurs actuellement en congé.\n\n' +
      '💡 *Chaque déclaration vous attribue le rôle Staff en Absence et envoie un log dans #log-absence-staff.*'
    )
    .setColor('#3498DB')
    .setThumbnail('https://i.imgur.com/8QG4m3b.png')
    .setFooter({ text: 'Gestion du Personnel Staff • Hamburg RP' })
    .setTimestamp();

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('btn_staff_absence_add_prompt')
      .setLabel('Déclarer une Absence')
      .setEmoji('📝')
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId('btn_staff_absence_return_prompt')
      .setLabel('Je suis de Retour')
      .setEmoji('🏠')
      .setStyle(ButtonStyle.Success),
    new ButtonBuilder()
      .setCustomId('btn_staff_absence_list_prompt')
      .setLabel('Absences Actives')
      .setEmoji('🔍')
      .setStyle(ButtonStyle.Secondary)
  );

  return { embeds: [embed], components: [row] };
}

// 29. Staff Absence Input Modal
function staffAbsenceInputModal() {
  const modal = new ModalBuilder()
    .setCustomId('modal_staff_absence_add')
    .setTitle('📝 Déclaration d\'Absence Staff');

  const inputStart = new TextInputBuilder()
    .setCustomId('start_date')
    .setLabel('Date de début de l\'absence')
    .setPlaceholder('ex: Aujourd\'hui ou 20/08/2026')
    .setStyle(TextInputStyle.Short)
    .setRequired(true);

  const inputEnd = new TextInputBuilder()
    .setCustomId('end_date')
    .setLabel('Date de retour prévue')
    .setPlaceholder('ex: 27/08/2026')
    .setStyle(TextInputStyle.Short)
    .setRequired(true);

  const inputReason = new TextInputBuilder()
    .setCustomId('reason')
    .setLabel('Motif de l\'absence')
    .setPlaceholder('ex: Vacances, examens, raisons personnelles...')
    .setStyle(TextInputStyle.Paragraph)
    .setRequired(true);

  modal.addComponents(
    new ActionRowBuilder().addComponents(inputStart),
    new ActionRowBuilder().addComponents(inputEnd),
    new ActionRowBuilder().addComponents(inputReason)
  );

  return modal;
}

// 30. Staff Absence Log Embed for #log-absence-staff
function staffAbsenceLogEmbed({ user, actionType, startDate, endDate, reason }) {
  const isAdd = actionType === 'declaration';
  const embed = new EmbedBuilder()
    .setTitle(isAdd ? '🌴 LOG : DÉCLARATION D\'ABSENCE STAFF' : '🏠 LOG : RETOUR D\'ABSENCE STAFF')
    .setColor(isAdd ? '#3498DB' : '#2ECC71')
    .addFields(
      { name: '👤 Modérateur', value: `<@${user.id}> (\`${user.tag || user.username}\`)`, inline: true },
      { name: '📌 Action', value: isAdd ? '📝 Prise d\'absence' : '🏠 Fin d\'absence (De retour)', inline: true }
    );

  if (isAdd) {
    embed.addFields(
      { name: '📅 Période d\'absence', value: `Du **${startDate}** au **${endDate}**`, inline: false },
      { name: '📝 Motif', value: `\`\`\`${reason}\`\`\``, inline: false }
    );
  } else {
    embed.addFields(
      { name: '⏱️ Statut', value: 'Le modérateur a repris ses fonctions et son rôle Staff en Absence a été retiré.', inline: false }
    );
  }

  embed.setFooter({ text: 'Gestion des Absences Staff • Hamburg RP' })
    .setTimestamp();

  return embed;
}

// 31. Staff Absence List Embed for #liste-absences-staff
function staffAbsenceListEmbed(activeAbsences = []) {
  const embed = new EmbedBuilder()
    .setTitle('🌴 LISTE DES ABSENCES STAFF ACTIVES')
    .setColor('#3498DB')
    .setFooter({ text: 'Mise à jour automatique • Hamburg RP' })
    .setTimestamp();

  if (!activeAbsences || activeAbsences.length === 0) {
    embed.setDescription('✅ **Aucun membre du staff n\'est actuellement en absence.** Tous les modérateurs sont disponibles !');
  } else {
    let description = `Voici la liste des **${activeAbsences.length}** membre(s) du staff actuellement en congé :\n\n`;
    activeAbsences.forEach((a, idx) => {
      description += `**${idx + 1}.** <@${a.userId}> (\`${a.username}\`)\n` +
        `📅 **Retour prévu** : ${a.endDate} *(Début : ${a.startDate})*\n` +
        `💬 **Motif** : ${a.reason}\n\n`;
    });
    embed.setDescription(description);
  }

  return embed;
}

// 32. Staff Review Dashboard Embed (Matching user screenshot UI)
function staffReviewDashboardEmbed() {
  const embed = new EmbedBuilder()
    .setTitle('📝 Donner un avis sur un membre du staff')
    .setDescription(
      'Partagez votre expérience avec l\'équipe !\n\n' +
      'Donnez votre avis sur un membre de l\'équipe de manière respectueuse et constructive.\n\n' +
      'ℹ️ Votre retour nous aide à améliorer la qualité du service.\n' +
      '⭐ Notez de 0 à 5 étoiles et exprimez votre ressenti.'
    )
    .setColor('#00BCD4')
    .setFooter({ text: 'Systeme d\'avis staff' })
    .setTimestamp();

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('btn_staff_review_prompt')
      .setLabel('Donner un avis')
      .setEmoji('📝')
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId('btn_staff_review_remove_prompt')
      .setLabel('Supprimer un avis')
      .setEmoji('🗑️')
      .setStyle(ButtonStyle.Secondary)
  );

  return { embeds: [embed], components: [row] };
}

// 33. Staff Review Input Modal
function staffReviewInputModal() {
  const modal = new ModalBuilder()
    .setCustomId('modal_staff_review_add')
    .setTitle('Avis sur un membre du staff');

  const inputStaff = new TextInputBuilder()
    .setCustomId('staff_target')
    .setLabel('Membre du Staff ciblé')
    .setPlaceholder('ex: @Modérateur ou Pseudo / ID')
    .setStyle(TextInputStyle.Short)
    .setRequired(true);

  const inputRating = new TextInputBuilder()
    .setCustomId('rating')
    .setLabel('Note (0 à 5 étoiles)')
    .setPlaceholder('Entrez un chiffre entre 0 et 5 (ex: 5)')
    .setStyle(TextInputStyle.Short)
    .setMinLength(1)
    .setMaxLength(2)
    .setRequired(true);

  const inputComment = new TextInputBuilder()
    .setCustomId('comment')
    .setLabel('Votre avis / Commentaire')
    .setPlaceholder('Partagez votre expérience de manière constructive...')
    .setStyle(TextInputStyle.Paragraph)
    .setMinLength(5)
    .setMaxLength(1000)
    .setRequired(true);

  const inputAnon = new TextInputBuilder()
    .setCustomId('anonymous')
    .setLabel('Anonymat ? (Oui / Non)')
    .setPlaceholder('Oui pour masquer votre pseudo (Par défaut: Non)')
    .setStyle(TextInputStyle.Short)
    .setRequired(false);

  modal.addComponents(
    new ActionRowBuilder().addComponents(inputStaff),
    new ActionRowBuilder().addComponents(inputRating),
    new ActionRowBuilder().addComponents(inputComment),
    new ActionRowBuilder().addComponents(inputAnon)
  );

  return modal;
}

// 34. Staff Review Remove Modal
function staffReviewRemoveModal() {
  const modal = new ModalBuilder()
    .setCustomId('modal_staff_review_remove')
    .setTitle('Supprimer un avis Staff');

  const inputStaff = new TextInputBuilder()
    .setCustomId('staff_target')
    .setLabel('Membre du Staff (Mention / Pseudo / ID)')
    .setPlaceholder('ex: @Modérateur ou Pseudo / ID')
    .setStyle(TextInputStyle.Short)
    .setRequired(true);

  const inputNum = new TextInputBuilder()
    .setCustomId('review_num')
    .setLabel('Numéro de l\'avis (ex: 1, 2) ou "tout"')
    .setPlaceholder('Tapez "1" pour la 1ère ou "tout" pour vider la fiche')
    .setStyle(TextInputStyle.Short)
    .setValue('tout')
    .setRequired(true);

  modal.addComponents(
    new ActionRowBuilder().addComponents(inputStaff),
    new ActionRowBuilder().addComponents(inputNum)
  );

  return modal;
}

// 35. Staff Review Log Embed for #log-avis-staff
function staffReviewLogEmbed({ reviewId, authorUser, staffTarget, staffUser, rating, comment, isAnonymous }) {
  const ratingInt = Math.max(0, Math.min(5, parseInt(rating) || 0));
  const stars = '⭐'.repeat(ratingInt) + '☆'.repeat(5 - ratingInt);

  const embed = new EmbedBuilder()
    .setTitle(`📝 NOUVEL AVIS STAFF #${reviewId || 'NEW'}`)
    .setColor('#00BCD4')
    .addFields(
      {
        name: '👤 Membre du Staff ciblé',
        value: staffUser ? `<@${staffUser.id}> (\`${staffUser.tag || staffUser.username}\`)` : `\`${staffTarget}\``,
        inline: true
      },
      {
        name: '✍️ Auteur de l\'avis',
        value: isAnonymous ? `🕵️ Anonyme (ID: \`${authorUser.id}\`)` : `<@${authorUser.id}> (\`${authorUser.tag || authorUser.username}\`)`,
        inline: true
      },
      {
        name: '⭐ Note attribuée',
        value: `**${stars}** (\`${ratingInt}/5\`)`,
        inline: true
      },
      {
        name: '💬 Commentaire & Ressenti',
        value: `\`\`\`${comment}\`\`\``,
        inline: false
      },
      {
        name: '🔒 Option d\'Anonymat',
        value: isAnonymous ? '🕵️ **Oui** (Masqué publiquement)' : '🌐 **Non** (Auteur visible)',
        inline: true
      }
    )
    .setFooter({ text: 'Logs Avis Staff • Hamburg RP' })
    .setTimestamp();

  if (staffUser && staffUser.displayAvatarURL) {
    embed.setThumbnail(staffUser.displayAvatarURL({ dynamic: true }));
  }

  return embed;
}

// 35. Staff Grouped Review Card Embed (Matches grouped sanctions behavior)
function staffReviewCardEmbed({ staffUser, staffQuery, reviewsList, stats }) {
  const avg = stats ? stats.avgRating : 0;
  const ratingStars = '⭐'.repeat(Math.round(avg)) + '☆'.repeat(5 - Math.round(avg));
  const displayName = staffUser ? (staffUser.username || staffUser.tag) : staffQuery;

  const embed = new EmbedBuilder()
    .setTitle(`⭐ DOSSIER D'AVIS STAFF • ${displayName.toUpperCase()}`)
    .setDescription(
      `👤 **Membre du Staff** : ${staffUser ? `<@${staffUser.id}> (\`${staffUser.tag || staffUser.username}\`)` : `\`${staffQuery}\``}\n` +
      `⭐ **Moyenne Générale** : **${avg} / 5** (${ratingStars})\n` +
      `📊 **Total des Avis** : \`${reviewsList.length}\` retour(s)\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`
    )
    .setColor('#00BCD4')
    .setFooter({ text: 'Dossier d\'Avis Staff • Hamburg RP' })
    .setTimestamp();

  if (staffUser && staffUser.displayAvatarURL) {
    embed.setThumbnail(staffUser.displayAvatarURL({ dynamic: true }));
  }

  const fields = [];
  reviewsList.forEach((r, idx) => {
    const stars = '⭐'.repeat(r.rating) + '☆'.repeat(5 - r.rating);
    const authorStr = r.isAnonymous ? '🕵️ *Anonyme*' : `<@${r.authorId}>`;
    fields.push({
      name: `📝 Avis #${idx + 1} — ${stars} (${r.rating}/5)`,
      value: `✍️ **Auteur** : ${authorStr}\n💬 **Commentaire** : ${r.comment}\n📅 **Date** : <t:${Math.floor(r.createdAt / 1000)}:f>`,
      inline: false
    });
  });

  embed.addFields(fields);
  return embed;
}

// 36. Staff Review Deletion Audit Log Embed for #log-serveur-ig
function staffReviewDeletionLogEmbed({ executorUser, staffUser, staffQuery, actionType, details }) {
  const embed = new EmbedBuilder()
    .setTitle('🗑️ LOG AUDIT : SUPPRESSION D\'AVIS STAFF')
    .setColor('#E53935')
    .addFields(
      {
        name: '👮 Exécuteur (Ping Fondation)',
        value: `<@${executorUser.id}> (\`${executorUser.tag || executorUser.username}\`)`,
        inline: true
      },
      {
        name: '🎯 Modérateur Concerné',
        value: staffUser ? `<@${staffUser.id}> (\`${staffUser.tag || staffUser.username}\`)` : `\`${staffQuery}\``,
        inline: true
      },
      {
        name: '⚡ Action Effectuée',
        value: `\`${actionType}\``,
        inline: false
      },
      {
        name: '📝 Détails de l\'avis supprimé',
        value: details ? `\`\`\`${details}\`\`\`` : '*Aucun détail supplémentaire*',
        inline: false
      }
    )
    .setFooter({ text: 'Logs Serveur IG • Hamburg RP' })
    .setTimestamp();

  return embed;
}

// 37. Suggestion Dashboard Panel Embed
function suggestionPanelEmbed() {
  const embed = new EmbedBuilder()
    .setTitle('💡 BOÎTE À SUGGESTIONS • HAMBURG ROLEPLAY')
    .setDescription(
      'Bienvenue sur le centre officiel de suggestions de **Hamburg RP** !\n\n' +
      'Avez-vous une idée d\'amélioration pour le serveur, les factions, les règles ou les fonctionnalités ?\n' +
      'Partagez votre idée directement avec la communauté et l\'équipe staff !\n\n' +
      '📌 **Comment ça fonctionne ?**\n' +
      '1️⃣ Cliquez sur le bouton **💡 Proposer une suggestion** ci-dessous.\n' +
      '2️⃣ Remplissez le formulaire avec votre idée et son titre.\n' +
      '3️⃣ Votre suggestion sera transmise dans le salon **#suggestions** où chacun pourra voter (👍 Pour / 👎 Contre) !\n\n' +
      '💡 *Chaque suggestion est examinée par la direction et le staff.*'
    )
    .setColor('#FFD700')
    .setThumbnail('https://i.imgur.com/8QG4m3b.png')
    .setFooter({ text: 'Boîte à Suggestions • Hamburg RP' })
    .setTimestamp();

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('btn_suggestion_prompt')
      .setLabel('Proposer une suggestion')
      .setEmoji('💡')
      .setStyle(ButtonStyle.Primary)
  );

  return { embeds: [embed], components: [row] };
}

// 38. Suggestion Input Modal
function suggestionInputModal() {
  const modal = new ModalBuilder()
    .setCustomId('modal_suggestion_add')
    .setTitle('Soumettre une Suggestion');

  const inputTitle = new TextInputBuilder()
    .setCustomId('suggestion_title')
    .setLabel('Titre / Sujet de la suggestion')
    .setPlaceholder('ex: Ajouter un nouveau véhicule Polizei')
    .setStyle(TextInputStyle.Short)
    .setMinLength(3)
    .setMaxLength(100)
    .setRequired(true);

  const inputDetails = new TextInputBuilder()
    .setCustomId('suggestion_details')
    .setLabel('Description & Explication détaillée')
    .setPlaceholder('Expliquez votre idée et pourquoi elle bénéficierait au serveur...')
    .setStyle(TextInputStyle.Paragraph)
    .setMinLength(10)
    .setMaxLength(1500)
    .setRequired(true);

  modal.addComponents(
    new ActionRowBuilder().addComponents(inputTitle),
    new ActionRowBuilder().addComponents(inputDetails)
  );

  return modal;
}

// 39. Suggestion Card Embed for #suggestions
function suggestionCardEmbed({ suggestion, authorUser, processedUser }) {
  const statusConfig = {
    PENDING: { label: '⏳ En attente de votes & avis', color: '#F1C40F' },
    ACCEPTED: { label: '🟢 Acceptée par le Staff', color: '#2ECC71' },
    REJECTED: { label: '🔴 Refusée par le Staff', color: '#E74C3C' },
    IN_PROGRESS: { label: '🛠️ En cours d\'implémentation', color: '#3498DB' },
    MERGED: { label: '🔀 Fusionnée avec une autre suggestion', color: '#7f8c8d' }
  };

  const statusInfo = statusConfig[suggestion.status] || statusConfig.PENDING;
  const authorMention = authorUser ? `<@${authorUser.id}> (\`${authorUser.tag || authorUser.username}\`)` : `<@${suggestion.authorId}>`;

  let proposals = [];
  try {
    proposals = JSON.parse(suggestion.proposals || '[]');
  } catch (e) {
    proposals = [];
  }

  let titleText = `💡 SUGGESTION #${suggestion.id} • ${suggestion.title.toUpperCase()}`;
  if (proposals.length > 1) {
    titleText = `💡 SUGGESTION #${suggestion.id} • ${suggestion.title.toUpperCase()} (${proposals.length} PROPOSITIONS REGROUPÉES)`;
  }

  let descriptionText = `📌 **Statut** : **${statusInfo.label}**\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n`;

  if (proposals.length > 1) {
    descriptionText += `👥 **Proposé conjointement par ${proposals.length} membres** :\n`;
    proposals.forEach((p, idx) => {
      descriptionText += `\n**[${idx + 1}]** <@${p.authorId}> : **${p.title}**\n\`\`\`${p.details}\`\`\``;
    });
  } else {
    descriptionText += `👤 **Proposé par** : ${authorMention}\n\n` +
      `📝 **Description & Détails :**\n\`\`\`${suggestion.details}\`\`\``;
  }

  const embed = new EmbedBuilder()
    .setTitle(titleText)
    .setDescription(descriptionText)
    .setColor(statusInfo.color)
    .addFields(
      {
        name: '📊 Bilan des Votes',
        value: `👍 **${suggestion.upVotes || 0}** Pour | 👎 **${suggestion.downVotes || 0}** Contre`,
        inline: true
      }
    )
    .setFooter({ text: `Suggestion #${suggestion.id} • Hamburg RP` })
    .setTimestamp(suggestion.createdAt);

  if (authorUser && authorUser.displayAvatarURL) {
    embed.setThumbnail(authorUser.displayAvatarURL({ dynamic: true }));
  }

  if (suggestion.status !== 'PENDING' && (processedUser || suggestion.processedBy)) {
    const staffMention = processedUser ? `<@${processedUser.id}>` : (suggestion.processedBy ? `<@${suggestion.processedBy}>` : 'Staff');
    embed.addFields({
      name: '👑 Décision du Staff',
      value: `👮 **Modérateur** : ${staffMention}\n💬 **Motif / Réponse** : ${suggestion.staffReason || '*Aucun motif précisé*'}`,
      inline: false
    });
  }

  const rowVotes = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`btn_suggest_up_${suggestion.id}`)
      .setLabel(`Pour (${suggestion.upVotes || 0})`)
      .setEmoji('👍')
      .setStyle(ButtonStyle.Success),
    new ButtonBuilder()
      .setCustomId(`btn_suggest_down_${suggestion.id}`)
      .setLabel(`Contre (${suggestion.downVotes || 0})`)
      .setEmoji('👎')
      .setStyle(ButtonStyle.Danger)
  );

  const rowManage = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`btn_suggest_manage_${suggestion.id}`)
      .setLabel('Gérer la Suggestion (Staff)')
      .setEmoji('⚙️')
      .setStyle(ButtonStyle.Secondary)
  );

  return { embeds: [embed], components: [rowVotes, rowManage] };
}

// 40. Suggestion Staff Management Modal
function suggestionStaffManageModal(suggestionId) {
  const modal = new ModalBuilder()
    .setCustomId(`modal_suggest_manage_${suggestionId}`)
    .setTitle(`Gérer la Suggestion #${suggestionId}`);

  const inputStatus = new TextInputBuilder()
    .setCustomId('status')
    .setLabel('Nouveau Statut (accepter / refuser / encours)')
    .setPlaceholder('Tapez: accepter, refuser, ou encours')
    .setStyle(TextInputStyle.Short)
    .setRequired(true);

  const inputReason = new TextInputBuilder()
    .setCustomId('reason')
    .setLabel('Motif / Explication du Staff')
    .setPlaceholder('Expliquez la raison de la décision...')
    .setStyle(TextInputStyle.Paragraph)
    .setRequired(false);

  modal.addComponents(
    new ActionRowBuilder().addComponents(inputStatus),
    new ActionRowBuilder().addComponents(inputReason)
  );

  return modal;
}

// 41. Suggestion Log Embed for #log-suggestions
function suggestionLogEmbed({ suggestion, authorUser, staffUser, status, reason }) {
  const statusLabels = {
    ACCEPTED: '🟢 Suggestion Acceptée',
    REJECTED: '🔴 Suggestion Refusée',
    IN_PROGRESS: '🛠️ En cours d\'implémentation'
  };

  const embed = new EmbedBuilder()
    .setTitle(`📜 LOG : TRAITEMENT SUGGESTION #${suggestion.id}`)
    .setColor(status === 'ACCEPTED' ? '#2ECC71' : status === 'REJECTED' ? '#E74C3C' : '#3498DB')
    .addFields(
      { name: '💡 Suggestion', value: `**#${suggestion.id} — ${suggestion.title}**`, inline: false },
      { name: '👤 Auteur', value: authorUser ? `<@${authorUser.id}> (\`${authorUser.tag || authorUser.username}\`)` : `<@${suggestion.authorId}>`, inline: true },
      { name: '👮 Modérateur', value: `<@${staffUser.id}> (\`${staffUser.tag || staffUser.username}\`)`, inline: true },
      { name: '📌 Décision', value: statusLabels[status] || status, inline: true },
      { name: '📊 Bilan des Votes', value: `👍 **${suggestion.upVotes || 0}** Pour | 👎 **${suggestion.downVotes || 0}** Contre`, inline: false },
      { name: '📝 Description originale', value: `\`\`\`${suggestion.details}\`\`\``, inline: false },
      { name: '💬 Motif / Réponse Staff', value: reason ? `\`\`\`${reason}\`\`\`` : '*Aucun motif précisé*', inline: false }
    )
    .setFooter({ text: 'Logs Suggestions • Hamburg RP' })
    .setTimestamp();

  return embed;
}

// 42. Duration Parser Utility
function parseDuration(str) {
  if (!str) return null;
  const match = str.trim().toLowerCase().match(/^(\d+)\s*([s|m|h|d])$/);
  if (!match) return null;
  const val = parseInt(match[1], 10);
  const unit = match[2];
  if (unit === 's') return val * 1000;
  if (unit === 'm') return val * 60 * 1000;
  if (unit === 'h') return val * 60 * 60 * 1000;
  if (unit === 'd') return val * 24 * 60 * 60 * 1000;
  return null;
}

// 43. Giveaway Dashboard Panel Embed
function giveawayDashboardEmbed() {
  const embed = new EmbedBuilder()
    .setTitle('🎉 PANNEAU DE GESTION DES GIVEAWAYS • HAMBURG ROLEPLAY')
    .setDescription(
      'Bienvenue sur le centre officiel de gestion des **Giveaways & Concours** de **Hamburg RP** !\n\n' +
      'Cet espace permet à l\'équipe Événementielle et Staff de lancer et gérer les tirages au sort pour la communauté.\n\n' +
      '📌 **Guide Rapide :**\n' +
      '1️⃣ Cliquez sur **🎉 Lancer un Giveaway** ci-dessous.\n' +
      '2️⃣ Renseignez le gain, la durée (ex: `10m`, `2h`, `24h`) et le nombre de gagnants.\n' +
      '3️⃣ Le bot gère automatiquement les inscriptions et effectue le tirage au sort impartial à la fin du compte à rebours !\n\n' +
      '🎲 *Commande Reroll disponible : `/giveaway reroll message_id:<ID>`*'
    )
    .setColor('#FF4081')
    .setThumbnail('https://i.imgur.com/8QG4m3b.png')
    .setFooter({ text: 'Gestion Giveaways • Hamburg RP' })
    .setTimestamp();

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('btn_giveaway_create_prompt')
      .setLabel('Lancer un Giveaway')
      .setEmoji('🎉')
      .setStyle(ButtonStyle.Primary)
  );

  return { embeds: [embed], components: [row] };
}

// 44. Giveaway Creation Modal
function giveawayCreateModal() {
  const modal = new ModalBuilder()
    .setCustomId('modal_giveaway_create')
    .setTitle('Lancer un Nouveau Giveaway');

  const inputPrize = new TextInputBuilder()
    .setCustomId('prize')
    .setLabel('Prix / Gain à remporter')
    .setPlaceholder('ex: 100.000€ IG + Role VIP')
    .setStyle(TextInputStyle.Short)
    .setRequired(true);

  const inputDuration = new TextInputBuilder()
    .setCustomId('duration')
    .setLabel('Durée (ex: 10m, 1h, 24h, 2d)')
    .setPlaceholder('ex: 1h pour 1 heure, 24h pour 1 jour')
    .setStyle(TextInputStyle.Short)
    .setRequired(true);

  const inputWinners = new TextInputBuilder()
    .setCustomId('winners')
    .setLabel('Nombre de gagnants')
    .setValue('1')
    .setStyle(TextInputStyle.Short)
    .setRequired(true);

  const inputDescription = new TextInputBuilder()
    .setCustomId('description')
    .setLabel('Conditions ou détails supplémentaires (optionnel)')
    .setPlaceholder('ex: Être présent sur le serveur Discord...')
    .setStyle(TextInputStyle.Paragraph)
    .setRequired(false);

  modal.addComponents(
    new ActionRowBuilder().addComponents(inputPrize),
    new ActionRowBuilder().addComponents(inputDuration),
    new ActionRowBuilder().addComponents(inputWinners),
    new ActionRowBuilder().addComponents(inputDescription)
  );

  return modal;
}

// 45. Giveaway Active Card Embed for Channel
function giveawayCardEmbed({ giveaway, hostUser, participantsCount = 0 }) {
  const endTimestamp = Math.floor(giveaway.endsAt / 1000);
  const hostMention = hostUser ? `<@${hostUser.id}> (\`${hostUser.tag || hostUser.username}\`)` : `<@${giveaway.hostId}>`;

  const embed = new EmbedBuilder()
    .setTitle(`🎉 GIVEAWAY • ${giveaway.prize.toUpperCase()}`)
    .setDescription(
      (giveaway.description ? `📝 **Conditions / Informations :**\n\`\`\`${giveaway.description}\`\`\`\n` : '') +
      `🎁 **Prix à gagner** : **${giveaway.prize}**\n` +
      `🏆 **Nombre de gagnants** : **${giveaway.winnersCount || 1}**\n` +
      `👑 **Organisé par** : ${hostMention}\n` +
      `⏳ **Fin du Concours** : <t:${endTimestamp}:R> (<t:${endTimestamp}:F>)\n` +
      `👥 **Participants** : **${participantsCount}** inscrit(s)\n\n` +
      `*Cliquez sur le bouton **🎉 Participer** ci-dessous pour vous inscrire au tirage au sort !*`
    )
    .setColor('#FF4081')
    .setFooter({ text: `Giveaway ID: ${giveaway.messageId || giveaway.id} • Hamburg RP` })
    .setTimestamp(giveaway.createdAt);

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`btn_giveaway_join_${giveaway.messageId || giveaway.id}`)
      .setLabel(`Participer (${participantsCount})`)
      .setEmoji('🎉')
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId(`btn_giveaway_participants_${giveaway.messageId || giveaway.id}`)
      .setLabel('Participants')
      .setEmoji('👥')
      .setStyle(ButtonStyle.Secondary)
  );

  return { embeds: [embed], components: [row] };
}

// 46. Giveaway Ended Card Embed for Channel
function giveawayEndedEmbed({ giveaway, hostUser, winnersUsers = [] }) {
  const hostMention = hostUser ? `<@${hostUser.id}>` : `<@${giveaway.hostId}>`;
  const hasWinners = winnersUsers && winnersUsers.length > 0;

  const winnersFormatted = hasWinners
    ? winnersUsers.map(w => `<@${w.id || w}>`).join(', ')
    : '*Aucun participant (Pas de gagnant)*';

  const embed = new EmbedBuilder()
    .setTitle(`🎉 GIVEAWAY TERMINÉ • ${giveaway.prize.toUpperCase()}`)
    .setDescription(
      `🎁 **Prix** : **${giveaway.prize}**\n` +
      `👑 **Hôte** : ${hostMention}\n` +
      `🏆 **Gagnant(s)** : ${winnersFormatted}\n\n` +
      `*Le tirage au sort est terminé. Merci à tous les participants !*`
    )
    .setColor(hasWinners ? '#2ECC71' : '#E74C3C')
    .setFooter({ text: `Giveaway Terminé • Hamburg RP` })
    .setTimestamp();

  const disabledRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`btn_giveaway_ended_disabled`)
      .setLabel('Concours Terminé')
      .setEmoji('🔒')
      .setStyle(ButtonStyle.Secondary)
      .setDisabled(true)
  );

  return { embeds: [embed], components: [disabledRow] };
}

// 47. Giveaway Audit Log Embed for #log-giveaways / #log-serveur-ig
function giveawayLogEmbed({ giveaway, hostUser, winnersUsers = [], actionType = 'TIRAGE_AU_SORT' }) {
  const hostMention = hostUser ? `<@${hostUser.id}> (\`${hostUser.tag || hostUser.username}\`)` : `<@${giveaway.hostId}>`;
  const winnersFormatted = winnersUsers && winnersUsers.length > 0
    ? winnersUsers.map(w => `<@${w.id || w}> (\`${w.tag || w.username || w}\`)`).join('\n')
    : '*Aucun gagnant (0 participant)*';

  const embed = new EmbedBuilder()
    .setTitle(`🎉 LOG AUDIT : ${actionType}`)
    .setColor('#FF4081')
    .addFields(
      { name: '🎁 Prix', value: `**${giveaway.prize}**`, inline: true },
      { name: '👑 Organisateur', value: hostMention, inline: true },
      { name: '🏆 Gagnant(s)', value: winnersFormatted, inline: false }
    )
    .setFooter({ text: 'Logs Giveaways • Hamburg RP' })
    .setTimestamp();

  return embed;
}

module.exports = {
  createEmbed,
  servicePanelEmbed,
  dispatch911Embed,
  verificationPanelEmbed,
  verificationRobloxModal,
  rulesAcceptEmbed,
  welcomeEmbed,
  leaveEmbed,
  securityLogEmbed,
  sanctionDashboardEmbed,
  sanctionInputModal,
  sanctionLookupModal,
  sanctionRemoveModal,
  playerSanctionCardEmbed,
  staffSanctionDashboardEmbed,
  staffSanctionInputModal,
  staffSanctionLookupModal,
  staffSanctionRemoveModal,
  staffSanctionCardEmbed,
  sanctionAuditLogEmbed,
  staffServiceDashboardEmbed,
  staffServiceLogEmbed,
  staffLeaderboardEmbed,
  formatMsDuration,
  staffRankDashboardEmbed,
  staffRankModal,
  staffRankLookupModal,
  staffRankLogEmbed,
  staffRankAnnouncementEmbed,
  staffAbsenceDashboardEmbed,
  staffAbsenceInputModal,
  staffAbsenceLogEmbed,
  staffAbsenceListEmbed,
  staffReviewDashboardEmbed,
  staffReviewInputModal,
  staffReviewRemoveModal,
  staffReviewLogEmbed,
  staffReviewCardEmbed,
  staffReviewDeletionLogEmbed,
  suggestionPanelEmbed,
  suggestionInputModal,
  suggestionCardEmbed,
  suggestionStaffManageModal,
  suggestionLogEmbed,
  parseDuration,
  giveawayDashboardEmbed,
  giveawayCreateModal,
  giveawayCardEmbed,
  giveawayEndedEmbed,
  giveawayLogEmbed,
  antiRaidDashboardEmbed,
  antiRaidConfigModal,
  staffRecruitmentPanelEmbed,
  staffQuizStep1Modal,
  staffQuizStep2Modal,
  staffQuizStep3Modal,
  staffQuizStep4Modal,
  staffCandidateCardEmbed,
  partnershipPanelEmbed,
  partnershipInputModal,
  partnershipCardEmbed,
  organizationPanelEmbed,
  gangCreateModal,
  businessCreateModal,
  organizationCardEmbed
};

// 51. Staff Recruitment Panel Embed
function staffRecruitmentPanelEmbed() {
  const embed = new EmbedBuilder()
    .setTitle('📋 PORTAIL OFFICIEL DE RECRUTEMENT STAFF • HAMBURG RP')
    .setDescription(
      'Bienvenue sur le centre de recrutement de l\'équipe de modération de **Emergency Hamburg RP** !\n\n' +
      'Vous souhaitez intégrer l\'équipe, aider les citoyens et faire respecter le règlement du serveur ?\n' +
      'Passez notre test de recrutement en **20 questions** (4 étapes interactives).\n\n' +
      '📌 **Prérequis obligatoires :**\n' +
      '• Être âgé(e) d\'au moins **14 ans** (Maturité exigée).\n' +
      '• Posséder un micro de bonne qualité et être actif sur Discord & Roblox.\n' +
      '• Connaître parfaitement le règlement du serveur (FearRP, NoPainRP, Mass RDM, etc.).\n' +
      '• Avoir un casier disciplinaire vierge ou irréprochable.\n\n' +
      '👇 Cliquez sur le bouton **📝 Passer le Test Staff (20 Questions)** ci-dessous pour démarrer :'
    )
    .setColor('#1E88E5')
    .setThumbnail('https://i.imgur.com/8QG4m3b.png')
    .setFooter({ text: 'Haute Direction • Recrutement Staff Hamburg RP' })
    .setTimestamp();

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('btn_staff_quiz_start')
      .setLabel('Passer le Test Staff (20 Questions)')
      .setEmoji('📝')
      .setStyle(ButtonStyle.Primary)
  );

  return { embeds: [embed], components: [row] };
}

// 52. Staff Recruitment 20-Question 4-Step Modals

function staffQuizStep1Modal() {

  const modal = new ModalBuilder()
    .setCustomId('modal_staff_quiz_step1')
    .setTitle('📋 Test Staff • Étape 1/4 (Q1 à Q5)');

  const q1 = new TextInputBuilder()
    .setCustomId('sq_1')
    .setLabel('1/20: Identité RP / Pseudo Roblox / Âge')
    .setPlaceholder('ex: Patrick_25 (Patou) | 16 ans')
    .setStyle(TextInputStyle.Short)
    .setRequired(true);

  const q2 = new TextInputBuilder()
    .setCustomId('sq_2')
    .setLabel('2/20: Disponibilités (heures/semaine)')
    .setPlaceholder('ex: 15 heures par semaine')
    .setStyle(TextInputStyle.Short)
    .setRequired(true);

  const q3 = new TextInputBuilder()
    .setCustomId('sq_3')
    .setLabel('3/20: Pourquoi postuler chez Hamburg RP ?')
    .setPlaceholder('Vos motivations principales pour nous rejoindre...')
    .setStyle(TextInputStyle.Paragraph)
    .setRequired(true);

  const q4 = new TextInputBuilder()
    .setCustomId('sq_4')
    .setLabel('4/20: Vos 3 qualités & 3 défauts RP')
    .setPlaceholder('Soyez honnête et concis...')
    .setStyle(TextInputStyle.Paragraph)
    .setRequired(true);

  const q5 = new TextInputBuilder()
    .setCustomId('sq_5')
    .setLabel('5/20: Vos expériences en modération')
    .setPlaceholder('Avez-vous déjà été staff sur Discord/Roblox ?')
    .setStyle(TextInputStyle.Paragraph)
    .setRequired(true);

  modal.addComponents(
    new ActionRowBuilder().addComponents(q1),
    new ActionRowBuilder().addComponents(q2),
    new ActionRowBuilder().addComponents(q3),
    new ActionRowBuilder().addComponents(q4),
    new ActionRowBuilder().addComponents(q5)
  );

  return modal;
}

function staffQuizStep2Modal() {
  const modal = new ModalBuilder()
    .setCustomId('modal_staff_quiz_step2')
    .setTitle('📋 Test Staff • Étape 2/4 (Q6 à Q10)');

  const q6 = new TextInputBuilder()
    .setCustomId('sq_6')
    .setLabel('6/20: Cas 1 - Mass RDM & Freekill spawn')
    .setPlaceholder('Procédure étape par étape...')
    .setStyle(TextInputStyle.Paragraph)
    .setRequired(true);

  const q7 = new TextInputBuilder()
    .setCustomId('sq_7')
    .setLabel('7/20: Cas 2 - Insultes HRP en ticket')
    .setPlaceholder('Réaction et sanction appliquée...')
    .setStyle(TextInputStyle.Paragraph)
    .setRequired(true);

  const q8 = new TextInputBuilder()
    .setCustomId('sq_8')
    .setLabel('8/20: Cas 3 - Refus d\'arrêter & CombatLog')
    .setPlaceholder('Procédure pour déconnexion en poursuite Polizei...')
    .setStyle(TextInputStyle.Paragraph)
    .setRequired(true);

  const q9 = new TextInputBuilder()
    .setCustomId('sq_9')
    .setLabel('9/20: Cas 4 - NoPainRP & Conduite HRP')
    .setPlaceholder('Sanction pour conduite sur voie ferrée sans RP...')
    .setStyle(TextInputStyle.Paragraph)
    .setRequired(true);

  const q10 = new TextInputBuilder()
    .setCustomId('sq_10')
    .setLabel('10/20: Cas 5 - FearRP face 3 armés')
    .setPlaceholder('Comment jugez-vous le non-respect du FearRP ?')
    .setStyle(TextInputStyle.Paragraph)
    .setRequired(true);

  modal.addComponents(
    new ActionRowBuilder().addComponents(q6),
    new ActionRowBuilder().addComponents(q7),
    new ActionRowBuilder().addComponents(q8),
    new ActionRowBuilder().addComponents(q9),
    new ActionRowBuilder().addComponents(q10)
  );

  return modal;
}

function staffQuizStep3Modal() {
  const modal = new ModalBuilder()
    .setCustomId('modal_staff_quiz_step3')
    .setTitle('📋 Test Staff • Étape 3/4 (Q11 à Q15)');

  const q11 = new TextInputBuilder()
    .setCustomId('sq_11')
    .setLabel('11/20: Cas 6 - Streamhack & Usurpation')
    .setPlaceholder('Procédure si un joueur usurpe une faction...')
    .setStyle(TextInputStyle.Paragraph)
    .setRequired(true);

  const q12 = new TextInputBuilder()
    .setCustomId('sq_12')
    .setLabel('12/20: Cas 7 - Abus de pouvoir / Favoris')
    .setPlaceholder('Que faites-vous si vous voyez un staff abuser ?')
    .setStyle(TextInputStyle.Paragraph)
    .setRequired(true);

  const q13 = new TextInputBuilder()
    .setCustomId('sq_13')
    .setLabel('13/20: Cas 8 - Metagaming Vocal / Radio')
    .setPlaceholder('Procédure face à du Metagaming Discord...')
    .setStyle(TextInputStyle.Paragraph)
    .setRequired(true);

  const q14 = new TextInputBuilder()
    .setCustomId('sq_14')
    .setLabel('14/20: Cas 9 - Règle Braquage & NLR')
    .setPlaceholder('Non-respect de la New Life Rule après mort...')
    .setStyle(TextInputStyle.Paragraph)
    .setRequired(true);

  const q15 = new TextInputBuilder()
    .setCustomId('sq_15')
    .setLabel('15/20: Cas 10 - Provocations & Dox')
    .setPlaceholder('Réaction face aux menaces informatiques / Dox...')
    .setStyle(TextInputStyle.Paragraph)
    .setRequired(true);

  modal.addComponents(
    new ActionRowBuilder().addComponents(q11),
    new ActionRowBuilder().addComponents(q12),
    new ActionRowBuilder().addComponents(q13),
    new ActionRowBuilder().addComponents(q14),
    new ActionRowBuilder().addComponents(q15)
  );

  return modal;
}

function staffQuizStep4Modal() {
  const modal = new ModalBuilder()
    .setCustomId('modal_staff_quiz_step4')
    .setTitle('📋 Test Staff • Étape 4/4 (Q16 à Q20)');

  const q16 = new TextInputBuilder()
    .setCustomId('sq_16')
    .setLabel('16/20: Procédure complète de Warn RP')
    .setPlaceholder('Comment délivrez-vous un avertissement ?')
    .setStyle(TextInputStyle.Paragraph)
    .setRequired(true);

  const q17 = new TextInputBuilder()
    .setCustomId('sq_17')
    .setLabel('17/20: Différence Mute/Kick/Ban/Perma')
    .setPlaceholder('Expliquez la hiérarchie des sanctions...')
    .setStyle(TextInputStyle.Paragraph)
    .setRequired(true);

  const q18 = new TextInputBuilder()
    .setCustomId('sq_18')
    .setLabel('18/20: Réaction si joueur conteste')
    .setPlaceholder('Comment gardez-vous votre calme en ticket ?')
    .setStyle(TextInputStyle.Paragraph)
    .setRequired(true);

  const q19 = new TextInputBuilder()
    .setCustomId('sq_19')
    .setLabel('19/20: Comment réagir si vous trompez')
    .setPlaceholder('Que faites-vous si vous mettez un mauvais ban ?')
    .setStyle(TextInputStyle.Paragraph)
    .setRequired(true);

  const q20 = new TextInputBuilder()
    .setCustomId('sq_20')
    .setLabel('20/20: Message final pour la Direction')
    .setPlaceholder('Un dernier mot pour convaincre l\'Administration...')
    .setStyle(TextInputStyle.Paragraph)
    .setRequired(true);

  modal.addComponents(
    new ActionRowBuilder().addComponents(q16),
    new ActionRowBuilder().addComponents(q17),
    new ActionRowBuilder().addComponents(q18),
    new ActionRowBuilder().addComponents(q19),
    new ActionRowBuilder().addComponents(q20)
  );

  return modal;
}

// 53. Staff Candidate Card Embed for High Direction
function staffCandidateCardEmbed({ testData, candidateUser, reviewerUser }) {
  const statusInfo = {
    PENDING: { label: '⏳ En attente d\'évaluation', color: '#F1C40F' },
    ACCEPTED: { label: '🟢 Candidature Acceptée', color: '#2ECC71' },
    REJECTED: { label: '🔴 Candidature Refusée', color: '#E74C3C' },
    INTERVIEW: { label: '🎤 Convoqué(e) en Oral', color: '#3498DB' }
  }[testData.status] || { label: testData.status, color: '#F1C40F' };

  const candMention = candidateUser ? `<@${candidateUser.id}> (\`${candidateUser.tag || candidateUser.username}\`)` : `<@${testData.userId}>`;

  let answers = {};
  if (testData.answersJson) {
    try {
      answers = typeof testData.answersJson === 'string' ? JSON.parse(testData.answersJson) : testData.answersJson;
    } catch (e) {
      answers = {};
    }
  }

  const robloxDisplay = answers['sq_1'] || testData.robloxUsername;
  const availDisplay = answers['sq_2'] || testData.availability;

  const embed = new EmbedBuilder()
    .setTitle(`📋 EXAMEN DE RECRUTEMENT STAFF (20 QUESTIONS) #${testData.id}`)
    .setDescription(
      `👤 **Candidat Discord** : ${candMention} (\`ID: ${testData.userId}\`)\n` +
      `🎮 **Identité RP / Roblox / Âge** : \`${robloxDisplay}\`\n` +
      `⏱️ **Disponibilités** : \`${availDisplay}\`\n` +
      `📌 **Statut** : **${statusInfo.label}**\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`
    )
    .setColor(statusInfo.color)
    .setFooter({ text: `Candidature Staff (20 Questions) #${testData.id} • Hamburg RP` })
    .setTimestamp(testData.createdAt);

  if (candidateUser && candidateUser.displayAvatarURL) {
    embed.setThumbnail(candidateUser.displayAvatarURL({ dynamic: true }));
  }

  if (Object.keys(answers).length >= 20) {
    embed.addFields(
      {
        name: '📌 1. PROFIL & MOTIVATIONS (Q1 - Q5)',
        value: `**1. Identité:** ${answers['sq_1'] || 'N/A'}\n` +
               `**2. Disponibilités:** ${answers['sq_2'] || 'N/A'}\n` +
               `**3. Motivations:** ${answers['sq_3'] || 'N/A'}\n` +
               `**4. Qualités & Défauts:** ${answers['sq_4'] || 'N/A'}\n` +
               `**5. Expériences:** ${answers['sq_5'] || 'N/A'}`,
        inline: false
      },
      {
        name: '⚖️ 2. CAS PRATIQUES RP (Q6 - Q10)',
        value: `**6. Mass RDM/Freekill:** ${answers['sq_6'] || 'N/A'}\n` +
               `**7. Insultes HRP Ticket:** ${answers['sq_7'] || 'N/A'}\n` +
               `**8. Combat Log:** ${answers['sq_8'] || 'N/A'}\n` +
               `**9. NoPainRP:** ${answers['sq_9'] || 'N/A'}\n` +
               `**10. FearRP:** ${answers['sq_10'] || 'N/A'}`,
        inline: false
      },
      {
        name: '🚨 3. CAS PRATIQUES AVANCÉS (Q11 - Q15)',
        value: `**11. Streamhack/Usurpation:** ${answers['sq_11'] || 'N/A'}\n` +
               `**12. Abus de Pouvoir:** ${answers['sq_12'] || 'N/A'}\n` +
               `**13. Metagaming:** ${answers['sq_13'] || 'N/A'}\n` +
               `**14. Braquages/NLR:** ${answers['sq_14'] || 'N/A'}\n` +
               `**15. Dox/Provocations:** ${answers['sq_15'] || 'N/A'}`,
        inline: false
      },
      {
        name: '📜 4. RÈGLEMENT & SANCTIONS (Q16 - Q20)',
        value: `**16. Procédure Warn:** ${answers['sq_16'] || 'N/A'}\n` +
               `**17. Différence Sanctions:** ${answers['sq_17'] || 'N/A'}\n` +
               `**18. Gestion Contestation:** ${answers['sq_18'] || 'N/A'}\n` +
               `**19. Gestion Erreur Staff:** ${answers['sq_19'] || 'N/A'}\n` +
               `**20. Mot de la Fin:** ${answers['sq_20'] || 'N/A'}`,
        inline: false
      }
    );
  } else {
    embed.addFields(
      { name: '📝 Cas 1 (Mass RDM / Freekill)', value: `\`\`\`${testData.case1}\`\`\``, inline: false },
      { name: '📝 Cas 2 (Insultes HRP / Trolling)', value: `\`\`\`${testData.case2}\`\`\``, inline: false },
      { name: '📝 Cas 3 (Combat Log & NoFearRP)', value: `\`\`\`${testData.case3}\`\`\``, inline: false }
    );
  }

  if (testData.status !== 'PENDING' && (reviewerUser || testData.reviewedBy)) {
    const adminMention = reviewerUser ? `<@${reviewerUser.id}>` : `<@${testData.reviewedBy}>`;
    embed.addFields({
      name: '👑 Décision de la Direction',
      value: `👮 **Administrateur** : ${adminMention}\n💬 **Motif / Remarques** : ${testData.reviewReason || '*Aucun motif précisé*'}`,
      inline: false
    });
  }

  const components = [];
  if (testData.status === 'PENDING') {
    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(`btn_staff_quiz_accept_${testData.id}`)
        .setLabel('Accepter Candidature')
        .setEmoji('🟢')
        .setStyle(ButtonStyle.Success),
      new ButtonBuilder()
        .setCustomId(`btn_staff_quiz_reject_${testData.id}`)
        .setLabel('Refuser Candidature')
        .setEmoji('🔴')
        .setStyle(ButtonStyle.Danger),
      new ButtonBuilder()
        .setCustomId(`btn_staff_quiz_interview_${testData.id}`)
        .setLabel('Convoquer Oral')
        .setEmoji('🎤')
        .setStyle(ButtonStyle.Primary)
    );
    components.push(row);
  }

  return { embeds: [embed], components };
}

// 54. Partnership Panel Embed

function partnershipPanelEmbed() {
  const embed = new EmbedBuilder()
    .setTitle('🤝 PORTAIL OFFICIEL DE PARTENARIAT • HAMBURG RP')
    .setDescription(
      'Bienvenue sur l\'espace de demande de partenariat de **Emergency Hamburg RP** !\n\n' +
      'Vous représentez un serveur Discord, un projet RP ou une communauté et souhaitez réaliser un échange de visibilité ?\n' +
      'Soumettez votre demande directement via le formulaire ci-dessous !\n\n' +
      '📌 **Conditions minimales :**\n' +
      '• Serveur actif et respectant les Termes de Discord.\n' +
      '• Lien d\'invitation valide et permanent.\n' +
      '• Contenu propre, sans propos haineux ou activités illégales.\n\n' +
      '👇 Cliquez sur le bouton **🤝 Demander un Partenariat** :'
    )
    .setColor('#9C27B0')
    .setThumbnail('https://i.imgur.com/8QG4m3b.png')
    .setFooter({ text: 'Relations Publiques • Hamburg RP' })
    .setTimestamp();

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('btn_partner_start')
      .setLabel('Demander un Partenariat')
      .setEmoji('🤝')
      .setStyle(ButtonStyle.Primary)
  );

  return { embeds: [embed], components: [row] };
}

// 55. Partnership Input Modal
function partnershipInputModal() {
  const modal = new ModalBuilder()
    .setCustomId('modal_partner_submit')
    .setTitle('🤝 Demande de Partenariat');

  const inputName = new TextInputBuilder()
    .setCustomId('server_name')
    .setLabel('Nom de votre serveur / Projet')
    .setPlaceholder('ex: Paris Roleplay RP')
    .setStyle(TextInputStyle.Short)
    .setRequired(true);

  const inputInvite = new TextInputBuilder()
    .setCustomId('invite_url')
    .setLabel('Lien d\'invitation permanent Discord')
    .setPlaceholder('ex: https://discord.gg/votrecode')
    .setStyle(TextInputStyle.Short)
    .setRequired(true);

  const inputCount = new TextInputBuilder()
    .setCustomId('member_count')
    .setLabel('Nombre de membres sur votre serveur')
    .setPlaceholder('ex: 450')
    .setStyle(TextInputStyle.Short)
    .setRequired(true);

  const inputType = new TextInputBuilder()
    .setCustomId('partner_type')
    .setLabel('Type de partenariat souhaité')
    .setPlaceholder('ex: Échange de pub / Événement conjointe')
    .setStyle(TextInputStyle.Short)
    .setRequired(true);

  const inputDesc = new TextInputBuilder()
    .setCustomId('description')
    .setLabel('Présentation & Description du serveur')
    .setPlaceholder('Décrivez brièvement votre projet...')
    .setStyle(TextInputStyle.Paragraph)
    .setRequired(true);

  modal.addComponents(
    new ActionRowBuilder().addComponents(inputName),
    new ActionRowBuilder().addComponents(inputInvite),
    new ActionRowBuilder().addComponents(inputCount),
    new ActionRowBuilder().addComponents(inputType),
    new ActionRowBuilder().addComponents(inputDesc)
  );

  return modal;
}

// 56. Partnership Card Embed for Staff Review
function partnershipCardEmbed({ partnerData, applicantUser, reviewerUser }) {
  const statusInfo = {
    PENDING: { label: '⏳ En attente de traitement', color: '#F1C40F' },
    ACCEPTED: { label: '🟢 Partenariat Validé', color: '#2ECC71' },
    REJECTED: { label: '🔴 Partenariat Refusé', color: '#E74C3C' }
  }[partnerData.status] || { label: partnerData.status, color: '#F1C40F' };

  const appMention = applicantUser ? `<@${applicantUser.id}> (\`${applicantUser.tag || applicantUser.username}\`)` : `<@${partnerData.userId}>`;

  const embed = new EmbedBuilder()
    .setTitle(`🤝 DEMANDE DE PARTENARIAT #${partnerData.id} • ${partnerData.serverName.toUpperCase()}`)
    .setDescription(
      `👤 **Représentant** : ${appMention} (\`ID: ${partnerData.userId}\`)\n` +
      `🌐 **Serveur** : **${partnerData.serverName}**\n` +
      `🔗 **Lien Invitation** : ${partnerData.inviteUrl}\n` +
      `👥 **Membres** : \`${partnerData.memberCount} membres\`\n` +
      `📌 **Type** : \`${partnerData.partnerType}\`\n` +
      `📊 **Statut** : **${statusInfo.label}**\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n` +
      `📝 **Présentation du Projet :**\n\`\`\`${partnerData.description}\`\`\``
    )
    .setColor(statusInfo.color)
    .setFooter({ text: `Partenariat #${partnerData.id} • Hamburg RP` })
    .setTimestamp(partnerData.createdAt);

  const components = [];
  if (partnerData.status === 'PENDING') {
    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(`btn_partner_accept_${partnerData.id}`)
        .setLabel('Accepter Partenariat')
        .setEmoji('🟢')
        .setStyle(ButtonStyle.Success),
      new ButtonBuilder()
        .setCustomId(`btn_partner_reject_${partnerData.id}`)
        .setLabel('Refuser')
        .setEmoji('🔴')
        .setStyle(ButtonStyle.Danger)
    );
    components.push(row);
  }

  return { embeds: [embed], components };
}

// 57. Organization (Gang / Business) Home Panel Embed
function organizationPanelEmbed() {
  const embed = new EmbedBuilder()
    .setTitle('🏢 & ⚔️ DÉPÔT DE DOSSIER D\'ORGANISATION • HAMBURG RP')
    .setDescription(
      'Bienvenue sur le portail de création et d\'officialisation des organisations de **Emergency Hamburg RP** !\n\n' +
      'Vous souhaitez développer votre entreprise légale ou fonder votre gang / faction illégale dans la ville ?\n' +
      'Déposez votre dossier d\'organisation directement via les boutons ci-dessous.\n\n' +
      '📌 **Options disponibles :**\n' +
      '• **⚔️ Faction Illégale / Gang** : Cartels, gangs de quartier, mafias, groupes de braqueurs.\n' +
      '• **🏢 Entreprise Légale** : Concessionnaire, sécurité privée, taxi, boîte de nuit, événementiel.\n\n' +
      '💡 *Chaque dossier est relu et validé par le Pôle Organisation & l\'Administration.*'
    )
    .setColor('#E67E22')
    .setThumbnail('https://i.imgur.com/8QG4m3b.png')
    .setFooter({ text: 'Gestion des Factions & Entreprises • Hamburg RP' })
    .setTimestamp();

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('btn_org_gang_start')
      .setLabel('Créer un Gang / Faction')
      .setEmoji('⚔️')
      .setStyle(ButtonStyle.Danger),
    new ButtonBuilder()
      .setCustomId('btn_org_business_start')
      .setLabel('Créer une Entreprise / Légal')
      .setEmoji('🏢')
      .setStyle(ButtonStyle.Success)
  );

  return { embeds: [embed], components: [row] };
}

// 58. Gang Creation Modal
function gangCreateModal() {
  const modal = new ModalBuilder()
    .setCustomId('modal_gang_submit')
    .setTitle('⚔️ Dossier de Faction Illégale / Gang');

  const inputName = new TextInputBuilder()
    .setCustomId('org_name')
    .setLabel('Nom du Gang / Cartel / Faction')
    .setPlaceholder('ex: Los Zetas Hamburg')
    .setStyle(TextInputStyle.Short)
    .setRequired(true);

  const inputMembers = new TextInputBuilder()
    .setCustomId('members_list')
    .setLabel('Effectifs & Pseudos (Roblox/Discord)')
    .setPlaceholder('ex: Chef: Patou | Membres: Tom, Alex, Hugo...')
    .setStyle(TextInputStyle.Short)
    .setRequired(true);

  const inputHQ = new TextInputBuilder()
    .setCustomId('location_hq')
    .setLabel('Quartier / QG souhaité dans Hamburg RP')
    .setPlaceholder('ex: Zone Industrielle Est / Port')
    .setStyle(TextInputStyle.Short)
    .setRequired(true);


  const inputLore = new TextInputBuilder()
    .setCustomId('lore')
    .setLabel('Histoire & Lore du Gang')
    .setPlaceholder('Expliquez l\'origine de votre groupe...')
    .setStyle(TextInputStyle.Paragraph)
    .setRequired(true);

  const inputActs = new TextInputBuilder()
    .setCustomId('activities')
    .setLabel('Activités Principales (Trafic, Braquages...)')
    .setPlaceholder('Renseignez les projets illégaux RP...')
    .setStyle(TextInputStyle.Paragraph)
    .setRequired(true);

  modal.addComponents(
    new ActionRowBuilder().addComponents(inputName),
    new ActionRowBuilder().addComponents(inputMembers),
    new ActionRowBuilder().addComponents(inputHQ),
    new ActionRowBuilder().addComponents(inputLore),
    new ActionRowBuilder().addComponents(inputActs)
  );

  return modal;
}

// 59. Business Creation Modal
function businessCreateModal() {
  const modal = new ModalBuilder()
    .setCustomId('modal_business_submit')
    .setTitle('🏢 Dossier d\'Entreprise Légale');

  const inputName = new TextInputBuilder()
    .setCustomId('org_name')
    .setLabel('Nom de la Société / Entreprise')
    .setPlaceholder('ex: Hamburg Security Services')
    .setStyle(TextInputStyle.Short)
    .setRequired(true);

  const inputSector = new TextInputBuilder()
    .setCustomId('sector')
    .setLabel('Secteur d\'activité (Sécurité, Taxi, Bar...)')
    .setPlaceholder('ex: Sécurité privée & Gardiennage')
    .setStyle(TextInputStyle.Short)
    .setRequired(true);

  const inputLeaders = new TextInputBuilder()
    .setCustomId('leaders')
    .setLabel('Dirigeants & Associés (Pseudos)')
    .setPlaceholder('ex: PDG: Patrick | DG: Lucas')
    .setStyle(TextInputStyle.Short)
    .setRequired(true);


  const inputPlan = new TextInputBuilder()
    .setCustomId('business_plan')
    .setLabel('Business Plan & Projets RP')
    .setPlaceholder('Expliquez comment votre entreprise fonctionnera...')
    .setStyle(TextInputStyle.Paragraph)
    .setRequired(true);

  modal.addComponents(
    new ActionRowBuilder().addComponents(inputName),
    new ActionRowBuilder().addComponents(inputSector),
    new ActionRowBuilder().addComponents(inputLeaders),
    new ActionRowBuilder().addComponents(inputPlan)
  );

  return modal;
}

// 60. Organization Card Embed for Admin Review
function organizationCardEmbed({ orgData, applicantUser, reviewerUser }) {
  const isGang = orgData.orgType === 'GANG';

  const statusInfo = {
    PENDING: { label: '⏳ Dossier en cours d\'étude', color: '#F1C40F' },
    ACCEPTED: { label: '🟢 Dossier Officiel Approuvé', color: '#2ECC71' },
    REJECTED: { label: '🔴 Dossier Refusé', color: '#E74C3C' },
    INTERVIEW: { label: '💬 Convoqué en Réunion RP', color: '#3498DB' }
  }[orgData.status] || { label: orgData.status, color: '#F1C40F' };

  const appMention = applicantUser ? `<@${applicantUser.id}> (\`${applicantUser.tag || applicantUser.username}\`)` : `<@${orgData.userId}>`;

  const embed = new EmbedBuilder()
    .setTitle(`${isGang ? '⚔️ DOSSIER GANG / FACTION' : '🏢 DOSSIER ENTREPRISE'} #${orgData.id} • ${orgData.orgName.toUpperCase()}`)
    .setDescription(
      `👤 **Fondateur / Demandeur** : ${appMention} (\`ID: ${orgData.userId}\`)\n` +
      `🏷️ **Nom Organisation** : **${orgData.orgName}**\n` +
      `📂 **Type** : \`${isGang ? 'Illégal (Gang / Cartel)' : 'Légal (Entreprise / Société)'}\`\n` +
      `📍 **${isGang ? 'Quartier / QG' : 'Secteur d\'activité'}** : \`${orgData.locationOrSector}\`\n` +
      `👥 **Membres / Dirigeants** : \`${orgData.membersList}\`\n` +
      `📊 **Statut** : **${statusInfo.label}**\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`
    )
    .setColor(isGang ? '#E53935' : '#43A047')
    .addFields(
      { name: isGang ? '📜 Lore & Histoire' : '💼 Business Plan RP', value: `\`\`\`${orgData.lore}\`\`\``, inline: false }
    )
    .setFooter({ text: `Dossier #${orgData.id} • Hamburg RP` })
    .setTimestamp(orgData.createdAt);

  if (orgData.businessPlan && isGang) {
    embed.addFields({ name: '🚨 Activités Principales', value: `\`\`\`${orgData.businessPlan}\`\`\``, inline: false });
  }

  const components = [];
  if (orgData.status === 'PENDING') {
    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(`btn_org_accept_${orgData.id}`)
        .setLabel('Approuver Dossier')
        .setEmoji('🟢')
        .setStyle(ButtonStyle.Success),
      new ButtonBuilder()
        .setCustomId(`btn_org_reject_${orgData.id}`)
        .setLabel('Refuser Dossier')
        .setEmoji('🔴')
        .setStyle(ButtonStyle.Danger),
      new ButtonBuilder()
        .setCustomId(`btn_org_interview_${orgData.id}`)
        .setLabel('Réunion RP Staff')
        .setEmoji('💬')
        .setStyle(ButtonStyle.Primary)
    );
    components.push(row);
  }

  return { embeds: [embed], components };
}


// 48. Anti-Raid & Security Dashboard Embed
function antiRaidDashboardEmbed(cfg, lastBackup) {
  const isLockdown = cfg.lockdown === 1;
  const isAntiBot = cfg.antiBot === 1;
  const isAntiAlt = cfg.antiAlt === 1;
  const isAntiSpam = cfg.antiSpam === 1;
  const isAntiMassJoin = cfg.antiMassJoin === 1;

  const statusBadge = (active) => active ? '🟢 **[ACTIVÉ]**' : '🔴 **[DÉSACTIVÉ]**';

  const lastBackupText = lastBackup 
    ? `<t:${Math.floor(lastBackup.createdAt / 1000)}:F> (<t:${Math.floor(lastBackup.createdAt / 1000)}:R>) par \`${lastBackup.createdBy}\``
    : '*Aucune sauvegarde enregistrée*';

  const embed = new EmbedBuilder()
    .setTitle('🛡️ PANNEAU DE SÉCURITÉ & ANTI-RAID • HAMBURG RP')
    .setDescription(
      'Bienvenue sur la centrale de protection et de sécurité avancée de la ville de **Hamburg**.\n\n' +
      `📌 **Statut Global :** ${isLockdown ? '🚨 **[VERROUILLÉ / LOCKDOWN EN COURS]**' : '🛡️ **[SERVEUR SÉCURISÉ & SOUS SURVEILLANCE]**'}\n` +
      '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━'
    )
    .setColor(isLockdown ? '#E53935' : config.colors?.primary || '#1E88E5')
    .setThumbnail('https://i.imgur.com/8QG4m3b.png')
    .addFields(
      {
        name: '🔒 1. Mode Lockdown (Verrouillage d\'Urgence)',
        value: `${statusBadge(isLockdown)}\n*Bloque immédiatement toutes les arrivées de nouveaux membres pendant un raid.*`,
        inline: false
      },
      {
        name: '🤖 2. Protection Anti-Bot',
        value: `${statusBadge(isAntiBot)}\n*Expulsion automatique des robots non autorisés.*`,
        inline: true
      },
      {
        name: '👶 3. Protection Anti-Alt & Comptes Récente',
        value: `${statusBadge(isAntiAlt)}\n*Exige un âge minimum de \`${cfg.minAccountAgeDays || 7} jours\` sur Discord.*`,
        inline: true
      },
      {
        name: '💥 4. Anti-Spam & Anti-Mass Mention',
        value: `${statusBadge(isAntiSpam)}\n*Max \`${cfg.maxMessagesPer5Sec || 5} msgs / 5s\` | Max \`${cfg.maxMentions || 4} pings / msg\`.*`,
        inline: true
      },
      {
        name: '⚡ 5. Protection Anti-Mass Join (Raid Spike)',
        value: `${statusBadge(isAntiMassJoin)}\n*Déclenché si > \`${cfg.maxJoinsPer10Sec || 5} arrivées / 10s\`.*`,
        inline: true
      },
      {
        name: '💾 6. Système de Sauvegarde (Backup)',
        value: `📂 **Dernier backup** : ${lastBackupText}\n*Sauvegarde automatique quotidienne de la DB et de la structure du serveur.*`,
        inline: false
      }
    )
    .setFooter({ text: 'Système Anti-Raid Centralisé • Hamburg RP' })
    .setTimestamp();

  const row1 = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('btn_antiraid_lockdown')
      .setLabel(isLockdown ? 'Désactiver Lockdown' : 'Activer Lockdown')
      .setEmoji(isLockdown ? '🔓' : '🔒')
      .setStyle(isLockdown ? ButtonStyle.Success : ButtonStyle.Danger),
    new ButtonBuilder()
      .setCustomId('btn_antiraid_antialt')
      .setLabel(isAntiAlt ? 'Désactiver Anti-Alt' : 'Activer Anti-Alt')
      .setEmoji('👶')
      .setStyle(isAntiAlt ? ButtonStyle.Secondary : ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId('btn_antiraid_antispam')
      .setLabel(isAntiSpam ? 'Désactiver Anti-Spam' : 'Activer Anti-Spam')
      .setEmoji('💥')
      .setStyle(isAntiSpam ? ButtonStyle.Secondary : ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId('btn_antiraid_antibot')
      .setLabel(isAntiBot ? 'Désactiver Anti-Bot' : 'Activer Anti-Bot')
      .setEmoji('🤖')
      .setStyle(isAntiBot ? ButtonStyle.Secondary : ButtonStyle.Primary)
  );

  const row2 = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('btn_antiraid_config_prompt')
      .setLabel('Réglages & Seuils')
      .setEmoji('⚙️')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('btn_antiraid_create_backup')
      .setLabel('Créer une Sauvegarde')
      .setEmoji('💾')
      .setStyle(ButtonStyle.Success),
    new ButtonBuilder()
      .setCustomId('btn_antiraid_refresh')
      .setLabel('Actualiser')
      .setEmoji('🔄')
      .setStyle(ButtonStyle.Secondary)
  );

  return { embeds: [embed], components: [row1, row2] };
}

// 49. Anti-Raid Config Thresholds Modal
function antiRaidConfigModal(cfg) {
  const modal = new ModalBuilder()
    .setCustomId('modal_antiraid_config')
    .setTitle('⚙️ Réglages des Seuils Anti-Raid');

  const inputAltAge = new TextInputBuilder()
    .setCustomId('min_alt_days')
    .setLabel('Âge min. des comptes Discord (Jours)')
    .setValue(String(cfg.minAccountAgeDays || 7))
    .setStyle(TextInputStyle.Short)
    .setRequired(true);

  const inputSpamMsgs = new TextInputBuilder()
    .setCustomId('max_spam_msgs')
    .setLabel('Max messages par 5 secondes (Spam)')
    .setValue(String(cfg.maxMessagesPer5Sec || 5))
    .setStyle(TextInputStyle.Short)
    .setRequired(true);

  const inputMentions = new TextInputBuilder()
    .setCustomId('max_mentions')
    .setLabel('Max mentions par message (Pings)')
    .setValue(String(cfg.maxMentions || 4))
    .setStyle(TextInputStyle.Short)
    .setRequired(true);

  const inputJoins = new TextInputBuilder()
    .setCustomId('max_joins')
    .setLabel('Max arrivées en 10s avant Lockdown')
    .setValue(String(cfg.maxJoinsPer10Sec || 5))
    .setStyle(TextInputStyle.Short)
    .setRequired(true);

  modal.addComponents(
    new ActionRowBuilder().addComponents(inputAltAge),
    new ActionRowBuilder().addComponents(inputSpamMsgs),
    new ActionRowBuilder().addComponents(inputMentions),
    new ActionRowBuilder().addComponents(inputJoins)
  );

  return modal;
}

// 50. Backup List Embed
function backupListEmbed(backupsList = []) {
  const embed = new EmbedBuilder()
    .setTitle('💾 HISTORIQUE DES SAUVEGARDES (BACKUPS)')
    .setColor('#43A047')
    .setFooter({ text: 'Système de Sauvegarde Automatique & Manuel • Hamburg RP' })
    .setTimestamp();

  if (!backupsList || backupsList.length === 0) {
    embed.setDescription('*Aucune sauvegarde enregistrée dans la base de données.*');
  } else {
    let desc = `Voici la liste des **${backupsList.length}** dernière(s) sauvegarde(s) de la ville :\n\n`;
    backupsList.forEach((b, idx) => {
      desc += `**${idx + 1}. \`${b.backupName}\`**\n` +
        `📅 **Date** : <t:${Math.floor(b.createdAt / 1000)}:F> (<t:${Math.floor(b.createdAt / 1000)}:R>)\n` +
        `✍️ **Auteur** : \`${b.createdBy}\` | 📁 **Type** : \`${b.fileType}\`\n` +
        `📝 **Détails** : ${b.details || 'N/A'}\n\n`;
    });
    embed.setDescription(desc);
  }

  return embed;
}


