const { EmbedBuilder, AuditLogEvent } = require('discord.js');
const { sendAuditLog } = require('../utils/auditLogger');
const config = require('../../config.json');

module.exports = {
  name: 'roleUpdate',
  async execute(oldRole, newRole) {
    try {
      if (!newRole.guild) return;

      const changes = [];

      if (oldRole.name !== newRole.name) {
        changes.push(`• **Nom** : \`${oldRole.name}\` ➔ \`${newRole.name}\``);
      }
      if (oldRole.hexColor !== newRole.hexColor) {
        changes.push(`• **Couleur** : \`${oldRole.hexColor}\` ➔ \`${newRole.hexColor}\``);
      }
      if (oldRole.hoist !== newRole.hoist) {
        changes.push(`• **Affichage séparé** : \`${oldRole.hoist ? 'Oui' : 'Non'}\` ➔ \`${newRole.hoist ? 'Oui' : 'Non'}\``);
      }
      if (oldRole.mentionable !== newRole.mentionable) {
        changes.push(`• **Mentionnable** : \`${oldRole.mentionable ? 'Oui' : 'Non'}\` ➔ \`${newRole.mentionable ? 'Oui' : 'Non'}\``);
      }

      if (changes.length === 0) return; // Ignore if permissions or position only changed without basic info

      const embed = new EmbedBuilder()
        .setTitle('⚙️ LOG AUDIT : MODIFICATION D\'UN RÔLE')
        .setColor('#8E24AA')
        .addFields(
          { name: '🏷️ Rôle modifié', value: `<@&${newRole.id}> (\`${newRole.name}\` | \`ID: ${newRole.id}\`)`, inline: false },
          { name: '📝 Changement(s) détecté(s)', value: changes.join('\n'), inline: false }
        )
        .setFooter({ text: `Role ID: ${newRole.id} • Hamburg RP` })
        .setTimestamp();

      try {
        const fetchedLogs = await newRole.guild.fetchAuditLogs({
          limit: 1,
          type: AuditLogEvent.RoleUpdate,
        });
        const auditEntry = fetchedLogs.entries.first();
        if (auditEntry && auditEntry.target.id === newRole.id && (Date.now() - auditEntry.createdTimestamp) < 5000) {
          embed.addFields({ name: '👮 Modifié par', value: `<@${auditEntry.executor.id}> (\`${auditEntry.executor.tag}\`)`, inline: false });
        }
      } catch (e) {}

      await sendAuditLog(newRole.guild, embed);
    } catch (error) {
      console.error('❌ Erreur dans l\'événement roleUpdate:', error);
    }
  }
};
