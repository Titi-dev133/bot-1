const db = require('../database/db');
const config = require('../../config.json');
const { sendAuditLog, triggerRaidAlert } = require('../utils/auditLogger');

const { antiRaidDashboardEmbed } = require('../utils/embeds');

// In-memory tracker for join rate limiting (Spike detection)
const guildJoinHistory = new Map();

module.exports = {
  name: 'guildMemberAdd',
  async execute(member) {
    try {
      const guild = member.guild;
      console.log(`📥 Nouveau membre arrivé: ${member.user.tag} (${member.id}) sur ${guild.name}`);

      const antiRaidConfig = await db.getAntiRaidConfig(guild.id);

      // --- 1. LOCKDOWN CHECK ---
      if (antiRaidConfig.lockdown === 1) {
        console.warn(`🚨 LOCKDOWN ACTIF : Expulsion automatique de ${member.user.tag}`);
        
        try {
          await member.send({
            content: `⛔ **Accès refusé :** Le serveur **${guild.name}** est actuellement en **Mode Lockdown / Verrouillage d'Urgence**. Les nouvelles arrivées sont temporairement bloquées.`
          });
        } catch (e) {}

        await member.kick('Anti-Raid Lockdown Actif');

        const logEmbed = {
          title: '🚨 ANTI-RAID : MEMBRE EXPULSÉ (LOCKDOWN ACTIF)',
          color: '#E53935',
          fields: [
            { name: '👤 Utilisateur ciblé', value: `<@${member.id}> (\`${member.user.tag}\` | \`ID: ${member.id}\`)`, inline: false },
            { name: '📌 Action', value: '🔨 **Kick Automatique** (Mode Lockdown en cours)', inline: false }
          ],
          timestamp: new Date()
        };
        await sendAuditLog(guild, logEmbed);
        return;
      }

      // --- 2. ANTI-BOT CHECK ---
      if (member.user.bot && antiRaidConfig.antiBot === 1) {
        console.warn(`🤖 ANTI-BOT ACTIF : Expulsion du bot non autorisé ${member.user.tag}`);
        await member.kick('Anti-Bot System');

        const logEmbed = {
          title: '🤖 ANTI-RAID : BOT EXPULSÉ AUTOMATIQUEMENT',
          color: '#E53935',
          fields: [
            { name: '🤖 Bot concerné', value: `<@${member.id}> (\`${member.user.tag}\`)`, inline: false },
            { name: '📌 Raison', value: 'Expulsion automatique des bots non autorisés', inline: false }
          ],
          timestamp: new Date()
        };
        await sendAuditLog(guild, logEmbed);
        return;
      }

      // --- 3. ANTI-ALT CHECK ---
      if (antiRaidConfig.antiAlt === 1 && !member.user.bot) {
        const createdTimestamp = member.user.createdTimestamp;
        const accountAgeDays = Math.floor((Date.now() - createdTimestamp) / (1000 * 60 * 60 * 24));
        const minDays = antiRaidConfig.minAccountAgeDays || 7;

        if (accountAgeDays < minDays) {
          console.warn(`👶 ANTI-ALT ACTIF : Expulsion de ${member.user.tag} (Compte créé il y a ${accountAgeDays}j, min requis: ${minDays}j)`);

          try {
            await member.send({
              content: `⚠️ **Accès refusé :** Votre compte Discord a été créé il y a **${accountAgeDays} jour(s)**. Le serveur **${guild.name}** exige un compte d'au moins **${minDays} jours** pour des raisons de sécurité.`
            });
          } catch (e) {}

          await member.kick(`Anti-Alt: Compte créé il y a ${accountAgeDays} jours (min ${minDays} jours)`);

          const logEmbed = {
            title: '👶 ANTI-RAID : COMPTE RÉCENT EXPULSÉ (ANTI-ALT)',
            color: '#FB8C00',
            fields: [
              { name: '👤 Utilisateur', value: `<@${member.id}> (\`${member.user.tag}\`)`, inline: true },
              { name: '📅 Âge du compte', value: `\`${accountAgeDays} jour(s)\` (Min requis: \`${minDays}j\`)`, inline: true },
              { name: '📌 Action', value: '🔨 Expulsion Automatique Anti-Alt', inline: false }
            ],
            timestamp: new Date()
          };
          await sendAuditLog(guild, logEmbed);
          return;
        }
      }

      // --- 4. JOIN SPIKE RATE LIMITER (MASS JOIN DETECTION) ---
      if (antiRaidConfig.antiMassJoin === 1) {
        const now = Date.now();
        if (!guildJoinHistory.has(guild.id)) {
          guildJoinHistory.set(guild.id, []);
        }

        const timestamps = guildJoinHistory.get(guild.id);
        timestamps.push(now);

        // Keep only timestamps within last 10 seconds
        const recentJoins = timestamps.filter(t => (now - t) <= 10000);
        guildJoinHistory.set(guild.id, recentJoins);

        const maxJoins = antiRaidConfig.maxJoinsPer10Sec || 5;
        if (recentJoins.length >= maxJoins) {
          console.error(`🚨 ALERTE RAID SPIKE : ${recentJoins.length} arrivées en 10s ! PASSAGE EN LOCKDOWN D'URGENCE.`);

          await db.updateAntiRaidConfig(guild.id, { lockdown: 1 });

          // Refresh active dashboard
          const updatedCfg = await db.getAntiRaidConfig(guild.id);
          const lastBackup = await db.getLastBackup(guild.id);
          const dbPanel = await db.getAntiRaidDashboard(guild.id);
          if (dbPanel) {
            try {
              const ch = await guild.channels.fetch(dbPanel.channelId);
              if (ch) {
                const msg = await ch.messages.fetch(dbPanel.messageId);
                if (msg) await msg.edit(antiRaidDashboardEmbed(updatedCfg, lastBackup));
              }
            } catch (e) {}
          }

          await triggerRaidAlert(guild, {
            reason: 'Mass Join Spike (Arrivées simultanées massives)',
            details: `⚠️ ${recentJoins.length} nouveaux membres ont rejoint le serveur en moins de 10 secondes.\n🔒 Le Mode Lockdown d'Urgence a été automatiquement activé pour verrouiller le serveur.`,
            joinCount: recentJoins.length
          });

        }
      }

      // --- NORMAL WELCOME PROCESS ---
      const welcomeConfig = await db.getWelcomeConfig(guild.id);

      const unverifiedRoleId = welcomeConfig?.unverifiedRoleId || config.unverifiedRoleId;
      let unverifiedRole = null;

      if (unverifiedRoleId) {
        unverifiedRole = guild.roles.cache.get(unverifiedRoleId);
      }

      if (!unverifiedRole) {
        unverifiedRole = guild.roles.cache.find(r => r.name.toLowerCase().includes('unverified') || r.name.toLowerCase().includes('non-vérifié') || r.name.toLowerCase().includes('non verifie'));
      }

      if (unverifiedRole) {
        await member.roles.add(unverifiedRole).catch(err => {
          console.error(`⚠️ Impossible d'ajouter le rôle unverified à ${member.user.tag}:`, err.message);
        });
      }

      const verifyChannelId = welcomeConfig?.verifyChannelId || config.channels?.verify;
      const verifyChannel = verifyChannelId ? guild.channels.cache.get(verifyChannelId) : null;

      try {
        await member.send({
          content: `👋 Bienvenue sur **${guild.name}** !\n\n` +
                   `Pour accéder à l'ensemble du serveur et obtenir le rôle **Membre**, veuillez vous rendre dans le salon ${verifyChannel ? verifyChannel : '#verification'} afin de lier votre compte Roblox et valider le règlement.`
        });
      } catch (dmErr) {}

    } catch (error) {
      console.error('❌ Erreur lors de l\'exécution de guildMemberAdd:', error);
    }
  }
};
