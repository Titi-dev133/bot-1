@echo off
echo ==============================================
echo   Enregistrement des commandes Slash Discord...
echo ==============================================
npm run deploy
pause
npm run deploy
