const db = require('../database/db');
const { giveawayEndedEmbed, giveawayLogEmbed } = require('./embeds');

/**
 * Tirage au sort aléatoire (Fisher-Yates) de N gagnants
 */
function pickRandomWinners(participants, count) {
  if (!participants || participants.length === 0) return [];
  const pool = [...participants];
  const winners = [];
  const targetCount = Math.min(pool.length, count);

  for (let i = 0; i < targetCount; i++) {
    const randomIndex = Math.floor(Math.random() * pool.length);
    winners.push(pool.splice(randomIndex, 1)[0]);
  }

  return winners;
}

/**
 * Traiter et terminer un giveaway spécifique
 */
async function processEndGiveaway(client, giveaway) {
  if (!giveaway || giveaway.ended) return null;

  let participants = [];
  try {
    participants = JSON.parse(giveaway.participants || '[]');
  } catch (e) {
    participants = [];
  }

  const winnersIds = pickRandomWinners(participants, giveaway.winnersCount || 1);

  // Update DB
  await db.endGiveawayRecord(giveaway.id, winnersIds);
  const updatedGiveaway = await db.getGiveawayRecord(giveaway.id);

  // Fetch host user
  const hostUser = await client.users.fetch(giveaway.hostId).catch(() => null);

  // Fetch winner user objects
  const winnerUsers = [];
  for (const id of winnersIds) {
    const u = await client.users.fetch(id).catch(() => null);
    if (u) winnerUsers.push(u);
    else winnerUsers.push({ id });
  }

  // Fetch guild & channel & card message
  const guild = client.guilds.cache.get(giveaway.guildId);
  if (guild) {
    const channel = guild.channels.cache.get(giveaway.channelId);
    if (channel) {
      try {
        const cardMsg = await channel.messages.fetch(giveaway.messageId).catch(() => null);
        if (cardMsg) {
          const endedPayload = giveawayEndedEmbed({
            giveaway: updatedGiveaway,
            hostUser,
            winnersUsers: winnerUsers
          });
          await cardMsg.edit(endedPayload).catch(() => {});
        }

        // Announcement message
        if (winnersIds.length > 0) {
          const mentions = winnersIds.map(w => `<@${w}>`).join(', ');
          await channel.send({
            content: `🎉 **FÉLICITATIONS !** ${mentions} vous remportez le giveaway pour **${giveaway.prize}** ! 🎁`
          }).catch(() => {});
        } else {
          await channel.send({
            content: `🔒 **GIVEAWAY TERMINÉ** : Aucun participant ne s'est inscrit pour le lot **${giveaway.prize}**.`
          }).catch(() => {});
        }
      } catch (e) {
        console.error('Erreur fin de giveaway:', e);
      }
    }

    // Log to log channel
    const logChannel = guild.channels.cache.find(
      c => c.isTextBased() && (
        c.name.toLowerCase() === 'log-giveaways' ||
        c.name.toLowerCase() === 'log-giveaway' ||
        c.name.toLowerCase() === 'log-serveur-ig'
      )
    );

    if (logChannel) {
      const logEmbed = giveawayLogEmbed({
        giveaway: updatedGiveaway,
        hostUser,
        winnersUsers: winnerUsers,
        actionType: 'TIRAGE AU SORT DE GIVEAWAY'
      });
      logChannel.send({ embeds: [logEmbed] }).catch(() => {});
    }
  }

  return { giveaway: updatedGiveaway, winners: winnersIds, winnerUsers };
}

/**
 * Vérification périodique de tous les giveaways arrivés à terme
 */
function initGiveawayScheduler(client) {
  // Check immediately on launch
  runGiveawayCheck(client);

  // Then check every 30 seconds
  setInterval(() => {
    runGiveawayCheck(client);
  }, 30000);
}

async function runGiveawayCheck(client) {
  try {
    const dueGiveaways = await db.getDueGiveawaysRecord();
    for (const g of dueGiveaways) {
      await processEndGiveaway(client, g);
    }
  } catch (e) {
    console.error('Erreur vérification scheduler giveaways:', e);
  }
}

module.exports = {
  pickRandomWinners,
  processEndGiveaway,
  initGiveawayScheduler
};
