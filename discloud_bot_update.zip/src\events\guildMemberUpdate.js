const { EmbedBuilder, AuditLogEvent } = require('discord.js');
const { sendAuditLog } = require('../utils/auditLogger');
const config = require('../../config.json');

module.exports = {
  name: 'guildMemberUpdate',
  async execute(oldMember, newMember) {
    try {
      if (!newMember.guild) return;

      // 1. Role Changes Detection
      const oldRoles = oldMember.roles.cache;
      const newRoles = newMember.roles.cache;

      const addedRoles = newRoles.filter(role => !oldRoles.has(role.id));
      const removedRoles = oldRoles.filter(role => !newRoles.has(role.id));

      if (addedRoles.size > 0 || removedRoles.size > 0) {
        const embed = new EmbedBuilder()
          .setTitle('🛡️ LOG AUDIT : MODIFICATION DES RÔLES D\'UN MEMBRE')
          .setColor(addedRoles.size > 0 ? (config.colors?.primary || '#1E88E5') : '#E53935')
          .setThumbnail(newMember.user.displayAvatarURL({ dynamic: true }))
          .addFields(
            { name: '👤 Membre concerné', value: `<@${newMember.id}> (\`${newMember.user.tag}\` | \`ID: ${newMember.id}\`)`, inline: false }
          )
          .setTimestamp();

        // Attempt audit log check
        try {
          const fetchedLogs = await newMember.guild.fetchAuditLogs({
            limit: 1,
            type: AuditLogEvent.MemberRoleUpdate,
          });
          const roleLog = fetchedLogs.entries.first();
          if (roleLog && roleLog.target.id === newMember.id && (Date.now() - roleLog.createdTimestamp) < 5000) {
            embed.addFields({ name: '👮 Action effectuée par', value: `<@${roleLog.executor.id}> (\`${roleLog.executor.tag}\`)`, inline: false });
          }
        } catch (auditErr) {
          // Ignore if missing permissions
        }

        if (addedRoles.size > 0) {
          let addedList = addedRoles.map(r => `🟢 <@&${r.id}> (\`${r.name}\`)`).join('\n');
          if (addedList.length > 900) addedList = addedList.substring(0, 900) + '...';
          embed.addFields({ name: `➕ Rôle(s) Ajouté(s) (${addedRoles.size})`, value: addedList, inline: false });
        }

        if (removedRoles.size > 0) {
          let removedList = removedRoles.map(r => `🔴 <@&${r.id}> (\`${r.name}\`)`).join('\n');
          if (removedList.length > 900) removedList = removedList.substring(0, 900) + '...';
          embed.addFields({ name: `➖ Rôle(s) Retiré(s) (${removedRoles.size})`, value: removedList, inline: false });
        }


        embed.setFooter({ text: `User ID: ${newMember.id} • Hamburg RP` });
        await sendAuditLog(newMember.guild, embed);
      }

      // 2. Nickname Changes Detection
      const oldNick = oldMember.nickname || oldMember.user.username;
      const newNick = newMember.nickname || newMember.user.username;

      if (oldMember.nickname !== newMember.nickname) {
        const nickEmbed = new EmbedBuilder()
          .setTitle('🏷️ LOG AUDIT : CHANGEMENT DE PSEUDO / NICKNAME')
          .setColor('#8E24AA')
          .setThumbnail(newMember.user.displayAvatarURL({ dynamic: true }))
          .addFields(
            { name: '👤 Membre concerné', value: `<@${newMember.id}> (\`${newMember.user.tag}\`)`, inline: false },
            { name: '📜 Ancien Pseudo', value: `\`${oldNick}\``, inline: true },
            { name: '🆕 Nouveau Pseudo', value: `\`${newNick}\``, inline: true }
          )
          .setFooter({ text: `User ID: ${newMember.id} • Hamburg RP` })
          .setTimestamp();

        await sendAuditLog(newMember.guild, nickEmbed);
      }
    } catch (error) {
      console.error('❌ Erreur dans l\'événement guildMemberUpdate:', error);
    }
  }
};
