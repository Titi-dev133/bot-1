const { EmbedBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder, ChannelType, PermissionFlagsBits, ButtonBuilder, ButtonStyle, MessageFlags, AttachmentBuilder } = require('discord.js');
const db = require('../database/db');
const { createEmbed, dispatch911Embed, verificationPanelEmbed, verificationRobloxModal, rulesAcceptEmbed, welcomeEmbed, securityLogEmbed, sanctionDashboardEmbed, sanctionInputModal, sanctionLookupModal, sanctionRemoveModal, playerSanctionCardEmbed, staffSanctionDashboardEmbed, staffSanctionInputModal, staffSanctionLookupModal, staffSanctionRemoveModal, staffSanctionCardEmbed, sanctionAuditLogEmbed, staffServiceDashboardEmbed, staffServiceLogEmbed, staffLeaderboardEmbed, formatMsDuration, staffRankDashboardEmbed, staffRankModal, staffRankLookupModal, staffRankLogEmbed, staffRankAnnouncementEmbed, staffAbsenceDashboardEmbed, staffAbsenceInputModal, staffAbsenceLogEmbed, staffAbsenceListEmbed, staffReviewDashboardEmbed, staffReviewInputModal, staffReviewRemoveModal, staffReviewLogEmbed, staffReviewCardEmbed, staffReviewDeletionLogEmbed, suggestionPanelEmbed, suggestionInputModal, suggestionCardEmbed, suggestionStaffManageModal, suggestionLogEmbed, giveawayDashboardEmbed, giveawayCreateModal, giveawayCardEmbed, giveawayEndedEmbed, giveawayLogEmbed, parseDuration, antiRaidDashboardEmbed, antiRaidConfigModal, backupListEmbed, staffRecruitmentPanelEmbed, staffQuizStep1Modal, staffQuizStep2Modal, staffQuizStep3Modal, staffQuizStep4Modal, staffCandidateCardEmbed, partnershipPanelEmbed, partnershipInputModal, partnershipCardEmbed, organizationPanelEmbed, gangCreateModal, businessCreateModal, organizationCardEmbed } = require('../utils/embeds');

const { createFullBackup } = require('../utils/backupManager');
const { sendAuditLog } = require('../utils/auditLogger');
const { fetchRobloxUser } = require('../utils/roblox');
const { createQuizSession } = require('../web/webServer');


const { createTicketChannelInterface } = require('../utils/dashboards');
const { generateAITicketGuidance } = require('../utils/aiAssistant');
const { startDiscordStaffQuiz } = require('../utils/staffQuizManager');

const config = require('../../config.json');


let callCounter = 800;
const userQuizSessions = new Map();
const activeQuizTimers = new Map();
const quizCooldowns = new Map();

/**
 * Annule immédiatement le test staff, ferme le ticket et enregistre un log d'audit.
 */
async function cancelStaffQuiz(guild, user, channel, reason) {
  if (activeQuizTimers.has(user.id)) {
    clearTimeout(activeQuizTimers.get(user.id));
    activeQuizTimers.delete(user.id);
  }
  userQuizSessions.delete(user.id);
  quizCooldowns.set(user.id, Date.now() + 24 * 60 * 60 * 1000); // Cooldown 24h

  const auditEmbed = {
    title: '🚨 LOG AUDIT : TEST STAFF ANNULÉ (TENTATIVE DE TRICHE / TIMEOUT)',
    color: '#E53935',
    fields: [
      { name: '👤 Candidat', value: `<@${user.id}> (\`${user.tag || user.username}\`)`, inline: true },
      { name: '📌 Motif d\'Annulation', value: `\`${reason}\``, inline: true }
    ],
    timestamp: new Date()
  };
  await sendAuditLog(guild, auditEmbed);

  if (channel) {
    try {
      await channel.send({
        content: `🚨 **TEST STAFF ANNULÉ ET SALON SUPPRIMÉ !**\nMotif : \`${reason}\`\nVous êtes bloqué(e) pendant **24 heures** avant de pouvoir faire une nouvelle tentative.`
      });
      setTimeout(async () => {
        await channel.delete().catch(() => {});
      }, 5000);
    } catch (e) {}
  }
}



/**
 * Obtenir ou créer la catégorie "SUPPORT" pour y placer TOUS les tickets
 */
async function getSupportCategory(guild) {
  let category = guild.channels.cache.find(
    c => c.type === ChannelType.GuildCategory && c.name.toLowerCase().includes('support')
  );

  if (!category) {
    try {
      category = await guild.channels.create({
        name: '📁 SUPPORT',
        type: ChannelType.GuildCategory
      });
    } catch (e) {
      console.error('Erreur lors de la création de la catégorie SUPPORT:', e);
    }
  }
  return category;
}

/**
 * Obtenir ou créer le salon "log-tickets" pour y consigner toutes les actions
 */
async function getLogTicketsChannel(guild) {
  let logChannel = guild.channels.cache.find(
    c => c.type === ChannelType.GuildText && (c.name.toLowerCase() === 'log-tickets' || c.name.toLowerCase() === 'logs-tickets' || c.name.toLowerCase().includes('log-ticket'))
  );

  if (!logChannel) {
    try {
      const supportCategory = await getSupportCategory(guild);
      logChannel = await guild.channels.create({
        name: 'log-tickets',
        type: ChannelType.GuildText,
        parent: supportCategory ? supportCategory.id : undefined,
        permissionOverwrites: [
          { id: guild.id, deny: [PermissionFlagsBits.ViewChannel] }
        ]
      });
    } catch (e) {
      console.error('Erreur lors de la création du salon log-tickets:', e);
    }
  }
  return logChannel;
}

/**
 * Obtenir ou créer le salon "demande-de-modo" pour recevoir les alertes modérateurs
 */
async function getModRequestChannel(guild) {
  let targetChannel = guild.channels.cache.find(
    c => c.type === ChannelType.GuildText && (
      c.name.toLowerCase() === 'demande-de-modo' ||
      c.name.toLowerCase() === 'demande-modo' ||
      c.name.toLowerCase().includes('demande-de-modo') ||
      c.name.toLowerCase().includes('demande-modo')
    )
  );

  if (!targetChannel) {
    try {
      const supportCategory = await getSupportCategory(guild);
      targetChannel = await guild.channels.create({
        name: 'demande-de-modo',
        type: ChannelType.GuildText,
        parent: supportCategory ? supportCategory.id : undefined
      });
    } catch (e) {
      console.error('Erreur lors de la création du salon demande-de-modo:', e);
    }
  }
  return targetChannel;
}

/**
 * Obtenir ou créer le salon "log-demande-de-modo" pour les logs de modération
 */
async function getModRequestLogChannel(guild) {
  let logChannel = guild.channels.cache.find(
    c => c.type === ChannelType.GuildText && (
      c.name.toLowerCase() === 'log-demande-de-modo' ||
      c.name.toLowerCase() === 'logs-demande-de-modo' ||
      c.name.toLowerCase() === 'log-demande-modo' ||
      c.name.toLowerCase().includes('log-demande')
    )
  );

  if (!logChannel) {
    try {
      const supportCategory = await getSupportCategory(guild);
      logChannel = await guild.channels.create({
        name: 'log-demande-de-modo',
        type: ChannelType.GuildText,
        parent: supportCategory ? supportCategory.id : undefined,
        permissionOverwrites: [
          { id: guild.id, deny: [PermissionFlagsBits.ViewChannel] }
        ]
      });
    } catch (e) {
      console.error('Erreur lors de la création du salon log-demande-de-modo:', e);
    }
  }
  return logChannel;
}

/**
 * Obtenir ou créer la catégorie "LOGS" pour y placer les salons de traçabilité
 */
async function getLogsCategory(guild) {
  let category = guild.channels.cache.find(
    c => c.type === ChannelType.GuildCategory && (
      c.name.toLowerCase() === 'logs' ||
      c.name.toLowerCase() === 'log' ||
      c.name.toLowerCase().includes('log')
    )
  );

  if (!category) {
    try {
      category = await guild.channels.create({
        name: '📁 LOGS',
        type: ChannelType.GuildCategory
      });
    } catch (e) {
      console.error('Erreur lors de la création de la catégorie LOGS:', e);
    }
  }
  return category;
}

/**
 * Obtenir ou créer le salon "log-sanction-joueur"
 */
async function getPlayerSanctionLogChannel(guild) {
  let logChannel = guild.channels.cache.find(
    c => c.type === ChannelType.GuildText && (
      c.name.toLowerCase() === 'log-sanction-joueur' ||
      c.name.toLowerCase() === 'logs-sanction-joueur' ||
      c.name.toLowerCase() === 'log-sanctions-joueur' ||
      c.name.toLowerCase().includes('log-sanction-joueur')
    )
  );

  if (!logChannel) {
    try {
      const logsCategory = await getLogsCategory(guild);
      logChannel = await guild.channels.create({
        name: 'log-sanction-joueur',
        type: ChannelType.GuildText,
        parent: logsCategory ? logsCategory.id : undefined,
        topic: 'Logs d\'audit des sanctions et retraits sur les joueurs'
      });
    } catch (e) {
      console.error('Erreur création log-sanction-joueur:', e);
    }
  }
  return logChannel;
}

/**
 * Obtenir ou créer le salon "log-sanction-staff"
 */
async function getStaffSanctionLogChannel(guild) {
  let logChannel = guild.channels.cache.find(
    c => c.type === ChannelType.GuildText && (
      c.name.toLowerCase() === 'log-sanction-staff' ||
      c.name.toLowerCase() === 'logs-sanction-staff' ||
      c.name.toLowerCase().includes('log-sanction-staff')
    )
  );

  if (!logChannel) {
    try {
      const logsCategory = await getLogsCategory(guild);
      logChannel = await guild.channels.create({
        name: 'log-sanction-staff',
        type: ChannelType.GuildText,
        parent: logsCategory ? logsCategory.id : undefined,
        topic: 'Logs d\'audit des sanctions et blâmes staff'
      });
    } catch (e) {
      console.error('Erreur création log-sanction-staff:', e);
    }
  }
  return logChannel;
}

/**
 * Obtenir ou créer le salon "log-service-staff"
 */
async function getStaffServiceLogChannel(guild) {
  let logChannel = guild.channels.cache.find(
    c => c.type === ChannelType.GuildText && (
      c.name.toLowerCase() === 'log-service-staff' ||
      c.name.toLowerCase() === 'logs-service-staff' ||
      c.name.toLowerCase() === 'log-prise-de-service-staff' ||
      c.name.toLowerCase().includes('log-service-staff')
    )
  );

  if (!logChannel) {
    try {
      const logsCategory = await getLogsCategory(guild);
      logChannel = await guild.channels.create({
        name: 'log-service-staff',
        type: ChannelType.GuildText,
        parent: logsCategory ? logsCategory.id : undefined,
        topic: 'Logs de prise, pause et fin de service des membres de l\'équipe Staff'
      });
    } catch (e) {
      console.error('Erreur création log-service-staff:', e);
    }
  }
  return logChannel;
}

/**
 * Obtenir ou créer le salon "#classement-staff" pour l'affichage dynamique
 */
async function getStaffLeaderboardChannel(guild) {
  let channel = guild.channels.cache.find(
    c => c.type === ChannelType.GuildText && (
      c.name.toLowerCase() === 'classement-staff' ||
      c.name.toLowerCase() === 'top-staff' ||
      c.name.toLowerCase().includes('classement-staff')
    )
  );

  if (!channel) {
    try {
      channel = await guild.channels.create({
        name: 'classement-staff',
        type: ChannelType.GuildText,
        topic: 'Classement général auto-rafraîchissant des heures de modération'
      });
    } catch (e) {
      console.error('Erreur création classement-staff:', e);
    }
  }
  return channel;
}

/**
 * Rafraîchir le message de classement auto-mis à jour dans #classement-staff
 */
async function refreshStaffLeaderboardMessage(guild) {
  try {
    const leaderboardData = await db.getStaffServiceLeaderboard(guild.id, 10);
    const embed = staffLeaderboardEmbed(leaderboardData);

    const configRecord = await db.getStaffLeaderboardConfig(guild.id);
    let targetChannel = null;

    if (configRecord && configRecord.channelId) {
      targetChannel = guild.channels.cache.get(configRecord.channelId);
    }

    if (!targetChannel) {
      targetChannel = await getStaffLeaderboardChannel(guild);
    }

    if (!targetChannel) return;

    let updatedMsg = null;
    if (configRecord && configRecord.messageId) {
      try {
        const existingMsg = await targetChannel.messages.fetch(configRecord.messageId).catch(() => null);
        if (existingMsg) {
          updatedMsg = await existingMsg.edit({ embeds: [embed] });
        }
      } catch (err) {}
    }

    if (!updatedMsg) {
      const newMsg = await targetChannel.send({ embeds: [embed] });
      await db.saveStaffLeaderboardConfig(guild.id, targetChannel.id, newMsg.id);
    }
  } catch (err) {
    console.error('Erreur lors du rafraîchissement du classement staff:', err);
  }
}

/**
 * Obtenir ou attribuer le rôle "Staff en Service"
 */
async function getOrCreateStaffDutyRole(guild) {
  let role = guild.roles.cache.find(
    r => r.name.toLowerCase() === 'staff en service' ||
         r.name.toLowerCase() === 'modérateur en service' ||
         r.name.toLowerCase() === 'staff service'
  );

  if (!role) {
    try {
      role = await guild.roles.create({
        name: 'Staff en Service',
        color: '#0D47A1',
        reason: 'Rôle automatique pour les modérateurs en prise de service'
      });
    } catch (e) {}
  }
  return role;
}

/**
 * Obtenir ou créer le salon "log-rank-staff"
 */
async function getStaffRankLogChannel(guild) {
  let logChannel = guild.channels.cache.find(
    c => c.type === ChannelType.GuildText && (
      c.name.toLowerCase() === 'log-rank-staff' ||
      c.name.toLowerCase() === 'logs-rank-staff' ||
      c.name.toLowerCase() === 'log-promotion-staff' ||
      c.name.toLowerCase().includes('log-rank')
    )
  );

  if (!logChannel) {
    try {
      const logsCategory = await getLogsCategory(guild);
      logChannel = await guild.channels.create({
        name: 'log-rank-staff',
        type: ChannelType.GuildText,
        parent: logsCategory ? logsCategory.id : undefined,
        topic: 'Logs d\'audit confidentiels des promotions et rétrogradations staff'
      });
    } catch (e) {
      console.error('Erreur création log-rank-staff:', e);
    }
  }
  return logChannel;
}

/**
 * Obtenir ou créer le salon "#promotions-staff" pour les annonces publiques
 */
async function getStaffRankAnnouncementChannel(guild) {
  let channel = guild.channels.cache.find(
    c => c.type === ChannelType.GuildText && (
      c.name.toLowerCase() === 'promotions-staff' ||
      c.name.toLowerCase() === 'annonces-staff' ||
      c.name.toLowerCase() === 'promotion-staff' ||
      c.name.toLowerCase().includes('promotion')
    )
  );

  if (!channel) {
    try {
      channel = await guild.channels.create({
        name: 'promotions-staff',
        type: ChannelType.GuildText,
        topic: 'Annonces officielles des promotions et évolutions de l\'équipe Staff'
      });
    } catch (e) {
      console.error('Erreur création promotions-staff:', e);
    }
  }
  return channel;
}

/**
 * Obtenir ou créer le salon "log-absence-staff"
 */
async function getStaffAbsenceLogChannel(guild) {
  let logChannel = guild.channels.cache.find(
    c => c.type === ChannelType.GuildText && (
      c.name.toLowerCase() === 'log-absence-staff' ||
      c.name.toLowerCase() === 'logs-absence-staff' ||
      c.name.toLowerCase() === 'log-absences-staff' ||
      c.name.toLowerCase().includes('log-absence')
    )
  );

  if (!logChannel) {
    try {
      const logsCategory = await getLogsCategory(guild);
      logChannel = await guild.channels.create({
        name: 'log-absence-staff',
        type: ChannelType.GuildText,
        parent: logsCategory ? logsCategory.id : undefined,
        topic: 'Logs d\'audit des déclarations d\'absences et retours du personnel Staff'
      });
    } catch (e) {
      console.error('Erreur création log-absence-staff:', e);
    }
  }
  return logChannel;
}

/**
 * Obtenir ou créer le salon "#liste-absences-staff"
 */
async function getStaffAbsenceListChannel(guild) {
  let channel = guild.channels.cache.find(
    c => c.type === ChannelType.GuildText && (
      c.name.toLowerCase() === 'liste-absences-staff' ||
      c.name.toLowerCase() === 'absences-staff' ||
      c.name.toLowerCase().includes('liste-absence')
    )
  );

  if (!channel) {
    try {
      channel = await guild.channels.create({
        name: 'liste-absences-staff',
        type: ChannelType.GuildText,
        topic: 'Liste mise à jour en temps réel des modérateurs actuellement absents'
      });
    } catch (e) {
      console.error('Erreur création liste-absences-staff:', e);
    }
  }
  return channel;
}

/**
 * Obtenir ou créer le salon "log-avis-staff"
 */
async function getStaffReviewLogChannel(guild) {
  let logChannel = guild.channels.cache.find(
    c => c.type === ChannelType.GuildText && (
      c.name.toLowerCase() === 'log-avis-staff' ||
      c.name.toLowerCase() === 'logs-avis-staff' ||
      c.name.toLowerCase() === 'log-avis' ||
      c.name.toLowerCase().includes('log-avis')
    )
  );

  if (!logChannel) {
    try {
      const logsCategory = await getLogsCategory(guild);
      logChannel = await guild.channels.create({
        name: 'log-avis-staff',
        type: ChannelType.GuildText,
        parent: logsCategory ? logsCategory.id : undefined,
        topic: 'Logs et retours des avis des membres sur l\'équipe Staff'
      });
    } catch (e) {
      console.error('Erreur création log-avis-staff:', e);
    }
  }
  return logChannel;
}

/**
 * Obtenir ou créer le salon "log-serveur-ig"
 */
async function getLogServeurIGChannel(guild) {
  let logChannel = guild.channels.cache.find(
    c => c.type === ChannelType.GuildText && (
      c.name.toLowerCase() === 'log-serveur-ig' ||
      c.name.toLowerCase() === 'logs-serveur-ig' ||
      c.name.toLowerCase().includes('log-serveur-ig')
    )
  );

  if (!logChannel) {
    try {
      const logsCategory = await getLogsCategory(guild);
      logChannel = await guild.channels.create({
        name: 'log-serveur-ig',
        type: ChannelType.GuildText,
        parent: logsCategory ? logsCategory.id : undefined,
        topic: 'Logs d\'audit et de suppressions sur le serveur IG'
      });
    } catch (e) {
      console.error('Erreur création log-serveur-ig:', e);
    }
  }
  return logChannel;
}

/**
 * Vérifie si un membre possède le rôle "ping fondation"
 */
function hasPingFondationRole(member) {
  if (!member || !member.roles) return false;
  if (member.permissions && member.permissions.has(PermissionFlagsBits.Administrator)) return true;
  return member.roles.cache.some(r =>
    r.name.toLowerCase() === 'ping fondation' ||
    r.name.toLowerCase() === 'fondation' ||
    r.name.toLowerCase().includes('ping fondation')
  );
}

/**
 * Obtenir ou créer le salon "#suggestions"
 */
async function getSuggestionsChannel(guild) {
  let channel = guild.channels.cache.find(
    c => c.type === ChannelType.GuildText && (
      c.name.toLowerCase() === 'suggestions' ||
      c.name.toLowerCase() === 'suggestion' ||
      c.name.toLowerCase() === 'salon-suggestions' ||
      c.name.toLowerCase().includes('suggestion')
    )
  );

  if (!channel) {
    try {
      channel = await guild.channels.create({
        name: 'suggestions',
        type: ChannelType.GuildText,
        topic: 'Salon officiel de réception des suggestions de la communauté'
      });
    } catch (e) {
      console.error('Erreur création salon suggestions:', e);
    }
  }
  return channel;
}

/**
 * Obtenir ou créer le salon "log-suggestions"
 */
async function getLogSuggestionsChannel(guild) {
  let logChannel = guild.channels.cache.find(
    c => c.type === ChannelType.GuildText && (
      c.name.toLowerCase() === 'log-suggestions' ||
      c.name.toLowerCase() === 'logs-suggestions' ||
      c.name.toLowerCase() === 'log-suggestion' ||
      c.name.toLowerCase().includes('log-suggestion')
    )
  );

  if (!logChannel) {
    try {
      const logsCategory = await getLogsCategory(guild);
      logChannel = await guild.channels.create({
        name: 'log-suggestions',
        type: ChannelType.GuildText,
        parent: logsCategory ? logsCategory.id : undefined,
        topic: 'Logs de suivi et traitement des suggestions par l\'équipe Staff'
      });
    } catch (e) {
      console.error('Erreur création log-suggestions:', e);
    }
  }
  return logChannel;
}

/**
 * Repositionne le dashboard de suggestion tout en bas du salon
 */
async function repositionSuggestionDashboard(guild, targetChannel) {
  if (!targetChannel) return;
  const dashConfig = await db.getSuggestionDashboard(guild.id);
  if (dashConfig) {
    try {
      const oldChannel = guild.channels.cache.get(dashConfig.channelId) || targetChannel;
      const oldMsg = await oldChannel.messages.fetch(dashConfig.messageId).catch(() => null);
      if (oldMsg) await oldMsg.delete().catch(() => {});
    } catch (e) {}
  }
  const payload = suggestionPanelEmbed();
  const newMsg = await targetChannel.send(payload);
  await db.saveSuggestionDashboard(guild.id, targetChannel.id, newMsg.id);
}

/**
 * Obtenir ou créer le rôle "Staff en Absence"
 */
async function getOrCreateStaffAbsenceRole(guild) {
  let role = guild.roles.cache.find(
    r => r.name.toLowerCase() === 'staff en absence' ||
         r.name.toLowerCase() === 'staff absent' ||
         r.name.toLowerCase() === 'absent'
  );

  if (!role) {
    try {
      role = await guild.roles.create({
        name: 'Staff en Absence',
        color: '#E67E22',
        reason: 'Rôle automatique pour les modérateurs en congé ou absence'
      });
    } catch (e) {}
  }
  return role;
}

/**
 * Rafraîchir le message de liste des absences actives
 */
async function refreshStaffAbsenceListMessage(guild) {
  const channel = await getStaffAbsenceListChannel(guild);
  if (!channel) return;

  const activeAbsences = await db.getAllActiveStaffAbsences(guild.id);
  const embed = staffAbsenceListEmbed(activeAbsences);

  try {
    const messages = await channel.messages.fetch({ limit: 10 }).catch(() => null);
    const existingMsg = messages ? messages.find(m => m.author.id === guild.client.user.id) : null;

    if (existingMsg) {
      await existingMsg.edit({ embeds: [embed] });
    } else {
      await channel.send({ embeds: [embed] });
    }
  } catch (e) {
    console.error('Erreur rafraîchissement liste absences:', e);
  }
}

/**
 * Résolution unifiée : Permet de trouver à la fois le compte Roblox ET le compte Discord
 * Accepte : Pseudo Roblox, Mention Discord (<@ID>), ID Discord, Pseudo Discord
 */
async function resolvePlayerInfo(query, client) {
  if (!query) return { robloxUser: null, discordUser: null };
  const cleanQuery = query.trim();

  let discordId = cleanQuery.replace(/[^0-9]/g, '');
  let discordUser = null;
  let robloxUser = null;

  if (discordId.length >= 17) {
    discordUser = await client.users.fetch(discordId).catch(() => null);
    if (discordUser) {
      const verification = await db.getVerification(discordUser.id);
      if (verification && verification.robloxUsername) {
        robloxUser = await fetchRobloxUser(verification.robloxUsername) || {
          id: verification.robloxId || verification.robloxUsername,
          name: verification.robloxUsername,
          displayName: verification.robloxUsername,
          avatarUrl: 'https://i.imgur.com/8QG4m3b.png'
        };
      }
    }
  }

  if (!robloxUser) {
    robloxUser = await fetchRobloxUser(cleanQuery);
  }

  if (!robloxUser) {
    robloxUser = {
      id: cleanQuery,
      name: cleanQuery,
      displayName: cleanQuery,
      avatarUrl: 'https://i.imgur.com/8QG4m3b.png'
    };
  }

  if (!discordUser && robloxUser.id) {
    const linkedDiscordId = await db.isRobloxLinkedToAnotherDiscord(robloxUser.id, '0');
    if (linkedDiscordId) {
      discordUser = await client.users.fetch(linkedDiscordId).catch(() => null);
    }
  }

  return { robloxUser, discordUser };
}

module.exports = {
  name: 'interactionCreate',
  async execute(interaction) {
    try {
      // 1. Slash Commands
      if (interaction.isChatInputCommand()) {
        const command = interaction.client.commands.get(interaction.commandName);
        if (!command) return;
        try {
          await command.execute(interaction);
        } catch (error) {
          console.error(`Erreur commande ${interaction.commandName}:`, error);
        }
        return;
      }

      // 2. Select Menu Dropdown Processing (Ouverture de Ticket par Motif)
      if (interaction.isStringSelectMenu()) {
        const { customId, user, guild, values } = interaction;

        if (customId === 'select_ticket_category') {
          const category = values[0];
          const sanitizeUser = user.username.toLowerCase().replace(/[^a-z0-9]/g, '');
          const channelName = `ticket-${category.toLowerCase().replace(/[^a-z0-9]/g, '-')}-${sanitizeUser}`;

          // Obtenir ou créer la catégorie "SUPPORT"
          const supportCategory = await getSupportCategory(guild);

          // Permission overwrites for Ticket Channel
          const permissionOverwrites = [
            { id: guild.id, deny: [PermissionFlagsBits.ViewChannel] },
            { id: user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.AttachFiles] }
          ];

          // Add staff roles permissions if configured
          if (config.factions && config.factions.police && config.factions.police.serviceRole) {
            permissionOverwrites.push({
              id: guild.roles.premiumSubscriberRole || guild.id, // Fallback
              allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages]
            });
          }

          const ticketChannel = await guild.channels.create({
            name: channelName,
            type: ChannelType.GuildText,
            parent: supportCategory ? supportCategory.id : undefined,
            permissionOverwrites
          });

          // Save ticket to DB
          await db.createTicketRecord(ticketChannel.id, user.id, category);

          // Post ticket welcome interface with 4 buttons
          const ticketPayload = createTicketChannelInterface(user, category);
          await ticketChannel.send(ticketPayload);

          // Log à log-tickets
          const logChannel = await getLogTicketsChannel(guild);
          if (logChannel) {
            const logEmbed = createEmbed({
              title: '🟢 NOUVEAU TICKET CRÉÉ',
              description:
                `👤 **Demandeur** : <@${user.id}> (\`${user.tag}\`)\n` +
                `📌 **Motif** : \`${category}\`\n` +
                `💬 **Salon** : ${ticketChannel}\n` +
                `🆔 **ID Salon** : \`${ticketChannel.id}\``,
              color: config.colors.success,
              footer: 'Système de Logs • Aubagne RP'
            });
            logChannel.send({ embeds: [logEmbed] }).catch(() => {});
          }

          return interaction.reply({
            content: `✅ Votre ticket pour **"${category}"** a été créé dans le salon ${ticketChannel}.`,
            flags: MessageFlags.Ephemeral
          });
        }
      }

      // 3. Modal Submits (Casino & Mini-Jeux Éphémères)
      if (interaction.isModalSubmit()) {
        const { customId, user } = interaction;

        if (customId === 'modal_game_slots') {
          const betStr = interaction.fields.getTextInputValue('input_slots_bet');
          const bet = parseInt(betStr, 10);
          if (isNaN(bet) || bet < 10) {
            return interaction.reply({ content: '❌ Veuillez saisir un montant valide (minimum 10 €).', flags: MessageFlags.Ephemeral });
          }

          const balance = await db.getUserBalance(user.id);
          if (balance < bet) {
            return interaction.reply({ content: `❌ Solde insuffisant (${balance} € disponible).`, flags: MessageFlags.Ephemeral });
          }

          await db.removeMoney(user.id, bet);
          const symbols = ['🍒', '🍋', '🍇', '💎', '7️⃣'];
          const slot1 = symbols[Math.floor(Math.random() * symbols.length)];
          const slot2 = symbols[Math.floor(Math.random() * symbols.length)];
          const slot3 = symbols[Math.floor(Math.random() * symbols.length)];

          let winAmount = 0;
          let mult = 0;
          if (slot1 === slot2 && slot2 === slot3) { mult = 5; winAmount = bet * mult; }
          else if (slot1 === slot2 || slot2 === slot3 || slot1 === slot3) { mult = 2; winAmount = bet * mult; }

          if (winAmount > 0) await db.addMoney(user.id, winAmount);
          const newBal = await db.getUserBalance(user.id);

          const embed = createEmbed({
            title: '🎰 MACHINE À SOUS • CASINO',
            description:
              `🎰 [ **${slot1}** | **${slot2}** | **${slot3}** ] 🎰\n\n` +
              (winAmount > 0
                ? `🎉 **GAGNÉ !** ${mult === 5 ? '💥 **JACKPOT x5 !**' : '✨ **COMBINAISON x2 !**'}\n💵 Gain : **+${winAmount} €**`
                : `❌ **PERDU !** Mise de **${bet} €** perdue.`) +
              `\n\n💰 **Nouveau Solde** : \`${newBal.toLocaleString('fr-FR')} €\``,
            color: winAmount > 0 ? config.colors.success : config.colors.danger
          });
          return interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
        }

        if (customId === 'modal_game_coinflip') {
          const betStr = interaction.fields.getTextInputValue('input_coinflip_bet');
          const choice = (interaction.fields.getTextInputValue('input_coinflip_choice') || '').toLowerCase().trim();
          const bet = parseInt(betStr, 10);

          if (isNaN(bet) || bet < 10) {
            return interaction.reply({ content: '❌ Veuillez saisir un montant valide (minimum 10 €).', flags: MessageFlags.Ephemeral });
          }
          if (!['pile', 'face'].includes(choice)) {
            return interaction.reply({ content: '❌ Saisissez "pile" ou "face".', flags: MessageFlags.Ephemeral });
          }

          const balance = await db.getUserBalance(user.id);
          if (balance < bet) {
            return interaction.reply({ content: `❌ Solde insuffisant (${balance} € disponible).`, flags: MessageFlags.Ephemeral });
          }

          await db.removeMoney(user.id, bet);
          const result = Math.random() < 0.5 ? 'pile' : 'face';
          const isWin = choice === result;

          if (isWin) await db.addMoney(user.id, bet * 2);
          const newBal = await db.getUserBalance(user.id);

          const embed = createEmbed({
            title: '🪙 PILE OU FACE • CASINO',
            description:
              `🪙 Résultat : **${result.toUpperCase()}** !\n\n` +
              (isWin
                ? `🎉 **GAGNÉ !** Votre pari (${choice.toUpperCase()}) était exact !\n💵 Gain total : **+${bet * 2} €**`
                : `❌ **PERDU !** La pièce est tombée sur ${result.toUpperCase()}.\nMise perdue : **${bet} €**`) +
              `\n\n💰 **Nouveau Solde** : \`${newBal.toLocaleString('fr-FR')} €\``,
            color: isWin ? config.colors.success : config.colors.danger
          });
          return interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
        }

        if (customId === 'modal_lookup_player') {
          const query = interaction.fields.getTextInputValue('input_lookup_query');
          const { performPlayerLookup } = require('../commands/lookup');
          const result = await performPlayerLookup({ guild: interaction.guild, query });
          return interaction.reply({ embeds: [result.embed], flags: MessageFlags.Ephemeral });
        }
      }


      // 4. Buttons Clicks
      if (interaction.isButton()) {
        const { customId, user, guild, channel } = interaction;

        if (customId === 'btn_lookup_prompt') {
          const modal = new ModalBuilder()
            .setCustomId('modal_lookup_player')
            .setTitle('🔍 Recherche de Joueur (Discord ↔ Roblox)');
          const input = new TextInputBuilder()
            .setCustomId('input_lookup_query')
            .setLabel('Pseudo Discord, ID ou Pseudo Roblox')
            .setStyle(TextInputStyle.Short)
            .setPlaceholder('Ex: @Pseudo, 123456789 ou RobloxUser')
            .setRequired(true);
          modal.addComponents(new ActionRowBuilder().addComponents(input));
          return await interaction.showModal(modal);
        }

        // --- Service Buttons (Prise et Fin de Service avec Paie RP) ---

        if (customId.startsWith('service_') && customId !== 'service_stop') {
          const faction = customId.replace('service_', '');
          const result = await db.startService(user.id, guild.id, faction);
          if (!result.success) {
            return interaction.reply({
              embeds: [createEmbed({ title: '⚠️ Prise de Service Impossible', description: result.message, color: config.colors.warning })],
              flags: MessageFlags.Ephemeral
            });
          }
          const factionNames = {
            bus: '🚌 Chauffeur de Bus (Paie: 1.2€/min)',
            camion: '🚚 Camionneur (Paie: 2.4€/min)',
            police: '🚓 Polizei / Police (Paie: 2.4€/min)',
            fire: '🚒 Feuerwehr / Pompiers (Paie: 3.0€/min)',
            ems: '🚑 Rettungsdienst / EMS (Paie: 4.8€/min)',
            adac: '🛞 ADAC Dépannage (Paie: 6.5€/min)'
          };
          const embed = createEmbed({
            title: '🟢 PRISE DE SERVICE VALIDÉE',
            description: `Vous avez pris votre service chez **${factionNames[faction] || faction.toUpperCase()}**.\n\n⏰ Début : <t:${Math.floor(result.startTime / 1000)}:F>\n📌 *Votre salaire s'accumule pendant votre service et vous sera versé lors de votre fin de service.*`,
            color: config.colors.success
          });
          return interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
        }

        if (customId === 'service_stop') {
          const result = await db.stopService(user.id);
          if (!result.success) {
            return interaction.reply({
              embeds: [createEmbed({ title: '⚠️ Fin de Service Impossible', description: result.message, color: config.colors.warning })],
              flags: MessageFlags.Ephemeral
            });
          }

          if (result.cancelled) {
            const embed = createEmbed({
              title: '❌ SERVICE ANNULÉ & PAIE RETIRÉE (0 €)',
              description: result.message,
              color: config.colors.danger
            });
            return interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
          }

          const hours = Math.floor(result.durationMinutes / 60);
          const mins = result.durationMinutes % 60;
          const durationStr = `${hours > 0 ? `${hours}h ` : ''}${mins}min`;

          const embed = createEmbed({
            title: '🔴 FIN DE SERVICE & PAIE BANCAIRE DIRECTE',
            description:
              `🏢 **Métier** : ${result.factionName}\n` +
              `⏱️ **Temps en service** : **${durationStr}** (${result.durationMinutes} min)\n` +
              `📊 **Multiplicateur de paie** : \`${result.multiplier}x\` (${result.baseRate}€ base / 10 min)\n` +
              `💶 **Taux de salaire** : \`${result.ratePerMin} € / min\`\n\n` +
              `💵 **SALAIRE VERSÉ SUR VOTRE COMPTE** : **+${result.earnedMoney.toLocaleString('fr-FR')} €**\n` +
              `💰 **Nouveau Solde Bancaire** : \`${result.newBalance.toLocaleString('fr-FR')} €\``,
            color: config.colors.gold
          });
          return interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
        }

        if (customId === 'btn_my_stats') {
          const data = await db.getServiceStats(user.id);
          const totalMins = data.stats ? data.stats.totalMinutes : 0;
          const shiftCount = data.stats ? data.stats.shiftCount : 0;
          const hours = Math.floor(totalMins / 60);
          const mins = totalMins % 60;

          const embed = createEmbed({
            title: `📊 VOTRE BILAN DE SERVICE • ${user.username}`,
            description:
              `⏱️ **Temps Total Cumulé** : **${hours}h ${mins}min** (${totalMins} min)\n` +
              `🚓 **Nombre de Services Effectués** : **${shiftCount}**`,
            color: config.colors.primary,
            thumbnail: user.displayAvatarURL({ dynamic: true })
          });
          return interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
        }

        if (customId === 'btn_leaderboard') {
          const leaderboard = await db.getServiceLeaderboard(10);
          if (!leaderboard || leaderboard.length === 0) {
            return interaction.reply({ content: 'Aucune donnée de service enregistrée pour le moment.', flags: MessageFlags.Ephemeral });
          }

          let desc = '';
          for (let i = 0; i < leaderboard.length; i++) {
            const item = leaderboard[i];
            const u = await interaction.client.users.fetch(item.userId).catch(() => null);
            const userName = u ? u.tag : `Agent (${item.userId})`;
            const hours = Math.floor(item.totalMinutes / 60);
            const mins = item.totalMinutes % 60;
            const medal = i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : '🔹';
            desc += `${medal} **#${i + 1}** ${userName} — **${hours}h ${mins}m** (${item.shiftCount} services)\n`;
          }

          const embed = createEmbed({
            title: '🏆 CLASSEMENT DES MEILLEURS AGENTS EN SERVICE',
            description: desc,
            color: config.colors.gold
          });
          return interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
        }

        if (customId === 'btn_my_id') {
          const profile = await db.getProfile(user.id);
          const balance = await db.getUserBalance(user.id);
          const embed = createEmbed({
            title: `🪪 CARTE D'IDENTITÉ RP • ${user.username}`,
            description:
              `👤 **Nom & Prénom** : ${profile.lastName} ${profile.firstName}\n` +
              `🎂 **Âge** : ${profile.age} ans\n` +
              `💼 **Métier / Faction** : ${profile.job}\n` +
              `📜 **Permis & Licences** : ${profile.licenses}\n` +
              `🎮 **Pseudo Roblox** : ${profile.robloxUsername || '❌ *Non lié*'}\n` +
              `💳 **Solde Bancaire** : \`${balance.toLocaleString('fr-FR')} €\``,
            color: config.colors.police,
            thumbnail: user.displayAvatarURL({ dynamic: true })
          });
          return interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
        }


        // --- Games & Casino Dashboard Buttons (100% Éphémères) ---
        if (customId === 'btn_game_balance') {
          const balance = await db.getUserBalance(user.id);
          const embed = createEmbed({
            title: `💳 VOTRE SOLDE BANCAIRE • ${user.username}`,
            description: `💰 **Solde Bancaire Actuel** : \`${balance.toLocaleString('fr-FR')} €\``,
            color: config.colors.gold,
            thumbnail: user.displayAvatarURL({ dynamic: true })
          });
          return interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
        }

        if (customId === 'btn_game_work') {
          const cooldown = await db.getCooldown(user.id, 'work');
          if (cooldown > 0) {
            const minsLeft = Math.ceil(cooldown / 60000);
            return interaction.reply({
              content: `⏳ **Vous êtes fatigué(e) !** Attendez encore **${minsLeft} minute(s)**.`,
              flags: MessageFlags.Ephemeral
            });
          }
          const reward = Math.floor(Math.random() * 151) + 50;
          await db.addMoney(user.id, reward);
          await db.setCooldown(user.id, 'work', 3600000);
          const newBal = await db.getUserBalance(user.id);
          const embed = createEmbed({
            title: '💼 MISSION DE TRAVAIL EFFECTUÉE',
            description: `💵 **Salaire perçu** : \`+${reward} €\`\n💰 **Nouveau Solde** : \`${newBal.toLocaleString('fr-FR')} €\``,
            color: config.colors.success
          });
          return interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
        }

        if (customId === 'btn_game_daily') {
          const cooldown = await db.getCooldown(user.id, 'daily');
          if (cooldown > 0) {
            const hoursLeft = Math.floor(cooldown / 3600000);
            const minsLeft = Math.ceil((cooldown % 3600000) / 60000);
            return interaction.reply({
              content: `⏳ **Déjà réclamé !** Revenez dans **${hoursLeft}h ${minsLeft}min**.`,
              flags: MessageFlags.Ephemeral
            });
          }
          const reward = 500;
          await db.addMoney(user.id, reward);
          await db.setCooldown(user.id, 'daily', 86400000);
          const newBal = await db.getUserBalance(user.id);
          const embed = createEmbed({
            title: '🎁 RÉCOMPENSE QUOTIDIENNE (24H)',
            description: `🎉 **Bonus Quotidien** : \`+${reward} €\`\n💰 **Nouveau Solde** : \`${newBal.toLocaleString('fr-FR')} €\``,
            color: config.colors.gold
          });
          return interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
        }

        if (customId === 'btn_game_slots_prompt') {
          const modal = new ModalBuilder()
            .setCustomId('modal_game_slots')
            .setTitle('🎰 Machine à Sous • Pari');
          const input = new TextInputBuilder()
            .setCustomId('input_slots_bet')
            .setLabel('Montant de votre mise (€)')
            .setStyle(TextInputStyle.Short)
            .setPlaceholder('Ex: 100')
            .setRequired(true);
          modal.addComponents(new ActionRowBuilder().addComponents(input));
          return await interaction.showModal(modal);
        }

        if (customId === 'btn_game_coinflip_prompt') {
          const modal = new ModalBuilder()
            .setCustomId('modal_game_coinflip')
            .setTitle('🪙 Pile ou Face • Pari');
          const inputBet = new TextInputBuilder()
            .setCustomId('input_coinflip_bet')
            .setLabel('Montant de votre mise (€)')
            .setStyle(TextInputStyle.Short)
            .setPlaceholder('Ex: 100')
            .setRequired(true);
          const inputChoice = new TextInputBuilder()
            .setCustomId('input_coinflip_choice')
            .setLabel('Votre choix : pile ou face')
            .setStyle(TextInputStyle.Short)
            .setPlaceholder('Saisissez "pile" ou "face"')
            .setRequired(true);
          modal.addComponents(
            new ActionRowBuilder().addComponents(inputBet),
            new ActionRowBuilder().addComponents(inputChoice)
          );
          return await interaction.showModal(modal);
        }

        // --- Anti-Raid & Security Dashboard Buttons ---



        if (customId === 'btn_antiraid_lockdown') {
          if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
            return interaction.reply({ content: '❌ Seuls les Administrateurs peuvent utiliser ce bouton.', flags: MessageFlags.Ephemeral });
          }
          await interaction.deferUpdate();
          const cfg = await db.getAntiRaidConfig(guild.id);
          const newLock = cfg.lockdown === 1 ? 0 : 1;
          await db.updateAntiRaidConfig(guild.id, { lockdown: newLock });

          const updatedCfg = await db.getAntiRaidConfig(guild.id);
          const lastBackup = await db.getLastBackup(guild.id);
          await interaction.message.edit(antiRaidDashboardEmbed(updatedCfg, lastBackup));

          const auditEmbed = {
            title: newLock ? '🚨 LOG AUDIT SÉCURITÉ : MODE LOCKDOWN ACTIVÉ' : '🔓 LOG AUDIT SÉCURITÉ : MODE LOCKDOWN DÉSACTIVÉ',
            color: newLock ? '#E53935' : '#43A047',
            fields: [
              { name: '👮 Administrateur', value: `<@${user.id}> (\`${user.tag}\`)`, inline: true },
              { name: '📌 Action', value: newLock ? '🔒 Activation du verrouillage' : '🔓 Désactivation du verrouillage', inline: true }
            ],
            timestamp: new Date()
          };
          await sendAuditLog(guild, auditEmbed);
          return;
        }

        if (customId === 'btn_antiraid_antialt') {
          if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
            return interaction.reply({ content: '❌ Seuls les Administrateurs peuvent utiliser ce bouton.', flags: MessageFlags.Ephemeral });
          }
          await interaction.deferUpdate();
          const cfg = await db.getAntiRaidConfig(guild.id);
          const newVal = cfg.antiAlt === 1 ? 0 : 1;
          await db.updateAntiRaidConfig(guild.id, { antiAlt: newVal });

          const updatedCfg = await db.getAntiRaidConfig(guild.id);
          const lastBackup = await db.getLastBackup(guild.id);
          await interaction.message.edit(antiRaidDashboardEmbed(updatedCfg, lastBackup));

          const auditEmbed = {
            title: '⚙️ LOG AUDIT SÉCURITÉ : PARAMÈTRE ANTI-ALT MODIFIÉ',
            color: newVal ? '#43A047' : '#FB8C00',
            fields: [
              { name: '👮 Administrateur', value: `<@${user.id}> (\`${user.tag}\`)`, inline: true },
              { name: '📌 Option', value: `**Protection Anti-Alt & Comptes Récentes** : ${newVal ? '🟢 **ACTIVÉE**' : '🔴 **DÉSACTIVÉE**'}`, inline: false }
            ],
            timestamp: new Date()
          };
          await sendAuditLog(guild, auditEmbed);
          return;
        }

        if (customId === 'btn_antiraid_antispam') {
          if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
            return interaction.reply({ content: '❌ Seuls les Administrateurs peuvent utiliser ce bouton.', flags: MessageFlags.Ephemeral });
          }
          await interaction.deferUpdate();
          const cfg = await db.getAntiRaidConfig(guild.id);
          const newVal = cfg.antiSpam === 1 ? 0 : 1;
          await db.updateAntiRaidConfig(guild.id, { antiSpam: newVal });

          const updatedCfg = await db.getAntiRaidConfig(guild.id);
          const lastBackup = await db.getLastBackup(guild.id);
          await interaction.message.edit(antiRaidDashboardEmbed(updatedCfg, lastBackup));

          const auditEmbed = {
            title: '⚙️ LOG AUDIT SÉCURITÉ : PARAMÈTRE ANTI-SPAM MODIFIÉ',
            color: newVal ? '#43A047' : '#FB8C00',
            fields: [
              { name: '👮 Administrateur', value: `<@${user.id}> (\`${user.tag}\`)`, inline: true },
              { name: '📌 Option', value: `**Protection Anti-Spam & Anti-Mention** : ${newVal ? '🟢 **ACTIVÉE**' : '🔴 **DÉSACTIVÉE**'}`, inline: false }
            ],
            timestamp: new Date()
          };
          await sendAuditLog(guild, auditEmbed);
          return;
        }

        if (customId === 'btn_antiraid_antibot') {
          if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
            return interaction.reply({ content: '❌ Seuls les Administrateurs peuvent utiliser ce bouton.', flags: MessageFlags.Ephemeral });
          }
          await interaction.deferUpdate();
          const cfg = await db.getAntiRaidConfig(guild.id);
          const newVal = cfg.antiBot === 1 ? 0 : 1;
          await db.updateAntiRaidConfig(guild.id, { antiBot: newVal });

          const updatedCfg = await db.getAntiRaidConfig(guild.id);
          const lastBackup = await db.getLastBackup(guild.id);
          await interaction.message.edit(antiRaidDashboardEmbed(updatedCfg, lastBackup));

          const auditEmbed = {
            title: '⚙️ LOG AUDIT SÉCURITÉ : PARAMÈTRE ANTI-BOT MODIFIÉ',
            color: newVal ? '#43A047' : '#FB8C00',
            fields: [
              { name: '👮 Administrateur', value: `<@${user.id}> (\`${user.tag}\`)`, inline: true },
              { name: '📌 Option', value: `**Protection Anti-Bot** : ${newVal ? '🟢 **ACTIVÉE**' : '🔴 **DÉSACTIVÉE**'}`, inline: false }
            ],
            timestamp: new Date()
          };
          await sendAuditLog(guild, auditEmbed);
          return;
        }


        if (customId === 'btn_antiraid_config_prompt') {
          if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
            return interaction.reply({ content: '❌ Seuls les Administrateurs peuvent utiliser ce bouton.', flags: MessageFlags.Ephemeral });
          }
          const cfg = await db.getAntiRaidConfig(guild.id);
          const modal = antiRaidConfigModal(cfg);
          return await interaction.showModal(modal);
        }

        if (customId === 'btn_antiraid_create_backup') {
          if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
            return interaction.reply({ content: '❌ Seuls les Administrateurs peuvent créer des sauvegardes.', flags: MessageFlags.Ephemeral });
          }
          await interaction.deferReply({ flags: MessageFlags.Ephemeral });
          const res = await createFullBackup(guild, user);
          if (res.success) {
            const updatedCfg = await db.getAntiRaidConfig(guild.id);
            const lastBackup = await db.getLastBackup(guild.id);
            await interaction.message.edit(antiRaidDashboardEmbed(updatedCfg, lastBackup));
            await interaction.editReply({ content: `✅ **Sauvegarde enregistrée avec succès :** \`${res.backupName}\`` });
          } else {
            await interaction.editReply({ content: `❌ **Erreur sauvegarde :** ${res.error}` });
          }
          return;
        }

        if (customId === 'btn_antiraid_refresh') {
          await interaction.deferUpdate();
          const updatedCfg = await db.getAntiRaidConfig(guild.id);
          const lastBackup = await db.getLastBackup(guild.id);
          await interaction.message.edit(antiRaidDashboardEmbed(updatedCfg, lastBackup));
          return;
        }

        // --- Sanctions Dashboard Buttons ---

        if (customId === 'btn_sanction_add_prompt') {
          const modal = sanctionInputModal();
          return await interaction.showModal(modal);
        }

        if (customId === 'btn_sanction_lookup_prompt') {
          const modal = sanctionLookupModal();
          return await interaction.showModal(modal);
        }

        if (customId === 'btn_sanction_remove_prompt') {
          const modal = sanctionRemoveModal();
          return await interaction.showModal(modal);
        }

        // --- Staff Sanctions Buttons ---
        if (customId === 'btn_staff_sanction_add_prompt') {
          const modal = staffSanctionInputModal();
          return await interaction.showModal(modal);
        }

        if (customId === 'btn_staff_sanction_lookup_prompt') {
          const modal = staffSanctionLookupModal();
          return await interaction.showModal(modal);
        }

        if (customId === 'btn_staff_sanction_remove_prompt') {
          const modal = staffSanctionRemoveModal();
          return await interaction.showModal(modal);
        }

        // --- Staff Service Shift Buttons ---
        if (customId === 'btn_staff_service_on') {
          await interaction.deferReply({ flags: MessageFlags.Ephemeral });

          const existingSession = await db.getActiveStaffService(guild.id, user.id);
          if (existingSession) {
            return interaction.editReply({
              content: `⚠️ **Vous êtes déjà en service staff !** (Statut actuel: \`${existingSession.status}\`)`
            });
          }

          const shift = await db.startStaffService(guild.id, user.id, user.tag || user.username);

          const role = await getOrCreateStaffDutyRole(guild);
          if (role) {
            const member = await guild.members.fetch(user.id).catch(() => null);
            if (member) await member.roles.add(role).catch(() => {});
          }

          const logChannel = await getStaffServiceLogChannel(guild);
          if (logChannel) {
            const logEmbed = staffServiceLogEmbed({
              user,
              action: '🟢 Prise de Service Staff',
              statusColor: config.colors.success
            });
            logChannel.send({ embeds: [logEmbed] }).catch(() => {});
          }

          return interaction.editReply({
            content: `🟢 **Prise de service staff enregistrée !** Bon courage pour votre temps de modération.`
          });
        }

        if (customId === 'btn_staff_service_break') {
          await interaction.deferReply({ flags: MessageFlags.Ephemeral });

          const activeSession = await db.getActiveStaffService(guild.id, user.id);
          if (!activeSession) {
            return interaction.editReply({
              content: `⚠️ Vous n'êtes actuellement pas en service staff.`
            });
          }

          let logAction = '';
          let newStatus = '';
          if (activeSession.status === 'active') {
            await db.pauseStaffService(guild.id, user.id);
            logAction = '☕ Passage en Pause Staff';
            newStatus = '☕ **Vous êtes désormais en PAUSE staff.**';
          } else {
            await db.resumeStaffService(guild.id, user.id);
            logAction = '▶️ Reprise de Service Staff';
            newStatus = '🟢 **Reprise de service staff effectuée.**';
          }

          const logChannel = await getStaffServiceLogChannel(guild);
          if (logChannel) {
            const logEmbed = staffServiceLogEmbed({
              user,
              action: logAction,
              statusColor: config.colors.warning
            });
            logChannel.send({ embeds: [logEmbed] }).catch(() => {});
          }

          return interaction.editReply({ content: newStatus });
        }

        if (customId === 'btn_staff_service_off') {
          await interaction.deferReply({ flags: MessageFlags.Ephemeral });

          const activeSession = await db.getActiveStaffService(guild.id, user.id);
          if (!activeSession) {
            return interaction.editReply({
              content: `⚠️ Vous n'avez aucun service staff en cours à clôturer.`
            });
          }

          const endedShift = await db.stopStaffService(guild.id, user.id);

          const role = await getOrCreateStaffDutyRole(guild);
          if (role) {
            const member = await guild.members.fetch(user.id).catch(() => null);
            if (member) await member.roles.remove(role).catch(() => {});
          }

          const stats = await db.getStaffServiceStats(guild.id, user.id);

          const logChannel = await getStaffServiceLogChannel(guild);
          if (logChannel) {
            const logEmbed = staffServiceLogEmbed({
              user,
              action: '🔴 Fin de Service Staff',
              durationMs: endedShift.totalDuration,
              totalTimeMs: stats.totalTimeMs,
              statusColor: config.colors.danger
            });
            logChannel.send({ embeds: [logEmbed] }).catch(() => {});
          }

          await refreshStaffLeaderboardMessage(guild);

          return interaction.editReply({
            content: `🔴 **Fin de service staff enregistrée !**\n\n` +
              `⏱️ **Durée de cette garde** : \`${formatMsDuration(endedShift.totalDuration)}\`\n` +
              `📊 **Temps total cumulé** : \`${formatMsDuration(stats.totalTimeMs)}\` (${stats.totalShifts} garde(s))\n` +
              `🏆 *Le classement dans #classement-staff a été mis à jour.*`
          });
        }

        if (customId === 'btn_staff_service_stats') {
          await interaction.deferReply({ flags: MessageFlags.Ephemeral });

          const stats = await db.getStaffServiceStats(guild.id, user.id);
          const activeSession = await db.getActiveStaffService(guild.id, user.id);

          let currentStatus = '🔴 Hors service';
          if (activeSession) {
            currentStatus = activeSession.status === 'active' ? '🟢 En service' : '☕ En pause';
          }

          return interaction.editReply({
            content: `📊 **Statistiques de Modération Staff — ${user.username}**\n\n` +
              `📌 **Statut actuel** : ${currentStatus}\n` +
              `⏱️ **Temps Total de Garde** : \`${formatMsDuration(stats.totalTimeMs)}\`\n` +
              `🔢 **Nombre de Gardes Effectuées** : \`${stats.totalShifts}\``
          });
        }

        // --- Staff Absence Buttons ---
        if (customId === 'btn_staff_absence_add_prompt') {
          const modal = staffAbsenceInputModal();
          return await interaction.showModal(modal);
        }

        if (customId === 'btn_staff_absence_return_prompt') {
          await interaction.deferReply({ flags: MessageFlags.Ephemeral });

          const activeAbsence = await db.getActiveStaffAbsence(guild.id, user.id);
          if (!activeAbsence) {
            return interaction.editReply({
              content: `ℹ️ **Vous n'avez aucune déclaration d'absence active à clôturer.**`
            });
          }

          const endedAbsence = await db.endStaffAbsence(guild.id, user.id);

          const role = await getOrCreateStaffAbsenceRole(guild);
          if (role) {
            const member = await guild.members.fetch(user.id).catch(() => null);
            if (member) await member.roles.remove(role).catch(() => {});
          }

          const logChannel = await getStaffAbsenceLogChannel(guild);
          if (logChannel) {
            const logEmbed = staffAbsenceLogEmbed({
              user,
              actionType: 'return'
            });
            logChannel.send({ embeds: [logEmbed] }).catch(() => {});
          }

          await refreshStaffAbsenceListMessage(guild);

          return interaction.editReply({
            content: `🏠 **Bon retour parmi nous, <@${user.id}> !**\n\nVotre période d'absence a été déclarée terminée, votre rôle **Staff en Absence** a été retiré et la liste a été mise à jour.`
          });
        }

        if (customId === 'btn_staff_absence_list_prompt') {
          await interaction.deferReply({ flags: MessageFlags.Ephemeral });
          const activeAbsences = await db.getAllActiveStaffAbsences(guild.id);
          const embed = staffAbsenceListEmbed(activeAbsences);

          return interaction.editReply({ embeds: [embed] });
        }

        // --- Staff Rank Buttons ---
        if (customId === 'btn_staff_rank_up_prompt') {
          const modal = staffRankModal('promotion');
          return await interaction.showModal(modal);
        }

        if (customId === 'btn_staff_rank_down_prompt') {
          const modal = staffRankModal('demotion');
          return await interaction.showModal(modal);
        }

        if (customId === 'btn_staff_rank_history_prompt') {
          const modal = staffRankLookupModal();
          return await interaction.showModal(modal);
        }

        // --- Staff Review Buttons ---
        if (customId === 'btn_staff_review_prompt') {
          const modal = staffReviewInputModal();
          return await interaction.showModal(modal);
        }

        if (customId === 'btn_staff_review_remove_prompt') {
          const member = await guild.members.fetch(user.id).catch(() => interaction.member);
          if (!hasPingFondationRole(member)) {
            return interaction.reply({
              content: '❌ **Permission refusée !** Seuls les membres possédant le rôle **Ping Fondation** sont autorisés à supprimer un avis staff.',
              flags: MessageFlags.Ephemeral
            });
          }
          const modal = staffReviewRemoveModal();
          return await interaction.showModal(modal);
        }

        // --- Suggestion System Buttons ---
        if (customId === 'btn_suggestion_prompt') {
          const modal = suggestionInputModal();
          return await interaction.showModal(modal);
        }

        if (customId.startsWith('btn_suggest_up_') || customId.startsWith('btn_suggest_down_')) {
          await interaction.deferReply({ flags: MessageFlags.Ephemeral });
          const isUp = customId.startsWith('btn_suggest_up_');
          const suggestionId = parseInt(customId.replace(isUp ? 'btn_suggest_up_' : 'btn_suggest_down_', ''), 10);

          const updatedSuggestion = await db.voteSuggestionRecord(suggestionId, user.id, isUp ? 'up' : 'down');
          if (!updatedSuggestion) {
            return interaction.editReply({ content: '❌ Suggestion introuvable.' });
          }

          const authorUser = await interaction.client.users.fetch(updatedSuggestion.authorId).catch(() => null);
          const processedUser = updatedSuggestion.processedBy ? await interaction.client.users.fetch(updatedSuggestion.processedBy).catch(() => null) : null;
          const cardPayload = suggestionCardEmbed({ suggestion: updatedSuggestion, authorUser, processedUser });
          await interaction.message.edit(cardPayload).catch(() => {});

          return interaction.editReply({
            content: `✅ **Vote pris en compte !** Vous avez voté ${isUp ? '👍 **Pour**' : '👎 **Contre**'} la suggestion #${suggestionId}.`
          });
        }

        if (customId.startsWith('btn_suggest_manage_')) {
          const member = await guild.members.fetch(user.id).catch(() => interaction.member);
          if (!member.permissions.has(PermissionFlagsBits.ManageMessages)) {
            return interaction.reply({
              content: '❌ **Permission refusée !** Seuls les membres de l\'équipe Staff peuvent gérer les suggestions.',
              flags: MessageFlags.Ephemeral
            });
          }
          const suggestionId = parseInt(customId.replace('btn_suggest_manage_', ''), 10);
          const modal = suggestionStaffManageModal(suggestionId);
          return await interaction.showModal(modal);
        }

        // --- Giveaway System Buttons ---
        if (customId === 'btn_giveaway_create_prompt') {
          const member = await guild.members.fetch(user.id).catch(() => interaction.member);
          if (!member.permissions.has(PermissionFlagsBits.ManageMessages)) {
            return interaction.reply({
              content: '❌ **Permission refusée !** Seuls les membres de l\'équipe Staff / Événementielle peuvent créer un giveaway.',
              flags: MessageFlags.Ephemeral
            });
          }
          const modal = giveawayCreateModal();
          return await interaction.showModal(modal);
        }

        if (customId.startsWith('btn_giveaway_join_')) {
          await interaction.deferReply({ flags: MessageFlags.Ephemeral });
          const msgId = customId.replace('btn_giveaway_join_', '');

          const result = await db.toggleGiveawayParticipantRecord(msgId, user.id);
          if (!result) {
            return interaction.editReply({ content: '❌ Concours introuvable ou déjà terminé.' });
          }

          const hostUser = await interaction.client.users.fetch(result.giveaway.hostId).catch(() => null);
          const cardPayload = giveawayCardEmbed({
            giveaway: result.giveaway,
            hostUser,
            participantsCount: result.count
          });

          await interaction.message.edit(cardPayload).catch(() => {});

          if (result.added) {
            return interaction.editReply({
              content: `🎉 **Votre participation au giveaway "${result.giveaway.prize}" a été enregistrée !** Bonne chance 🍀`
            });
          } else {
            return interaction.editReply({
              content: `🗑️ **Votre participation au giveaway "${result.giveaway.prize}" a été retirée.**`
            });
          }
          return;
        }

        // --- Staff Recruitment Buttons (20 Questions - Web Portal Anti-Cheat & Mouse Detector) ---
        if (customId === 'btn_staff_quiz_start') {
          if (quizCooldowns.has(user.id) && Date.now() < quizCooldowns.get(user.id)) {
            const timeLeftMs = quizCooldowns.get(user.id) - Date.now();
            const hoursLeft = Math.ceil(timeLeftMs / (1000 * 60 * 60));
            return interaction.reply({
              content: `❌ **Session bloquée (Anti-Cheat) !** Vous devez attendre **${hoursLeft} heure(s)** avant de pouvoir repasser le test de recrutement staff.`,
              flags: MessageFlags.Ephemeral
            });
          }

          const cleanName = `test-staff-${user.username.toLowerCase().replace(/[^a-z0-9]/g, '')}`;
          let existingCh = guild.channels.cache.find(c => c.name === cleanName);
          if (existingCh) {
            return interaction.reply({
              content: `⚠️ Vous avez déjà un salon de test actif : ${existingCh} !`,
              flags: MessageFlags.Ephemeral
            });
          }

          await interaction.deferReply({ flags: MessageFlags.Ephemeral });

          const supportCat = await getSupportCategory(guild);
          const quizChannel = await guild.channels.create({
            name: cleanName,
            type: ChannelType.GuildText,
            parent: supportCat ? supportCat.id : undefined,
            permissionOverwrites: [
              { id: guild.id, deny: [PermissionFlagsBits.ViewChannel] },
              { id: user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory] },
              { id: guild.members.me.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.EmbedLinks, PermissionFlagsBits.ManageChannels] }
            ]
          });

          const quizSession = createQuizSession({ client: interaction.client, guild, user, channel: quizChannel });
          const quizUrl = `http://localhost:${process.env.PORT || 3000}/quiz?token=${quizSession.token}`;

          const introEmbed = new EmbedBuilder()
            .setTitle('🛡️ PORTAIL WEB CHRONOMÉTRÉ ANTI-TRICHE (20 QUESTIONS) • HAMBURG RP')
            .setDescription(
              `Bienvenue <@${user.id}> dans votre salon privé de recrutement !\n\n` +
              `🚨 **CONSIGNES & RÈGLES STRICTES DU DÉTECTEUR ANTI-TRICHE :**\n` +
              `• L'examen comporte **20 questions** sur notre portail Web sécurisé.\n` +
              `• **DÉTECTEUR DE SOURIS ACTIF :** Si vous sortez la souris de la zone d'examen ou changez d'onglet (Google/ChatGPT) :\n` +
              `  - ⚠️ 1ère fois : *Avertissement 1/3*\n` +
              `  - ⚠️ 2ème fois : *Avertissement 2/3*\n` +
              `  - 💥 **3ème fois : SUPPRESSION IMMÉDIATE DE CE SALON TICKET !**\n` +
              `• Une fois l'examen validé, **l'intégralité de vos 20 réponses sera affichée directement dans ce salon ticket**.\n\n` +
              `👇 Cliquez sur le bouton ci-dessous pour ouvrir votre session Web d'examen :`
            )
            .setColor('#1E88E5')
            .setFooter({ text: 'Session Web Anti-Triche • Hamburg RP' })
            .setTimestamp();

          const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
              .setLabel('🌐 Lancer l\'Examen Web Anti-Triche (20 Questions)')
              .setURL(quizUrl)
              .setStyle(ButtonStyle.Link)
          );

          await quizChannel.send({ content: `<@${user.id}>`, embeds: [introEmbed], components: [row] });

          return interaction.editReply({
            content: `✅ **Votre salon de test privé a été créé :** ${quizChannel} !\nRendez-vous dans ce salon pour ouvrir votre examen Web Anti-Triche.`
          });
        }


        if (customId === 'btn_staff_quiz_step1_trigger') {
          if (activeQuizTimers.has(user.id)) {
            clearTimeout(activeQuizTimers.get(user.id));
          }
          return await interaction.showModal(staffQuizStep1Modal());
        }

        if (customId === 'btn_staff_quiz_step2') {
          if (activeQuizTimers.has(user.id)) {
            clearTimeout(activeQuizTimers.get(user.id));
          }
          return await interaction.showModal(staffQuizStep2Modal());
        }

        if (customId === 'btn_staff_quiz_step3') {
          if (activeQuizTimers.has(user.id)) {
            clearTimeout(activeQuizTimers.get(user.id));
          }
          return await interaction.showModal(staffQuizStep3Modal());
        }

        if (customId === 'btn_staff_quiz_step4') {
          if (activeQuizTimers.has(user.id)) {
            clearTimeout(activeQuizTimers.get(user.id));
          }
          return await interaction.showModal(staffQuizStep4Modal());
        }



        if (customId.startsWith('btn_staff_quiz_')) {
          if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
            return interaction.reply({ content: '❌ Seuls les Administrateurs peuvent évaluer les candidatures.', flags: MessageFlags.Ephemeral });
          }

          const parts = customId.split('_'); // btn_staff_quiz_accept_12
          const action = parts[3]; // accept, reject, interview
          const testId = parseInt(parts[4], 10);

          const testRecord = await db.getStaffTestRecord(testId);
          if (!testRecord) {
            return interaction.reply({ content: '❌ Candidature introuvable dans la base de données.', flags: MessageFlags.Ephemeral });
          }

          let newStatus = 'PENDING';
          let statusText = '';
          let dmMsg = '';

          if (action === 'accept') {
            newStatus = 'ACCEPTED';
            statusText = '🟢 **Candidature Acceptée**';
            dmMsg = `🎉 **Félicitations !** Votre candidature pour intégrer l'équipe Staff de **Emergency Hamburg RP** a été **ACCEPTÉE** !\nUn administrateur va vous contacter prochainement pour votre intégration.`;
          } else if (action === 'reject') {
            newStatus = 'REJECTED';
            statusText = '🔴 **Candidature Refusée**';
            dmMsg = `❌ **Désolé.** Après étude de votre dossier, votre candidature pour l'équipe Staff de **Emergency Hamburg RP** n'a pas été retenue.`;
          } else if (action === 'interview') {
            newStatus = 'INTERVIEW';
            statusText = '🎤 **Convoqué(e) en Oral**';
            dmMsg = `🎤 **Convocation Oral !** Vous êtes convoqué(e) en entretien oral pour finaliser votre recrutement Staff sur **Emergency Hamburg RP**.\nVeuillez vous présenter dans un salon d'attente Vocal Staff.`;
          }

          await db.updateStaffTestStatus(testId, newStatus, user.id, `Action par ${user.tag}`);
          const updatedRecord = await db.getStaffTestRecord(testId);

          const candidateUser = await interaction.client.users.fetch(testRecord.userId).catch(() => null);
          const cardData = staffCandidateCardEmbed({ testData: updatedRecord, candidateUser, reviewerUser: user });

          await interaction.message.edit(cardData);

          // Send DM to candidate
          if (candidateUser) {
            await candidateUser.send({ content: dmMsg }).catch(() => {});
          }

          // Animer et notifier le salon ticket du candidat
          const decisionEmbed = new EmbedBuilder()
            .setTitle(`📢 DÉCISION DE LA DIRECTION • CANDIDATURE #${testId}`)
            .setDescription(
              `👮 **Évalué par** : <@${user.id}>\n` +
              `👤 **Candidat** : <@${testRecord.userId}>\n` +
              `📌 **Décision** : ${statusText}\n\n` +
              `${dmMsg}`
            )
            .setColor(newStatus === 'ACCEPTED' ? '#10B981' : (newStatus === 'REJECTED' ? '#EF4444' : '#3B82F6'))
            .setTimestamp();

          await interaction.channel.send({ content: `<@${testRecord.userId}>`, embeds: [decisionEmbed] }).catch(() => {});


          // Audit log
          const auditEmbed = {
            title: `📋 LOG AUDIT : CANDIDATURE STAFF #${testId} EVALUÉE`,
            color: newStatus === 'ACCEPTED' ? '#43A047' : (newStatus === 'REJECTED' ? '#E53935' : '#1E88E5'),
            fields: [
              { name: '👮 Administrateur', value: `<@${user.id}> (\`${user.tag}\`)`, inline: true },
              { name: '👤 Candidat', value: candidateUser ? `<@${candidateUser.id}>` : `\`${testRecord.userId}\``, inline: true },
              { name: '📌 Statut', value: statusText, inline: true }
            ],
            timestamp: new Date()
          };
          await sendAuditLog(guild, auditEmbed);

          return interaction.reply({ content: `✅ Statut de la candidature #${testId} mis à jour : ${statusText}`, flags: MessageFlags.Ephemeral });
        }

        // --- Partnership Buttons ---
        if (customId === 'btn_partner_start') {
          return await interaction.showModal(partnershipInputModal());
        }

        if (customId.startsWith('btn_partner_')) {
          if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
            return interaction.reply({ content: '❌ Seuls les Administrateurs peuvent évaluer les partenariats.', flags: MessageFlags.Ephemeral });
          }

          const parts = customId.split('_'); // btn_partner_accept_5
          const action = parts[2]; // accept, reject
          const partnerId = parseInt(parts[3], 10);

          const partnerRecord = await db.getPartnershipRecord(partnerId);
          if (!partnerRecord) {
            return interaction.reply({ content: '❌ Demande de partenariat introuvable.', flags: MessageFlags.Ephemeral });
          }

          let newStatus = action === 'accept' ? 'ACCEPTED' : 'REJECTED';
          let statusText = action === 'accept' ? '🟢 **Partenariat Accepté**' : '🔴 **Partenariat Refusé**';
          let dmMsg = action === 'accept'
            ? `🤝 **Partenariat Accepté !** Votre demande de partenariat pour **${partnerRecord.serverName}** a été acceptée par l'équipe de **Emergency Hamburg RP** !`
            : `❌ **Partenariat Refusé.** Votre demande de partenariat pour **${partnerRecord.serverName}** n'a pas été retenue.`;

          await db.updatePartnershipStatus(partnerId, newStatus, user.id, `Action par ${user.tag}`);
          const updatedRecord = await db.getPartnershipRecord(partnerId);

          const applicantUser = await interaction.client.users.fetch(partnerRecord.userId).catch(() => null);
          const cardData = partnershipCardEmbed({ partnerData: updatedRecord, applicantUser, reviewerUser: user });

          await interaction.message.edit(cardData);

          if (applicantUser) {
            await applicantUser.send({ content: dmMsg }).catch(() => {});
          }

          const auditEmbed = {
            title: `🤝 LOG AUDIT : DEMANDE PARTENARIAT #${partnerId} EVALUÉE`,
            color: newStatus === 'ACCEPTED' ? '#43A047' : '#E53935',
            fields: [
              { name: '👮 Administrateur', value: `<@${user.id}> (\`${user.tag}\`)`, inline: true },
              { name: '🌐 Serveur', value: `\`${partnerRecord.serverName}\``, inline: true },
              { name: '📌 Statut', value: statusText, inline: true }
            ],
            timestamp: new Date()
          };
          await sendAuditLog(guild, auditEmbed);

          return interaction.reply({ content: `✅ Statut du partenariat #${partnerId} mis à jour : ${statusText}`, flags: MessageFlags.Ephemeral });
        }

        // --- Organization Buttons (Gang / Business) ---
        if (customId === 'btn_org_gang_start') {
          return await interaction.showModal(gangCreateModal());
        }

        if (customId === 'btn_org_business_start') {
          return await interaction.showModal(businessCreateModal());
        }

        if (customId.startsWith('btn_org_')) {
          if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
            return interaction.reply({ content: '❌ Seuls les Administrateurs peuvent évaluer les dossiers d\'organisations.', flags: MessageFlags.Ephemeral });
          }

          const parts = customId.split('_'); // btn_org_accept_8
          const action = parts[2]; // accept, reject, interview
          const orgId = parseInt(parts[3], 10);

          const orgRecord = await db.getOrganizationRecord(orgId);
          if (!orgRecord) {
            return interaction.reply({ content: '❌ Dossier d\'organisation introuvable.', flags: MessageFlags.Ephemeral });
          }

          let newStatus = 'PENDING';
          let statusText = '';
          let dmMsg = '';

          if (action === 'accept') {
            newStatus = 'ACCEPTED';
            statusText = '🟢 **Dossier Approuvé & Officiel**';
            dmMsg = `🎉 **Félicitations !** Votre dossier d'organisation pour **${orgRecord.orgName}** a été **APPROUVÉ** par l'Administration de **Emergency Hamburg RP** !\nVos accès et rôles vous seront attribués sous peu.`;
          } else if (action === 'reject') {
            newStatus = 'REJECTED';
            statusText = '🔴 **Dossier Refusé**';
            dmMsg = `❌ **Dossier Refusé.** Votre demande de création pour **${orgRecord.orgName}** n'a pas été retenue par l'équipe d'Administration.`;
          } else if (action === 'interview') {
            newStatus = 'INTERVIEW';
            statusText = '💬 **Convoqué(e) en Réunion RP Staff**';
            dmMsg = `💬 **Convocation Réunion RP !** Votre dossier d'organisation pour **${orgRecord.orgName}** nécessite un entretien oral de mise au point.\nVeuillez ouvrir un ticket ou rejoindre un salon d'attente Staff.`;
          }

          await db.updateOrganizationStatus(orgId, newStatus, user.id, `Action par ${user.tag}`);
          const updatedRecord = await db.getOrganizationRecord(orgId);

          const applicantUser = await interaction.client.users.fetch(orgRecord.userId).catch(() => null);
          const cardData = organizationCardEmbed({ orgData: updatedRecord, applicantUser, reviewerUser: user });

          await interaction.message.edit(cardData);

          if (applicantUser) {
            await applicantUser.send({ content: dmMsg }).catch(() => {});
          }

          const auditEmbed = {
            title: `🏢 LOG AUDIT : DOSSIER ORGANISATION #${orgId} EVALUÉ`,
            color: newStatus === 'ACCEPTED' ? '#43A047' : (newStatus === 'REJECTED' ? '#E53935' : '#1E88E5'),
            fields: [
              { name: '👮 Administrateur', value: `<@${user.id}> (\`${user.tag}\`)`, inline: true },
              { name: '🏷️ Organisation', value: `\`${orgRecord.orgName}\` (${orgRecord.orgType})`, inline: true },
              { name: '📌 Statut', value: statusText, inline: true }
            ],
            timestamp: new Date()
          };
          await sendAuditLog(guild, auditEmbed);

          return interaction.reply({ content: `✅ Statut du dossier #${orgId} (${orgRecord.orgName}) mis à jour : ${statusText}`, flags: MessageFlags.Ephemeral });
        }


        if (customId.startsWith('btn_giveaway_participants_')) {
          await interaction.deferReply({ flags: MessageFlags.Ephemeral });
          const msgId = customId.replace('btn_giveaway_participants_', '');
          const giveaway = await db.getGiveawayByMessageRecord(msgId);
          if (!giveaway) {
            return interaction.editReply({ content: '❌ Concours introuvable.' });
          }

          let participants = [];
          try { participants = JSON.parse(giveaway.participants || '[]'); } catch (e) {}

          if (participants.length === 0) {
            return interaction.editReply({ content: '👥 **0 participant** inscrit pour le moment.' });
          }

          const list = participants.slice(0, 50).map(id => `<@${id}>`).join(', ');
          return interaction.editReply({
            content: `👥 **${participants.length} Participant(s) inscrit(s) :**\n${list}` + (participants.length > 50 ? `\n*... et ${participants.length - 50} autres.*` : '')
          });
        }

        // --- Verification System Buttons ---
        if (customId === 'verify_start') {
          const modal = verificationRobloxModal();
          return await interaction.showModal(modal);
        }

        if (customId.startsWith('verify_accept_rules_')) {
          const robloxId = customId.replace('verify_accept_rules_', '');
          await interaction.deferReply({ flags: MessageFlags.Ephemeral });

          const member = await guild.members.fetch(user.id);
          const robloxData = await fetchRobloxUser(robloxId);

          if (!robloxData) {
            return interaction.editReply({
              content: '❌ Erreur lors de la récupération de votre compte Roblox. Veuillez recommencer.'
            });
          }

          // Double account check
          const existingDiscordUser = await db.isRobloxLinkedToAnotherDiscord(robloxData.id, user.id);
          if (existingDiscordUser) {
            return interaction.editReply({
              content: `🚫 **Erreur Sécurité Anti-Double Compte !** Ce compte Roblox est déjà lié à un autre membre Discord (<@${existingDiscordUser}>).`
            });
          }

          // Save Verification in DB
          await db.saveVerification(user.id, guild.id, robloxData.id, robloxData.name);

          // Manage Roles
          const welcomeConfig = await db.getWelcomeConfig(guild.id);

          // 1. Remove Unverified Role
          const unverifiedRoleId = welcomeConfig?.unverifiedRoleId || config.unverifiedRoleId;
          let unverifiedRole = unverifiedRoleId ? guild.roles.cache.get(unverifiedRoleId) : null;
          if (!unverifiedRole) {
            unverifiedRole = guild.roles.cache.find(r =>
              r.name.toLowerCase().includes('unverified') ||
              r.name.toLowerCase().includes('non-vérifié') ||
              r.name.toLowerCase().includes('non verifie')
            );
          }

          if (unverifiedRole && member.roles.cache.has(unverifiedRole.id)) {
            await member.roles.remove(unverifiedRole).catch(err => {
              console.error('⚠️ Impossible de retirer le rôle unverified:', err.message);
            });
          }

          // 2. Add Verified / Member Role
          const verifiedRoleId = welcomeConfig?.verifiedRoleId || config.verifiedRoleId;
          let verifiedRole = verifiedRoleId ? guild.roles.cache.get(verifiedRoleId) : null;
          if (!verifiedRole) {
            verifiedRole = guild.roles.cache.find(r =>
              r.name.toLowerCase().includes('membre') ||
              r.name.toLowerCase().includes('citoyen') ||
              r.name.toLowerCase().includes('verified') ||
              r.name.toLowerCase().includes('vérifié')
            );
          }

          if (verifiedRole) {
            await member.roles.add(verifiedRole).catch(err => {
              console.error('⚠️ Impossible d\'ajouter le rôle membre:', err.message);
            });
          }

          // Set Nickname (Optional / Best Effort)
          try {
            await member.setNickname(`[RP] ${robloxData.displayName}`).catch(() => {});
          } catch (e) {}

          // 3. Log to Security Channel
          const securityChannelId = welcomeConfig?.securityLogChannelId || config.channels?.securityLogs || config.channels?.moderationLogs;
          if (securityChannelId) {
            const securityChannel = guild.channels.cache.get(securityChannelId);
            if (securityChannel) {
              const logEmbed = securityLogEmbed({
                member,
                robloxData,
                status: '✅ Membre Vérifié avec Succès',
                details: `Compte Roblox: [${robloxData.name}](https://www.roblox.com/users/${robloxData.id}/profile) (ID: \`${robloxData.id}\`)\n` +
                         `Règlement accepté & Rôle Membre attribué.`,
                color: config.colors.success
              });
              securityChannel.send({ embeds: [logEmbed] }).catch(() => {});
            }
          }

          // 4. Post Welcome Message in Welcome Channel
          const welcomeChannelId = welcomeConfig?.welcomeChannelId || config.channels?.welcome;
          if (welcomeChannelId) {
            const welcomeChannel = guild.channels.cache.get(welcomeChannelId);
            if (welcomeChannel) {
              const welcome = welcomeEmbed(member, guild.memberCount, robloxData);
              welcomeChannel.send({ content: `🎉 Bienvenue à ${member} !`, embeds: [welcome] }).catch(() => {});
            }
          }

          return interaction.editReply({
            content: `🎉 **Vérification réussie !**\n\nVotre compte Roblox **${robloxData.displayName}** (@${robloxData.name}) a été lié avec succès.\nVous avez reçu le rôle **${verifiedRole ? verifiedRole.name : 'Membre'}** et vous avez désormais accès à l'ensemble du serveur !`
          });
        }

        // --- Ticket Action Buttons Inside Ticket Channel ---
        if (customId === 'ticket_claim') {
          await db.claimTicketRecord(channel.id, user.id);

          const embed = createEmbed({
            title: '✋ TICKET PRIS EN CHARGE',
            description: `Le membre de l'équipe staff <@${user.id}> a pris en charge ce ticket.\n\n🤖 *L'assistant IA est désormais en pause. Pour le faire intervenir à nouveau, mentionnez-le (@bot).*`,
            color: config.colors.success
          });

          // Log prise en charge à log-tickets
          const logChannel = await getLogTicketsChannel(guild);
          if (logChannel) {
            const ticketRecord = await db.getTicketByChannel(channel.id);
            const category = ticketRecord ? ticketRecord.category : 'Assistance';
            const openerId = ticketRecord ? ticketRecord.userId : 'Inconnu';

            const logEmbed = createEmbed({
              title: '✋ TICKET PRIS EN CHARGE',
              description:
                `👮 **Staff** : <@${user.id}> (\`${user.tag}\`)\n` +
                `👤 **Demandeur** : <@${openerId}>\n` +
                `📌 **Motif** : \`${category}\`\n` +
                `💬 **Salon** : <#${channel.id}> (\`#${channel.name}\`)`,
              color: config.colors.warning,
              footer: 'Système de Logs • Aubagne RP'
            });
            logChannel.send({ embeds: [logEmbed] }).catch(() => {});
          }

          return interaction.reply({ embeds: [embed] });
        }

        if (customId === 'ticket_ai_help') {
          const ticketRecord = await db.getTicketByChannel(channel.id);
          const category = ticketRecord ? ticketRecord.category : 'Autres';
          const openerId = ticketRecord ? ticketRecord.userId : user.id;
          const openerUser = await interaction.client.users.fetch(openerId).catch(() => user);

          const aiEmbed = generateAITicketGuidance({
            category,
            ticketOpener: openerUser,
            staffUser: user
          });

          return interaction.reply({ embeds: [aiEmbed] });
        }

        if (customId === 'ticket_transcript') {
          await interaction.deferReply();
          const messages = await channel.messages.fetch({ limit: 100 });
          let transcriptText = `==============================================\n`;
          transcriptText += `📋 TRANSCRIPT DU TICKET : ${channel.name}\n`;
          transcriptText += `📅 DATE : ${new Date().toLocaleString('fr-FR')}\n`;
          transcriptText += `==============================================\n\n`;

          messages.reverse().forEach(m => {
            transcriptText += `[${new Date(m.createdAt).toLocaleTimeString('fr-FR')}] ${m.author.tag}: ${m.content || '[Embed / Fichier]'}\n`;
          });

          const buffer = Buffer.from(transcriptText, 'utf-8');
          const attachment = new AttachmentBuilder(buffer, { name: `transcript-${channel.name}.txt` });

          return interaction.editReply({
            content: `📋 Voici le transcript complet des échanges du ticket :`,
            files: [attachment]
          });
        }

        if (customId === 'ticket_close') {
          await db.closeTicketRecord(channel.id);

          // Log fermeture à log-tickets avec le transcript joint
          const logChannel = await getLogTicketsChannel(guild);
          if (logChannel) {
            const ticketRecord = await db.getTicketByChannel(channel.id);
            const category = ticketRecord ? ticketRecord.category : 'Assistance';
            const openerId = ticketRecord ? ticketRecord.userId : 'Inconnu';
            const claimedBy = ticketRecord && ticketRecord.claimedBy ? `<@${ticketRecord.claimedBy}>` : 'Non pris en charge';

            let files = [];
            try {
              const messages = await channel.messages.fetch({ limit: 100 });
              if (messages && messages.size > 0) {
                let transcriptText = `==============================================\n`;
                transcriptText += `📋 TRANSCRIPT DU TICKET : ${channel.name}\n`;
                transcriptText += `📅 DATE DE CLÔTURE : ${new Date().toLocaleString('fr-FR')}\n`;
                transcriptText += `==============================================\n\n`;

                messages.reverse().forEach(m => {
                  transcriptText += `[${new Date(m.createdAt).toLocaleTimeString('fr-FR')}] ${m.author.tag}: ${m.content || '[Embed / Fichier]'}\n`;
                });

                const buffer = Buffer.from(transcriptText, 'utf-8');
                const attachment = new AttachmentBuilder(buffer, { name: `transcript-${channel.name}.txt` });
                files.push(attachment);
              }
            } catch (err) {
              console.error('Erreur lors de la génération du transcript de log:', err);
            }

            const logEmbed = createEmbed({
              title: '🔴 TICKET CLÔTURÉ ET SUPPRIMÉ',
              description:
                `🔒 **Clôturé par** : <@${user.id}> (\`${user.tag}\`)\n` +
                `👤 **Demandeur** : <@${openerId}>\n` +
                `✋ **Staff assigné** : ${claimedBy}\n` +
                `📌 **Motif** : \`${category}\`\n` +
                `💬 **Ancien salon** : \`#${channel.name}\``,
              color: config.colors.danger,
              footer: 'Système de Logs • Aubagne RP'
            });

            logChannel.send({ embeds: [logEmbed], files }).catch(() => {});
          }

          await interaction.reply({
            embeds: [createEmbed({
              title: '🔒 CLÔTURE DU TICKET',
              description: `Ce ticket a été clôturé par <@${user.id}>.\nCe salon sera supprimé automatiquement dans **5 secondes**...`,
              color: config.colors.danger
            })]
          });

          setTimeout(() => {
            channel.delete().catch(() => {});
          }, 5000);
          return;
        }

        // --- Service Buttons ---
        if (customId.startsWith('service_')) {
          const serviceType = customId.replace('service_', '');

          if (serviceType === 'stop') {
            const result = await db.stopService(user.id);
            if (!result.success) {
              return interaction.reply({ content: `⚠️ ${result.message}`, flags: MessageFlags.Ephemeral });
            }
            const hours = Math.floor(result.durationMinutes / 60);
            const mins = result.durationMinutes % 60;
            return interaction.reply({
              embeds: [createEmbed({
                title: '🔴 FIN DE SERVICE',
                description: `<@${user.id}> a clôturé son service.\n⏱️ **Durée totale** : **${hours}h ${mins}min**`,
                color: config.colors.danger
              })]
            });
          }

          const result = await db.startService(user.id, guild.id, serviceType);
          if (!result.success) {
            return interaction.reply({ content: `⚠️ ${result.message}`, flags: MessageFlags.Ephemeral });
          }
          const factionData = config.factions[serviceType] || { name: serviceType, emoji: '🚨' };
          return interaction.reply({
            embeds: [createEmbed({
              title: `${factionData.emoji} PRISE DE SERVICE CONFIRMÉE`,
              description: `<@${user.id}> est désormais en service chez **${factionData.name}** !\n⏰ Début : <t:${Math.floor(result.startTime / 1000)}:t>`,
              color: config.colors.success
            })]
          });
        }

        // --- Dashboard Buttons ---
        if (customId === 'btn_my_stats') {
          const data = await db.getServiceStats(user.id);
          const totalMins = data.stats ? data.stats.totalMinutes : 0;
          const shiftCount = data.stats ? data.stats.shiftCount : 0;
          const hours = Math.floor(totalMins / 60);
          const mins = totalMins % 60;

          return interaction.reply({
            embeds: [createEmbed({
              title: `📊 Vos Statistiques Personnelles • ${user.username}`,
              description: `⏱️ **Temps Total** : **${hours}h ${mins}min**\n🚓 **Services Effectués** : **${shiftCount}**`,
              color: config.colors.primary,
              thumbnail: user.displayAvatarURL({ dynamic: true })
            })],
            flags: MessageFlags.Ephemeral
          });
        }

        if (customId === 'btn_leaderboard') {
          const leaderboard = await db.getServiceLeaderboard(10);
          if (!leaderboard || leaderboard.length === 0) {
            return interaction.reply({ content: 'Aucune donnée de service enregistrée pour le moment.', flags: MessageFlags.Ephemeral });
          }
          let desc = '';
          for (let i = 0; i < leaderboard.length; i++) {
            const item = leaderboard[i];
            const u = await interaction.client.users.fetch(item.userId).catch(() => null);
            const userName = u ? u.tag : `Utilisateur (${item.userId})`;
            const hours = Math.floor(item.totalMinutes / 60);
            const mins = item.totalMinutes % 60;
            const medal = i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : '🔹';
            desc += `${medal} **#${i + 1}** ${userName} — **${hours}h ${mins}m**\n`;
          }
          return interaction.reply({
            embeds: [createEmbed({
              title: '🏆 CLASSEMENT DES MEILLEURS AGENTS',
              description: desc,
              color: config.colors.gold
            })]
          });
        }

        if (customId === 'btn_my_id') {
          const profile = await db.getProfile(user.id);
          const robloxStr = profile.robloxUsername
            ? `[${profile.robloxUsername} (ID: ${profile.robloxId})](https://www.roblox.com/users/${profile.robloxId}/profile)`
            : '❌ Non lié (`/link-roblox`)';

          return interaction.reply({
            embeds: [createEmbed({
              title: '🪪 VOTRE CARTE D\'IDENTITÉ RP',
              description: `👤 **Nom** : ${profile.lastName.toUpperCase()} ${profile.firstName}\n` +
                `🎂 **Âge** : ${profile.age} ans\n` +
                `💼 **Emploi** : ${profile.job}\n` +
                `🎮 **Compte Roblox** : ${robloxStr}\n` +
                `🏦 **Solde Banque** : ${profile.bankBalance} ${config.currencySymbol}`,
              color: config.colors.primary,
              thumbnail: user.displayAvatarURL({ dynamic: true })
            })],
            flags: MessageFlags.Ephemeral
          });
        }

        // --- Roblox Linking Prompt Button ---
        if (customId === 'btn_link_roblox_prompt') {
          const modal = new ModalBuilder().setCustomId('modal_link_roblox').setTitle('🎮 Liaison de Compte Roblox');
          const input = new TextInputBuilder()
            .setCustomId('roblox_username')
            .setLabel('Pseudo Roblox ou User ID')
            .setStyle(TextInputStyle.Short)
            .setPlaceholder('ex: Builderman ou 156')
            .setRequired(true);

          modal.addComponents(new ActionRowBuilder().addComponents(input));
          return await interaction.showModal(modal);
        }

        if (customId === 'btn_view_roblox') {
          const profile = await db.getProfile(user.id);
          if (!profile.robloxUsername) {
            return interaction.reply({
              content: '❌ Vous n\'avez pas encore lié votre compte Roblox ! Cliquez sur **🔗 Lier mon Compte Roblox**.',
              flags: MessageFlags.Ephemeral
            });
          }

          const embed = createEmbed({
            title: '🎮 COMPTE ROBLOX LIÉ (VOUS SEUL VOYEZ CE MESSAGE)',
            description: `Votre profil Discord est associé au compte Roblox :\n\n` +
              `👤 **Pseudo Roblox** : **[${profile.robloxUsername}](https://www.roblox.com/users/${profile.robloxId}/profile)**\n` +
              `🏷️ **Nom d'affichage** : ${profile.robloxDisplayName || profile.robloxUsername}\n` +
              `🆔 **Roblox User ID** : \`${profile.robloxId}\``,
            color: config.colors.roblox || '#E2231A',
            thumbnail: `https://www.roblox.com/headshot-thumbnail/image?userId=${profile.robloxId}&width=420&height=420&format=png`
          });

          return interaction.reply({
            embeds: [embed],
            flags: MessageFlags.Ephemeral
          });
        }

        if (customId === 'btn_unlink_roblox') {
          await db.unlinkRobloxAccount(user.id);
          return interaction.reply({
            embeds: [createEmbed({
              title: '✅ COMPTE ROBLOX DÉLIÉ',
              description: 'Votre compte Roblox a été retiré de votre profil Discord avec succès.',
              color: config.colors.success
            })],
            flags: MessageFlags.Ephemeral
          });
        }

        // Modals Triggers
        if (customId === 'btn_edit_id') {
          const modal = new ModalBuilder().setCustomId('modal_edit_id').setTitle('⚙️ Configurer votre Carte RP');
          const input1 = new TextInputBuilder().setCustomId('nom').setLabel('Nom de famille RP').setStyle(TextInputStyle.Short).setRequired(true);
          const input2 = new TextInputBuilder().setCustomId('prenom').setLabel('Prénom RP').setStyle(TextInputStyle.Short).setRequired(true);
          const input3 = new TextInputBuilder().setCustomId('age').setLabel('Âge RP').setStyle(TextInputStyle.Short).setRequired(true);
          const input4 = new TextInputBuilder().setCustomId('emploi').setLabel('Métier / Emploi').setStyle(TextInputStyle.Short).setRequired(true);

          modal.addComponents(
            new ActionRowBuilder().addComponents(input1),
            new ActionRowBuilder().addComponents(input2),
            new ActionRowBuilder().addComponents(input3),
            new ActionRowBuilder().addComponents(input4)
          );
          return await interaction.showModal(modal);
        }

        // 911 Call Modals
        if (customId.startsWith('btn_911_')) {
          const service = customId.replace('btn_911_', '');
          const modal = new ModalBuilder().setCustomId(`modal_911_${service}`).setTitle(`🚨 Appel Urgence 911 • ${service.toUpperCase()}`);
          const inputLoc = new TextInputBuilder().setCustomId('location').setLabel('Localisation précise').setStyle(TextInputStyle.Short).setRequired(true);
          const inputDesc = new TextInputBuilder().setCustomId('description').setLabel('Description de l\'urgence').setStyle(TextInputStyle.Paragraph).setRequired(true);

          modal.addComponents(
            new ActionRowBuilder().addComponents(inputLoc),
            new ActionRowBuilder().addComponents(inputDesc)
          );
          return await interaction.showModal(modal);
        }

        if (customId === 'btn_police_wanted') {
          const modal = new ModalBuilder().setCustomId('modal_wanted_add').setTitle('🚨 Placer en Avis de Recherche');
          const input1 = new TextInputBuilder().setCustomId('target').setLabel('Nom du criminel / suspect').setStyle(TextInputStyle.Short).setRequired(true);
          const input2 = new TextInputBuilder().setCustomId('reason').setLabel('Motif de l\'avis de recherche').setStyle(TextInputStyle.Paragraph).setRequired(true);
          const input3 = new TextInputBuilder().setCustomId('danger').setLabel('Danger Level (1 à 5 stars)').setStyle(TextInputStyle.Short).setValue('3').setRequired(true);
          const input4 = new TextInputBuilder().setCustomId('bounty').setLabel('Montant amende/prime (€)').setStyle(TextInputStyle.Short).setValue('1000').setRequired(false);

          modal.addComponents(
            new ActionRowBuilder().addComponents(input1),
            new ActionRowBuilder().addComponents(input2),
            new ActionRowBuilder().addComponents(input3),
            new ActionRowBuilder().addComponents(input4)
          );
          return await interaction.showModal(modal);
        }

        if (customId === 'btn_police_unwanted') {
          const modal = new ModalBuilder().setCustomId('modal_wanted_remove').setTitle('✅ Retirer un Avis de Recherche');
          const input1 = new TextInputBuilder().setCustomId('target').setLabel('Nom du suspect à retirer').setStyle(TextInputStyle.Short).setRequired(true);
          modal.addComponents(new ActionRowBuilder().addComponents(input1));
          return await interaction.showModal(modal);
        }

        if (customId === 'btn_police_wanted_list') {
          const list = await db.getWantedList();
          if (!list || list.length === 0) {
            return interaction.reply({ content: '✅ Aucun avis de recherche actif actuellement.' });
          }
          let desc = '';
          for (const w of list) {
            const stars = '⭐'.repeat(w.dangerLevel);
            desc += `🔴 **${w.targetName}** (${stars})\n📝 Motif: ${w.reason} | 💰 Prime: ${w.fineAmount} ${config.currencySymbol}\n\n`;
          }
          return interaction.reply({
            embeds: [createEmbed({ title: '🚨 LISTE DES RECHERCHÉS (WANTED LIST)', description: desc, color: config.colors.danger })]
          });
        }

        if (customId === 'btn_police_amende') {
          const modal = new ModalBuilder().setCustomId('modal_fine_add').setTitle('💵 Délivrer une Amende RP');
          const input1 = new TextInputBuilder().setCustomId('target').setLabel('Nom du citoyen').setStyle(TextInputStyle.Short).setRequired(true);
          const input2 = new TextInputBuilder().setCustomId('amount').setLabel('Montant de l\'amende (€)').setStyle(TextInputStyle.Short).setRequired(true);
          const input3 = new TextInputBuilder().setCustomId('reason').setLabel('Motif de l\'amende').setStyle(TextInputStyle.Paragraph).setRequired(true);

          modal.addComponents(
            new ActionRowBuilder().addComponents(input1),
            new ActionRowBuilder().addComponents(input2),
            new ActionRowBuilder().addComponents(input3)
          );
          return await interaction.showModal(modal);
        }

        if (customId === 'btn_police_casier') {
          const modal = new ModalBuilder().setCustomId('modal_police_casier').setTitle('📁 Consulter Casier RP');
          const input1 = new TextInputBuilder().setCustomId('target').setLabel('Nom du citoyen').setStyle(TextInputStyle.Short).setRequired(true);
          modal.addComponents(new ActionRowBuilder().addComponents(input1));
          return await interaction.showModal(modal);
        }

        if (customId === 'btn_police_fourriere') {
          const modal = new ModalBuilder().setCustomId('modal_police_fourriere').setTitle('🛞 Saisie & Fourrière ADAC');
          const input1 = new TextInputBuilder().setCustomId('vehicle').setLabel('Modèle / Marque du véhicule').setStyle(TextInputStyle.Short).setRequired(true);
          const input2 = new TextInputBuilder().setCustomId('plate').setLabel('Plaque d\'immatriculation').setStyle(TextInputStyle.Short).setRequired(true);
          const input3 = new TextInputBuilder().setCustomId('owner').setLabel('Nom du propriétaire').setStyle(TextInputStyle.Short).setRequired(true);
          const input4 = new TextInputBuilder().setCustomId('reason').setLabel('Motif de saisie').setStyle(TextInputStyle.Short).setRequired(true);
          const input5 = new TextInputBuilder().setCustomId('fee').setLabel('Frais de fourrière (€)').setStyle(TextInputStyle.Short).setValue('500').setRequired(true);

          modal.addComponents(
            new ActionRowBuilder().addComponents(input1),
            new ActionRowBuilder().addComponents(input2),
            new ActionRowBuilder().addComponents(input3),
            new ActionRowBuilder().addComponents(input4),
            new ActionRowBuilder().addComponents(input5)
          );
          return await interaction.showModal(modal);
        }

        if (customId === 'btn_braquage_alert') {
          const modal = new ModalBuilder().setCustomId('modal_braquage_alert').setTitle('🏦 Alerte Braquage en Cours');
          const input1 = new TextInputBuilder().setCustomId('location').setLabel('Lieu du braquage (ex: Banque Central)').setStyle(TextInputStyle.Short).setRequired(true);
          const input2 = new TextInputBuilder().setCustomId('details').setLabel('Nombre d\'individus & véhicules').setStyle(TextInputStyle.Paragraph).setRequired(true);

          modal.addComponents(
            new ActionRowBuilder().addComponents(input1),
            new ActionRowBuilder().addComponents(input2)
          );
          return await interaction.showModal(modal);
        }

        // --- Pompier / Feuerwehr Dashboard Buttons ---
        if (customId === 'btn_fire_report') {
          const modal = new ModalBuilder().setCustomId('modal_fire_report').setTitle('📝 Rapport Intervention Pompier');
          const input1 = new TextInputBuilder().setCustomId('location').setLabel('Localisation de l\'intervention').setStyle(TextInputStyle.Short).setRequired(true);
          const input2 = new TextInputBuilder().setCustomId('type').setLabel('Type d\'intervention (Incendie/Accident)').setStyle(TextInputStyle.Short).setRequired(true);
          const input3 = new TextInputBuilder().setCustomId('vehicles').setLabel('Engins/Véhicules engagés (FPT/VSAV)').setStyle(TextInputStyle.Short).setRequired(true);
          const input4 = new TextInputBuilder().setCustomId('bilan').setLabel('Bilan de l\'intervention').setStyle(TextInputStyle.Paragraph).setRequired(true);

          modal.addComponents(
            new ActionRowBuilder().addComponents(input1),
            new ActionRowBuilder().addComponents(input2),
            new ActionRowBuilder().addComponents(input3),
            new ActionRowBuilder().addComponents(input4)
          );
          return await interaction.showModal(modal);
        }

        if (customId === 'btn_fire_alert') {
          const modal = new ModalBuilder().setCustomId('modal_fire_alert').setTitle('🔥 Alerte Code Rouge Incendie');
          const input1 = new TextInputBuilder().setCustomId('location').setLabel('Lieu précis du sinistre').setStyle(TextInputStyle.Short).setRequired(true);
          const input2 = new TextInputBuilder().setCustomId('details').setLabel('Nature du feu & Risques').setStyle(TextInputStyle.Paragraph).setRequired(true);

          modal.addComponents(
            new ActionRowBuilder().addComponents(input1),
            new ActionRowBuilder().addComponents(input2)
          );
          return await interaction.showModal(modal);
        }

        if (customId === 'btn_fire_inspection') {
          const modal = new ModalBuilder().setCustomId('modal_fire_inspection').setTitle('🧯 Inspection Sécurité Pompier');
          const input1 = new TextInputBuilder().setCustomId('building').setLabel('Établissement / Bâtiment').setStyle(TextInputStyle.Short).setRequired(true);
          const input2 = new TextInputBuilder().setCustomId('status').setLabel('Avis (Favorable / Défavorable)').setStyle(TextInputStyle.Short).setValue('Favorable').setRequired(true);
          const input3 = new TextInputBuilder().setCustomId('notes').setLabel('Remarques & Préconisations').setStyle(TextInputStyle.Paragraph).setRequired(true);

          modal.addComponents(
            new ActionRowBuilder().addComponents(input1),
            new ActionRowBuilder().addComponents(input2),
            new ActionRowBuilder().addComponents(input3)
          );
          return await interaction.showModal(modal);
        }

        if (customId === 'btn_fire_ems') {
          const modal = new ModalBuilder().setCustomId('modal_fire_ems').setTitle('🚑 Demande Renfort Médical EMS');
          const input1 = new TextInputBuilder().setCustomId('location').setLabel('Localisation précise').setStyle(TextInputStyle.Short).setRequired(true);
          const input2 = new TextInputBuilder().setCustomId('condition').setLabel('État des victimes').setStyle(TextInputStyle.Paragraph).setRequired(true);

          modal.addComponents(
            new ActionRowBuilder().addComponents(input1),
            new ActionRowBuilder().addComponents(input2)
          );
          return await interaction.showModal(modal);
        }

        // --- HARS / ADAC Dashboard Buttons ---
        if (customId === 'btn_hars_report') {
          const modal = new ModalBuilder().setCustomId('modal_hars_report').setTitle('🛞 Fiche Dépannage HARS/ADAC');
          const input1 = new TextInputBuilder().setCustomId('vehicle').setLabel('Véhicule dépanné').setStyle(TextInputStyle.Short).setRequired(true);
          const input2 = new TextInputBuilder().setCustomId('owner').setLabel('Propriétaire / Client').setStyle(TextInputStyle.Short).setRequired(true);
          const input3 = new TextInputBuilder().setCustomId('service').setLabel('Prestation (Remorquage, Pneu, Essence)').setStyle(TextInputStyle.Short).setRequired(true);
          const input4 = new TextInputBuilder().setCustomId('fee').setLabel('Montant (€)').setStyle(TextInputStyle.Short).setValue('300').setRequired(true);

          modal.addComponents(
            new ActionRowBuilder().addComponents(input1),
            new ActionRowBuilder().addComponents(input2),
            new ActionRowBuilder().addComponents(input3),
            new ActionRowBuilder().addComponents(input4)
          );
          return await interaction.showModal(modal);
        }

        if (customId === 'btn_hars_tow') {
          const modal = new ModalBuilder().setCustomId('modal_hars_tow').setTitle('🛠️ Ordre de Remorquage Urgent');
          const input1 = new TextInputBuilder().setCustomId('location').setLabel('Localisation du véhicule').setStyle(TextInputStyle.Short).setRequired(true);
          const input2 = new TextInputBuilder().setCustomId('vehicle').setLabel('Modèle & Immatriculation').setStyle(TextInputStyle.Short).setRequired(true);

          modal.addComponents(
            new ActionRowBuilder().addComponents(input1),
            new ActionRowBuilder().addComponents(input2)
          );
          return await interaction.showModal(modal);
        }

        if (customId === 'btn_hars_medical') {
          const modal = new ModalBuilder().setCustomId('modal_hars_medical').setTitle('🚑 Fiche Soins EMS / HARS');
          const input1 = new TextInputBuilder().setCustomId('patient').setLabel('Nom RP du Patient').setStyle(TextInputStyle.Short).setRequired(true);
          const input2 = new TextInputBuilder().setCustomId('diagnosis').setLabel('Diagnostic & Traitement').setStyle(TextInputStyle.Paragraph).setRequired(true);
          const input3 = new TextInputBuilder().setCustomId('status').setLabel('Statut (Hospitalisé / Libéré)').setStyle(TextInputStyle.Short).setValue('Libéré').setRequired(true);

          modal.addComponents(
            new ActionRowBuilder().addComponents(input1),
            new ActionRowBuilder().addComponents(input2),
            new ActionRowBuilder().addComponents(input3)
          );
          return await interaction.showModal(modal);
        }

        if (customId === 'btn_hars_hazard') {
          const modal = new ModalBuilder().setCustomId('modal_hars_hazard').setTitle('🚨 Alerte Voie Bloquée');
          const input1 = new TextInputBuilder().setCustomId('location').setLabel('Localisation du danger').setStyle(TextInputStyle.Short).setRequired(true);
          const input2 = new TextInputBuilder().setCustomId('hazard').setLabel('Nature du problème / Obstacle').setStyle(TextInputStyle.Paragraph).setRequired(true);

          modal.addComponents(
            new ActionRowBuilder().addComponents(input1),
            new ActionRowBuilder().addComponents(input2)
          );
          return await interaction.showModal(modal);
        }

        if (customId === 'btn_fire_fuel') {
          const modal = new ModalBuilder().setCustomId('modal_fire_fuel').setTitle('⛽ Pollution / Carburant Chaussée');
          const input1 = new TextInputBuilder().setCustomId('location').setLabel('Localisation de la fuite / flaque').setStyle(TextInputStyle.Short).setRequired(true);
          const input2 = new TextInputBuilder().setCustomId('extent').setLabel('Surface & Danger de glissade').setStyle(TextInputStyle.Paragraph).setRequired(true);

          modal.addComponents(
            new ActionRowBuilder().addComponents(input1),
            new ActionRowBuilder().addComponents(input2)
          );
          return await interaction.showModal(modal);
        }

        if (customId === 'btn_fire_debris') {
          const modal = new ModalBuilder().setCustomId('modal_fire_debris').setTitle('📦 Objets Tombés de Camion');
          const input1 = new TextInputBuilder().setCustomId('location').setLabel('Localisation des objets').setStyle(TextInputStyle.Short).setRequired(true);
          const input2 = new TextInputBuilder().setCustomId('description').setLabel('Nature des objets tombés / Encombrants').setStyle(TextInputStyle.Paragraph).setRequired(true);

          modal.addComponents(
            new ActionRowBuilder().addComponents(input1),
            new ActionRowBuilder().addComponents(input2)
          );
          return await interaction.showModal(modal);
        }

        if (customId === 'btn_hars_traffic_light') {
          const modal = new ModalBuilder().setCustomId('modal_hars_traffic_light').setTitle('🚦 Panne / Casse Feux Tricolores');
          const input1 = new TextInputBuilder().setCustomId('intersection').setLabel('Carrefour / Intersection impactée').setStyle(TextInputStyle.Short).setRequired(true);
          const input2 = new TextInputBuilder().setCustomId('details').setLabel('État des feux & Risque de collision').setStyle(TextInputStyle.Paragraph).setRequired(true);

          modal.addComponents(
            new ActionRowBuilder().addComponents(input1),
            new ActionRowBuilder().addComponents(input2)
          );
          return await interaction.showModal(modal);
        }

        if (customId === 'btn_hars_train_barrier') {
          const modal = new ModalBuilder().setCustomId('modal_hars_train_barrier').setTitle('🚂 Panne Barrières de Sécurité Train');
          const input1 = new TextInputBuilder().setCustomId('crossing').setLabel('Localisation du Passage à Niveau').setStyle(TextInputStyle.Short).setRequired(true);
          const input2 = new TextInputBuilder().setCustomId('details').setLabel('Problème (Barrière arrachée/bloquée)').setStyle(TextInputStyle.Paragraph).setRequired(true);

          modal.addComponents(
            new ActionRowBuilder().addComponents(input1),
            new ActionRowBuilder().addComponents(input2)
          );
          return await interaction.showModal(modal);
        }

        if (customId === 'btn_joint_dispatch') {
          const modal = new ModalBuilder().setCustomId('modal_joint_dispatch').setTitle('📡 Radio Inter-Services (Inter-Factions)');
          const input1 = new TextInputBuilder().setCustomId('service').setLabel('Votre Service (Police / Pompiers / HARS)').setStyle(TextInputStyle.Short).setRequired(true);
          const input2 = new TextInputBuilder().setCustomId('location').setLabel('Lieu de l\'opération conjointe').setStyle(TextInputStyle.Short).setRequired(true);
          const input3 = new TextInputBuilder().setCustomId('requested_factions').setLabel('Renforts requis (Police, Pompiers, HARS)').setStyle(TextInputStyle.Short).setRequired(true);
          const input4 = new TextInputBuilder().setCustomId('instructions').setLabel('Consignes & Détails de l\'intervention').setStyle(TextInputStyle.Paragraph).setRequired(true);

          modal.addComponents(
            new ActionRowBuilder().addComponents(input1),
            new ActionRowBuilder().addComponents(input2),
            new ActionRowBuilder().addComponents(input3),
            new ActionRowBuilder().addComponents(input4)
          );
          return await interaction.showModal(modal);
        }

        // --- TV News & Médias Dashboard Buttons ---
        if (customId === 'btn_tv_breaking') {
          const modal = new ModalBuilder().setCustomId('modal_tv_breaking').setTitle('🔴 Flash Info Urgent • TV RP');
          const input1 = new TextInputBuilder().setCustomId('headline').setLabel('Titre du Flash Info').setStyle(TextInputStyle.Short).setRequired(true);
          const input2 = new TextInputBuilder().setCustomId('details').setLabel('Détails du direct d\'information').setStyle(TextInputStyle.Paragraph).setRequired(true);

          modal.addComponents(
            new ActionRowBuilder().addComponents(input1),
            new ActionRowBuilder().addComponents(input2)
          );
          return await interaction.showModal(modal);
        }

        if (customId === 'btn_tv_news') {
          const modal = new ModalBuilder().setCustomId('modal_tv_news').setTitle('📺 Publier Journal / Article TV');
          const input1 = new TextInputBuilder().setCustomId('title').setLabel('Titre du reportage / article').setStyle(TextInputStyle.Short).setRequired(true);
          const input2 = new TextInputBuilder().setCustomId('author').setLabel('Journaliste / Présentateur').setStyle(TextInputStyle.Short).setRequired(true);
          const input3 = new TextInputBuilder().setCustomId('content').setLabel('Texte du reportage').setStyle(TextInputStyle.Paragraph).setRequired(true);

          modal.addComponents(
            new ActionRowBuilder().addComponents(input1),
            new ActionRowBuilder().addComponents(input2),
            new ActionRowBuilder().addComponents(input3)
          );
          return await interaction.showModal(modal);
        }

        if (customId === 'btn_tv_interview') {
          const modal = new ModalBuilder().setCustomId('modal_tv_interview').setTitle('🎤 Demande d\'Interview TV');
          const input1 = new TextInputBuilder().setCustomId('target').setLabel('Personnalité RP ciblée').setStyle(TextInputStyle.Short).setRequired(true);
          const input2 = new TextInputBuilder().setCustomId('subject').setLabel('Sujet & Thèmes abordés').setStyle(TextInputStyle.Paragraph).setRequired(true);

          modal.addComponents(
            new ActionRowBuilder().addComponents(input1),
            new ActionRowBuilder().addComponents(input2)
          );
          return await interaction.showModal(modal);
        }

        if (customId === 'btn_tv_witness') {
          const modal = new ModalBuilder().setCustomId('modal_tv_witness').setTitle('📸 Appel à Témoins TV');
          const input1 = new TextInputBuilder().setCustomId('topic').setLabel('Sujet / Recherche de faits').setStyle(TextInputStyle.Short).setRequired(true);
          const input2 = new TextInputBuilder().setCustomId('contact').setLabel('Informations & Contact rédactions').setStyle(TextInputStyle.Paragraph).setRequired(true);

          modal.addComponents(
            new ActionRowBuilder().addComponents(input1),
            new ActionRowBuilder().addComponents(input2)
          );
          return await interaction.showModal(modal);
        }

        if (customId === 'btn_darkweb_post') {
          const modal = new ModalBuilder().setCustomId('modal_darkweb').setTitle('🌐 Message Darkweb Anonyme');
          const input1 = new TextInputBuilder().setCustomId('message').setLabel('Message crypté').setStyle(TextInputStyle.Paragraph).setRequired(true);
          modal.addComponents(new ActionRowBuilder().addComponents(input1));
          return await interaction.showModal(modal);
        }

        // --- Demande de Modo Dashboard Button ---
        if (customId === 'btn_request_modo_prompt') {
          const modal = new ModalBuilder().setCustomId('modal_request_modo').setTitle('🛡️ Demande de Modérateur');
          const input1 = new TextInputBuilder().setCustomId('pseudo_rp').setLabel('Pseudo Roblox / Nom RP').setStyle(TextInputStyle.Short).setRequired(true);
          const input2 = new TextInputBuilder().setCustomId('reason').setLabel('Motif / Raison de la demande').setStyle(TextInputStyle.Paragraph).setRequired(true);
          const input3 = new TextInputBuilder().setCustomId('location').setLabel('Localisation in-game (ex: Banane)').setStyle(TextInputStyle.Short).setRequired(false);

          modal.addComponents(
            new ActionRowBuilder().addComponents(input1),
            new ActionRowBuilder().addComponents(input2),
            new ActionRowBuilder().addComponents(input3)
          );
          return await interaction.showModal(modal);
        }

        // --- Demande de Modo Action Buttons (Prendre en charge / Clôturer) ---
        if (customId.startsWith('btn_take_modo_')) {
          const parts = customId.split('_'); // ['btn', 'take', 'modo', requestId, openerId]
          const requestId = parts[3];
          const openerId = parts[4];

          const targetChannel = interaction.channel;
          const logChannel = await getModRequestLogChannel(guild);

          const oldEmbed = interaction.message.embeds[0];
          const updatedEmbed = EmbedBuilder.from(oldEmbed)
            .setTitle(`✋ DEMANDE MODO PRISE EN CHARGE • #${requestId}`)
            .setColor(config.colors.warning)
            .setFields(
              { name: '🟢 Pris en charge par', value: `<@${user.id}> (\`${user.tag}\`)`, inline: true },
              { name: '👤 Demandeur', value: `<@${openerId}>`, inline: true }
            );

          const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId(`btn_close_modo_${requestId}_${openerId}`).setLabel('Clôturer la demande').setEmoji('✅').setStyle(ButtonStyle.Secondary)
          );

          await interaction.update({ embeds: [updatedEmbed], components: [row] });

          if (logChannel) {
            const logEmbed = createEmbed({
              title: `✋ LOG: DEMANDE MODO PRISE EN CHARGE • #${requestId}`,
              description:
                `👮 **Staff** : <@${user.id}> (\`${user.tag}\`)\n` +
                `👤 **Demandeur** : <@${openerId}>\n` +
                `💬 **Salon Demande** : ${targetChannel}`,
              color: config.colors.warning,
              footer: 'Logs Demandes Modo • Aubagne RP'
            });
            await logChannel.send({ embeds: [logEmbed] }).catch(() => {});
          }
          return;
        }

        if (customId.startsWith('btn_close_modo_')) {
          const parts = customId.split('_');
          const requestId = parts[3];
          const openerId = parts[4];

          const targetChannel = interaction.channel;
          const logChannel = await getModRequestLogChannel(guild);

          const oldEmbed = interaction.message.embeds[0];
          const updatedEmbed = EmbedBuilder.from(oldEmbed)
            .setTitle(`✅ DEMANDE MODO TRAITÉE & CLÔTURÉE • #${requestId}`)
            .setColor(config.colors.success)
            .setFields(
              { name: '✅ Clôturé par', value: `<@${user.id}> (\`${user.tag}\`)`, inline: true },
              { name: '👤 Demandeur', value: `<@${openerId}>`, inline: true }
            );

          await interaction.update({ embeds: [updatedEmbed], components: [] });

          if (logChannel) {
            const logEmbed = createEmbed({
              title: `✅ LOG: DEMANDE MODO CLÔTURÉE • #${requestId}`,
              description:
                `🔒 **Clôturée par** : <@${user.id}> (\`${user.tag}\`)\n` +
                `👤 **Demandeur** : <@${openerId}>\n` +
                `💬 **Salon Demande** : ${targetChannel}`,
              color: config.colors.success,
              footer: 'Logs Demandes Modo • Aubagne RP'
            });
            await logChannel.send({ embeds: [logEmbed] }).catch(() => {});
          }
          return;
        }
      }

      // 4. Modals Submit Processing
      if (interaction.isModalSubmit()) {
        const { customId, user, guild } = interaction;

        // --- Anti-Raid Config Modal Submit ---
        if (customId === 'modal_antiraid_config') {
          await interaction.deferReply({ flags: MessageFlags.Ephemeral });

          const altDays = parseInt(interaction.fields.getTextInputValue('min_alt_days'), 10) || 7;
          const spamMsgs = parseInt(interaction.fields.getTextInputValue('max_spam_msgs'), 10) || 5;
          const pings = parseInt(interaction.fields.getTextInputValue('max_mentions'), 10) || 4;
          const joins = parseInt(interaction.fields.getTextInputValue('max_joins'), 10) || 5;

          await db.updateAntiRaidConfig(guild.id, {
            minAccountAgeDays: altDays,
            maxMessagesPer5Sec: spamMsgs,
            maxMentions: pings,
            maxJoinsPer10Sec: joins
          });

          const updatedCfg = await db.getAntiRaidConfig(guild.id);
          const lastBackup = await db.getLastBackup(guild.id);

          const dbPanel = await db.getAntiRaidDashboard(guild.id);
          if (dbPanel) {
            try {
              const ch = await guild.channels.fetch(dbPanel.channelId);
              if (ch) {
                const msg = await ch.messages.fetch(dbPanel.messageId);
                if (msg) await msg.edit(antiRaidDashboardEmbed(updatedCfg, lastBackup));
              }
            } catch (e) {}
          }

          // Audit Log
          const auditEmbed = {
            title: '⚙️ LOG AUDIT SÉCURITÉ : SEUILS ANTI-RAID MODIFIÉS',
            color: '#1E88E5',
            fields: [
              { name: '👮 Administrateur', value: `<@${user.id}> (\`${user.tag}\`)`, inline: true },
              {
                name: '📝 Nouveaux Seuils',
                value: `• **Âge min compte** : \`${altDays} jours\`\n` +
                       `• **Spam max** : \`${spamMsgs} msgs / 5s\`\n` +
                       `• **Mentions max** : \`${pings} pings / msg\`\n` +
                       `• **Arrivées simultanées max** : \`${joins} joins / 10s\``,
                inline: false
              }
            ],
            timestamp: new Date()
          };
          await sendAuditLog(guild, auditEmbed);

          return interaction.editReply({
            content: `⚙️ **Réglages mis à jour avec succès :**\n` +
                     `• Âge min comptes Discord: \`${altDays} jours\`\n` +
                     `• Max messages par 5s: \`${spamMsgs}\`\n` +
                     `• Max mentions par message: \`${pings}\`\n` +
                     `• Max arrivées simultanées en 10s: \`${joins}\``
          });
        }

        // --- Staff Recruitment Quiz 20-Question 4-Step Modals (Ticket Anti-Cheat & 60s Chrono) ---
        if (customId === 'modal_staff_quiz_step1') {
          if (activeQuizTimers.has(user.id)) clearTimeout(activeQuizTimers.get(user.id));
          await interaction.deferReply({ flags: MessageFlags.Ephemeral });

          const session = userQuizSessions.get(user.id) || {};
          session['sq_1'] = interaction.fields.getTextInputValue('sq_1').trim();
          session['sq_2'] = interaction.fields.getTextInputValue('sq_2').trim();
          session['sq_3'] = interaction.fields.getTextInputValue('sq_3').trim();
          session['sq_4'] = interaction.fields.getTextInputValue('sq_4').trim();
          session['sq_5'] = interaction.fields.getTextInputValue('sq_5').trim();
          userQuizSessions.set(user.id, session);

          // Reset 60s timer for Step 2
          const timer = setTimeout(() => {
            cancelStaffQuiz(guild, user, interaction.channel, 'Chrono expiré (Plus de 60s pour valider l\'Étape 2)');
          }, 60000);
          activeQuizTimers.set(user.id, timer);

          const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
              .setCustomId('btn_staff_quiz_step2')
              .setLabel('➡️ Étape 2 : Cas Pratiques (Q6 à Q10 - 60s)')
              .setStyle(ButtonStyle.Success)
          );

          await interaction.channel.send({
            content: `<@${user.id}> ⏱️ **Étape 1/4 validée (5/20 questions) !** Cliquez ci-dessous pour ouvrir l'Étape 2 (Chrono 60s) :`,
            components: [row]
          });

          return interaction.editReply({ content: `✅ Étape 1/4 enregistrée. Veuillez poursuivre dans le salon ${interaction.channel}.` });
        }

        if (customId === 'modal_staff_quiz_step2') {
          if (activeQuizTimers.has(user.id)) clearTimeout(activeQuizTimers.get(user.id));
          await interaction.deferReply({ flags: MessageFlags.Ephemeral });

          const session = userQuizSessions.get(user.id) || {};
          session['sq_6'] = interaction.fields.getTextInputValue('sq_6').trim();
          session['sq_7'] = interaction.fields.getTextInputValue('sq_7').trim();
          session['sq_8'] = interaction.fields.getTextInputValue('sq_8').trim();
          session['sq_9'] = interaction.fields.getTextInputValue('sq_9').trim();
          session['sq_10'] = interaction.fields.getTextInputValue('sq_10').trim();
          userQuizSessions.set(user.id, session);

          // Reset 60s timer for Step 3
          const timer = setTimeout(() => {
            cancelStaffQuiz(guild, user, interaction.channel, 'Chrono expiré (Plus de 60s pour valider l\'Étape 3)');
          }, 60000);
          activeQuizTimers.set(user.id, timer);

          const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
              .setCustomId('btn_staff_quiz_step3')
              .setLabel('➡️ Étape 3 : Cas Pratiques Avancés (Q11 à Q15 - 60s)')
              .setStyle(ButtonStyle.Success)
          );

          await interaction.channel.send({
            content: `<@${user.id}> ⏱️ **Étape 2/4 validée (10/20 questions) !** Cliquez ci-dessous pour ouvrir l'Étape 3 (Chrono 60s) :`,
            components: [row]
          });

          return interaction.editReply({ content: `✅ Étape 2/4 enregistrée. Veuillez poursuivre dans le salon ${interaction.channel}.` });
        }

        if (customId === 'modal_staff_quiz_step3') {
          if (activeQuizTimers.has(user.id)) clearTimeout(activeQuizTimers.get(user.id));
          await interaction.deferReply({ flags: MessageFlags.Ephemeral });

          const session = userQuizSessions.get(user.id) || {};
          session['sq_11'] = interaction.fields.getTextInputValue('sq_11').trim();
          session['sq_12'] = interaction.fields.getTextInputValue('sq_12').trim();
          session['sq_13'] = interaction.fields.getTextInputValue('sq_13').trim();
          session['sq_14'] = interaction.fields.getTextInputValue('sq_14').trim();
          session['sq_15'] = interaction.fields.getTextInputValue('sq_15').trim();
          userQuizSessions.set(user.id, session);

          // Reset 60s timer for Step 4
          const timer = setTimeout(() => {
            cancelStaffQuiz(guild, user, interaction.channel, 'Chrono expiré (Plus de 60s pour valider l\'Étape 4)');
          }, 60000);
          activeQuizTimers.set(user.id, timer);

          const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
              .setCustomId('btn_staff_quiz_step4')
              .setLabel('➡️ Étape 4 : Règlement & Finale (Q16 à Q20 - 60s)')
              .setStyle(ButtonStyle.Success)
          );

          await interaction.channel.send({
            content: `<@${user.id}> ⏱️ **Étape 3/4 validée (15/20 questions) !** Cliquez ci-dessous pour la dernière étape (Chrono 60s) :`,
            components: [row]
          });

          return interaction.editReply({ content: `✅ Étape 3/4 enregistrée. Veuillez poursuivre dans le salon ${interaction.channel}.` });
        }

        if (customId === 'modal_staff_quiz_step4') {
          if (activeQuizTimers.has(user.id)) {
            clearTimeout(activeQuizTimers.get(user.id));
            activeQuizTimers.delete(user.id);
          }
          await interaction.deferReply({ flags: MessageFlags.Ephemeral });

          const session = userQuizSessions.get(user.id) || {};
          session['sq_16'] = interaction.fields.getTextInputValue('sq_16').trim();
          session['sq_17'] = interaction.fields.getTextInputValue('sq_17').trim();
          session['sq_18'] = interaction.fields.getTextInputValue('sq_18').trim();
          session['sq_19'] = interaction.fields.getTextInputValue('sq_19').trim();
          session['sq_20'] = interaction.fields.getTextInputValue('sq_20').trim();

          const testId = await db.createStaffTestRecord({
            guildId: guild.id,
            userId: user.id,
            userTag: user.tag || user.username,
            robloxUsername: session['sq_1'] || user.username,
            age: 0,
            availability: session['sq_2'] || 'N/A',
            experience: session['sq_5'] || 'N/A',
            case1: session['sq_6'] || 'N/A',
            case2: session['sq_7'] || 'N/A',
            case3: session['sq_8'] || 'N/A',
            answersJson: session
          });

          userQuizSessions.delete(user.id);

          const testData = await db.getStaffTestRecord(testId);

          let targetChannel = guild.channels.cache.find(
            c => c.type === ChannelType.GuildText && (
              c.name.toLowerCase() === 'recrutement-staff' ||
              c.name.toLowerCase() === 'candidatures-staff' ||
              c.name.toLowerCase().includes('recrutement')
            )
          );

          if (!targetChannel) {
            targetChannel = interaction.channel;
          }

          const cardData = staffCandidateCardEmbed({ testData, candidateUser: user, reviewerUser: null });
          const sentMsg = await targetChannel.send(cardData);

          await db.updateStaffTestStatus(testId, 'PENDING', null, null, targetChannel.id, sentMsg.id);

          await interaction.channel.send({
            content: `🎉 **Félicitations <@${user.id}> ! Votre examen de recrutement Staff en 20 questions (Candidature #${testId}) a été transmis avec succès !**\nLa Haute Direction examinera votre dossier dans ${targetChannel}.\n\n🔒 *Ce salon de test privé va automatiquement se fermer et se supprimer dans 10 secondes.*`
          });

          // Auto-delete ticket channel in 10s
          setTimeout(async () => {
            await interaction.channel.delete().catch(() => {});
          }, 10000);

          return interaction.editReply({
            content: `🎉 **Examen à 20 questions terminé avec succès !** Merci pour vos réponses.`
          });
        }


        // --- Partnership Modal Submit ---
        if (customId === 'modal_partner_submit') {
          await interaction.deferReply({ flags: MessageFlags.Ephemeral });

          const serverName = interaction.fields.getTextInputValue('server_name').trim();
          const inviteUrl = interaction.fields.getTextInputValue('invite_url').trim();
          const memberCount = parseInt(interaction.fields.getTextInputValue('member_count'), 10) || 0;
          const partnerType = interaction.fields.getTextInputValue('partner_type').trim();
          const description = interaction.fields.getTextInputValue('description').trim();

          const partnerId = await db.createPartnershipRecord({
            guildId: guild.id,
            userId: user.id,
            userTag: user.tag || user.username,
            serverName,
            inviteUrl,
            memberCount,
            partnerType,
            description
          });

          const partnerData = await db.getPartnershipRecord(partnerId);

          let targetChannel = guild.channels.cache.find(
            c => c.type === ChannelType.GuildText && (
              c.name.toLowerCase() === 'demandes-partenariat' ||
              c.name.toLowerCase() === 'partenariats' ||
              c.name.toLowerCase().includes('partenariat')
            )
          );

          if (!targetChannel) {
            targetChannel = interaction.channel;
          }

          const cardData = partnershipCardEmbed({ partnerData, applicantUser: user, reviewerUser: null });
          const sentMsg = await targetChannel.send(cardData);

          await db.updatePartnershipStatus(partnerId, 'PENDING', null, null, targetChannel.id, sentMsg.id);

          return interaction.editReply({
            content: `✅ **Votre demande de partenariat #${partnerId} pour "${serverName}" a été envoyée !**\nL'équipe la traitera dans ${targetChannel}.`
          });
        }

        // --- Gang Creation Modal Submit ---
        if (customId === 'modal_gang_submit') {
          await interaction.deferReply({ flags: MessageFlags.Ephemeral });

          const orgName = interaction.fields.getTextInputValue('org_name').trim();
          const membersList = interaction.fields.getTextInputValue('members_list').trim();
          const locationOrSector = interaction.fields.getTextInputValue('location_hq').trim();
          const lore = interaction.fields.getTextInputValue('lore').trim();
          const activities = interaction.fields.getTextInputValue('activities').trim();

          const orgId = await db.createOrganizationRecord({
            guildId: guild.id,
            userId: user.id,
            userTag: user.tag || user.username,
            orgType: 'GANG',
            orgName,
            lore,
            membersList,
            locationOrSector,
            businessPlan: activities
          });

          const orgData = await db.getOrganizationRecord(orgId);

          let targetChannel = guild.channels.cache.find(
            c => c.type === ChannelType.GuildText && (
              c.name.toLowerCase() === 'dossiers-organisations' ||
              c.name.toLowerCase() === 'creations-gangs' ||
              c.name.toLowerCase().includes('organisation')
            )
          );

          if (!targetChannel) {
            targetChannel = interaction.channel;
          }

          const cardData = organizationCardEmbed({ orgData, applicantUser: user, reviewerUser: null });
          const sentMsg = await targetChannel.send(cardData);

          await db.updateOrganizationStatus(orgId, 'PENDING', null, null, targetChannel.id, sentMsg.id);

          return interaction.editReply({
            content: `⚔️ **Votre dossier de Faction Illégale / Gang #${orgId} ("${orgName}") a bien été transmis !**\nLe Pôle Organisation l'analysera dans ${targetChannel}.`
          });
        }

        // --- Business Creation Modal Submit ---
        if (customId === 'modal_business_submit') {
          await interaction.deferReply({ flags: MessageFlags.Ephemeral });

          const orgName = interaction.fields.getTextInputValue('org_name').trim();
          const sector = interaction.fields.getTextInputValue('sector').trim();
          const leaders = interaction.fields.getTextInputValue('leaders').trim();
          const businessPlan = interaction.fields.getTextInputValue('business_plan').trim();

          const orgId = await db.createOrganizationRecord({
            guildId: guild.id,
            userId: user.id,
            userTag: user.tag || user.username,
            orgType: 'BUSINESS',
            orgName,
            lore: businessPlan,
            membersList: leaders,
            locationOrSector: sector,
            businessPlan: null
          });

          const orgData = await db.getOrganizationRecord(orgId);

          let targetChannel = guild.channels.cache.find(
            c => c.type === ChannelType.GuildText && (
              c.name.toLowerCase() === 'dossiers-organisations' ||
              c.name.toLowerCase() === 'creations-entreprises' ||
              c.name.toLowerCase().includes('organisation')
            )
          );

          if (!targetChannel) {
            targetChannel = interaction.channel;
          }

          const cardData = organizationCardEmbed({ orgData, applicantUser: user, reviewerUser: null });
          const sentMsg = await targetChannel.send(cardData);

          await db.updateOrganizationStatus(orgId, 'PENDING', null, null, targetChannel.id, sentMsg.id);

          return interaction.editReply({
            content: `🏢 **Votre dossier d'Entreprise Légale #${orgId} ("${orgName}") a bien été transmis !**\nL'Administration l'analysera dans ${targetChannel}.`
          });
        }


        // --- Staff Review Modal Submit ---

        if (customId === 'modal_staff_review_add') {
          await interaction.deferReply({ flags: MessageFlags.Ephemeral });

          const staffTarget = interaction.fields.getTextInputValue('staff_target').trim();
          const rawRating = interaction.fields.getTextInputValue('rating').trim();
          const comment = interaction.fields.getTextInputValue('comment').trim();
          const rawAnon = interaction.fields.getTextInputValue('anonymous')?.trim().toLowerCase() || 'non';

          const rating = parseInt(rawRating, 10);
          if (isNaN(rating) || rating < 0 || rating > 5) {
            return interaction.editReply({
              content: '❌ **Note invalide !** Veuillez saisir un chiffre entre **0 et 5**.'
            });
          }

          const isAnonymous = ['oui', 'yes', '1', 'vrai', 'true'].includes(rawAnon);

          // Resolution of staff user
          const { discordUser: staffUser } = await resolvePlayerInfo(staffTarget, interaction.client);
          const staffUserId = staffUser ? staffUser.id : null;

          // Save to DB
          const reviewId = await db.addStaffReview(
            guild.id,
            user.id,
            user.tag || user.username,
            staffTarget,
            staffUserId,
            rating,
            comment,
            isAnonymous
          );

          // Send and update grouped review card in log-avis-staff
          const staffKey = staffUserId || staffTarget.toLowerCase();
          const reviewsList = await db.getStaffReviews(guild.id, staffKey);
          const reviewStats = await db.getStaffReviewStats(guild.id, staffKey);

          const cardEmbed = staffReviewCardEmbed({
            staffUser,
            staffQuery: staffTarget,
            reviewsList,
            stats: reviewStats
          });

          const logChannel = await getStaffReviewLogChannel(guild);
          if (logChannel) {
            const existingCard = await db.getStaffReviewCard(guild.id, staffKey);
            let updatedCardMsg = null;

            if (existingCard) {
              try {
                const existingMsg = await logChannel.messages.fetch(existingCard.messageId).catch(() => null);
                if (existingMsg) {
                  updatedCardMsg = await existingMsg.edit({ embeds: [cardEmbed] });
                }
              } catch (e) {}
            }

            if (!updatedCardMsg) {
              const newMsg = await logChannel.send({ embeds: [cardEmbed] });
              await db.saveStaffReviewCard(guild.id, staffKey, logChannel.id, newMsg.id);
            }
          }

          return interaction.editReply({
            content: `✅ **Votre avis sur l'équipe staff a été transmis et ajouté au dossier du modérateur !**\n\n` +
              `👤 **Staff ciblé** : ${staffUser ? `<@${staffUser.id}>` : `\`${staffTarget}\``}\n` +
              `⭐ **Note attribuée** : **${rating} / 5** (Moyenne actuelle: **${reviewStats.avgRating}/5** pour ${reviewsList.length} avis)\n` +
              `🔒 **Anonymat** : ${isAnonymous ? '🕵️ Oui' : '🌐 Non'}\n\n` +
              `*La fiche de ce modérateur dans ${logChannel || '#log-avis-staff'} a été mise à jour.*`
          });
        }

        // --- Staff Review Remove Modal Submit ---
        if (customId === 'modal_staff_review_remove') {
          await interaction.deferReply({ flags: MessageFlags.Ephemeral });

          const member = await guild.members.fetch(user.id).catch(() => interaction.member);
          if (!hasPingFondationRole(member)) {
            return interaction.editReply({
              content: '❌ **Permission refusée !** Seuls les membres possédant le rôle **Ping Fondation** sont autorisés à supprimer un avis staff.'
            });
          }

          const staffTarget = interaction.fields.getTextInputValue('staff_target').trim();
          const targetStr = interaction.fields.getTextInputValue('review_num').trim().toLowerCase();

          const { discordUser: staffUser } = await resolvePlayerInfo(staffTarget, interaction.client);
          const staffKey = staffUser ? staffUser.id : staffTarget.toLowerCase();

          const history = await db.getStaffReviews(guild.id, staffKey);

          if (!history || history.length === 0) {
            return interaction.editReply({
              content: `❌ Aucun avis trouvé à supprimer pour **${staffUser ? staffUser.username : staffTarget}**.`
            });
          }

          const logChannel = await getStaffReviewLogChannel(guild);
          const igLogChannel = await getLogServeurIGChannel(guild);

          if (targetStr === 'tout' || targetStr === 'all' || targetStr === '*') {
            await db.clearStaffReviews(guild.id, staffKey);

            const existingCard = await db.getStaffReviewCard(guild.id, staffKey);
            if (existingCard && logChannel) {
              try {
                const msg = await logChannel.messages.fetch(existingCard.messageId).catch(() => null);
                if (msg) await msg.delete().catch(() => {});
              } catch (e) {}
              await db.deleteStaffReviewCard(guild.id, staffKey);
            }

            // Log à log-serveur-ig
            if (igLogChannel) {
              const auditEmbed = staffReviewDeletionLogEmbed({
                executorUser: user,
                staffUser,
                staffQuery: staffTarget,
                actionType: 'Purger / Effacer tous les avis staff',
                details: `Réinitialisation complète du dossier d'avis (${history.length} avis effacés).`
              });
              igLogChannel.send({ embeds: [auditEmbed] }).catch(() => {});
            }

            return interaction.editReply({
              content: `🗑️ **Tous les avis sur ${staffUser ? `<@${staffUser.id}>` : `\`${staffTarget}\``} ont été effacés avec succès !** La fiche du modérateur a été réinitialisée.`
            });
          }

          const idx = parseInt(targetStr, 10) - 1;
          if (isNaN(idx) || idx < 0 || idx >= history.length) {
            return interaction.editReply({
              content: `⚠️ Numéro d'avis invalide. Ce modérateur a **${history.length}** avis. Spécifiez un nombre entre \`1\` et \`${history.length}\`, ou \`tout\`.`
            });
          }

          const targetReview = history[idx];
          await db.removeStaffReviewRecord(targetReview.id);

          const remainingReviews = await db.getStaffReviews(guild.id, staffKey);
          const remainingStats = await db.getStaffReviewStats(guild.id, staffKey);

          const existingCard = await db.getStaffReviewCard(guild.id, staffKey);
          if (existingCard && logChannel) {
            if (remainingReviews.length > 0) {
              const cardEmbed = staffReviewCardEmbed({
                staffUser,
                staffQuery: staffTarget,
                reviewsList: remainingReviews,
                stats: remainingStats
              });
              try {
                const msg = await logChannel.messages.fetch(existingCard.messageId).catch(() => null);
                if (msg) await msg.edit({ embeds: [cardEmbed] });
              } catch (e) {}
            } else {
              try {
                const msg = await logChannel.messages.fetch(existingCard.messageId).catch(() => null);
                if (msg) await msg.delete().catch(() => {});
              } catch (e) {}
              await db.deleteStaffReviewCard(guild.id, staffKey);
            }
          }

          // Log à log-serveur-ig
          if (igLogChannel) {
            const stars = '⭐'.repeat(targetReview.rating) + '☆'.repeat(5 - targetReview.rating);
            const authorInfo = targetReview.isAnonymous ? `🕵️ Anonyme (ID: ${targetReview.authorId})` : `<@${targetReview.authorId}>`;
            const auditEmbed = staffReviewDeletionLogEmbed({
              executorUser: user,
              staffUser,
              staffQuery: staffTarget,
              actionType: `Suppression de l'avis #${idx + 1}`,
              details: `Note: ${stars} (${targetReview.rating}/5)\nAuteur: ${authorInfo}\nCommentaire: "${targetReview.comment}"`
            });
            igLogChannel.send({ embeds: [auditEmbed] }).catch(() => {});
          }

          return interaction.editReply({
            content: `🗑️ **L'avis #${idx + 1} sur ${staffUser ? `<@${staffUser.id}>` : `\`${staffTarget}\``} a été supprimé !** (Avis restants: **${remainingReviews.length}**)`
          });
        }

        // --- Suggestion Add Modal Submit ---
        if (customId === 'modal_suggestion_add') {
          await interaction.deferReply({ flags: MessageFlags.Ephemeral });

          const title = interaction.fields.getTextInputValue('suggestion_title').trim();
          const details = interaction.fields.getTextInputValue('suggestion_details').trim();

          const targetChannel = await getSuggestionsChannel(guild);
          if (!targetChannel) {
            return interaction.editReply({ content: '❌ Salon #suggestions introuvable.' });
          }

          // Check if a similar suggestion already exists
          const similarSuggestion = await db.findSimilarPendingSuggestion(guild.id, title);

          if (similarSuggestion) {
            // Append proposal to existing suggestion card
            const updatedSuggestion = await db.addProposalToSuggestionRecord(
              similarSuggestion.id,
              user.id,
              user.tag || user.username,
              title,
              details
            );

            // Fetch channel & message
            const suggestionsChannel = guild.channels.cache.get(similarSuggestion.channelId) || targetChannel;
            if (suggestionsChannel && similarSuggestion.messageId) {
              try {
                const msg = await suggestionsChannel.messages.fetch(similarSuggestion.messageId).catch(() => null);
                if (msg) {
                  const authorUser = await interaction.client.users.fetch(similarSuggestion.authorId).catch(() => null);
                  const cardPayload = suggestionCardEmbed({ suggestion: updatedSuggestion, authorUser });
                  await msg.edit(cardPayload);
                }
              } catch (e) {}
            }

            return interaction.editReply({
              content: `🔀 **Votre idée a été automatiquement regroupée avec la suggestion existante #${similarSuggestion.id} !**\n\n` +
                `📌 **Sujet regroupé** : **${similarSuggestion.title}**\n` +
                `💡 *Votre proposition a été ajoutée sous la fiche principale dans ${targetChannel} pour éviter de disperser les votes de la communauté.*`
            });
          }

          // Send draft card
          const draftSuggestion = {
            id: '...',
            title,
            details,
            status: 'PENDING',
            upVotes: 0,
            downVotes: 0,
            authorId: user.id,
            createdAt: Date.now()
          };

          const cardPayload = suggestionCardEmbed({ suggestion: draftSuggestion, authorUser: user });
          const cardMsg = await targetChannel.send(cardPayload);

          // Insert in DB
          const suggestionId = await db.createSuggestionRecord(
            guild.id,
            user.id,
            user.tag || user.username,
            title,
            details,
            targetChannel.id,
            cardMsg.id
          );

          // Update card message with real ID & DB state
          const realSuggestion = await db.getSuggestionRecord(suggestionId);
          const realPayload = suggestionCardEmbed({ suggestion: realSuggestion, authorUser: user });
          await cardMsg.edit(realPayload).catch(() => {});

          // Reposition Dashboard to bottom of #suggestions channel
          await repositionSuggestionDashboard(guild, targetChannel);

          return interaction.editReply({
            content: `💡 **Votre suggestion a été transmise avec succès !**\n📌 Elle est désormais disponible au vote dans le salon ${targetChannel} (ID: **#${suggestionId}**).`
          });
        }

        // --- Suggestion Staff Manage Modal Submit ---
        if (customId.startsWith('modal_suggest_manage_')) {
          await interaction.deferReply({ flags: MessageFlags.Ephemeral });
          const suggestionId = parseInt(customId.replace('modal_suggest_manage_', ''), 10);

          const rawStatus = interaction.fields.getTextInputValue('status').trim().toLowerCase();
          const reason = interaction.fields.getTextInputValue('reason')?.trim() || null;

          let statusKey = 'PENDING';
          if (rawStatus.includes('accept') || rawStatus === 'oui' || rawStatus === 'ok') statusKey = 'ACCEPTED';
          else if (rawStatus.includes('refus') || rawStatus === 'non') statusKey = 'REJECTED';
          else if (rawStatus.includes('cours') || rawStatus.includes('dev') || rawStatus.includes('progr')) statusKey = 'IN_PROGRESS';
          else {
            return interaction.editReply({
              content: '⚠️ **Statut invalide !** Veuillez taper : `accepter`, `refuser`, ou `encours`.'
            });
          }

          const updatedSuggestion = await db.updateSuggestionStatusRecord(suggestionId, statusKey, user.id, reason);

          const authorUser = await interaction.client.users.fetch(updatedSuggestion.authorId).catch(() => null);

          // Update or delete card in #suggestions
          const suggestionsChannel = guild.channels.cache.get(updatedSuggestion.channelId) || await getSuggestionsChannel(guild);
          if (suggestionsChannel && updatedSuggestion.messageId) {
            try {
              const cardMsg = await suggestionsChannel.messages.fetch(updatedSuggestion.messageId).catch(() => null);
              if (cardMsg) {
                if (statusKey === 'ACCEPTED' || statusKey === 'REJECTED') {
                  await cardMsg.delete().catch(() => {});
                } else {
                  const cardPayload = suggestionCardEmbed({ suggestion: updatedSuggestion, authorUser, processedUser: user });
                  await cardMsg.edit(cardPayload);
                }
              }
            } catch (e) {}
          }

          // Log into #log-suggestions
          const logChannel = await getLogSuggestionsChannel(guild);
          if (logChannel) {
            const logEmbed = suggestionLogEmbed({
              suggestion: updatedSuggestion,
              authorUser,
              staffUser: user,
              status: statusKey,
              reason
            });
            logChannel.send({ embeds: [logEmbed] }).catch(() => {});
          }

          const statusLabels = {
            ACCEPTED: '🟢 Acceptée',
            REJECTED: '🔴 Refusée',
            IN_PROGRESS: '🛠️ En cours d\'implémentation'
          };

          return interaction.editReply({
            content: `✅ **Suggestion #${suggestionId} traitée avec succès !**\n📌 Nouveau statut : **${statusLabels[statusKey] || statusKey}**`
          });
        }

        // --- Giveaway Create Modal Submit ---
        if (customId === 'modal_giveaway_create') {
          await interaction.deferReply({ flags: MessageFlags.Ephemeral });

          const prize = interaction.fields.getTextInputValue('prize').trim();
          const durationStr = interaction.fields.getTextInputValue('duration').trim();
          const winnersRaw = interaction.fields.getTextInputValue('winners').trim();
          const description = interaction.fields.getTextInputValue('description')?.trim() || null;

          const winnersCount = parseInt(winnersRaw, 10) || 1;
          const durationMs = parseDuration(durationStr);

          if (!durationMs || durationMs < 5000) {
            return interaction.editReply({
              content: '❌ **Format de durée invalide !** Utilisez un format comme `10m` (10 min), `1h` (1 heure), `24h` (1 jour) ou `2d` (2 jours).'
            });
          }

          const targetChannel = interaction.channel;
          const endsAt = Date.now() + durationMs;

          const draftGiveaway = {
            id: 'PENDING',
            prize,
            description,
            winnersCount,
            hostId: user.id,
            endsAt,
            createdAt: Date.now()
          };

          const cardPayload = giveawayCardEmbed({ giveaway: draftGiveaway, hostUser: user, participantsCount: 0 });
          const cardMsg = await targetChannel.send(cardPayload);

          const giveawayId = await db.createGiveawayRecord(
            guild.id,
            targetChannel.id,
            cardMsg.id,
            prize,
            description,
            winnersCount,
            user.id,
            endsAt
          );

          const realGiveaway = await db.getGiveawayRecord(giveawayId);
          const realPayload = giveawayCardEmbed({ giveaway: realGiveaway, hostUser: user, participantsCount: 0 });
          await cardMsg.edit(realPayload).catch(() => {});

          return interaction.editReply({
            content: `🎉 **Giveaway créé et lancé avec succès !**\n🎁 Gain : **${prize}** dans ${targetChannel} !`
          });
        }

        // --- Sanction Add Modal Submit ---
        if (customId === 'modal_sanction_add') {
          await interaction.deferReply({ flags: MessageFlags.Ephemeral });
          const rawInput = interaction.fields.getTextInputValue('roblox_username').trim();
          const sanctionType = interaction.fields.getTextInputValue('sanction_type').trim();
          const details = interaction.fields.getTextInputValue('sanction_details').trim();

          // Unified resolution (Roblox + Discord)
          const { robloxUser, discordUser } = await resolvePlayerInfo(rawInput, interaction.client);
          const linkedDiscordId = discordUser ? discordUser.id : null;

          // 3. Save sanction in SQLite
          await db.addSanctionRecord(
            guild.id,
            robloxUser.name,
            robloxUser.id,
            linkedDiscordId,
            user.id,
            sanctionType,
            details
          );

          // 4. Fetch complete history for this player
          const history = await db.getPlayerSanctionsHistory(robloxUser.id || robloxUser.name);

          // 5. Find target channel #sanction-joueur
          let sanctionChannel = guild.channels.cache.find(
            c => c.type === ChannelType.GuildText && (
              c.name.toLowerCase() === 'sanction-joueur' ||
              c.name.toLowerCase() === 'sanctions-joueur' ||
              c.name.toLowerCase() === 'sanction-joueurs' ||
              c.name.toLowerCase() === 'sanctions-joueurs' ||
              c.name.toLowerCase().includes('sanction')
            )
          );

          if (!sanctionChannel) {
            // Auto-create channel if it doesn't exist
            try {
              sanctionChannel = await guild.channels.create({
                name: 'sanction-joueur',
                type: ChannelType.GuildText,
                topic: 'Dossiers disciplinaires et sanctions des joueurs'
              });
            } catch (e) {
              console.error('Erreur lors de la création du salon sanction-joueur:', e);
              sanctionChannel = interaction.channel;
            }
          }

          // 6. Check existing card in DB
          const cardEmbed = playerSanctionCardEmbed({
            robloxUser,
            sanctionsList: history,
            discordUser
          });

          const existingCard = await db.getPlayerSanctionCard(guild.id, robloxUser.id || robloxUser.name);
          let updatedMessage = null;

          if (existingCard) {
            try {
              const existingMsg = await sanctionChannel.messages.fetch(existingCard.messageId).catch(() => null);
              if (existingMsg) {
                updatedMessage = await existingMsg.edit({ embeds: [cardEmbed] });
              }
            } catch (err) {
              console.error('Impossible d\'éditer l\'ancien message de sanction:', err);
            }
          }

          if (!updatedMessage) {
            const newMsg = await sanctionChannel.send({ embeds: [cardEmbed] });
            await db.savePlayerSanctionCard(guild.id, robloxUser.id || robloxUser.name, sanctionChannel.id, newMsg.id);
          }

          // Log to #log-sanction-joueur in LOGS category
          const playerLogChannel = await getPlayerSanctionLogChannel(guild);
          if (playerLogChannel) {
            const auditEmbed = sanctionAuditLogEmbed({
              title: '📜 LOG : NOUVELLE SANCTION JOUEUR',
              target: `${robloxUser.displayName} (@${robloxUser.name}) - ID: \`${robloxUser.id}\``,
              moderator: `<@${user.id}> (${user.tag})`,
              sanctionType,
              details,
              color: config.colors.danger
            });
            playerLogChannel.send({ embeds: [auditEmbed] }).catch(() => {});
          }

          return interaction.editReply({
            content: `✅ **Sanction enregistrée avec succès !**\n\n` +
              `👤 **Joueur** : **${robloxUser.displayName}** (@${robloxUser.name})\n` +
              `🚨 **Sanction** : \`${sanctionType}\`\n` +
              `💬 **Dossier mis à jour dans** : ${sanctionChannel} (Total: **${history.length}** sanction(s))`
          });
        }

        // --- Sanction Lookup Modal Submit ---
        if (customId === 'modal_sanction_lookup') {
          await interaction.deferReply({ flags: MessageFlags.Ephemeral });
          const targetQuery = interaction.fields.getTextInputValue('target_query').trim();

          const { robloxUser, discordUser } = await resolvePlayerInfo(targetQuery, interaction.client);
          const history = await db.getPlayerSanctionsHistory(robloxUser.id || targetQuery);

          if (!history || history.length === 0) {
            return interaction.editReply({
              content: `ℹ️ Aucun dossier ou sanction trouvé pour **${robloxUser.displayName}** (\`${targetQuery}\`).`
            });
          }

          const cardEmbed = playerSanctionCardEmbed({
            robloxUser,
            sanctionsList: history,
            discordUser
          });

          return interaction.editReply({ embeds: [cardEmbed] });
        }

        // --- Sanction Remove Modal Submit ---
        if (customId === 'modal_sanction_remove') {
          await interaction.deferReply({ flags: MessageFlags.Ephemeral });
          const rawInput = interaction.fields.getTextInputValue('roblox_username').trim();
          const targetStr = interaction.fields.getTextInputValue('sanction_num').trim().toLowerCase();

          const { robloxUser, discordUser } = await resolvePlayerInfo(rawInput, interaction.client);
          const history = await db.getPlayerSanctionsHistory(robloxUser.id || rawInput);

          if (!history || history.length === 0) {
            return interaction.editReply({
              content: `❌ Aucune sanction à supprimer trouvée pour **${robloxUser.displayName}**.`
            });
          }

          let sanctionChannel = guild.channels.cache.find(
            c => c.type === ChannelType.GuildText && (
              c.name.toLowerCase() === 'sanction-joueur' ||
              c.name.toLowerCase() === 'sanctions-joueur' ||
              c.name.toLowerCase().includes('sanction')
            )
          );

          if (targetStr === 'tout' || targetStr === 'all' || targetStr === '*') {
            await db.clearPlayerSanctions(robloxUser.id || robloxUsername);

            const existingCard = await db.getPlayerSanctionCard(guild.id, robloxUser.id || robloxUsername);
            if (existingCard && sanctionChannel) {
              try {
                const msg = await sanctionChannel.messages.fetch(existingCard.messageId).catch(() => null);
                if (msg) await msg.delete().catch(() => {});
              } catch (e) {}
              await db.deletePlayerSanctionCard(guild.id, robloxUser.id || robloxUsername);
            }

            const playerLogChannel = await getPlayerSanctionLogChannel(guild);
            if (playerLogChannel) {
              const auditEmbed = sanctionAuditLogEmbed({
                title: '🗑️ LOG : SANCTIONS JOUEUR PURGÉES',
                target: `${robloxUser.displayName} (@${robloxUser.name})`,
                moderator: `<@${user.id}> (${user.tag})`,
                sanctionType: 'Effacement total du dossier',
                details: 'Le modérateur a réinitialisé le casier du joueur.',
                color: config.colors.warning
              });
              playerLogChannel.send({ embeds: [auditEmbed] }).catch(() => {});
            }

            return interaction.editReply({
              content: `🗑️ **Toutes les sanctions de ${robloxUser.displayName} (@${robloxUser.name}) ont été effacées !** Son dossier disciplinaire a été réinitialisé.`
            });
          }

          const idx = parseInt(targetStr, 10) - 1;
          if (isNaN(idx) || idx < 0 || idx >= history.length) {
            return interaction.editReply({
              content: `⚠️ Numéro de sanction invalide. Le joueur a **${history.length}** sanction(s). Entrez un chiffre entre \`1\` et \`${history.length}\`, ou \`tout\`.`
            });
          }

          const targetSanction = history[idx];
          await db.removeSanctionRecord(targetSanction.id);

          const remainingHistory = await db.getPlayerSanctionsHistory(robloxUser.id || robloxUsername);

          const existingCard = await db.getPlayerSanctionCard(guild.id, robloxUser.id || robloxUsername);
          if (existingCard && sanctionChannel) {
            try {
              const msg = await sanctionChannel.messages.fetch(existingCard.messageId).catch(() => null);
              if (msg) {
                if (remainingHistory.length === 0) {
                  await msg.delete().catch(() => {});
                  await db.deletePlayerSanctionCard(guild.id, robloxUser.id || robloxUsername);
                } else {
                  const linkedDiscordId = await db.isRobloxLinkedToAnotherDiscord(robloxUser.id, '0');
                  const discordUser = linkedDiscordId ? await interaction.client.users.fetch(linkedDiscordId).catch(() => null) : null;
                  const cardEmbed = playerSanctionCardEmbed({
                    robloxUser,
                    sanctionsList: remainingHistory,
                    discordUser
                  });
                  await msg.edit({ embeds: [cardEmbed] });
                }
              }
            } catch (e) {}
          }

          const playerLogChannel = await getPlayerSanctionLogChannel(guild);
          if (playerLogChannel) {
            const auditEmbed = sanctionAuditLogEmbed({
              title: '🗑️ LOG : SANCTION JOUEUR RETIRÉE',
              target: `${robloxUser.displayName} (@${robloxUser.name})`,
              moderator: `<@${user.id}> (${user.tag})`,
              sanctionType: `Suppression Sanction #${idx + 1}`,
              details: `Suppression de la sanction: ${targetSanction.sanctionType}`,
              color: config.colors.warning
            });
            playerLogChannel.send({ embeds: [auditEmbed] }).catch(() => {});
          }

          return interaction.editReply({
            content: `🗑️ **Sanction #${idx + 1} retirée pour ${robloxUser.displayName} !** (${remainingHistory.length} sanction(s) restante(s))`
          });
        }

        // --- Staff Sanction Add Modal Submit ---
        if (customId === 'modal_staff_sanction_add') {
          await interaction.deferReply({ flags: MessageFlags.Ephemeral });
          const staffInput = interaction.fields.getTextInputValue('staff_target').trim();
          const sanctionType = interaction.fields.getTextInputValue('sanction_type').trim();
          const details = interaction.fields.getTextInputValue('sanction_details').trim();

          let targetUserId = staffInput.replace(/[^0-9]/g, '');
          let staffUser = null;
          if (targetUserId) {
            staffUser = await interaction.client.users.fetch(targetUserId).catch(() => null);
          }
          if (!staffUser) {
            const member = guild.members.cache.find(m => m.user.username.toLowerCase().includes(staffInput.toLowerCase()));
            if (member) staffUser = member.user;
          }

          if (!staffUser) {
            staffUser = { id: targetUserId || '0', tag: staffInput, username: staffInput };
          }

          await db.addStaffSanctionRecord(
            guild.id,
            staffUser.tag || staffUser.username,
            staffUser.id,
            user.id,
            sanctionType,
            details
          );

          const history = await db.getStaffSanctionsHistory(staffUser.id);

          let staffSanctionChannel = guild.channels.cache.find(
            c => c.type === ChannelType.GuildText && (
              c.name.toLowerCase() === 'sanction-staff' ||
              c.name.toLowerCase() === 'sanctions-staff' ||
              c.name.toLowerCase().includes('sanction-staff')
            )
          );

          if (!staffSanctionChannel) {
            try {
              staffSanctionChannel = await guild.channels.create({
                name: 'sanction-staff',
                type: ChannelType.GuildText,
                topic: 'Dossiers disciplinaires des membres de l\'équipe Staff'
              });
            } catch (e) {
              staffSanctionChannel = interaction.channel;
            }
          }

          const cardEmbed = staffSanctionCardEmbed({
            staffUser,
            sanctionsList: history
          });

          const existingCard = await db.getStaffSanctionCard(guild.id, staffUser.id);
          let updatedMessage = null;

          if (existingCard) {
            try {
              const existingMsg = await staffSanctionChannel.messages.fetch(existingCard.messageId).catch(() => null);
              if (existingMsg) {
                updatedMessage = await existingMsg.edit({ embeds: [cardEmbed] });
              }
            } catch (err) {}
          }

          if (!updatedMessage) {
            const newMsg = await staffSanctionChannel.send({ embeds: [cardEmbed] });
            await db.saveStaffSanctionCard(guild.id, staffUser.id, staffSanctionChannel.id, newMsg.id);
          }

          const staffLogChannel = await getStaffSanctionLogChannel(guild);
          if (staffLogChannel) {
            const logEmbed = sanctionAuditLogEmbed({
              title: '👑 LOG : NOUVELLE SANCTION STAFF',
              target: `${staffUser.tag || staffUser.username} (<@${staffUser.id}>)`,
              moderator: `<@${user.id}> (${user.tag})`,
              sanctionType,
              details,
              color: config.colors.police || '#0D47A1'
            });
            staffLogChannel.send({ embeds: [logEmbed] }).catch(() => {});
          }

          return interaction.editReply({
            content: `✅ **Sanction Staff enregistrée avec succès !**\n\n` +
              `👤 **Membre Staff** : <@${staffUser.id}> (${staffUser.tag || staffUser.username})\n` +
              `🚨 **Sanction** : \`${sanctionType}\`\n` +
              `💬 **Dossier mis à jour dans** : ${staffSanctionChannel} (Total: **${history.length}** sanction(s))`
          });
        }

        // --- Staff Sanction Lookup Modal Submit ---
        if (customId === 'modal_staff_sanction_lookup') {
          await interaction.deferReply({ flags: MessageFlags.Ephemeral });
          const staffInput = interaction.fields.getTextInputValue('staff_target').trim();
          let targetUserId = staffInput.replace(/[^0-9]/g, '');

          let staffUser = targetUserId ? await interaction.client.users.fetch(targetUserId).catch(() => null) : null;
          if (!staffUser) {
            const member = guild.members.cache.find(m => m.user.username.toLowerCase().includes(staffInput.toLowerCase()));
            if (member) staffUser = member.user;
          }

          const searchKey = staffUser ? staffUser.id : staffInput;
          const history = await db.getStaffSanctionsHistory(searchKey);

          if (!history || history.length === 0) {
            return interaction.editReply({
              content: `ℹ️ Aucun dossier disciplinaire staff trouvé pour \`${staffInput}\`.`
            });
          }

          const cardEmbed = staffSanctionCardEmbed({
            staffUser: staffUser || { id: searchKey, username: staffInput, tag: staffInput },
            sanctionsList: history
          });

          return interaction.editReply({ embeds: [cardEmbed] });
        }

        // --- Staff Sanction Remove Modal Submit ---
        if (customId === 'modal_staff_sanction_remove') {
          await interaction.deferReply({ flags: MessageFlags.Ephemeral });
          const staffInput = interaction.fields.getTextInputValue('staff_target').trim();
          const targetStr = interaction.fields.getTextInputValue('sanction_num').trim().toLowerCase();

          let targetUserId = staffInput.replace(/[^0-9]/g, '');
          let staffUser = targetUserId ? await interaction.client.users.fetch(targetUserId).catch(() => null) : null;
          if (!staffUser) {
            const member = guild.members.cache.find(m => m.user.username.toLowerCase().includes(staffInput.toLowerCase()));
            if (member) staffUser = member.user;
          }

          const searchKey = staffUser ? staffUser.id : staffInput;
          const history = await db.getStaffSanctionsHistory(searchKey);

          if (!history || history.length === 0) {
            return interaction.editReply({
              content: `❌ Aucune sanction staff à supprimer pour \`${staffInput}\`.`
            });
          }

          let staffSanctionChannel = guild.channels.cache.find(
            c => c.type === ChannelType.GuildText && (
              c.name.toLowerCase() === 'sanction-staff' ||
              c.name.toLowerCase() === 'sanctions-staff' ||
              c.name.toLowerCase().includes('sanction-staff')
            )
          );

          if (targetStr === 'tout' || targetStr === 'all' || targetStr === '*') {
            await db.clearStaffSanctions(searchKey);

            const existingCard = await db.getStaffSanctionCard(guild.id, searchKey);
            if (existingCard && staffSanctionChannel) {
              try {
                const msg = await staffSanctionChannel.messages.fetch(existingCard.messageId).catch(() => null);
                if (msg) await msg.delete().catch(() => {});
              } catch (e) {}
              await db.deleteStaffSanctionCard(guild.id, searchKey);
            }

            const staffLogChannel = await getStaffSanctionLogChannel(guild);
            if (staffLogChannel) {
              const logEmbed = sanctionAuditLogEmbed({
                title: '🗑️ LOG : SANCTIONS STAFF PURGÉES',
                target: staffUser ? `${staffUser.tag} (<@${staffUser.id}>)` : staffInput,
                moderator: `<@${user.id}> (${user.tag})`,
                sanctionType: 'Effacement total du dossier staff',
                details: 'L\'administrateur a réinitialisé le casier disciplinaire staff.',
                color: config.colors.warning
              });
              staffLogChannel.send({ embeds: [logEmbed] }).catch(() => {});
            }

            return interaction.editReply({
              content: `🗑️ **Toutes les sanctions staff de \`${staffInput}\` ont été effacées !**`
            });
          }

          const idx = parseInt(targetStr, 10) - 1;
          if (isNaN(idx) || idx < 0 || idx >= history.length) {
            return interaction.editReply({
              content: `⚠️ Numéro invalide. Le membre staff a **${history.length}** sanction(s). Entrez entre \`1\` et \`${history.length}\`, ou \`tout\`.`
            });
          }

          const targetSanction = history[idx];
          await db.removeStaffSanctionRecord(targetSanction.id);

          const remainingHistory = await db.getStaffSanctionsHistory(searchKey);

          const existingCard = await db.getStaffSanctionCard(guild.id, searchKey);
          if (existingCard && staffSanctionChannel) {
            try {
              const msg = await staffSanctionChannel.messages.fetch(existingCard.messageId).catch(() => null);
              if (msg) {
                if (remainingHistory.length === 0) {
                  await msg.delete().catch(() => {});
                  await db.deleteStaffSanctionCard(guild.id, searchKey);
                } else {
                  const cardEmbed = staffSanctionCardEmbed({
                    staffUser: staffUser || { id: searchKey, username: staffInput },
                    sanctionsList: remainingHistory
                  });
                  await msg.edit({ embeds: [cardEmbed] });
                }
              }
            } catch (e) {}
          }

          const staffLogChannel = await getStaffSanctionLogChannel(guild);
          if (staffLogChannel) {
            const logEmbed = sanctionAuditLogEmbed({
              title: '🗑️ LOG : SANCTION STAFF RETIRÉE',
              target: staffUser ? `${staffUser.tag} (<@${staffUser.id}>)` : staffInput,
              moderator: `<@${user.id}> (${user.tag})`,
              sanctionType: `Suppression Sanction Staff #${idx + 1}`,
              details: `Suppression de la sanction: ${targetSanction.sanctionType}`,
              color: config.colors.warning
            });
            staffLogChannel.send({ embeds: [logEmbed] }).catch(() => {});
          }

          return interaction.editReply({
            content: `🗑️ **Sanction Staff #${idx + 1} retirée pour \`${staffInput}\` !** (${remainingHistory.length} sanction(s) restante(s))`
          });
        }

        // --- Staff Rank Up & Rank Down Modal Submit ---
        if (customId === 'modal_staff_rank_up' || customId === 'modal_staff_rank_down') {
          await interaction.deferReply({ flags: MessageFlags.Ephemeral });
          const isUp = customId === 'modal_staff_rank_up';
          const actionType = isUp ? 'promotion' : 'demotion';

          const staffInput = interaction.fields.getTextInputValue('staff_target').trim();
          const oldRank = interaction.fields.getTextInputValue('old_rank').trim();
          const newRank = interaction.fields.getTextInputValue('new_rank').trim();
          const reason = interaction.fields.getTextInputValue('reason').trim();

          let targetUserId = staffInput.replace(/[^0-9]/g, '');
          let staffUser = null;
          if (targetUserId) {
            staffUser = await interaction.client.users.fetch(targetUserId).catch(() => null);
          }
          if (!staffUser) {
            const member = guild.members.cache.find(m => m.user.username.toLowerCase().includes(staffInput.toLowerCase()));
            if (member) staffUser = member.user;
          }

          if (!staffUser) {
            staffUser = { id: targetUserId || '0', tag: staffInput, username: staffInput };
          }

          await db.addStaffRankRecord(
            guild.id,
            staffUser.id,
            staffUser.tag || staffUser.username,
            user.id,
            actionType,
            oldRank,
            newRank,
            reason
          );

          if (staffUser.id !== '0') {
            const member = await guild.members.fetch(staffUser.id).catch(() => null);
            if (member) {
              const newRole = guild.roles.cache.find(r => r.name.toLowerCase() === newRank.toLowerCase());
              const oldRole = guild.roles.cache.find(r => r.name.toLowerCase() === oldRank.toLowerCase());
              if (newRole) await member.roles.add(newRole).catch(() => {});
              if (oldRole) await member.roles.remove(oldRole).catch(() => {});
            }
          }

          const rankLogChannel = await getStaffRankLogChannel(guild);
          if (rankLogChannel) {
            const logEmbed = staffRankLogEmbed({
              staffUser,
              adminUser: user,
              actionType,
              oldRank,
              newRank,
              reason
            });
            rankLogChannel.send({ embeds: [logEmbed] }).catch(() => {});
          }

          const announcementChannel = await getStaffRankAnnouncementChannel(guild);
          if (announcementChannel) {
            const announceEmbed = staffRankAnnouncementEmbed({
              staffUser,
              actionType,
              oldRank,
              newRank,
              reason
            });
            announcementChannel.send({
              content: isUp ? `🎉 **NOUVELLE PROMOTION STAFF !** CC: <@${staffUser.id}>` : `📢 **MISE À JOUR DE GRADE STAFF**`,
              embeds: [announceEmbed]
            }).catch(() => {});
          }

          return interaction.editReply({
            content: isUp
              ? `🎉 **Promotion effectuée avec succès !**\n\n👤 **Staff** : <@${staffUser.id}>\n📈 **Grade** : \`${oldRank}\` ➔ **\`${newRank}\`**\n📜 **Log & Annonce transmis.**`
              : `📉 **Rétrogradation enregistrée.**\n\n👤 **Staff** : <@${staffUser.id}>\n📉 **Grade** : \`${oldRank}\` ➔ **\`${newRank}\`**\n📜 **Log & Annonce transmis.**`
          });
        }

        // --- Staff Rank History Modal Submit ---
        if (customId === 'modal_staff_rank_history') {
          await interaction.deferReply({ flags: MessageFlags.Ephemeral });
          const staffInput = interaction.fields.getTextInputValue('staff_target').trim();
          let targetUserId = staffInput.replace(/[^0-9]/g, '');

          let staffUser = targetUserId ? await interaction.client.users.fetch(targetUserId).catch(() => null) : null;
          if (!staffUser) {
            const member = guild.members.cache.find(m => m.user.username.toLowerCase().includes(staffInput.toLowerCase()));
            if (member) staffUser = member.user;
          }

          const searchKey = staffUser ? staffUser.id : staffInput;
          const history = await db.getStaffRankHistory(guild.id, searchKey);

          if (!history || history.length === 0) {
            return interaction.editReply({
              content: `ℹ️ Aucun historique de promotion/grade trouvé pour \`${staffInput}\`.`
            });
          }

          const embed = new EmbedBuilder()
            .setTitle(`📜 PARCOURS & HISTORIQUE DES RANKS • ${staffUser ? staffUser.username : staffInput}`)
            .setDescription(`Voici l'historique complet des évolutions de carrière au sein du staff.\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`)
            .setColor(config.colors.gold || '#F1C40F')
            .setFooter({ text: 'Historique Carrière Staff • Hamburg RP' })
            .setTimestamp();

          history.forEach((h, idx) => {
            const symbol = h.actionType === 'promotion' ? '⬆️ PROMOTION' : '⬇️ RÉTROGRADATION';
            embed.addFields({
              name: `${symbol} #${history.length - idx} — \`${h.oldRank}\` ➔ \`${h.newRank}\``,
              value: `📝 **Motif** : ${h.reason}\n👑 **Administrateur** : <@${h.adminId}>\n📅 **Date** : <t:${Math.floor(h.createdAt / 1000)}:F>`,
              inline: false
            });
          });

          return interaction.editReply({ embeds: [embed] });
        }

        // --- Staff Absence Modal Submit ---
        if (customId === 'modal_staff_absence_add') {
          await interaction.deferReply({ flags: MessageFlags.Ephemeral });
          const startDate = interaction.fields.getTextInputValue('start_date').trim();
          const endDate = interaction.fields.getTextInputValue('end_date').trim();
          const reason = interaction.fields.getTextInputValue('reason').trim();

          await db.addStaffAbsence(
            guild.id,
            user.id,
            user.tag || user.username,
            startDate,
            endDate,
            reason
          );

          const role = await getOrCreateStaffAbsenceRole(guild);
          if (role) {
            const member = await guild.members.fetch(user.id).catch(() => null);
            if (member) await member.roles.add(role).catch(() => {});
          }

          const logChannel = await getStaffAbsenceLogChannel(guild);
          if (logChannel) {
            const logEmbed = staffAbsenceLogEmbed({
              user,
              actionType: 'declaration',
              startDate,
              endDate,
              reason
            });
            logChannel.send({ embeds: [logEmbed] }).catch(() => {});
          }

          await refreshStaffAbsenceListMessage(guild);

          return interaction.editReply({
            content: `📝 **Votre déclaration d'absence a été enregistrée avec succès !**\n\n` +
              `📅 **Période** : Du **${startDate}** au **${endDate}**\n` +
              `💬 **Motif** : ${reason}\n\n` +
              `📌 *Le rôle **Staff en Absence** vous a été attribué et le log a été transmis au Management.*`
          });
        }

        // --- Roblox Verification Modal Submit ---
        if (customId === 'modal_verify_roblox') {
          await interaction.deferReply({ flags: MessageFlags.Ephemeral });
          const usernameInput = interaction.fields.getTextInputValue('roblox_username');

          const robloxData = await fetchRobloxUser(usernameInput);
          if (!robloxData) {
            return interaction.editReply({
              content: `❌ **Compte Roblox introuvable !** Impossible de trouver un utilisateur Roblox pour \`${usernameInput}\`. Veuillez vérifier l'orthographe.`
            });
          }

          // Security Check 1: Anti-Alt / Double Account Roblox Check
          const existingDiscordUser = await db.isRobloxLinkedToAnotherDiscord(robloxData.id, user.id);
          if (existingDiscordUser) {
            // Log security warning
            const welcomeConfig = await db.getWelcomeConfig(guild.id);
            const securityChannelId = welcomeConfig?.securityLogChannelId || config.channels?.securityLogs || config.channels?.moderationLogs;
            if (securityChannelId) {
              const securityChannel = guild.channels.cache.get(securityChannelId);
              if (securityChannel) {
                const member = await guild.members.fetch(user.id);
                const alertEmbed = securityLogEmbed({
                  member,
                  robloxData,
                  status: '⛔ BLOQUÉ : TENTATIVE DE DOUBLE COMPTE',
                  details: `Le membre Discord <@${user.id}> a tenté de lier le compte Roblox \`${robloxData.name}\` (ID: \`${robloxData.id}\`) qui est DÉJÀ lié au membre Discord <@${existingDiscordUser}> !`,
                  color: config.colors.danger
                });
                securityChannel.send({ content: '🚨 **ALERTE SÉCURITÉ ANTI-ALT !**', embeds: [alertEmbed] }).catch(() => {});
              }
            }

            return interaction.editReply({
              content: `🚫 **Accès Refusé (Détection Double Compte) !**\nLe compte Roblox **${robloxData.name}** (ID: \`${robloxData.id}\`) est déjà enregistré par un autre membre du serveur.\nLes doubles comptes ne sont pas autorisés.`
            });
          }

          // Security Check 2: Account Age Check
          const accountAgeMs = Date.now() - user.createdTimestamp;
          const accountAgeDays = Math.floor(accountAgeMs / (1000 * 60 * 60 * 24));
          const welcomeConfig = await db.getWelcomeConfig(guild.id);
          const minAgeDays = welcomeConfig?.minAccountAgeDays || 7;

          let ageNotice = '';
          if (accountAgeDays < minAgeDays) {
            ageNotice = `\n\n⚠️ *Note de sécurité : Votre compte Discord est récent (${accountAgeDays} jour(s)). Un audit de sécurité a été transmis aux modérateurs.*`;

            // Security log for recent accounts
            const securityChannelId = welcomeConfig?.securityLogChannelId || config.channels?.securityLogs || config.channels?.moderationLogs;
            if (securityChannelId) {
              const securityChannel = guild.channels.cache.get(securityChannelId);
              if (securityChannel) {
                const member = await guild.members.fetch(user.id);
                const ageEmbed = securityLogEmbed({
                  member,
                  robloxData,
                  status: '⚠️ AVERTISSEMENT : COMPTE DISCORD RÉCENT',
                  details: `Compte Discord créé il y a seulement **${accountAgeDays} jour(s)** (seuil: ${minAgeDays} jours).\nCompte Roblox: ${robloxData.name} (ID: ${robloxData.id}).`,
                  color: config.colors.warning
                });
                securityChannel.send({ embeds: [ageEmbed] }).catch(() => {});
              }
            }
          }

          // Return Rules Confirmation Embed
          const rules = rulesAcceptEmbed(robloxData);
          if (ageNotice) {
            rules.embeds[0].setDescription(rules.embeds[0].data.description + ageNotice);
          }

          return interaction.editReply(rules);
        }

        // Mod Request Modal Submission
        if (customId === 'modal_request_modo') {
          const pseudo_rp = interaction.fields.getTextInputValue('pseudo_rp');
          const reason = interaction.fields.getTextInputValue('reason');
          const location = interaction.fields.getTextInputValue('location') || 'Non précisée';

          const requestId = Date.now().toString().slice(-6);
          const targetChannel = await getModRequestChannel(interaction.guild);
          const logChannel = await getModRequestLogChannel(interaction.guild);

          const staffPing = config.staffPingRole ? `<@&${config.staffPingRole}>` : '@here';

          const reqEmbed = createEmbed({
            title: `🚨 DEMANDE DE MODÉRATEUR • #${requestId}`,
            description:
              `👤 **Demandeur (Discord)** : <@${user.id}> (\`${user.tag}\`)\n` +
              `🎮 **Nom RP / Roblox** : **${pseudo_rp}**\n` +
              `📍 **Localisation in-game** : \`${location}\`\n\n` +
              `📝 **Motif de la demande** :\n\`\`\`${reason}\`\`\`\n\n` +
              `⏳ **Statut** : 🔴 En attente d'intervention Staff`,
            color: config.colors.danger,
            footer: `Demande Modo #${requestId} • Aubagne RP`
          });

          const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId(`btn_take_modo_${requestId}_${user.id}`).setLabel('Prendre en charge').setEmoji('✋').setStyle(ButtonStyle.Success),
            new ButtonBuilder().setCustomId(`btn_close_modo_${requestId}_${user.id}`).setLabel('Clôturer la demande').setEmoji('✅').setStyle(ButtonStyle.Secondary)
          );

          if (targetChannel) {
            await targetChannel.send({
              content: `${staffPing} 🚨 **Intervention Modérateur Requise !**`,
              embeds: [reqEmbed],
              components: [row]
            });
          }

          if (logChannel) {
            const logEmbed = createEmbed({
              title: `🟢 LOG: NOUVELLE DEMANDE MODO • #${requestId}`,
              description:
                `👤 **Demandeur** : <@${user.id}> (\`${user.tag}\`)\n` +
                `🎮 **Pseudo RP / Roblox** : **${pseudo_rp}**\n` +
                `📍 **Localisation** : \`${location}\`\n` +
                `📝 **Motif** : ${reason}\n` +
                `💬 **Salon Demande** : ${targetChannel}`,
              color: config.colors.success,
              footer: 'Logs Demandes Modo • Aubagne RP'
            });
            await logChannel.send({ embeds: [logEmbed] }).catch(() => {});
          }

          return interaction.reply({
            content: `✅ Votre demande de modérateur **#${requestId}** a été transmise dans le salon ${targetChannel || 'demande-de-modo'}.`,
            flags: MessageFlags.Ephemeral
          });
        }

        // Roblox Link Modal Processing
        if (customId === 'modal_link_roblox') {
          const inputQuery = interaction.fields.getTextInputValue('roblox_username');
          const robloxUser = await fetchRobloxUser(inputQuery);

          if (!robloxUser) {
            return interaction.reply({
              content: `❌ Aucun utilisateur Roblox n'a été trouvé pour **"${inputQuery}"**. Veuillez vérifier le pseudo ou l'ID Roblox.`,
              flags: MessageFlags.Ephemeral
            });
          }

          await db.linkRobloxAccount(user.id, robloxUser.name, robloxUser.id, robloxUser.displayName);

          const embed = createEmbed({
            title: '🎮 COMPTE ROBLOX LIÉ AVEC SUCCÈS !',
            description: `Le membre <@${user.id}> a lié son compte Roblox :\n\n` +
              `👤 **Pseudo Roblox** : **[${robloxUser.name}](${robloxUser.profileUrl})**\n` +
              `🏷️ **Nom d'affichage** : ${robloxUser.displayName}\n` +
              `🆔 **Roblox ID** : \`${robloxUser.id}\``,
            color: config.colors.success,
            thumbnail: robloxUser.avatarUrl
          });

          return interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
        }

        // Edit ID Modal
        if (customId === 'modal_edit_id') {
          const lastName = interaction.fields.getTextInputValue('nom');
          const firstName = interaction.fields.getTextInputValue('prenom');
          const age = parseInt(interaction.fields.getTextInputValue('age')) || 25;
          const job = interaction.fields.getTextInputValue('emploi');

          await db.updateProfile(user.id, lastName, firstName, age, job);
          return interaction.reply({
            embeds: [createEmbed({
              title: '✅ IDENTITÉ RP MISE À JOUR',
              description: `👤 Nom : **${firstName} ${lastName.toUpperCase()}**\n🎂 Âge : **${age} ans**\n💼 Emploi : **${job}**`,
              color: config.colors.success
            })],
            flags: MessageFlags.Ephemeral
          });
        }

        // 911 Call Modals
        if (customId.startsWith('modal_911_')) {
          const service = customId.replace('modal_911_', '');
          const location = interaction.fields.getTextInputValue('location');
          const description = interaction.fields.getTextInputValue('description');
          callCounter++;

          const payload = dispatch911Embed({
            caller: `${user} (${user.tag})`,
            service,
            location,
            description,
            callId: callCounter
          });

          await interaction.reply({ content: `✅ Appel 911 **#${callCounter}** émis avec succès.`, flags: MessageFlags.Ephemeral });
          return interaction.channel.send(payload);
        }

        // Wanted Add Modal
        if (customId === 'modal_wanted_add') {
          const target = interaction.fields.getTextInputValue('target');
          const reason = interaction.fields.getTextInputValue('reason');
          const danger = parseInt(interaction.fields.getTextInputValue('danger')) || 3;
          const bounty = parseInt(interaction.fields.getTextInputValue('bounty')) || 0;

          await db.addWanted(target, null, reason, danger, bounty, user.id);
          const stars = '⭐'.repeat(danger);

          return interaction.reply({
            embeds: [createEmbed({
              title: '🚨 POLIZEI HAMBURG • AVIS DE RECHERCHE',
              description: `👤 **Recherché** : **${target}**\n⚠️ **Danger** : ${stars}\n📝 **Motif** : ${reason}\n💰 **Prime** : ${bounty} ${config.currencySymbol}\n👮 par <@${user.id}>`,
              color: config.colors.danger
            })]
          });
        }

        // Wanted Remove Modal
        if (customId === 'modal_wanted_remove') {
          const target = interaction.fields.getTextInputValue('target');
          const success = await db.removeWanted(target);
          if (!success) {
            return interaction.reply({ content: `❌ Aucun avis actif trouvé pour **${target}**.`, flags: MessageFlags.Ephemeral });
          }
          return interaction.reply({
            embeds: [createEmbed({
              title: '✅ AVIS DE RECHERCHE CLÔTURÉ',
              description: `L'individu **${target}** n'est plus recherché.`,
              color: config.colors.success
            })]
          });
        }

        // Amende Modal
        if (customId === 'modal_fine_add') {
          const target = interaction.fields.getTextInputValue('target');
          const amount = parseInt(interaction.fields.getTextInputValue('amount')) || 100;
          const reason = interaction.fields.getTextInputValue('reason');

          await db.addFine(target, null, amount, reason, user.id);
          return interaction.reply({
            embeds: [createEmbed({
              title: '📜 CONTRAVENTION POLICE HAMBURG',
              description: `👤 **Citoyen** : **${target}**\n💵 **Montant** : **${amount} ${config.currencySymbol}**\n📝 **Motif** : ${reason}\n👮 Agent: <@${user.id}>`,
              color: config.colors.warning
            })]
          });
        }

        // Police Casier Modal Submit
        if (customId === 'modal_police_casier') {
          const targetName = interaction.fields.getTextInputValue('target');
          const fines = await db.getFinesHistory(targetName);

          if (!fines || fines.length === 0) {
            return interaction.reply({
              embeds: [createEmbed({
                title: `📁 CASIER JUDICIAIRE • ${targetName}`,
                description: `✅ Le casier judiciaire de **${targetName}** est vierge. Aucune amende enregistrée.`,
                color: config.colors.success
              })]
            });
          }

          let total = 0;
          let desc = '';
          for (const f of fines) {
            total += f.amount;
            desc += `📌 **${f.amount} ${config.currencySymbol}** — Motif: *${f.reason}* (<t:${Math.floor(f.createdAt / 1000)}:d> par <@${f.officerId}>)\n`;
          }

          const embed = createEmbed({
            title: `📁 CASIER JUDICIAIRE • ${targetName}`,
            description: `**Montant total d'amendes enregistrées : ${total} ${config.currencySymbol}**\n\n${desc}`,
            color: config.colors.danger
          });

          return interaction.reply({ embeds: [embed] });
        }

        // Police Fourriere Modal Submit
        if (customId === 'modal_police_fourriere') {
          const vehicle = interaction.fields.getTextInputValue('vehicle');
          const plate = interaction.fields.getTextInputValue('plate');
          const owner = interaction.fields.getTextInputValue('owner');
          const reason = interaction.fields.getTextInputValue('reason');
          const fee = parseInt(interaction.fields.getTextInputValue('fee')) || 500;

          const embed = createEmbed({
            title: '🛞 AVIS DE MISE EN FOURRIÈRE (ADAC / POLIZEI)',
            description: `Un véhicule a été saisi et transféré à la fourrière centrale.\n\n` +
              `🚘 **Véhicule** : ${vehicle}\n` +
              `🔢 **Plaque** : \`${plate.toUpperCase()}\`\n` +
              `👤 **Propriétaire** : ${owner}\n` +
              `📝 **Motif** : ${reason}\n` +
              `💶 **Frais de libération** : **${fee} ${config.currencySymbol}**\n` +
              `👮 Agent : <@${user.id}>`,
            color: config.colors.adac
          });

          return interaction.reply({ embeds: [embed] });
        }

        // Braquage Alert Modal Submit
        if (customId === 'modal_braquage_alert') {
          const location = interaction.fields.getTextInputValue('location');
          const details = interaction.fields.getTextInputValue('details');

          const staffPing = config.staffPingRole ? `<@&${config.staffPingRole}>` : '@here';

          const embed = createEmbed({
            title: '🚨 ALERTE CODE 10-90 • BRAQUAGE EN COURS !',
            description: `Une alerte braquage critique a été déclenchée !\n\n` +
              `📍 **Localisation** : \`${location}\`\n` +
              `📝 **Détails & Suspects** :\n\`\`\`${details}\`\`\`\n` +
              `👮 Signalé par : <@${user.id}>\n\n` +
              `📢 **Forces de l'Ordre (Police / SWAT)** : Intervenez immédiatement !`,
            color: config.colors.danger
          });

          await interaction.reply({ content: `🚨 **ALERTE BRAQUAGE ÉMISE !**`, flags: MessageFlags.Ephemeral });
          return interaction.channel.send({
            content: `${staffPing} 🚨 **ALERTE BRAQUAGE CODE 10-90 !**`,
            embeds: [embed]
          });
        }

        // Pompier Report Modal Submit
        if (customId === 'modal_fire_report') {
          const location = interaction.fields.getTextInputValue('location');
          const type = interaction.fields.getTextInputValue('type');
          const vehicles = interaction.fields.getTextInputValue('vehicles');
          const bilan = interaction.fields.getTextInputValue('bilan');

          const embed = createEmbed({
            title: '📝 RAPPORT D\'INTERVENTION • FEUERWEHR',
            description: `Un rapport d'intervention sapeurs-pompiers a été enregistré par <@${user.id}>.\n\n` +
              `📍 **Localisation** : \`${location}\`\n` +
              `🔥 **Type d'intervention** : **${type}**\n` +
              `🚒 **Engins engagés** : \`${vehicles}\`\n\n` +
              `📋 **Bilan & Compte-Rendu** :\n\`\`\`${bilan}\`\`\``,
            color: config.colors.fire
          });

          return interaction.reply({ embeds: [embed] });
        }

        // Pompier Alert Modal Submit
        if (customId === 'modal_fire_alert') {
          const location = interaction.fields.getTextInputValue('location');
          const details = interaction.fields.getTextInputValue('details');

          const staffPing = config.staffPingRole ? `<@&${config.staffPingRole}>` : '@here';

          const embed = createEmbed({
            title: '🔥 ALERTE CODE ROUGE • INCENDIE MAJEUR !',
            description: `Une alerte incendie critique a été transmise à la centrale des secours !\n\n` +
              `📍 **Localisation** : \`${location}\`\n` +
              `📝 **Nature & Risques** :\n\`\`\`${details}\`\`\`\n` +
              `🚒 Signalé par : <@${user.id}>\n\n` +
              `📢 **Sapeurs-Pompiers (Feuerwehr)** : Mobilisez vos casernes immédiatement !`,
            color: config.colors.fire
          });

          await interaction.reply({ content: `🔥 **ALERTE INCENDIE ÉMISE !**`, flags: MessageFlags.Ephemeral });
          return interaction.channel.send({
            content: `${staffPing} 🔥 **ALERTE CODE ROUGE INCENDIE !**`,
            embeds: [embed]
          });
        }

        // Pompier Inspection Modal Submit
        if (customId === 'modal_fire_inspection') {
          const building = interaction.fields.getTextInputValue('building');
          const status = interaction.fields.getTextInputValue('status');
          const notes = interaction.fields.getTextInputValue('notes');

          const isFav = status.toLowerCase().includes('favor');

          const embed = createEmbed({
            title: '🧯 PROCÈS-VERBAL D\'INSPECTION SÉCURITÉ INCENDIE',
            description: `Rapport d'inspection de prévention incendie par <@${user.id}>.\n\n` +
              `🏢 **Établissement** : **${building}**\n` +
              `📊 **Avis de la commission** : ${isFav ? '✅ **FAVORABLE**' : '🔴 **DÉFAVORABLE / RÉRERVES**'}\n\n` +
              `📝 **Remarques & Exigences** :\n\`\`\`${notes}\`\`\``,
            color: isFav ? config.colors.success : config.colors.danger
          });

          return interaction.reply({ embeds: [embed] });
        }

        // Pompier EMS Reinforcement Modal Submit
        if (customId === 'modal_fire_ems') {
          const location = interaction.fields.getTextInputValue('location');
          const condition = interaction.fields.getTextInputValue('condition');

          const staffPing = config.staffPingRole ? `<@&${config.staffPingRole}>` : '@here';

          const embed = createEmbed({
            title: '🚑 DEMANDE DE RENFORT MÉDICAL EMS URGENT',
            description: `Une demande d'ambulance et d'équipe médicale a été émise sur zone !\n\n` +
              `📍 **Localisation** : \`${location}\`\n` +
              `📋 **État des victimes** :\n\`\`\`${condition}\`\`\`\n` +
              `🚒 Demandé par : <@${user.id}>`,
            color: config.colors.ems
          });

          await interaction.reply({ content: `🚑 **DEMANDE RENFORT EMS ÉMISE !**`, flags: MessageFlags.Ephemeral });
          return interaction.channel.send({
            content: `${staffPing} 🚑 **RENFORT EMS REQUIS SUR ZONE !**`,
            embeds: [embed]
          });
        }

        // HARS Report Modal Submit
        if (customId === 'modal_hars_report') {
          const vehicle = interaction.fields.getTextInputValue('vehicle');
          const owner = interaction.fields.getTextInputValue('owner');
          const service = interaction.fields.getTextInputValue('service');
          const fee = parseInt(interaction.fields.getTextInputValue('fee')) || 300;

          const embed = createEmbed({
            title: '🛞 FICHE D\'INTERVENTION DÉPANNAGE • HARS & ADAC',
            description: `Un dépannage routier a été réalisé et clôturé par <@${user.id}>.\n\n` +
              `🚘 **Véhicule** : ${vehicle}\n` +
              `👤 **Client / Propriétaire** : ${owner}\n` +
              `🛠️ **Prestation** : ${service}\n` +
              `💵 **Tarif facturé** : **${fee} ${config.currencySymbol}**`,
            color: config.colors.adac
          });

          return interaction.reply({ embeds: [embed] });
        }

        // HARS Tow Modal Submit
        if (customId === 'modal_hars_tow') {
          const location = interaction.fields.getTextInputValue('location');
          const vehicle = interaction.fields.getTextInputValue('vehicle');

          const embed = createEmbed({
            title: '🛠️ ORDRE DE REMORQUAGE EN URGENCE',
            description: `Un véhicule nécessite un remorquage prioritaire vers le garage ADAC !\n\n` +
              `📍 **Localisation** : \`${location}\`\n` +
              `🚘 **Véhicule concerné** : **${vehicle}**\n` +
              `👨‍🔧 Demandé par : <@${user.id}>`,
            color: config.colors.adac
          });

          return interaction.reply({ embeds: [embed] });
        }

        // HARS Medical Modal Submit
        if (customId === 'modal_hars_medical') {
          const patient = interaction.fields.getTextInputValue('patient');
          const diagnosis = interaction.fields.getTextInputValue('diagnosis');
          const status = interaction.fields.getTextInputValue('status');

          const embed = createEmbed({
            title: '🚑 FICHE MÉDICALE D\'ADMISSION DISPATCH • EMS',
            description: `Une prise en charge médicale a été effectuée par <@${user.id}>.\n\n` +
              `👤 **Patient / Victime** : **${patient}**\n` +
              `🏥 **Statut du patient** : **${status}**\n\n` +
              `📋 **Diagnostic & Traitement** :\n\`\`\`${diagnosis}\`\`\``,
            color: config.colors.ems
          });

          return interaction.reply({ embeds: [embed] });
        }

        // HARS Hazard Modal Submit
        if (customId === 'modal_hars_hazard') {
          const location = interaction.fields.getTextInputValue('location');
          const hazard = interaction.fields.getTextInputValue('hazard');

          const embed = createEmbed({
            title: '🚨 ALERTE SÉCURITÉ ROUTIÈRE • VOIE BLOQUÉE',
            description: `Un obstacle ou danger majeur perturbe la circulation à Hamburg !\n\n` +
              `📍 **Localisation** : \`${location}\`\n` +
              `⚠️ **Nature du problème** :\n\`\`\`${hazard}\`\`\`\n` +
              `🛞 Balisage & Signalisation par : <@${user.id}>`,
            color: config.colors.warning
          });

          return interaction.reply({ embeds: [embed] });
        }

        // Pompier Fuel Spill Modal Submit
        if (customId === 'modal_fire_fuel') {
          const location = interaction.fields.getTextInputValue('location');
          const extent = interaction.fields.getTextInputValue('extent');

          const embed = createEmbed({
            title: '⛽ ALERTE POLLUTION & RISQUE GLISSADE • POLIZEI / FEUERWEHR',
            description: `Un épandage d'essence ou produit glissant sur chaussée a été signalé !\n\n` +
              `📍 **Localisation** : \`${location}\`\n` +
              `⚠️ **Surface & Risque** :\n\`\`\`${extent}\`\`\`\n` +
              `🚒 **Action Pompiers / Voirie** : Épandage d'absorbant & balisage de sécurité en cours par <@${user.id}>.`,
            color: config.colors.warning
          });

          return interaction.reply({ embeds: [embed] });
        }

        // Pompier Cargo Debris Modal Submit
        if (customId === 'modal_fire_debris') {
          const location = interaction.fields.getTextInputValue('location');
          const description = interaction.fields.getTextInputValue('description');

          const embed = createEmbed({
            title: '📦 ALERTE CHARGEMENT / OBJET TOMBÉ SUR VOIE',
            description: `Des encombrants ou marchandises tombées d'un poids-lourd entravent la route !\n\n` +
              `📍 **Localisation** : \`${location}\`\n` +
              `📝 **Description des objets** :\n\`\`\`${description}\`\`\`\n` +
              `🚒 **Sapeurs-Pompiers & ADAC** : Intervention d'évacuation par <@${user.id}>.`,
            color: config.colors.fire
          });

          return interaction.reply({ embeds: [embed] });
        }

        // HARS Traffic Light Modal Submit
        if (customId === 'modal_hars_traffic_light') {
          const intersection = interaction.fields.getTextInputValue('intersection');
          const details = interaction.fields.getTextInputValue('details');

          const embed = createEmbed({
            title: '🚦 SIGNALEMENT PANNE FEUX TRICOLORES • INFRASTRUCTURE ADAC',
            description: `Une panne ou destruction de feux tricolores a été déclarée !\n\n` +
              `📍 **Carrefour / Intersection** : \`${intersection}\`\n` +
              `⚠️ **Détails du problème** :\n\`\`\`${details}\`\`\`\n` +
              `🛠️ **ADAC / Voirie** : Équipe technique dépêchée sur place par <@${user.id}>.\n` +
              `👮 **Police** : Régulation manuelle recommandée.`,
            color: config.colors.adac
          });

          return interaction.reply({ embeds: [embed] });
        }

        // HARS Train Barrier Modal Submit
        if (customId === 'modal_hars_train_barrier') {
          const crossing = interaction.fields.getTextInputValue('crossing');
          const details = interaction.fields.getTextInputValue('details');

          const staffPing = config.staffPingRole ? `<@&${config.staffPingRole}>` : '@here';

          const embed = createEmbed({
            title: '🚂 ALERTE CRITIQUE • BARRIÈRES TRAIN / PASSAGE À NIVEAU H.S.',
            description: `Dysfonctionnement grave des barrières de sécurité ferroviaires !\n\n` +
              `📍 **Passage à Niveau** : \`${crossing}\`\n` +
              `⚠️ **Rapport d'anomalie** :\n\`\`\`${details}\`\`\`\n` +
              `🚨 **DANGER TRAIN** : Sécurisation d'urgence par <@${user.id}> !\n` +
              `📢 **Police & ADAC** : Intervenez pour bloquer le passage des véhicules !`,
            color: config.colors.danger
          });

          await interaction.reply({ content: `🚨 **ALERTE PASSAGE À NIVEAU ÉMISE !**`, flags: MessageFlags.Ephemeral });
          return interaction.channel.send({
            content: `${staffPing} 🚂 **ALERTE FERROVIAIRE URGENTE !**`,
            embeds: [embed]
          });
        }

        // Joint Dispatch Radio Inter-Services Modal Submit
        if (customId === 'modal_joint_dispatch') {
          const service = interaction.fields.getTextInputValue('service');
          const location = interaction.fields.getTextInputValue('location');
          const requestedFactions = interaction.fields.getTextInputValue('requested_factions');
          const instructions = interaction.fields.getTextInputValue('instructions');

          const staffPing = config.staffPingRole ? `<@&${config.staffPingRole}>` : '@here';

          const embed = createEmbed({
            title: '📡 RADIO INTER-SERVICES • OPÉRATION CONJOINTE MULTI-FACTIONS',
            description: `Un appel de coordination inter-services a été transmitted !\n\n` +
              `📻 **Service Émetteur** : **${service}** (Agent <@${user.id}>)\n` +
              `📍 **Localisation** : \`${location}\`\n` +
              `🤝 **Factions Requises** : \`${requestedFactions}\`\n\n` +
              `📋 **Consignes & Plan d'Action** :\n\`\`\`${instructions}\`\`\`\n` +
              `💬 *Toutes les unités (Police 🚓, Pompiers 🚒, HARS/ADAC 🛞) basculent sur le canal radio commun !*`,
            color: config.colors.primary
          });

          await interaction.reply({ content: `📡 **MESSAGE RADIO INTER-SERVICES TRANSMIS !**`, flags: MessageFlags.Ephemeral });
          return interaction.channel.send({
            content: `${staffPing} 📡 **CANAL RADIO INTER-SERVICES ACTIF !**`,
            embeds: [embed]
          });
        }

        // TV Breaking News Modal Submit
        if (customId === 'modal_tv_breaking') {
          const headline = interaction.fields.getTextInputValue('headline');
          const details = interaction.fields.getTextInputValue('details');

          const embed = createEmbed({
            title: '🔴 FLASH INFO URGENT • HAMBURG TV',
            description: `**ÉDITION SPÉCIALE HORS-SÉRIE**\n\n` +
              `📢 **${headline.toUpperCase()}**\n\n` +
              `\`\`\`${details}\`\`\`\n` +
              `🎥 *En direct du studio Hamburg News avec <@${user.id}>*`,
            color: '#ED4245'
          });

          await interaction.reply({ content: '🔴 **FLASH INFO ÉMIS AVEC SUCCÈS !**', flags: MessageFlags.Ephemeral });
          return interaction.channel.send({ content: '@everyone 🔴 **FLASH INFO EN DIRECT !**', embeds: [embed] });
        }

        // TV News Article Modal Submit
        if (customId === 'modal_tv_news') {
          const title = interaction.fields.getTextInputValue('title');
          const author = interaction.fields.getTextInputValue('author');
          const content = interaction.fields.getTextInputValue('content');

          const embed = createEmbed({
            title: `📺 JOURNAL TÉLÉVISÉ • ${title.toUpperCase()}`,
            description: `📰 **Édition Hamburg RP** | Rédigé par **${author}** (<@${user.id}>)\n\n` +
              `${content}\n\n` +
              `*© Rédaction Hamburg News • Droits réservés*`,
            color: '#9C27B0'
          });

          return interaction.reply({ embeds: [embed] });
        }

        // TV Interview Modal Submit
        if (customId === 'modal_tv_interview') {
          const target = interaction.fields.getTextInputValue('target');
          const subject = interaction.fields.getTextInputValue('subject');

          const embed = createEmbed({
            title: '🎤 DEMANDE D\'INTERVIEW EXCLUSIVE • HAMBURG TV',
            description: `La rédaction souhaite organiser une interview en plateau ou en direct.\n\n` +
              `👤 **Invité pressenti** : **${target}**\n` +
              `📝 **Sujets & Thèmes** :\n\`\`\`${subject}\`\`\`\n` +
              `🎥 Demandé par le journaliste <@${user.id}>`,
            color: config.colors.primary
          });

          return interaction.reply({ embeds: [embed] });
        }

        // TV Witness Modal Submit
        if (customId === 'modal_tv_witness') {
          const topic = interaction.fields.getTextInputValue('topic');
          const contact = interaction.fields.getTextInputValue('contact');

          const embed = createEmbed({
            title: '📸 APPEL À TÉMOINS • HAMBURG NEWS',
            description: `La rédaction recherche des témoignages, photos ou vidéos RP !\n\n` +
              `📌 **Événement recherché** : **${topic}**\n` +
              `📞 **Consignes & Contact** :\n\`\`\`${contact}\`\`\`\n` +
              `🎥 Publié par <@${user.id}>`,
            color: config.colors.gold
          });

          return interaction.reply({ embeds: [embed] });
        }

        // Darkweb Modal
        if (customId === 'modal_darkweb') {
          const message = interaction.fields.getTextInputValue('message');
          const embed = createEmbed({
            title: '🌐 DARKWEB HAMBURG • ANNONCE CRYPTÉE',
            description: `\`\`\`${message}\`\`\`\n*🔒 Identité masquée — IP Tor Anonymisée*`,
            color: config.colors.darkweb
          });
          await interaction.reply({ content: '✅ Message anonyme envoyé sur le Darkweb.', flags: MessageFlags.Ephemeral });
          return interaction.channel.send({ embeds: [embed] });
        }
      }
    } catch (err) {
      console.error('Erreur globale interactionCreate:', err);
    }
  }
};
