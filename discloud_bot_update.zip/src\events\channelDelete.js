const { EmbedBuilder, AuditLogEvent } = require('discord.js');
const { sendAuditLog } = require('../utils/auditLogger');
const config = require('../../config.json');

module.exports = {
  name: 'channelDelete',
  async execute(channel) {
    try {
      if (!channel.guild) return;

      const embed = new EmbedBuilder()
        .setTitle('🗑️ LOG AUDIT : SUPPRESSION D\'UN SALON')
        .setColor(config.colors?.danger || '#E53935')
        .addFields(
          { name: '📍 Salon supprimé', value: `\`#${channel.name}\` (\`ID: ${channel.id}\`)`, inline: false },
          { name: '📁 Type', value: `\`${channel.type}\``, inline: true }
        )
        .setFooter({ text: `Channel ID: ${channel.id} • Hamburg RP` })
        .setTimestamp();

      try {
        const fetchedLogs = await channel.guild.fetchAuditLogs({
          limit: 1,
          type: AuditLogEvent.ChannelDelete,
        });
        const auditEntry = fetchedLogs.entries.first();
        if (auditEntry && (Date.now() - auditEntry.createdTimestamp) < 5000) {
          embed.addFields({ name: '👮 Supprimé par', value: `<@${auditEntry.executor.id}> (\`${auditEntry.executor.tag}\`)`, inline: false });
        }
      } catch (e) {}

      await sendAuditLog(channel.guild, embed);
    } catch (error) {
      console.error('❌ Erreur dans l\'événement channelDelete:', error);
    }
  }
};
