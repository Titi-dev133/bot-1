const { SlashCommandBuilder, PermissionFlagsBits, MessageFlags } = require('discord.js');
const { suggestionPanelEmbed, suggestionCardEmbed, suggestionLogEmbed } = require('../utils/embeds');
const db = require('../database/db');

module.exports = [
  {
    data: new SlashCommandBuilder()
      .setName('suggestion')
      .setDescription('Système officiel de suggestions et boîte à idées de la communauté.')
      .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
      .addSubcommand(sub =>
        sub.setName('dashboard')
           .setDescription('Publie le panneau de la Boîte à Suggestions dans ce salon (avec le bouton "Proposer").')
      )
      .addSubcommand(sub =>
        sub.setName('traiter')
           .setDescription('Accepter, refuser ou mettre à jour le statut d\'une suggestion.')
           .addIntegerOption(opt =>
             opt.setName('id')
                .setDescription('ID de la suggestion (ex: 1, 2)')
                .setRequired(true)
           )
           .addStringOption(opt =>
             opt.setName('statut')
                .setDescription('Décision du staff')
                .setRequired(true)
                .addChoices(
                  { name: '🟢 Accepter (ACCEPTED)', value: 'ACCEPTED' },
                  { name: '🔴 Refuser (REJECTED)', value: 'REJECTED' },
                  { name: '🛠️ En cours d\'implémentation (IN_PROGRESS)', value: 'IN_PROGRESS' }
                )
           )
           .addStringOption(opt =>
             opt.setName('motif')
                .setDescription('Motif ou réponse officielle du staff')
                .setRequired(false)
           )
      )
      .addSubcommand(sub =>
        sub.setName('fusionner')
           .setDescription('Regrouper / fusionner une suggestion similaire vers une suggestion principale.')
           .addIntegerOption(opt =>
             opt.setName('source_id')
                .setDescription('ID de la suggestion à fusionner (qui sera absorbée)')
                .setRequired(true)
           )
           .addIntegerOption(opt =>
             opt.setName('cible_id')
                .setDescription('ID de la suggestion principale (qui reçoit les propositions et votes)')
                .setRequired(true)
           )
      ),

    async execute(interaction) {
      const subcommand = interaction.options.getSubcommand();
      const { guild, channel, user } = interaction;

      // 1. Subcommand: dashboard
      if (subcommand === 'dashboard') {
        const oldDash = await db.getSuggestionDashboard(guild.id);
        if (oldDash) {
          try {
            const oldChan = guild.channels.cache.get(oldDash.channelId);
            if (oldChan) {
              const oldMsg = await oldChan.messages.fetch(oldDash.messageId).catch(() => null);
              if (oldMsg) await oldMsg.delete().catch(() => {});
            }
          } catch (e) {}
        }

        const payload = suggestionPanelEmbed();
        const msg = await channel.send(payload);
        await db.saveSuggestionDashboard(guild.id, channel.id, msg.id);

        return interaction.reply({
          content: `✅ **Panneau de Boîte à Suggestions publié avec succès dans ${channel} !**`,
          flags: MessageFlags.Ephemeral
        });
      }

      // 2. Subcommand: traiter
      if (subcommand === 'traiter') {
        await interaction.deferReply({ flags: MessageFlags.Ephemeral });

        const suggestionId = interaction.options.getInteger('id');
        const newStatus = interaction.options.getString('statut');
        const reason = interaction.options.getString('motif') || null;

        const suggestion = await db.getSuggestionRecord(suggestionId);
        if (!suggestion) {
          return interaction.editReply({
            content: `❌ Aucune suggestion trouvée avec l'ID **#${suggestionId}**.`
          });
        }

        // Update DB
        const updatedSuggestion = await db.updateSuggestionStatusRecord(suggestionId, newStatus, user.id, reason);

        // Fetch author user
        const authorUser = await interaction.client.users.fetch(suggestion.authorId).catch(() => null);

        // Update card in #suggestions channel
        let suggestionsChannel = guild.channels.cache.get(suggestion.channelId);
        if (!suggestionsChannel) {
          suggestionsChannel = guild.channels.cache.find(
            c => c.type === ChannelType.GuildText && (
              c.name.toLowerCase() === 'suggestions' ||
              c.name.toLowerCase() === 'suggestion' ||
              c.name.toLowerCase().includes('suggestion')
            )
          );
        }

        if (suggestionsChannel && suggestion.messageId) {
          try {
            const cardMsg = await suggestionsChannel.messages.fetch(suggestion.messageId).catch(() => null);
            if (cardMsg) {
              if (newStatus === 'ACCEPTED' || newStatus === 'REJECTED') {
                await cardMsg.delete().catch(() => {});
              } else {
                const cardPayload = suggestionCardEmbed({
                  suggestion: updatedSuggestion,
                  authorUser,
                  processedUser: user
                });
                await cardMsg.edit(cardPayload);
              }
            }
          } catch (e) {
            console.error('Erreur lors de la mise à jour de la suggestion:', e);
          }
        }

        // Log into #log-suggestions
        let logSuggestionsChannel = guild.channels.cache.find(
          c => c.type === ChannelType.GuildText && (
            c.name.toLowerCase() === 'log-suggestions' ||
            c.name.toLowerCase() === 'logs-suggestions' ||
            c.name.toLowerCase() === 'log-suggestion' ||
            c.name.toLowerCase().includes('log-suggestion')
          )
        );

        if (logSuggestionsChannel) {
          const logEmbed = suggestionLogEmbed({
            suggestion: updatedSuggestion,
            authorUser,
            staffUser: user,
            status: newStatus,
            reason
          });
          logSuggestionsChannel.send({ embeds: [logEmbed] }).catch(() => {});
        }

        const statusLabels = {
          ACCEPTED: '🟢 Acceptée',
          REJECTED: '🔴 Refusée',
          IN_PROGRESS: '🛠️ En cours d\'implémentation'
        };

        return interaction.editReply({
          content: `✅ **Suggestion #${suggestionId} mise à jour avec succès !**\n📌 Nouveau statut : **${statusLabels[newStatus] || newStatus}**`
        });
      }

      // 3. Subcommand: fusionner
      if (subcommand === 'fusionner') {
        await interaction.deferReply({ flags: MessageFlags.Ephemeral });

        const sourceId = interaction.options.getInteger('source_id');
        const targetId = interaction.options.getInteger('cible_id');

        if (sourceId === targetId) {
          return interaction.editReply({ content: '⚠️ Les IDs source et cible doivent être différents.' });
        }

        const source = await db.getSuggestionRecord(sourceId);
        const target = await db.getSuggestionRecord(targetId);

        if (!source || !target) {
          return interaction.editReply({ content: '❌ L\'une des deux suggestions est introuvable.' });
        }

        const updatedTarget = await db.mergeSuggestionsRecord(sourceId, targetId, user.id);

        // Update target card in #suggestions
        let suggestionsChannel = guild.channels.cache.get(target.channelId);
        if (suggestionsChannel && target.messageId) {
          try {
            const cardMsg = await suggestionsChannel.messages.fetch(target.messageId).catch(() => null);
            if (cardMsg) {
              const authorUser = await interaction.client.users.fetch(target.authorId).catch(() => null);
              const cardPayload = suggestionCardEmbed({ suggestion: updatedTarget, authorUser });
              await cardMsg.edit(cardPayload);
            }
          } catch (e) {}
        }

        // Delete or update source card
        let sourceChannel = guild.channels.cache.get(source.channelId);
        if (sourceChannel && source.messageId) {
          try {
            const sourceMsg = await sourceChannel.messages.fetch(source.messageId).catch(() => null);
            if (sourceMsg) await sourceMsg.delete().catch(() => {});
          } catch (e) {}
        }

        // Audit log in #log-suggestions
        let logSuggestionsChannel = guild.channels.cache.find(
          c => c.type === ChannelType.GuildText && (
            c.name.toLowerCase().includes('log-suggestion')
          )
        );

        if (logSuggestionsChannel) {
          const logEmbed = suggestionLogEmbed({
            suggestion: updatedTarget,
            authorUser: await interaction.client.users.fetch(source.authorId).catch(() => null),
            staffUser: user,
            status: 'MERGED',
            reason: `Fusion manuelle de la suggestion #${sourceId} ("${source.title}") vers #${targetId} ("${target.title}").`
          });
          logSuggestionsChannel.send({ embeds: [logEmbed] }).catch(() => {});
        }

        return interaction.editReply({
          content: `🔀 **Suggestion #${sourceId} fusionnée avec succès dans la suggestion #${targetId} !**\nLes propositions et les votes ont été centralisés sur la fiche #${targetId}.`
        });
      }
    }
  }
];
