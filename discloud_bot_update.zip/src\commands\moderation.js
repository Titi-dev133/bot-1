const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const db = require('../database/db');
const { createEmbed } = require('../utils/embeds');
const { createSupportTicketDashboard, createModRequestDashboard } = require('../utils/dashboards');
const config = require('../../config.json');

module.exports = [
  // 1. /bot-status
  {
    data: new SlashCommandBuilder()
      .setName('bot-status')
      .setDescription('Consulter l\'état du bot, le ping et les performances.'),
    async execute(interaction) {
      const ping = interaction.client.ws.ping;
      const uptime = Math.floor(interaction.client.uptime / 1000);
      const hours = Math.floor(uptime / 3600);
      const mins = Math.floor((uptime % 3600) / 60);

      const embed = createEmbed({
        title: '🤖 ÉTAT TECHNIQUE DU BOT',
        description: `Informations sur le système et le serveur Discord :\n\n` +
          `📡 **Latence API Discord** : \`${ping} ms\`\n` +
          `⏱️ **Temps d'activité (Uptime)** : \`${hours}h ${mins}m\`\n` +
          `🏠 **Serveurs actifs** : \`${interaction.client.guilds.cache.size}\`\n` +
          `👥 **Membres gérés** : \`${interaction.guild.memberCount}\``,
        color: config.colors.primary
      });

      await interaction.reply({ embeds: [embed] });
    }
  },

  // 2. /clear
  {
    data: new SlashCommandBuilder()
      .setName('clear')
      .setDescription('Supprimer rapidement un nombre de messages dans le salon.')
      .addIntegerOption(opt => opt.setName('nombre').setDescription('Nombre de messages à supprimer (1 à 100)').setRequired(true).setMinValue(1).setMaxValue(100))
      .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),
    async execute(interaction) {
      const count = interaction.options.getInteger('nombre');
      const deleted = await interaction.channel.bulkDelete(count, true);

      await interaction.reply({
        content: `🧹 **${deleted.size}** message(s) ont été supprimés du salon.`
      });
    }
  },

  // 3. /warn
  {
    data: new SlashCommandBuilder()
      .setName('warn')
      .setDescription('Attribuer un avertissement staff à un joueur.')
      .addUserOption(opt => opt.setName('membre').setDescription('Membre à avertir').setRequired(true))
      .addStringOption(opt => opt.setName('raison').setDescription('Raison de l\'avertissement').setRequired(true))
      .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),
    async execute(interaction) {
      const target = interaction.options.getUser('membre');
      const reason = interaction.options.getString('raison');

      await db.addWarning(target.id, interaction.user.id, reason);
      const warnings = await db.getWarnings(target.id);

      const embed = createEmbed({
        title: '⚠️ AVERTISSEMENT STAFF',
        description: `Un avertissement a été attribué à <@${target.id}> par <@${interaction.user.id}>.\n\n` +
          `📝 **Raison** : ${reason}\n` +
          `📊 **Total d'avertissements actifs** : **${warnings.length} warn(s)**`,
        color: config.colors.warning
      });

      await interaction.reply({ embeds: [embed] });
    }
  },

  // 4. /warnings
  {
    data: new SlashCommandBuilder()
      .setName('warnings')
      .setDescription('Consulter la liste des avertissements d\'un joueur.')
      .addUserOption(opt => opt.setName('membre').setDescription('Membre à consulter').setRequired(true)),
    async execute(interaction) {
      const target = interaction.options.getUser('membre');
      const list = await db.getWarnings(target.id);

      if (!list || list.length === 0) {
        return interaction.reply({
          embeds: [createEmbed({
            title: `🛡️ AVERTISSEMENTS • ${target.username}`,
            description: `✅ Ce joueur n'a aucun avertissement dans son dossier.`,
            color: config.colors.success
          })]
        });
      }

      let desc = '';
      for (let i = 0; i < list.length; i++) {
        const w = list[i];
        desc += `**#${i + 1}** — *${w.reason}* (Par <@${w.moderatorId}> le <t:${Math.floor(w.createdAt / 1000)}:d>)\n`;
      }

      const embed = createEmbed({
        title: `🛡️ DOSSIER DISCIPLINAIRE • ${target.username}`,
        description: desc,
        color: config.colors.danger
      });

      await interaction.reply({ embeds: [embed] });
    }
  },

  // 5. /unwarn
  {
    data: new SlashCommandBuilder()
      .setName('unwarn')
      .setDescription('Effacer tous les avertissements d\'un membre.')
      .addUserOption(opt => opt.setName('membre').setDescription('Membre à gracier').setRequired(true))
      .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),
    async execute(interaction) {
      const target = interaction.options.getUser('membre');
      await db.clearWarnings(target.id);

      const embed = createEmbed({
        title: '✅ AVERTISSEMENTS REINITIALISES',
        description: `Tous les avertissements de <@${target.id}> ont été effacés du système par <@${interaction.user.id}>.`,
        color: config.colors.success
      });

      await interaction.reply({ embeds: [embed] });
    }
  },

  // 6. /kick
  {
    data: new SlashCommandBuilder()
      .setName('kick')
      .setDescription('Expulser un membre du serveur Discord.')
      .addUserOption(opt => opt.setName('membre').setDescription('Membre à expulser').setRequired(true))
      .addStringOption(opt => opt.setName('raison').setDescription('Motif de l\'expulsion').setRequired(false))
      .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers),
    async execute(interaction) {
      const user = interaction.options.getUser('membre');
      const reason = interaction.options.getString('raison') || 'Aucune raison fournie';
      const member = await interaction.guild.members.fetch(user.id).catch(() => null);

      if (!member) return interaction.reply({ content: '❌ Membre introuvable.' });

      await member.kick(reason);

      const embed = createEmbed({
        title: '🥾 EXPULSION DE MEMBRE',
        description: `**${user.tag}** a été expulsé du serveur.\n📝 **Motif** : ${reason}\n🛡️ Moderateur : <@${interaction.user.id}>`,
        color: config.colors.warning
      });

      await interaction.reply({ embeds: [embed] });
    }
  },

  // 7. /ban
  {
    data: new SlashCommandBuilder()
      .setName('ban')
      .setDescription('Bannir définitivement un membre du serveur Discord.')
      .addUserOption(opt => opt.setName('membre').setDescription('Membre à bannir').setRequired(true))
      .addStringOption(opt => opt.setName('raison').setDescription('Motif du bannissement').setRequired(false))
      .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers),
    async execute(interaction) {
      const user = interaction.options.getUser('membre');
      const reason = interaction.options.getString('raison') || 'Aucune raison fournie';

      await interaction.guild.members.ban(user.id, { reason });

      const embed = createEmbed({
        title: '🔨 BANNISSEMENT DU SERVEUR',
        description: `**${user.tag}** a été banni du serveur.\n📝 **Motif** : ${reason}\n🛡️ Moderateur : <@${interaction.user.id}>`,
        color: config.colors.danger
      });

      await interaction.reply({ embeds: [embed] });
    }
  },

  // 8. /dashboard-ticket (Panneau Support identique à l'image)
  {
    data: new SlashCommandBuilder()
      .setName('dashboard-ticket')
      .setDescription('Déployer le panneau permanent de Support & Tickets avec catégories.')
      .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
    async execute(interaction) {
      const d = await createSupportTicketDashboard();
      await interaction.reply({ content: '🚀 **Installation du Dashboard Support & Tickets...**' });
      await interaction.channel.send(d);
    }
  },

  // 9. /ticket-setup (Alias)
  {
    data: new SlashCommandBuilder()
      .setName('ticket-setup')
      .setDescription('Déployer le panneau permanent de Support & Tickets.')
      .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
    async execute(interaction) {
      const d = await createSupportTicketDashboard();
      await interaction.reply({ content: '🚀 **Installation du Dashboard Support & Tickets...**' });
      await interaction.channel.send(d);
    }
  },

  // 10. /dashboard-modo
  {
    data: new SlashCommandBuilder()
      .setName('dashboard-modo')
      .setDescription('Déployer le panneau permanent de demande de modérateur.')
      .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
    async execute(interaction) {
      const d = createModRequestDashboard();
      await interaction.reply({ content: '🚀 **Installation du Dashboard Demande de Modérateur...**' });
      await interaction.channel.send(d);
    }
  }
];
