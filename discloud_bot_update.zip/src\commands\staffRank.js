const { SlashCommandBuilder, PermissionFlagsBits, ChannelType, MessageFlags, EmbedBuilder } = require('discord.js');
const { staffRankDashboardEmbed, staffRankLogEmbed, staffRankAnnouncementEmbed } = require('../utils/embeds');
const db = require('../database/db');
const config = require('../../config.json');

module.exports = [
  {
    data: new SlashCommandBuilder()
      .setName('rank-staff')
      .setDescription('Système de gestion des promotions et grades pour l\'équipe Staff (Management).')
      .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
      .addSubcommand(sub =>
        sub.setName('dashboard')
           .setDescription('Publie le panneau interactif de gestion des Ranks Staff dans ce salon.')
      )
      .addSubcommand(sub =>
        sub.setName('promouvoir')
           .setDescription('Promouvoir un membre du staff à un grade supérieur.')
           .addUserOption(opt => opt.setName('staff').setDescription('Membre du staff à promouvoir').setRequired(true))
           .addStringOption(opt => opt.setName('ancien_grade').setDescription('Grade actuel / Ancien grade').setRequired(true))
           .addStringOption(opt => opt.setName('nouveau_grade').setDescription('Nouveau grade après promotion').setRequired(true))
           .addStringOption(opt => opt.setName('motif').setDescription('Motif de la promotion et félicitations').setRequired(true))
      )
      .addSubcommand(sub =>
        sub.setName('retrograder')
           .setDescription('Rétrograder un membre du staff à un grade inférieur.')
           .addUserOption(opt => opt.setName('staff').setDescription('Membre du staff à rétrograder').setRequired(true))
           .addStringOption(opt => opt.setName('ancien_grade').setDescription('Grade actuel').setRequired(true))
           .addStringOption(opt => opt.setName('nouveau_grade').setDescription('Nouveau grade après rétrogradation').setRequired(true))
           .addStringOption(opt => opt.setName('motif').setDescription('Motif de la rétrogradation').setRequired(true))
      )
      .addSubcommand(sub =>
        sub.setName('historique')
           .setDescription('Consulter l\'historique des promotions d\'un membre du staff.')
           .addUserOption(opt => opt.setName('staff').setDescription('Membre du staff ciblé').setRequired(true))
      ),

    async execute(interaction) {
      const subcommand = interaction.options.getSubcommand();
      const { guild, channel, user } = interaction;

      // Subcommand 1: dashboard
      if (subcommand === 'dashboard') {
        const payload = staffRankDashboardEmbed();
        await channel.send(payload);

        return interaction.reply({
          content: `✅ **Panneau de Gestion des Ranks Staff publié dans ${channel} !**`,
          flags: MessageFlags.Ephemeral
        });
      }

      // Subcommands 2 & 3: promouvoir & retrograder
      if (subcommand === 'promouvoir' || subcommand === 'retrograder') {
        await interaction.deferReply({ flags: MessageFlags.Ephemeral });
        const isUp = subcommand === 'promouvoir';
        const actionType = isUp ? 'promotion' : 'demotion';

        const staffUser = interaction.options.getUser('staff');
        const oldRank = interaction.options.getString('ancien_grade').trim();
        const newRank = interaction.options.getString('nouveau_grade').trim();
        const reason = interaction.options.getString('motif').trim();

        // Save in DB
        await db.addStaffRankRecord(
          guild.id,
          staffUser.id,
          staffUser.tag || staffUser.username,
          user.id,
          actionType,
          oldRank,
          newRank,
          reason
        );

        // Update Discord Roles if matching roles exist
        const member = await guild.members.fetch(staffUser.id).catch(() => null);
        if (member) {
          const newRole = guild.roles.cache.find(r => r.name.toLowerCase() === newRank.toLowerCase());
          const oldRole = guild.roles.cache.find(r => r.name.toLowerCase() === oldRank.toLowerCase());
          if (newRole) await member.roles.add(newRole).catch(() => {});
          if (oldRole) await member.roles.remove(oldRole).catch(() => {});
        }

        // Log in #log-rank-staff under LOGS category
        let rankLogChannel = guild.channels.cache.find(c => c.name.toLowerCase() === 'log-rank-staff');
        if (rankLogChannel) {
          const logEmbed = staffRankLogEmbed({
            staffUser,
            adminUser: user,
            actionType,
            oldRank,
            newRank,
            reason
          });
          rankLogChannel.send({ embeds: [logEmbed] }).catch(() => {});
        }

        // Public Announcement in #promotions-staff
        let announcementChannel = guild.channels.cache.find(
          c => c.name.toLowerCase() === 'promotions-staff' || c.name.toLowerCase() === 'annonces-staff'
        );
        if (announcementChannel) {
          const announceEmbed = staffRankAnnouncementEmbed({
            staffUser,
            actionType,
            oldRank,
            newRank,
            reason
          });
          announcementChannel.send({
            content: isUp ? `🎉 **NOUVELLE PROMOTION STAFF !** CC: <@${staffUser.id}>` : `📢 **MISE À JOUR DE GRADE STAFF**`,
            embeds: [announceEmbed]
          }).catch(() => {});
        }

        return interaction.editReply({
          content: isUp
            ? `🎉 **Promotion effectuée avec succès !**\n\n👤 **Staff** : ${staffUser} (\`${staffUser.tag}\`)\n📈 **Grade** : \`${oldRank}\` ➔ **\`${newRank}\`**\n📜 **Log & Annonce transmis.**`
            : `📉 **Rétrogradation enregistrée.**\n\n👤 **Staff** : ${staffUser} (\`${staffUser.tag}\`)\n📉 **Grade** : \`${oldRank}\` ➔ **\`${newRank}\`**\n📜 **Log & Annonce transmis.**`
        });
      }

      // Subcommand 4: historique
      if (subcommand === 'historique') {
        await interaction.deferReply({ flags: MessageFlags.Ephemeral });
        const staffUser = interaction.options.getUser('staff');

        const history = await db.getStaffRankHistory(guild.id, staffUser.id);
        if (!history || history.length === 0) {
          return interaction.editReply({
            content: `ℹ️ Aucun historique de promotion/grade trouvé pour ${staffUser}.`
          });
        }

        const embed = new EmbedBuilder()
          .setTitle(`📜 PARCOURS & HISTORIQUE DES RANKS • ${staffUser.username}`)
          .setDescription(`Voici l'historique complet des évolutions de carrière au sein du staff.\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`)
          .setColor(config.colors.gold || '#F1C40F')
          .setFooter({ text: 'Historique Carrière Staff • Hamburg RP' })
          .setTimestamp();

        history.forEach((h, idx) => {
          const symbol = h.actionType === 'promotion' ? '⬆️ PROMOTION' : '⬇️ RÉTROGRADATION';
          embed.addFields({
            name: `${symbol} #${history.length - idx} — \`${h.oldRank}\` ➔ \`${h.newRank}\``,
            value: `📝 **Motif** : ${h.reason}\n👑 **Administrateur** : <@${h.adminId}>\n📅 **Date** : <t:${Math.floor(h.createdAt / 1000)}:F>`,
            inline: false
          });
        });

        return interaction.editReply({ embeds: [embed] });
      }
    }
  }
];
