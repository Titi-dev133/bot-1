const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const dbPath = path.join(__dirname, '../../database.sqlite');
const db = new sqlite3.Database(dbPath);

db.serialize(() => {
  db.run('PRAGMA journal_mode = WAL;');
  db.run('PRAGMA synchronous = NORMAL;');
  db.run('PRAGMA temp_store = MEMORY;');
});

function runAsync(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.run(sql, params, function (err) {
      if (err) reject(err);
      else resolve(this);
    });
  });
}

function getAsync(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.get(sql, params, (err, row) => {
      if (err) reject(err);
      else resolve(row);
    });
  });
}

function allAsync(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.all(sql, params, (err, rows) => {
      if (err) reject(err);
      else resolve(rows);
    });
  });
}

async function initDatabase() {
  await runAsync(`
    CREATE TABLE IF NOT EXISTS service_sessions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      userId TEXT NOT NULL,
      guildId TEXT NOT NULL,
      faction TEXT NOT NULL,
      startTime INTEGER NOT NULL,
      endTime INTEGER,
      durationMinutes INTEGER DEFAULT 0,
      status TEXT DEFAULT 'ACTIVE'
    )
  `);

  await runAsync(`
    CREATE TABLE IF NOT EXISTS service_stats (
      userId TEXT PRIMARY KEY,
      totalMinutes INTEGER DEFAULT 0,
      shiftCount INTEGER DEFAULT 0
    )
  `);

  await runAsync(`
    CREATE TABLE IF NOT EXISTS wanted_list (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      targetName TEXT NOT NULL,
      userId TEXT,
      reason TEXT NOT NULL,
      dangerLevel INTEGER DEFAULT 1,
      fineAmount INTEGER DEFAULT 0,
      officerId TEXT NOT NULL,
      createdAt INTEGER NOT NULL,
      active INTEGER DEFAULT 1
    )
  `);

  await runAsync(`
    CREATE TABLE IF NOT EXISTS fines (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      targetName TEXT NOT NULL,
      userId TEXT,
      amount INTEGER NOT NULL,
      reason TEXT NOT NULL,
      officerId TEXT NOT NULL,
      createdAt INTEGER NOT NULL
    )
  `);

  await runAsync(`
    CREATE TABLE IF NOT EXISTS rp_profiles (
      userId TEXT PRIMARY KEY,
      lastName TEXT DEFAULT 'Inconnu',
      firstName TEXT DEFAULT 'Citoyen',
      age INTEGER DEFAULT 25,
      job TEXT DEFAULT 'Chômeur',
      licenses TEXT DEFAULT 'Permis B (Valide)',
      bankBalance INTEGER DEFAULT 10000,
      robloxUsername TEXT,
      robloxId TEXT,
      robloxDisplayName TEXT,
      updatedAt INTEGER
    )
  `);

  // Bank balance init on table create only



  try {
    await runAsync(`ALTER TABLE rp_profiles ADD COLUMN robloxUsername TEXT`);
  } catch (e) {}
  try {
    await runAsync(`ALTER TABLE rp_profiles ADD COLUMN robloxId TEXT`);
  } catch (e) {}
  try {
    await runAsync(`ALTER TABLE rp_profiles ADD COLUMN robloxDisplayName TEXT`);
  } catch (e) {}

  await runAsync(`
    CREATE TABLE IF NOT EXISTS active_patrols (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      vehicle TEXT NOT NULL,
      leaderId TEXT NOT NULL,
      members TEXT NOT NULL,
      createdAt INTEGER NOT NULL
    )
  `);

  await runAsync(`
    CREATE TABLE IF NOT EXISTS warnings (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      userId TEXT NOT NULL,
      moderatorId TEXT NOT NULL,
      reason TEXT NOT NULL,
      createdAt INTEGER NOT NULL
    )
  `);

  await runAsync(`
    CREATE TABLE IF NOT EXISTS welcome_config (
      guildId TEXT PRIMARY KEY,
      welcomeChannelId TEXT,
      leaveChannelId TEXT,
      verifyChannelId TEXT,
      unverifiedRoleId TEXT,
      verifiedRoleId TEXT,
      securityLogChannelId TEXT,
      minAccountAgeDays INTEGER DEFAULT 7,
      welcomeDMEnabled INTEGER DEFAULT 0
    )
  `);

  await runAsync(`
    CREATE TABLE IF NOT EXISTS player_sanctions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      guildId TEXT NOT NULL,
      robloxUsername TEXT NOT NULL,
      robloxId TEXT NOT NULL,
      discordUserId TEXT,
      moderatorId TEXT NOT NULL,
      sanctionType TEXT NOT NULL,
      details TEXT NOT NULL,
      createdAt INTEGER NOT NULL
    )
  `);

  await runAsync(`
    CREATE TABLE IF NOT EXISTS player_sanction_cards (
      guildId TEXT NOT NULL,
      robloxId TEXT PRIMARY KEY,
      channelId TEXT NOT NULL,
      messageId TEXT NOT NULL,
      updatedAt INTEGER NOT NULL
    )
  `);

  await runAsync(`
    CREATE TABLE IF NOT EXISTS staff_sanctions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      guildId TEXT NOT NULL,
      staffUsername TEXT NOT NULL,
      staffUserId TEXT NOT NULL,
      adminId TEXT NOT NULL,
      sanctionType TEXT NOT NULL,
      details TEXT NOT NULL,
      createdAt INTEGER NOT NULL
    )
  `);

  await runAsync(`
    CREATE TABLE IF NOT EXISTS staff_sanction_cards (
      guildId TEXT NOT NULL,
      staffUserId TEXT PRIMARY KEY,
      channelId TEXT NOT NULL,
      messageId TEXT NOT NULL,
      updatedAt INTEGER NOT NULL
    )
  `);

  await runAsync(`
    CREATE TABLE IF NOT EXISTS staff_services (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      guildId TEXT NOT NULL,
      userId TEXT NOT NULL,
      username TEXT NOT NULL,
      status TEXT NOT NULL,
      startTime INTEGER NOT NULL,
      pauseStartTime INTEGER,
      totalPauseMs INTEGER DEFAULT 0,
      endTime INTEGER,
      totalDuration INTEGER DEFAULT 0
    )
  `);

  await runAsync(`
    CREATE TABLE IF NOT EXISTS staff_leaderboard_config (
      guildId TEXT PRIMARY KEY,
      channelId TEXT NOT NULL,
      messageId TEXT NOT NULL,
      updatedAt INTEGER NOT NULL
    )
  `);

  await runAsync(`
    CREATE TABLE IF NOT EXISTS staff_rank_promotions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      guildId TEXT NOT NULL,
      staffUserId TEXT NOT NULL,
      staffUsername TEXT NOT NULL,
      adminId TEXT NOT NULL,
      actionType TEXT NOT NULL,
      oldRank TEXT NOT NULL,
      newRank TEXT NOT NULL,
      reason TEXT NOT NULL,
      createdAt INTEGER NOT NULL
    )
  `);

  await runAsync(`
    CREATE TABLE IF NOT EXISTS staff_absences (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      guildId TEXT NOT NULL,
      userId TEXT NOT NULL,
      username TEXT NOT NULL,
      startDate TEXT NOT NULL,
      endDate TEXT NOT NULL,
      reason TEXT NOT NULL,
      status TEXT NOT NULL,
      createdAt INTEGER NOT NULL,
      endedAt INTEGER
    )
  `);

  await runAsync(`
    CREATE TABLE IF NOT EXISTS staff_reviews (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      guildId TEXT NOT NULL,
      authorId TEXT NOT NULL,
      authorUsername TEXT NOT NULL,
      staffQuery TEXT NOT NULL,
      staffUserId TEXT,
      rating INTEGER NOT NULL,
      comment TEXT NOT NULL,
      isAnonymous INTEGER DEFAULT 0,
      createdAt INTEGER NOT NULL
    )
  `);

  await runAsync(`
    CREATE TABLE IF NOT EXISTS staff_review_cards (
      guildId TEXT NOT NULL,
      staffKey TEXT PRIMARY KEY,
      channelId TEXT NOT NULL,
      messageId TEXT NOT NULL,
      updatedAt INTEGER NOT NULL
    )
  `);

  await runAsync(`
    CREATE TABLE IF NOT EXISTS suggestions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      guildId TEXT NOT NULL,
      authorId TEXT NOT NULL,
      authorUsername TEXT NOT NULL,
      title TEXT NOT NULL,
      details TEXT NOT NULL,
      status TEXT DEFAULT 'PENDING',
      upVotes INTEGER DEFAULT 0,
      downVotes INTEGER DEFAULT 0,
      voters TEXT DEFAULT '{}',
      proposals TEXT DEFAULT '[]',
      mergedInto INTEGER,
      channelId TEXT NOT NULL,
      messageId TEXT NOT NULL,
      processedBy TEXT,
      staffReason TEXT,
      createdAt INTEGER NOT NULL,
      updatedAt INTEGER NOT NULL
    )
  `);

  try { await runAsync(`ALTER TABLE suggestions ADD COLUMN proposals TEXT DEFAULT '[]'`); } catch (e) {}
  try { await runAsync(`ALTER TABLE suggestions ADD COLUMN mergedInto INTEGER`); } catch (e) {}

  await runAsync(`
    CREATE TABLE IF NOT EXISTS suggestion_dashboards (
      guildId TEXT PRIMARY KEY,
      channelId TEXT NOT NULL,
      messageId TEXT NOT NULL,
      updatedAt INTEGER NOT NULL
    )
  `);

  await runAsync(`
    CREATE TABLE IF NOT EXISTS giveaways (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      guildId TEXT NOT NULL,
      channelId TEXT NOT NULL,
      messageId TEXT NOT NULL,
      prize TEXT NOT NULL,
      description TEXT,
      winnersCount INTEGER DEFAULT 1,
      hostId TEXT NOT NULL,
      participants TEXT DEFAULT '[]',
      endsAt INTEGER NOT NULL,
      ended INTEGER DEFAULT 0,
      winners TEXT DEFAULT '[]',
      createdAt INTEGER NOT NULL
    )
  `);

  await runAsync(`
    CREATE TABLE IF NOT EXISTS giveaway_dashboards (
      guildId TEXT PRIMARY KEY,
      channelId TEXT NOT NULL,
      messageId TEXT NOT NULL,
      updatedAt INTEGER NOT NULL
    )
  `);

  await runAsync(`
    CREATE TABLE IF NOT EXISTS antiraid_config (
      guildId TEXT PRIMARY KEY,
      lockdown INTEGER DEFAULT 0,
      antiBot INTEGER DEFAULT 1,
      antiAlt INTEGER DEFAULT 1,
      minAccountAgeDays INTEGER DEFAULT 7,
      antiSpam INTEGER DEFAULT 1,
      maxMessagesPer5Sec INTEGER DEFAULT 5,
      maxMentions INTEGER DEFAULT 4,
      antiMassJoin INTEGER DEFAULT 1,
      maxJoinsPer10Sec INTEGER DEFAULT 5,
      logChannelId TEXT,
      updatedAt INTEGER NOT NULL
    )
  `);

  await runAsync(`
    CREATE TABLE IF NOT EXISTS antiraid_dashboards (
      guildId TEXT PRIMARY KEY,
      channelId TEXT NOT NULL,
      messageId TEXT NOT NULL,
      updatedAt INTEGER NOT NULL
    )
  `);

  await runAsync(`
    CREATE TABLE IF NOT EXISTS server_backups (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      guildId TEXT NOT NULL,
      backupName TEXT NOT NULL,
      fileType TEXT NOT NULL,
      filePath TEXT NOT NULL,
      createdBy TEXT NOT NULL,
      createdAt INTEGER NOT NULL,
      details TEXT
    )
  `);

  await runAsync(`
    CREATE TABLE IF NOT EXISTS staff_recruitment_tests (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      guildId TEXT NOT NULL,
      userId TEXT NOT NULL,
      userTag TEXT NOT NULL,
      robloxUsername TEXT NOT NULL,
      age INTEGER NOT NULL,
      availability TEXT NOT NULL,
      experience TEXT NOT NULL,
      case1 TEXT NOT NULL,
      case2 TEXT NOT NULL,
      case3 TEXT NOT NULL,
      answersJson TEXT,
      status TEXT DEFAULT 'PENDING',
      channelId TEXT,
      messageId TEXT,
      reviewedBy TEXT,
      reviewReason TEXT,
      createdAt INTEGER NOT NULL,
      updatedAt INTEGER NOT NULL
    )
  `);
  try { await runAsync(`ALTER TABLE staff_recruitment_tests ADD COLUMN answersJson TEXT`); } catch (e) {}





  await runAsync(`
    CREATE TABLE IF NOT EXISTS partnership_requests (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      guildId TEXT NOT NULL,
      userId TEXT NOT NULL,
      userTag TEXT NOT NULL,
      serverName TEXT NOT NULL,
      inviteUrl TEXT NOT NULL,
      memberCount INTEGER NOT NULL,
      partnerType TEXT NOT NULL,
      description TEXT NOT NULL,
      status TEXT DEFAULT 'PENDING',
      channelId TEXT,
      messageId TEXT,
      reviewedBy TEXT,
      reviewReason TEXT,
      createdAt INTEGER NOT NULL,
      updatedAt INTEGER NOT NULL
    )
  `);

  await runAsync(`
    CREATE TABLE IF NOT EXISTS organization_requests (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      guildId TEXT NOT NULL,
      userId TEXT NOT NULL,
      userTag TEXT NOT NULL,
      orgType TEXT NOT NULL,
      orgName TEXT NOT NULL,
      lore TEXT NOT NULL,
      membersList TEXT NOT NULL,
      locationOrSector TEXT NOT NULL,
      businessPlan TEXT,
      status TEXT DEFAULT 'PENDING',
      channelId TEXT,
      messageId TEXT,
      reviewedBy TEXT,
      reviewReason TEXT,
      createdAt INTEGER NOT NULL,
      updatedAt INTEGER NOT NULL
    )
  `);

  await runAsync(`

    CREATE TABLE IF NOT EXISTS user_cooldowns (
      userId TEXT NOT NULL,
      type TEXT NOT NULL,
      endsAt INTEGER NOT NULL,
      PRIMARY KEY (userId, type)
    )
  `);

  await runAsync(`
    CREATE TABLE IF NOT EXISTS user_levels (
      userId TEXT PRIMARY KEY,
      xp INTEGER DEFAULT 0,
      level INTEGER DEFAULT 1,
      messageCount INTEGER DEFAULT 0,
      updatedAt INTEGER NOT NULL
    )
  `);

  await runAsync(`
    CREATE TABLE IF NOT EXISTS xp_dashboards (
      guildId TEXT PRIMARY KEY,
      channelId TEXT NOT NULL,
      messageId TEXT NOT NULL,
      updatedAt INTEGER NOT NULL
    )
  `);

  console.log('✅ Base de données SQLite initialisée et migrée avec succès.');
}




// === SERVICE METHODS ===
async function startService(userId, guildId, faction) {
  const profile = await getAsync(`SELECT * FROM rp_profiles WHERE userId = ?`, [userId]);
  if (!profile || (!profile.robloxUsername && !profile.robloxId)) {
    return {
      success: false,
      reason: 'NOT_LINKED',
      message: '❌ **Compte Roblox non lié !** Vous devez obligatoirement lier votre compte Roblox avec `/link-roblox [VotrePseudo]` avant de pouvoir prendre votre service RP.'
    };
  }

  const now = Date.now();
  const existing = await getAsync(
    `SELECT * FROM service_sessions WHERE userId = ? AND status = 'ACTIVE'`,
    [userId]
  );
  if (existing) {
    return { success: false, message: 'Vous avez déjà un service actif.' };
  }
  await runAsync(
    `INSERT INTO service_sessions (userId, guildId, faction, startTime, status) VALUES (?, ?, ?, ?, 'ACTIVE')`,
    [userId, guildId, faction, now]
  );
  return { success: true, startTime: now, robloxUsername: profile.robloxUsername };
}

async function stopService(userId) {
  const session = await getAsync(
    `SELECT * FROM service_sessions WHERE userId = ? AND status = 'ACTIVE'`,
    [userId]
  );
  if (!session) {
    return { success: false, message: "Vous n'avez aucun service en cours." };
  }

  const profile = await getAsync(`SELECT * FROM rp_profiles WHERE userId = ?`, [userId]);
  const isLinked = profile && (profile.robloxUsername || profile.robloxId);

  const now = Date.now();
  const durationMs = now - session.startTime;
  const durationMinutes = Math.floor(durationMs / (1000 * 60));

  if (!isLinked) {
    // Si non lié ou déconnecté du jeu : annulation du service et retrait total de la paie (0 €)
    await runAsync(
      `UPDATE service_sessions SET endTime = ?, durationMinutes = ?, status = 'CANCELLED_UNLINKED' WHERE id = ?`,
      [now, durationMinutes, session.id]
    );
    const currentBalance = await getUserBalance(userId);
    return {
      success: true,
      cancelled: true,
      reason: 'NOT_LINKED',
      earnedMoney: 0,
      newBalance: currentBalance,
      durationMinutes,
      message: '⚠️ **SERVICE ANNULÉ & PAIE SUPPRIMÉE** : Votre compte Roblox n\'est pas lié ou connecté au jeu ! Votre salaire pour cette session a été annulé (0 €).'
    };
  }

  await runAsync(
    `UPDATE service_sessions SET endTime = ?, durationMinutes = ?, status = 'COMPLETED' WHERE id = ?`,
    [now, durationMinutes, session.id]
  );

  const stats = await getAsync(`SELECT * FROM service_stats WHERE userId = ?`, [userId]);
  if (stats) {
    await runAsync(
      `UPDATE service_stats SET totalMinutes = totalMinutes + ?, shiftCount = shiftCount + 1 WHERE userId = ?`,
      [durationMinutes, userId]
    );
  } else {
    await runAsync(
      `INSERT INTO service_stats (userId, totalMinutes, shiftCount) VALUES (?, ?, 1)`,
      [userId, durationMinutes]
    );
  }

  // Grille des salaires officielle : 450€ toutes les 10 minutes (base 45€/min) avec multiplicateurs exacts
  const payConfig = {
    bus: { name: 'Chauffeur de Bus 🚌', base: 450, multiplier: 1.2, ratePerMin: 54 },
    camion: { name: 'Camionneur 🚚', base: 450, multiplier: 1.2, ratePerMin: 54 },
    police: { name: 'Polizei (Police) 🚓', base: 450, multiplier: 1.2, ratePerMin: 54 },
    pompiers: { name: 'Feuerwehr (Pompiers) 🚒', base: 450, multiplier: 1.0, ratePerMin: 45 },
    fire: { name: 'Feuerwehr (Pompiers) 🚒', base: 450, multiplier: 1.0, ratePerMin: 45 },
    ems: { name: 'Rettungsdienst (EMS / Médecin) 🚑', base: 450, multiplier: 1.2, ratePerMin: 54 },
    adac: { name: 'ADAC (Dépannage) 🛞', base: 450, multiplier: 1.3, ratePerMin: 58.5 }
  };

  const factionKey = (session.faction || '').toLowerCase();
  const cfg = payConfig[factionKey] || { name: session.faction, base: 450, multiplier: 1.0, ratePerMin: 45 };

  const minsToPay = Math.max(1, durationMinutes);
  const earnedMoney = Math.round(minsToPay * cfg.ratePerMin);

  await addMoney(userId, earnedMoney);
  const newBalance = await getUserBalance(userId);

  return {
    success: true,
    cancelled: false,
    faction: session.faction,
    factionName: cfg.name,
    baseRate: cfg.base,
    multiplier: cfg.multiplier,
    ratePerMin: cfg.ratePerMin,
    earnedMoney,
    newBalance,
    durationMinutes,
    startTime: session.startTime,
    endTime: now
  };
}


// === ECONOMY METHODS ===
async function getUserBalance(userId) {
  const profile = await getAsync(`SELECT bankBalance FROM rp_profiles WHERE userId = ?`, [userId]);
  return profile && profile.bankBalance !== null && profile.bankBalance !== undefined ? profile.bankBalance : 10000;
}

async function addMoney(userId, amount) {
  const profile = await getAsync(`SELECT * FROM rp_profiles WHERE userId = ?`, [userId]);
  const now = Date.now();
  if (profile) {
    await runAsync(`UPDATE rp_profiles SET bankBalance = bankBalance + ?, updatedAt = ? WHERE userId = ?`, [amount, now, userId]);
  } else {
    await runAsync(`INSERT INTO rp_profiles (userId, bankBalance, updatedAt) VALUES (?, ?, ?)`, [userId, 10000 + amount, now]);
  }
  return await getUserBalance(userId);
}


async function removeMoney(userId, amount) {
  const current = await getUserBalance(userId);
  if (current < amount) return false;
  const now = Date.now();
  await runAsync(`UPDATE rp_profiles SET bankBalance = bankBalance - ?, updatedAt = ? WHERE userId = ?`, [amount, now, userId]);
  return true;
}

const cooldownCache = new Map();

async function setCooldown(userId, type, durationMs) {
  const endsAt = Date.now() + durationMs;
  const key = `${userId}_${type}`;
  cooldownCache.set(key, endsAt);
  runAsync(`INSERT OR REPLACE INTO user_cooldowns (userId, type, endsAt) VALUES (?, ?, ?)`, [userId, type, endsAt]).catch(() => {});
}

async function getCooldown(userId, type) {
  const key = `${userId}_${type}`;
  const cachedEndsAt = cooldownCache.get(key);
  if (cachedEndsAt) {
    const remaining = cachedEndsAt - Date.now();
    if (remaining > 0) return remaining;
    cooldownCache.delete(key);
    return 0;
  }
  const record = await getAsync(`SELECT endsAt FROM user_cooldowns WHERE userId = ? AND type = ?`, [userId, type]);
  if (!record) return 0;
  const remaining = record.endsAt - Date.now();
  if (remaining > 0) {
    cooldownCache.set(key, record.endsAt);
    return remaining;
  }
  return 0;
}

// === XP & LEVELING METHODS ===
function getRequiredXPForLevel(level) {
  return level * level * 100;
}

async function addXP(userId, xpAmount) {
  const now = Date.now();
  let userRecord = await getAsync(`SELECT * FROM user_levels WHERE userId = ?`, [userId]);

  if (!userRecord) {
    userRecord = { userId, xp: 0, level: 1, messageCount: 0 };
    await runAsync(
      `INSERT INTO user_levels (userId, xp, level, messageCount, updatedAt) VALUES (?, 0, 1, 0, ?)`,
      [userId, now]
    );
  }

  let newXP = userRecord.xp + xpAmount;
  let newLevel = userRecord.level;
  let messageCount = userRecord.messageCount + 1;
  let leveledUp = false;

  let reqXP = getRequiredXPForLevel(newLevel);
  while (newXP >= reqXP) {
    newLevel++;
    leveledUp = true;
    reqXP = getRequiredXPForLevel(newLevel);
  }

  await runAsync(
    `UPDATE user_levels SET xp = ?, level = ?, messageCount = ?, updatedAt = ? WHERE userId = ?`,
    [newXP, newLevel, messageCount, now, userId]
  );

  return {
    xp: newXP,
    level: newLevel,
    messageCount,
    leveledUp,
    oldLevel: userRecord.level
  };
}

async function getUserLevelInfo(userId) {
  const userRecord = await getAsync(`SELECT * FROM user_levels WHERE userId = ?`, [userId]);
  if (!userRecord) {
    return { xp: 0, level: 1, messageCount: 0, nextLevelXP: 100 };
  }
  const nextLevelXP = getRequiredXPForLevel(userRecord.level);
  return { ...userRecord, nextLevelXP };
}

async function getTopXPLeaderboard(limit = 10) {
  return await allAsync(
    `SELECT * FROM user_levels ORDER BY level DESC, xp DESC LIMIT ?`,
    [limit]
  );
}

async function saveXpDashboardRecord(guildId, channelId, messageId) {
  const now = Date.now();
  await runAsync(
    `INSERT OR REPLACE INTO xp_dashboards (guildId, channelId, messageId, updatedAt) VALUES (?, ?, ?, ?)`,
    [guildId, channelId, messageId, now]
  );
}

async function getXpDashboardRecord(guildId) {
  return await getAsync(`SELECT * FROM xp_dashboards WHERE guildId = ?`, [guildId]);
}

async function getAllXpDashboardsRecords() {
  return await allAsync(`SELECT * FROM xp_dashboards`);
}



async function getActiveService(userId) {
  return await getAsync(
    `SELECT * FROM service_sessions WHERE userId = ? AND status = 'ACTIVE'`,
    [userId]
  );
}

async function getAllActiveServices() {
  return await allAsync(
    `SELECT * FROM service_sessions WHERE status = 'ACTIVE' ORDER BY startTime DESC`
  );
}


async function getServiceStats(userId) {
  const totalStats = await getAsync(`SELECT * FROM service_stats WHERE userId = ?`, [userId]);
  const recentSessions = await allAsync(
    `SELECT * FROM service_sessions WHERE userId = ? AND status = 'COMPLETED' ORDER BY endTime DESC LIMIT 5`,
    [userId]
  );
  return { stats: totalStats, recent: recentSessions };
}

async function getServiceLeaderboard(limit = 10) {
  return await allAsync(
    `SELECT * FROM service_stats ORDER BY totalMinutes DESC LIMIT ?`,
    [limit]
  );
}

// === WANTED LIST & FINES ===
async function addWanted(targetName, userId, reason, dangerLevel, fineAmount, officerId) {
  const result = await runAsync(
    `INSERT INTO wanted_list (targetName, userId, reason, dangerLevel, fineAmount, officerId, createdAt, active) VALUES (?, ?, ?, ?, ?, ?, ?, 1)`,
    [targetName, userId || null, reason, dangerLevel, fineAmount, officerId, Date.now()]
  );
  return result.lastID;
}

async function removeWanted(targetName) {
  const result = await runAsync(
    `UPDATE wanted_list SET active = 0 WHERE (targetName LIKE ? OR userId = ?) AND active = 1`,
    [`%${targetName}%`, targetName]
  );
  return result.changes > 0;
}

async function getWantedList() {
  return await allAsync(`SELECT * FROM wanted_list WHERE active = 1 ORDER BY dangerLevel DESC, createdAt DESC`);
}

async function addFine(targetName, userId, amount, reason, officerId) {
  return await runAsync(
    `INSERT INTO fines (targetName, userId, amount, reason, officerId, createdAt) VALUES (?, ?, ?, ?, ?, ?)`,
    [targetName, userId || null, amount, reason, officerId, Date.now()]
  );
}

async function getFinesHistory(targetNameOrUserId) {
  return await allAsync(
    `SELECT * FROM fines WHERE targetName LIKE ? OR userId = ? ORDER BY createdAt DESC`,
    [`%${targetNameOrUserId}%`, targetNameOrUserId]
  );
}

// === RP PROFILE & ROBLOX LINKING ===
async function getProfile(userId) {
  let profile = await getAsync(`SELECT * FROM rp_profiles WHERE userId = ?`, [userId]);
  if (!profile) {
    await runAsync(
      `INSERT INTO rp_profiles (userId, lastName, firstName, age, job, licenses, bankBalance, updatedAt) VALUES (?, 'Aubagne', 'Citoyen', 25, 'Civil', 'Permis B (Valide)', 10000, ?)`,
      [userId, Date.now()]
    );
    profile = await getAsync(`SELECT * FROM rp_profiles WHERE userId = ?`, [userId]);
  }
  return profile;
}

async function getProfileByDiscord(userId) {
  return await getAsync(`SELECT * FROM rp_profiles WHERE userId = ?`, [userId]);
}

async function getProfileByRoblox(robloxQuery) {
  return await getAsync(
    `SELECT * FROM rp_profiles WHERE LOWER(robloxUsername) = LOWER(?) OR LOWER(robloxDisplayName) = LOWER(?) OR robloxId = ?`,
    [robloxQuery, robloxQuery, robloxQuery]
  );
}


async function updateProfile(userId, lastName, firstName, age, job) {
  await getProfile(userId);
  await runAsync(
    `UPDATE rp_profiles SET lastName = ?, firstName = ?, age = ?, job = ?, updatedAt = ? WHERE userId = ?`,
    [lastName, firstName, age, job, Date.now(), userId]
  );
}

async function linkRobloxAccount(userId, robloxUsername, robloxId, robloxDisplayName) {
  await getProfile(userId);
  await runAsync(
    `UPDATE rp_profiles SET robloxUsername = ?, robloxId = ?, robloxDisplayName = ?, updatedAt = ? WHERE userId = ?`,
    [robloxUsername, robloxId.toString(), robloxDisplayName, Date.now(), userId]
  );
}

async function unlinkRobloxAccount(userId) {
  await getProfile(userId);
  await runAsync(
    `UPDATE rp_profiles SET robloxUsername = NULL, robloxId = NULL, robloxDisplayName = NULL, updatedAt = ? WHERE userId = ?`,
    [Date.now(), userId]
  );
}

async function updateBank(userId, amountToAdd) {
  await getProfile(userId);
  await runAsync(
    `UPDATE rp_profiles SET bankBalance = bankBalance + ?, updatedAt = ? WHERE userId = ?`,
    [amountToAdd, Date.now(), userId]
  );
  return await getProfile(userId);
}

// === TICKETS & STATS ===
async function createTicketRecord(channelId, userId, category) {
  return await runAsync(
    `INSERT INTO tickets (channelId, userId, category, status, createdAt) VALUES (?, ?, ?, 'OPEN', ?)`,
    [channelId, userId, category, Date.now()]
  );
}

async function claimTicketRecord(channelId, staffId) {
  const existing = await getAsync(`SELECT * FROM tickets WHERE channelId = ?`, [channelId]);
  if (existing) {
    return await runAsync(
      `UPDATE tickets SET status = 'CLAIMED', claimedBy = ? WHERE channelId = ?`,
      [staffId, channelId]
    );
  } else {
    return await runAsync(
      `INSERT INTO tickets (channelId, userId, category, status, claimedBy, createdAt) VALUES (?, 'UNKNOWN', 'Assistance', 'CLAIMED', ?, ?)`,
      [channelId, staffId, Date.now()]
    );
  }
}

async function closeTicketRecord(channelId) {
  return await runAsync(
    `UPDATE tickets SET status = 'CLOSED', closedAt = ? WHERE channelId = ?`,
    [Date.now(), channelId]
  );
}

async function getTicketByChannel(channelId) {
  return await getAsync(`SELECT * FROM tickets WHERE channelId = ?`, [channelId]);
}

async function getTicketStats() {
  const openRow = await getAsync(`SELECT COUNT(*) as count FROM tickets WHERE status != 'CLOSED'`);
  const closedRow = await getAsync(`SELECT COUNT(*) as count FROM tickets WHERE status = 'CLOSED'`);
  return {
    openCount: openRow ? openRow.count : 0,
    closedCount: closedRow ? closedRow.count : 0
  };
}

// === PATROLS ===
async function createPatrol(name, vehicle, leaderId) {
  const result = await runAsync(
    `INSERT INTO active_patrols (name, vehicle, leaderId, members, createdAt) VALUES (?, ?, ?, ?, ?)`,
    [name, vehicle, leaderId, JSON.stringify([leaderId]), Date.now()]
  );
  return result.lastID;
}

async function getActivePatrols() {
  return await allAsync(`SELECT * FROM active_patrols ORDER BY createdAt DESC`);
}

async function deletePatrol(patrolId) {
  await runAsync(`DELETE FROM active_patrols WHERE id = ?`, [patrolId]);
}

// === WARNINGS ===
async function addWarning(userId, moderatorId, reason) {
  return await runAsync(
    `INSERT INTO warnings (userId, moderatorId, reason, createdAt) VALUES (?, ?, ?, ?)`,
    [userId, moderatorId, reason, Date.now()]
  );
}

async function getWarnings(userId) {
  return await allAsync(`SELECT * FROM warnings WHERE userId = ? ORDER BY createdAt DESC`, [userId]);
}

async function clearWarnings(userId) {
  return await runAsync(`DELETE FROM warnings WHERE userId = ?`, [userId]);
}

// === WELCOME & VERIFICATION METHODS ===
async function getWelcomeConfig(guildId) {
  let config = await getAsync(`SELECT * FROM welcome_config WHERE guildId = ?`, [guildId]);
  if (!config) {
    await runAsync(`INSERT INTO welcome_config (guildId) VALUES (?)`, [guildId]);
    config = await getAsync(`SELECT * FROM welcome_config WHERE guildId = ?`, [guildId]);
  }
  return config;
}

async function updateWelcomeConfig(guildId, updates) {
  await getWelcomeConfig(guildId);
  const fields = [];
  const params = [];
  for (const [key, value] of Object.entries(updates)) {
    fields.push(`${key} = ?`);
    params.push(value);
  }
  if (fields.length === 0) return;
  params.push(guildId);
  await runAsync(`UPDATE welcome_config SET ${fields.join(', ')} WHERE guildId = ?`, params);
  return await getWelcomeConfig(guildId);
}

async function isRobloxLinkedToAnotherDiscord(robloxId, currentUserId) {
  const rIdStr = robloxId.toString();
  const row = await getAsync(
    `SELECT userId FROM verifications WHERE robloxId = ? AND userId != ?`,
    [rIdStr, currentUserId]
  );
  if (row) return row.userId;

  const profileRow = await getAsync(
    `SELECT userId FROM rp_profiles WHERE robloxId = ? AND userId != ?`,
    [rIdStr, currentUserId]
  );
  if (profileRow) return profileRow.userId;

  return null;
}

async function saveVerification(userId, guildId, robloxId, robloxUsername) {
  const now = Date.now();
  await runAsync(
    `INSERT INTO verifications (userId, guildId, robloxId, robloxUsername, verifiedAt, rulesAccepted)
     VALUES (?, ?, ?, ?, ?, 1)
     ON CONFLICT(userId) DO UPDATE SET
       robloxId = excluded.robloxId,
       robloxUsername = excluded.robloxUsername,
       verifiedAt = excluded.verifiedAt,
       rulesAccepted = 1`,
    [userId, guildId, robloxId.toString(), robloxUsername, now]
  );

  await linkRobloxAccount(userId, robloxUsername, robloxId, robloxUsername);
}

async function getVerification(userId) {
  return await getAsync(`SELECT * FROM verifications WHERE userId = ?`, [userId]);
}

// === PLAYER SANCTION METHODS ===
async function addSanctionRecord(guildId, robloxUsername, robloxId, discordUserId, moderatorId, sanctionType, details) {
  const now = Date.now();
  const result = await runAsync(
    `INSERT INTO player_sanctions (guildId, robloxUsername, robloxId, discordUserId, moderatorId, sanctionType, details, createdAt)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
    [guildId, robloxUsername, robloxId ? robloxId.toString() : '', discordUserId || null, moderatorId, sanctionType, details, now]
  );
  return result.lastID;
}

async function getPlayerSanctionsHistory(robloxIdOrUsername) {
  const inputStr = robloxIdOrUsername.toString();
  return await allAsync(
    `SELECT * FROM player_sanctions WHERE robloxId = ? OR robloxUsername LIKE ? OR discordUserId = ? ORDER BY createdAt ASC`,
    [inputStr, `%${inputStr}%`, inputStr]
  );
}

async function getPlayerSanctionCard(guildId, robloxId) {
  return await getAsync(
    `SELECT * FROM player_sanction_cards WHERE guildId = ? AND robloxId = ?`,
    [guildId, robloxId.toString()]
  );
}

async function savePlayerSanctionCard(guildId, robloxId, channelId, messageId) {
  const now = Date.now();
  await runAsync(
    `INSERT INTO player_sanction_cards (guildId, robloxId, channelId, messageId, updatedAt)
     VALUES (?, ?, ?, ?, ?)
     ON CONFLICT(robloxId) DO UPDATE SET
       channelId = excluded.channelId,
       messageId = excluded.messageId,
       updatedAt = excluded.updatedAt`,
    [guildId, robloxId.toString(), channelId, messageId, now]
  );
}

async function removeSanctionRecord(id) {
  return await runAsync(`DELETE FROM player_sanctions WHERE id = ?`, [id]);
}

async function clearPlayerSanctions(robloxIdOrUsername) {
  const inputStr = robloxIdOrUsername.toString();
  return await runAsync(
    `DELETE FROM player_sanctions WHERE robloxId = ? OR robloxUsername LIKE ? OR discordUserId = ?`,
    [inputStr, `%${inputStr}%`, inputStr]
  );
}

async function deletePlayerSanctionCard(guildId, robloxId) {
  return await runAsync(
    `DELETE FROM player_sanction_cards WHERE guildId = ? AND robloxId = ?`,
    [guildId, robloxId.toString()]
  );
}

// === STAFF SANCTION METHODS ===
async function addStaffSanctionRecord(guildId, staffUsername, staffUserId, adminId, sanctionType, details) {
  const now = Date.now();
  const result = await runAsync(
    `INSERT INTO staff_sanctions (guildId, staffUsername, staffUserId, adminId, sanctionType, details, createdAt)
     VALUES (?, ?, ?, ?, ?, ?, ?)`,
    [guildId, staffUsername, staffUserId, adminId, sanctionType, details, now]
  );
  return result.lastID;
}

async function getStaffSanctionsHistory(staffUserIdOrUsername) {
  const inputStr = staffUserIdOrUsername.toString();
  return await allAsync(
    `SELECT * FROM staff_sanctions WHERE staffUserId = ? OR staffUsername LIKE ? ORDER BY createdAt ASC`,
    [inputStr, `%${inputStr}%`]
  );
}

async function getStaffSanctionCard(guildId, staffUserId) {
  return await getAsync(
    `SELECT * FROM staff_sanction_cards WHERE guildId = ? AND staffUserId = ?`,
    [guildId, staffUserId.toString()]
  );
}

async function saveStaffSanctionCard(guildId, staffUserId, channelId, messageId) {
  const now = Date.now();
  await runAsync(
    `INSERT INTO staff_sanction_cards (guildId, staffUserId, channelId, messageId, updatedAt)
     VALUES (?, ?, ?, ?, ?)
     ON CONFLICT(staffUserId) DO UPDATE SET
       channelId = excluded.channelId,
       messageId = excluded.messageId,
       updatedAt = excluded.updatedAt`,
    [guildId, staffUserId.toString(), channelId, messageId, now]
  );
}

async function removeStaffSanctionRecord(id) {
  return await runAsync(`DELETE FROM staff_sanctions WHERE id = ?`, [id]);
}

async function clearStaffSanctions(staffUserIdOrUsername) {
  const inputStr = staffUserIdOrUsername.toString();
  return await runAsync(
    `DELETE FROM staff_sanctions WHERE staffUserId = ? OR staffUsername LIKE ?`,
    [inputStr, `%${inputStr}%`]
  );
}

async function deleteStaffSanctionCard(guildId, staffUserId) {
  return await runAsync(
    `DELETE FROM staff_sanction_cards WHERE guildId = ? AND staffUserId = ?`,
    [guildId, staffUserId.toString()]
  );
}

// === STAFF SERVICE SHIFT METHODS ===
async function startStaffService(guildId, userId, username) {
  const active = await getAsync(
    `SELECT * FROM staff_services WHERE guildId = ? AND userId = ? AND status != 'ended'`,
    [guildId, userId]
  );
  if (active) return active;

  const now = Date.now();
  const res = await runAsync(
    `INSERT INTO staff_services (guildId, userId, username, status, startTime) VALUES (?, ?, ?, 'active', ?)`,
    [guildId, userId, username, now]
  );
  return await getAsync(`SELECT * FROM staff_services WHERE id = ?`, [res.lastID]);
}

async function pauseStaffService(guildId, userId) {
  const active = await getAsync(
    `SELECT * FROM staff_services WHERE guildId = ? AND userId = ? AND status = 'active'`,
    [guildId, userId]
  );
  if (!active) return null;

  const now = Date.now();
  await runAsync(
    `UPDATE staff_services SET status = 'break', pauseStartTime = ? WHERE id = ?`,
    [now, active.id]
  );
  return await getAsync(`SELECT * FROM staff_services WHERE id = ?`, [active.id]);
}

async function resumeStaffService(guildId, userId) {
  const breakSession = await getAsync(
    `SELECT * FROM staff_services WHERE guildId = ? AND userId = ? AND status = 'break'`,
    [guildId, userId]
  );
  if (!breakSession) return null;

  const now = Date.now();
  const pauseDuration = breakSession.pauseStartTime ? (now - breakSession.pauseStartTime) : 0;
  const newTotalPause = (breakSession.totalPauseMs || 0) + pauseDuration;

  await runAsync(
    `UPDATE staff_services SET status = 'active', pauseStartTime = NULL, totalPauseMs = ? WHERE id = ?`,
    [newTotalPause, breakSession.id]
  );
  return await getAsync(`SELECT * FROM staff_services WHERE id = ?`, [breakSession.id]);
}

async function stopStaffService(guildId, userId) {
  const session = await getAsync(
    `SELECT * FROM staff_services WHERE guildId = ? AND userId = ? AND status != 'ended'`,
    [guildId, userId]
  );
  if (!session) return null;

  const now = Date.now();
  let extraPause = 0;
  if (session.status === 'break' && session.pauseStartTime) {
    extraPause = now - session.pauseStartTime;
  }
  const totalPause = (session.totalPauseMs || 0) + extraPause;
  const rawDuration = now - session.startTime;
  const durationMs = Math.max(0, rawDuration - totalPause);

  await runAsync(
    `UPDATE staff_services SET status = 'ended', endTime = ?, totalPauseMs = ?, totalDuration = ? WHERE id = ?`,
    [now, totalPause, durationMs, session.id]
  );
  return { ...session, endTime: now, totalDuration: durationMs };
}

async function getActiveStaffService(guildId, userId) {
  return await getAsync(
    `SELECT * FROM staff_services WHERE guildId = ? AND userId = ? AND status != 'ended'`,
    [guildId, userId]
  );
}

async function getAllActiveStaffServices(guildId) {
  return await allAsync(
    `SELECT * FROM staff_services WHERE guildId = ? AND status != 'ended'`,
    [guildId]
  );
}

async function getStaffServiceStats(guildId, userId) {
  const result = await getAsync(
    `SELECT COUNT(*) as totalShifts, SUM(totalDuration) as totalTimeMs FROM staff_services WHERE guildId = ? AND userId = ? AND status = 'ended'`,
    [guildId, userId]
  );
  return {
    totalShifts: result?.totalShifts || 0,
    totalTimeMs: result?.totalTimeMs || 0
  };
}

async function getStaffServiceLeaderboard(guildId, limit = 10) {
  return await allAsync(
    `SELECT userId, username, COUNT(*) as shiftCount, SUM(totalDuration) as totalTimeMs
     FROM staff_services
     WHERE guildId = ? AND status = 'ended'
     GROUP BY userId
     ORDER BY totalTimeMs DESC
     LIMIT ?`,
    [guildId, limit]
  );
}

async function saveStaffLeaderboardConfig(guildId, channelId, messageId) {
  const now = Date.now();
  await runAsync(
    `INSERT INTO staff_leaderboard_config (guildId, channelId, messageId, updatedAt)
     VALUES (?, ?, ?, ?)
     ON CONFLICT(guildId) DO UPDATE SET
       channelId = excluded.channelId,
       messageId = excluded.messageId,
       updatedAt = excluded.updatedAt`,
    [guildId, channelId, messageId, now]
  );
}

async function getStaffLeaderboardConfig(guildId) {
  return await getAsync(
    `SELECT * FROM staff_leaderboard_config WHERE guildId = ?`,
    [guildId]
  );
}

// === STAFF RANK PROMOTION METHODS ===
async function addStaffRankRecord(guildId, staffUserId, staffUsername, adminId, actionType, oldRank, newRank, reason) {
  const now = Date.now();
  const res = await runAsync(
    `INSERT INTO staff_rank_promotions (guildId, staffUserId, staffUsername, adminId, actionType, oldRank, newRank, reason, createdAt)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [guildId, staffUserId, staffUsername, adminId, actionType, oldRank, newRank, reason, now]
  );
  return res.lastID;
}

async function getStaffRankHistory(guildId, staffUserId) {
  const inputStr = staffUserId.toString();
  return await allAsync(
    `SELECT * FROM staff_rank_promotions WHERE guildId = ? AND (staffUserId = ? OR staffUsername LIKE ?) ORDER BY createdAt DESC`,
    [guildId, inputStr, `%${inputStr}%`]
  );
}

// === STAFF ABSENCE METHODS ===
async function addStaffAbsence(guildId, userId, username, startDate, endDate, reason) {
  const now = Date.now();
  await runAsync(
    `UPDATE staff_absences SET status = 'ended', endedAt = ? WHERE guildId = ? AND userId = ? AND status = 'active'`,
    [now, guildId, userId]
  );

  const res = await runAsync(
    `INSERT INTO staff_absences (guildId, userId, username, startDate, endDate, reason, status, createdAt)
     VALUES (?, ?, ?, ?, ?, ?, 'active', ?)`,
    [guildId, userId, username, startDate, endDate, reason, now]
  );
  return res.lastID;
}

async function endStaffAbsence(guildId, userId) {
  const active = await getAsync(
    `SELECT * FROM staff_absences WHERE guildId = ? AND userId = ? AND status = 'active'`,
    [guildId, userId]
  );
  if (!active) return null;

  const now = Date.now();
  await runAsync(
    `UPDATE staff_absences SET status = 'ended', endedAt = ? WHERE id = ?`,
    [now, active.id]
  );
  return { ...active, status: 'ended', endedAt: now };
}

async function getActiveStaffAbsence(guildId, userId) {
  return await getAsync(
    `SELECT * FROM staff_absences WHERE guildId = ? AND userId = ? AND status = 'active'`,
    [guildId, userId]
  );
}

async function getAllActiveStaffAbsences(guildId) {
  return await allAsync(
    `SELECT * FROM staff_absences WHERE guildId = ? AND status = 'active' ORDER BY createdAt DESC`,
    [guildId]
  );
}

async function getStaffAbsenceHistory(guildId, userId) {
  const inputStr = userId.toString();
  return await allAsync(
    `SELECT * FROM staff_absences WHERE guildId = ? AND (userId = ? OR username LIKE ?) ORDER BY createdAt DESC`,
    [guildId, inputStr, `%${inputStr}%`]
  );
}

// === STAFF REVIEW METHODS ===
async function addStaffReview(guildId, authorId, authorUsername, staffQuery, staffUserId, rating, comment, isAnonymous = 0) {
  const now = Date.now();
  const res = await runAsync(
    `INSERT INTO staff_reviews (guildId, authorId, authorUsername, staffQuery, staffUserId, rating, comment, isAnonymous, createdAt)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [guildId, authorId, authorUsername, staffQuery, staffUserId || null, rating, comment, isAnonymous ? 1 : 0, now]
  );
  return res.lastID;
}

async function getStaffReviews(guildId, staffUserIdOrQuery = null) {
  if (staffUserIdOrQuery) {
    const queryStr = staffUserIdOrQuery.toString();
    return await allAsync(
      `SELECT * FROM staff_reviews WHERE guildId = ? AND (staffUserId = ? OR staffQuery LIKE ?) ORDER BY createdAt DESC`,
      [guildId, queryStr, `%${queryStr}%`]
    );
  }
  return await allAsync(
    `SELECT * FROM staff_reviews WHERE guildId = ? ORDER BY createdAt DESC`,
    [guildId]
  );
}

async function getStaffReviewStats(guildId, staffUserIdOrQuery = null) {
  let sql = `SELECT COUNT(*) as totalReviews, AVG(rating) as avgRating FROM staff_reviews WHERE guildId = ?`;
  const params = [guildId];

  if (staffUserIdOrQuery) {
    const queryStr = staffUserIdOrQuery.toString();
    sql += ` AND (staffUserId = ? OR staffQuery LIKE ?)`;
    params.push(queryStr, `%${queryStr}%`);
  }

  const result = await getAsync(sql, params);
  return {
    totalReviews: result?.totalReviews || 0,
    avgRating: result?.avgRating ? parseFloat(result.avgRating.toFixed(2)) : 0
  };
}

async function getStaffReviewCard(guildId, staffKey) {
  return await getAsync(
    `SELECT * FROM staff_review_cards WHERE guildId = ? AND staffKey = ?`,
    [guildId, staffKey.toString().toLowerCase()]
  );
}

async function saveStaffReviewCard(guildId, staffKey, channelId, messageId) {
  const now = Date.now();
  const keyStr = staffKey.toString().toLowerCase();
  await runAsync(
    `INSERT INTO staff_review_cards (guildId, staffKey, channelId, messageId, updatedAt)
     VALUES (?, ?, ?, ?, ?)
     ON CONFLICT(staffKey) DO UPDATE SET
       channelId = excluded.channelId,
       messageId = excluded.messageId,
       updatedAt = excluded.updatedAt`,
    [guildId, keyStr, channelId, messageId, now]
  );
}

async function deleteStaffReviewCard(guildId, staffKey) {
  return await runAsync(
    `DELETE FROM staff_review_cards WHERE guildId = ? AND staffKey = ?`,
    [guildId, staffKey.toString().toLowerCase()]
  );
}

async function removeStaffReviewRecord(id) {
  return await runAsync(`DELETE FROM staff_reviews WHERE id = ?`, [id]);
}

async function clearStaffReviews(guildId, staffKey) {
  const keyStr = staffKey.toString().toLowerCase();
  return await runAsync(
    `DELETE FROM staff_reviews WHERE guildId = ? AND (staffUserId = ? OR staffQuery LIKE ?)`,
    [guildId, keyStr, `%${keyStr}%`]
  );
}

// === SUGGESTIONS METHODS ===
async function createSuggestionRecord(guildId, authorId, authorUsername, title, details, channelId, messageId) {
  const now = Date.now();
  const initialProposals = JSON.stringify([
    { authorId, authorUsername, title, details, createdAt: now }
  ]);
  const res = await runAsync(
    `INSERT INTO suggestions (guildId, authorId, authorUsername, title, details, status, upVotes, downVotes, voters, proposals, channelId, messageId, createdAt, updatedAt)
     VALUES (?, ?, ?, ?, ?, 'PENDING', 0, 0, '{}', ?, ?, ?, ?, ?)`,
    [guildId, authorId, authorUsername, title, details, initialProposals, channelId, messageId, now, now]
  );
  return res.lastID;
}

async function getSuggestionRecord(id) {
  return await getAsync(`SELECT * FROM suggestions WHERE id = ?`, [id]);
}

async function getSuggestionByMessageRecord(messageId) {
  return await getAsync(`SELECT * FROM suggestions WHERE messageId = ?`, [messageId]);
}

async function updateSuggestionStatusRecord(id, status, processedBy, staffReason = null) {
  const now = Date.now();
  await runAsync(
    `UPDATE suggestions SET status = ?, processedBy = ?, staffReason = ?, updatedAt = ? WHERE id = ?`,
    [status, processedBy, staffReason || null, now, id]
  );
  return await getSuggestionRecord(id);
}

async function voteSuggestionRecord(id, userId, voteType) {
  const suggestion = await getSuggestionRecord(id);
  if (!suggestion) return null;

  let voters = {};
  try {
    voters = JSON.parse(suggestion.voters || '{}');
  } catch (e) {
    voters = {};
  }

  let upVotes = suggestion.upVotes || 0;
  let downVotes = suggestion.downVotes || 0;

  const previousVote = voters[userId];

  if (previousVote === voteType) {
    delete voters[userId];
    if (voteType === 'up') upVotes = Math.max(0, upVotes - 1);
    else if (voteType === 'down') downVotes = Math.max(0, downVotes - 1);
  } else {
    if (previousVote === 'up') upVotes = Math.max(0, upVotes - 1);
    else if (previousVote === 'down') downVotes = Math.max(0, downVotes - 1);

    voters[userId] = voteType;
    if (voteType === 'up') upVotes++;
    else if (voteType === 'down') downVotes++;
  }

  const now = Date.now();
  await runAsync(
    `UPDATE suggestions SET upVotes = ?, downVotes = ?, voters = ?, updatedAt = ? WHERE id = ?`,
    [upVotes, downVotes, JSON.stringify(voters), now, id]
  );

  return await getSuggestionRecord(id);
}

async function getSuggestionsHistoryRecord(guildId, limit = 20) {
  return await allAsync(
    `SELECT * FROM suggestions WHERE guildId = ? ORDER BY createdAt DESC LIMIT ?`,
    [guildId, limit]
  );
}

async function addProposalToSuggestionRecord(suggestionId, authorId, authorUsername, title, details) {
  const suggestion = await getSuggestionRecord(suggestionId);
  if (!suggestion) return null;

  let proposals = [];
  try {
    proposals = JSON.parse(suggestion.proposals || '[]');
  } catch (e) {
    proposals = [];
  }

  if (proposals.length === 0) {
    proposals.push({
      authorId: suggestion.authorId,
      authorUsername: suggestion.authorUsername,
      title: suggestion.title,
      details: suggestion.details,
      createdAt: suggestion.createdAt
    });
  }

  proposals.push({
    authorId,
    authorUsername,
    title,
    details,
    createdAt: Date.now()
  });

  const now = Date.now();
  await runAsync(
    `UPDATE suggestions SET proposals = ?, updatedAt = ? WHERE id = ?`,
    [JSON.stringify(proposals), now, suggestionId]
  );

  return await getSuggestionRecord(suggestionId);
}

function calculateTitleSimilarity(title1, title2) {
  const normalize = str => str.toLowerCase()
    .normalize("NFD").replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9\s]/g, "")
    .split(/\s+/)
    .filter(w => w.length > 2);

  const words1 = normalize(title1);
  const words2 = normalize(title2);

  if (words1.length === 0 || words2.length === 0) return 0;

  const set2 = new Set(words2);
  const commonWords = words1.filter(w => set2.has(w));

  const minLength = Math.min(words1.length, words2.length);
  return commonWords.length / minLength;
}

async function findSimilarPendingSuggestion(guildId, newTitle) {
  const pendingSuggestions = await allAsync(
    `SELECT * FROM suggestions WHERE guildId = ? AND status = 'PENDING' AND (mergedInto IS NULL OR mergedInto = 0) ORDER BY createdAt DESC`,
    [guildId]
  );

  for (const s of pendingSuggestions) {
    const similarity = calculateTitleSimilarity(newTitle, s.title);
    if (similarity >= 0.5) {
      return s;
    }
  }
  return null;
}

async function mergeSuggestionsRecord(sourceId, targetId, staffUserId) {
  const source = await getSuggestionRecord(sourceId);
  const target = await getSuggestionRecord(targetId);
  if (!source || !target) return null;

  let targetProposals = [];
  try { targetProposals = JSON.parse(target.proposals || '[]'); } catch (e) {}
  if (targetProposals.length === 0) {
    targetProposals.push({
      authorId: target.authorId,
      authorUsername: target.authorUsername,
      title: target.title,
      details: target.details,
      createdAt: target.createdAt
    });
  }

  let sourceProposals = [];
  try { sourceProposals = JSON.parse(source.proposals || '[]'); } catch (e) {}
  if (sourceProposals.length === 0) {
    sourceProposals.push({
      authorId: source.authorId,
      authorUsername: source.authorUsername,
      title: source.title,
      details: source.details,
      createdAt: source.createdAt
    });
  }

  const mergedProposals = [...targetProposals, ...sourceProposals];

  let targetVoters = {};
  try { targetVoters = JSON.parse(target.voters || '{}'); } catch (e) {}
  let sourceVoters = {};
  try { sourceVoters = JSON.parse(source.voters || '{}'); } catch (e) {}

  const combinedVoters = { ...sourceVoters, ...targetVoters };

  let upVotes = 0;
  let downVotes = 0;
  for (const v of Object.values(combinedVoters)) {
    if (v === 'up') upVotes++;
    else if (v === 'down') downVotes++;
  }

  const now = Date.now();

  await runAsync(
    `UPDATE suggestions SET proposals = ?, voters = ?, upVotes = ?, downVotes = ?, updatedAt = ? WHERE id = ?`,
    [JSON.stringify(mergedProposals), JSON.stringify(combinedVoters), upVotes, downVotes, now, targetId]
  );

  await runAsync(
    `UPDATE suggestions SET status = 'MERGED', mergedInto = ?, processedBy = ?, updatedAt = ? WHERE id = ?`,
    [targetId, staffUserId, now, sourceId]
  );

  return await getSuggestionRecord(targetId);
}

async function saveSuggestionDashboard(guildId, channelId, messageId) {
  const now = Date.now();
  return await runAsync(
    `INSERT INTO suggestion_dashboards (guildId, channelId, messageId, updatedAt)
     VALUES (?, ?, ?, ?)
     ON CONFLICT(guildId) DO UPDATE SET
       channelId = excluded.channelId,
       messageId = excluded.messageId,
       updatedAt = excluded.updatedAt`,
    [guildId, channelId, messageId, now]
  );
}

async function getSuggestionDashboard(guildId) {
  return await getAsync(`SELECT * FROM suggestion_dashboards WHERE guildId = ?`, [guildId]);
}

async function deleteSuggestionDashboard(guildId) {
  return await runAsync(`DELETE FROM suggestion_dashboards WHERE guildId = ?`, [guildId]);
}

// === GIVEAWAY METHODS ===
async function createGiveawayRecord(guildId, channelId, messageId, prize, description, winnersCount, hostId, endsAt) {
  const now = Date.now();
  const res = await runAsync(
    `INSERT INTO giveaways (guildId, channelId, messageId, prize, description, winnersCount, hostId, participants, endsAt, ended, winners, createdAt)
     VALUES (?, ?, ?, ?, ?, ?, ?, '[]', ?, 0, '[]', ?)`,
    [guildId, channelId, messageId, prize, description || null, winnersCount || 1, hostId, endsAt, now]
  );
  return res.lastID;
}

async function getGiveawayRecord(id) {
  return await getAsync(`SELECT * FROM giveaways WHERE id = ?`, [id]);
}

async function getGiveawayByMessageRecord(messageId) {
  return await getAsync(`SELECT * FROM giveaways WHERE messageId = ? OR id = ?`, [messageId, messageId]);
}

async function getActiveGiveawaysRecord(guildId = null) {
  if (guildId) {
    return await allAsync(`SELECT * FROM giveaways WHERE guildId = ? AND ended = 0 ORDER BY endsAt ASC`, [guildId]);
  }
  return await allAsync(`SELECT * FROM giveaways WHERE ended = 0 ORDER BY endsAt ASC`);
}

async function getDueGiveawaysRecord() {
  const now = Date.now();
  return await allAsync(`SELECT * FROM giveaways WHERE ended = 0 AND endsAt <= ? ORDER BY endsAt ASC`, [now]);
}

async function toggleGiveawayParticipantRecord(messageId, userId) {
  const g = await getGiveawayByMessageRecord(messageId);
  if (!g || g.ended) return null;

  let participants = [];
  try {
    participants = JSON.parse(g.participants || '[]');
  } catch (e) {
    participants = [];
  }

  const index = participants.indexOf(userId);
  let added = false;

  if (index === -1) {
    participants.push(userId);
    added = true;
  } else {
    participants.splice(index, 1);
    added = false;
  }

  await runAsync(
    `UPDATE giveaways SET participants = ? WHERE id = ?`,
    [JSON.stringify(participants), g.id]
  );

  return {
    added,
    count: participants.length,
    participants,
    giveaway: await getGiveawayRecord(g.id)
  };
}

async function endGiveawayRecord(id, winnersArray = []) {
  await runAsync(
    `UPDATE giveaways SET ended = 1, winners = ? WHERE id = ?`,
    [JSON.stringify(winnersArray), id]
  );
  return await getGiveawayRecord(id);
}

async function saveGiveawayDashboard(guildId, channelId, messageId) {
  const now = Date.now();
  return await runAsync(
    `INSERT INTO giveaway_dashboards (guildId, channelId, messageId, updatedAt)
     VALUES (?, ?, ?, ?)
     ON CONFLICT(guildId) DO UPDATE SET
       channelId = excluded.channelId,
       messageId = excluded.messageId,
       updatedAt = excluded.updatedAt`,
    [guildId, channelId, messageId, now]
  );
}

async function getGiveawayDashboard(guildId) {
  return await getAsync(`SELECT * FROM giveaway_dashboards WHERE guildId = ?`, [guildId]);
}

// === ANTI-RAID & BACKUP METHODS ===
const antiRaidCache = new Map();

async function getAntiRaidConfig(guildId) {
  const cached = antiRaidCache.get(guildId);
  if (cached && (Date.now() - cached.timestamp < 30000)) {
    return cached.data;
  }
  let cfg = await getAsync(`SELECT * FROM antiraid_config WHERE guildId = ?`, [guildId]);
  if (!cfg) {
    const now = Date.now();
    await runAsync(
      `INSERT INTO antiraid_config (guildId, lockdown, antiBot, antiAlt, minAccountAgeDays, antiSpam, maxMessagesPer5Sec, maxMentions, antiMassJoin, maxJoinsPer10Sec, updatedAt)
       VALUES (?, 0, 1, 1, 7, 1, 5, 4, 1, 5, ?)`,
      [guildId, now]
    );
    cfg = await getAsync(`SELECT * FROM antiraid_config WHERE guildId = ?`, [guildId]);
  }
  antiRaidCache.set(guildId, { data: cfg, timestamp: Date.now() });
  return cfg;
}

async function updateAntiRaidConfig(guildId, updates) {
  antiRaidCache.delete(guildId);
  await getAntiRaidConfig(guildId);
  const fields = [];
  const params = [];
  for (const [key, value] of Object.entries(updates)) {
    fields.push(`${key} = ?`);
    params.push(value);
  }
  if (fields.length === 0) return await getAntiRaidConfig(guildId);

  fields.push(`updatedAt = ?`);
  params.push(Date.now());
  params.push(guildId);

  await runAsync(`UPDATE antiraid_config SET ${fields.join(', ')} WHERE guildId = ?`, params);
  antiRaidCache.delete(guildId);
  return await getAntiRaidConfig(guildId);
}

async function saveAntiRaidDashboard(guildId, channelId, messageId) {
  const now = Date.now();
  await runAsync(
    `INSERT INTO antiraid_dashboards (guildId, channelId, messageId, updatedAt)
     VALUES (?, ?, ?, ?)
     ON CONFLICT(guildId) DO UPDATE SET
       channelId = excluded.channelId,
       messageId = excluded.messageId,
       updatedAt = excluded.updatedAt`,
    [guildId, channelId, messageId, now]
  );
}

async function getAntiRaidDashboard(guildId) {
  return await getAsync(`SELECT * FROM antiraid_dashboards WHERE guildId = ?`, [guildId]);
}

async function addBackupRecord(guildId, backupName, fileType, filePath, createdBy, details) {
  const now = Date.now();
  const res = await runAsync(
    `INSERT INTO server_backups (guildId, backupName, fileType, filePath, createdBy, createdAt, details)
     VALUES (?, ?, ?, ?, ?, ?, ?)`,
    [guildId, backupName, fileType, filePath, createdBy, now, details || null]
  );
  return res.lastID;
}

async function getBackupsHistory(guildId, limit = 10) {
  return await allAsync(
    `SELECT * FROM server_backups WHERE guildId = ? ORDER BY createdAt DESC LIMIT ?`,
    [guildId, limit]
  );
}

async function getLastBackup(guildId) {
  return await getAsync(
    `SELECT * FROM server_backups WHERE guildId = ? ORDER BY createdAt DESC LIMIT 1`,
    [guildId]
  );
}

// === STAFF RECRUITMENT METHODS ===
async function createStaffTestRecord({ guildId, userId, userTag, robloxUsername, age, availability, experience, case1, case2, case3, answersJson }) {
  const now = Date.now();
  const jsonStr = typeof answersJson === 'object' ? JSON.stringify(answersJson) : answersJson;
  const res = await runAsync(
    `INSERT INTO staff_recruitment_tests (guildId, userId, userTag, robloxUsername, age, availability, experience, case1, case2, case3, answersJson, status, createdAt, updatedAt)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'PENDING', ?, ?)`,
    [guildId, userId, userTag, robloxUsername || 'N/A', age || 0, availability || 'N/A', experience || 'N/A', case1 || 'N/A', case2 || 'N/A', case3 || 'N/A', jsonStr || null, now, now]
  );
  return res.lastID;
}


async function getStaffTestRecord(id) {
  return await getAsync(`SELECT * FROM staff_recruitment_tests WHERE id = ?`, [id]);
}

async function updateStaffTestStatus(id, status, reviewedBy, reviewReason, channelId, messageId) {
  const now = Date.now();
  const fields = ['status = ?', 'updatedAt = ?'];
  const params = [status, now];

  if (reviewedBy) { fields.push('reviewedBy = ?'); params.push(reviewedBy); }
  if (reviewReason) { fields.push('reviewReason = ?'); params.push(reviewReason); }
  if (channelId) { fields.push('channelId = ?'); params.push(channelId); }
  if (messageId) { fields.push('messageId = ?'); params.push(messageId); }

  params.push(id);
  await runAsync(`UPDATE staff_recruitment_tests SET ${fields.join(', ')} WHERE id = ?`, params);
  return await getStaffTestRecord(id);
}

// === PARTNERSHIP METHODS ===
async function createPartnershipRecord({ guildId, userId, userTag, serverName, inviteUrl, memberCount, partnerType, description }) {
  const now = Date.now();
  const res = await runAsync(
    `INSERT INTO partnership_requests (guildId, userId, userTag, serverName, inviteUrl, memberCount, partnerType, description, status, createdAt, updatedAt)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'PENDING', ?, ?)`,
    [guildId, userId, userTag, serverName, inviteUrl, memberCount, partnerType, description, now, now]
  );
  return res.lastID;
}

async function getPartnershipRecord(id) {
  return await getAsync(`SELECT * FROM partnership_requests WHERE id = ?`, [id]);
}

async function updatePartnershipStatus(id, status, reviewedBy, reviewReason, channelId, messageId) {
  const now = Date.now();
  const fields = ['status = ?', 'updatedAt = ?'];
  const params = [status, now];

  if (reviewedBy) { fields.push('reviewedBy = ?'); params.push(reviewedBy); }
  if (reviewReason) { fields.push('reviewReason = ?'); params.push(reviewReason); }
  if (channelId) { fields.push('channelId = ?'); params.push(channelId); }
  if (messageId) { fields.push('messageId = ?'); params.push(messageId); }

  params.push(id);
  await runAsync(`UPDATE partnership_requests SET ${fields.join(', ')} WHERE id = ?`, params);
  return await getPartnershipRecord(id);
}

// === ORGANIZATION METHODS (GANG / BUSINESS) ===
async function createOrganizationRecord({ guildId, userId, userTag, orgType, orgName, lore, membersList, locationOrSector, businessPlan }) {
  const now = Date.now();
  const res = await runAsync(
    `INSERT INTO organization_requests (guildId, userId, userTag, orgType, orgName, lore, membersList, locationOrSector, businessPlan, status, createdAt, updatedAt)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'PENDING', ?, ?)`,
    [guildId, userId, userTag, orgType, orgName, lore, membersList, locationOrSector, businessPlan || null, now, now]
  );
  return res.lastID;
}

async function getOrganizationRecord(id) {
  return await getAsync(`SELECT * FROM organization_requests WHERE id = ?`, [id]);
}

async function updateOrganizationStatus(id, status, reviewedBy, reviewReason, channelId, messageId) {
  const now = Date.now();
  const fields = ['status = ?', 'updatedAt = ?'];
  const params = [status, now];

  if (reviewedBy) { fields.push('reviewedBy = ?'); params.push(reviewedBy); }
  if (reviewReason) { fields.push('reviewReason = ?'); params.push(reviewReason); }
  if (channelId) { fields.push('channelId = ?'); params.push(channelId); }
  if (messageId) { fields.push('messageId = ?'); params.push(messageId); }

  params.push(id);
  await runAsync(`UPDATE organization_requests SET ${fields.join(', ')} WHERE id = ?`, params);
  return await getOrganizationRecord(id);
}

module.exports = {

  db,
  initDatabase,
  startService,
  stopService,
  getActiveService,
  getServiceStats,
  getServiceLeaderboard,
  addWanted,
  removeWanted,
  getWantedList,
  addFine,
  getFinesHistory,
  getProfile,
  updateProfile,
  linkRobloxAccount,
  unlinkRobloxAccount,
  updateBank,
  createTicketRecord,
  claimTicketRecord,
  closeTicketRecord,
  getTicketByChannel,
  getTicketStats,
  createPatrol,
  getActivePatrols,
  deletePatrol,
  addWarning,
  getWarnings,
  clearWarnings,
  getWelcomeConfig,
  updateWelcomeConfig,
  isRobloxLinkedToAnotherDiscord,
  saveVerification,
  getVerification,
  addSanctionRecord,
  getPlayerSanctionsHistory,
  getPlayerSanctionCard,
  savePlayerSanctionCard,
  removeSanctionRecord,
  clearPlayerSanctions,
  deletePlayerSanctionCard,
  addStaffSanctionRecord,
  getStaffSanctionsHistory,
  getStaffSanctionCard,
  saveStaffSanctionCard,
  removeStaffSanctionRecord,
  clearStaffSanctions,
  deleteStaffSanctionCard,
  startStaffService,
  pauseStaffService,
  resumeStaffService,
  stopStaffService,
  getActiveStaffService,
  getAllActiveStaffServices,
  getStaffServiceStats,
  getStaffServiceLeaderboard,
  saveStaffLeaderboardConfig,
  getStaffLeaderboardConfig,
  addStaffRankRecord,
  getStaffRankHistory,
  addStaffAbsence,
  endStaffAbsence,
  getActiveStaffAbsence,
  getAllActiveStaffAbsences,
  getStaffAbsenceHistory,
  addStaffReview,
  getStaffReviews,
  getStaffReviewStats,
  getStaffReviewCard,
  saveStaffReviewCard,
  deleteStaffReviewCard,
  removeStaffReviewRecord,
  clearStaffReviews,
  createSuggestionRecord,
  getSuggestionRecord,
  getSuggestionByMessageRecord,
  updateSuggestionStatusRecord,
  voteSuggestionRecord,
  getSuggestionsHistoryRecord,
  addProposalToSuggestionRecord,
  findSimilarPendingSuggestion,
  mergeSuggestionsRecord,
  saveSuggestionDashboard,
  getSuggestionDashboard,
  deleteSuggestionDashboard,
  createGiveawayRecord,
  getGiveawayRecord,
  getGiveawayByMessageRecord,
  getActiveGiveawaysRecord,
  getDueGiveawaysRecord,
  toggleGiveawayParticipantRecord,
  endGiveawayRecord,
  saveGiveawayDashboard,
  getGiveawayDashboard,
  getAntiRaidConfig,
  updateAntiRaidConfig,
  saveAntiRaidDashboard,
  getAntiRaidDashboard,
  addBackupRecord,
  getBackupsHistory,
  getLastBackup,
  createStaffTestRecord,
  getStaffTestRecord,
  updateStaffTestStatus,
  createPartnershipRecord,
  getPartnershipRecord,
  updatePartnershipStatus,
  createOrganizationRecord,
  getOrganizationRecord,
  updateOrganizationStatus,
  getUserBalance,
  addMoney,
  removeMoney,
  setCooldown,
  getCooldown,
  addXP,
  getUserLevelInfo,
  getTopXPLeaderboard,
  saveXpDashboardRecord,
  getXpDashboardRecord,
  getAllXpDashboardsRecords,
  getRequiredXPForLevel,
  getProfileByDiscord,
  getProfileByRoblox,
  getAllActiveServices
};







