const { EmbedBuilder } = require('discord.js');
const config = require('../../config.json');

/**
 * Varied, natural human support agent response patterns for Aubagne / Hamburg RP
 */

function getRandomGreeting(username) {
  const greetings = [
    `Bonjour ${username} ! Je suis l'assistant virtuel d'Aubagne RP. Comment puis-je t'aider ?`,
    `Salut ${username} ! Je t'écoute, dis-moi ce dont tu as besoin pour ton ticket.`,
    `Bonjour ${username} ! Je suis là pour répondre à tes questions. Que puis-je faire pour toi ?`
  ];
  return greetings[Math.floor(Math.random() * greetings.length)];
}

/**
 * Advanced Conversational AI Engine
 */
async function processAIConversation({ userMessage, category, conversationHistory = [] }) {
  const text = userMessage.content.toLowerCase().trim();
  const username = userMessage.author.username;

  // 1. Escalation Keywords -> Immediate Staff Transfer
  const staffEscalationKeywords = [
    'staff', 'admin', 'modérateur', 'moderateur', 'fondateur', 'humain', 'parler a quelqu\'un',
    'report', 'plainte', 'freetill', 'freeshoot', 'no rp', 'metagaming', 'powergaming', 'fear rp',
    'bannissement', 'deban', 'unban', 'video', 'rec', 'preuve', 'remboursement', 'sanction', 'insulte'
  ];

  const needsEscalation = staffEscalationKeywords.some(keyword => text.includes(keyword));

  if (needsEscalation) {
    return {
      response: `Absolument ! Je viens de transmettre ton ticket à l'équipe Staff d'Aubagne RP. Un modérateur va prendre le relais sous peu ! 🚨`,
      shouldPingStaff: true,
      reason: `Demande de prise en charge staff / modération pour : "${text.slice(0, 50)}..."`
    };
  }

  // 2. Greetings
  if (/^(bonjour|salut|coucou|hello|bonsoir|yop|hey)$/i.test(text)) {
    return {
      response: `${getRandomGreeting(username)}\n\nTu as ouvert un ticket pour **${category}**. Peux-tu me préciser ta demande ?`,
      shouldPingStaff: false
    };
  }

  // 3. Category & Topic Intent Analysis

  // --- Roblox Account Linking ---
  if (text.includes('roblox') || text.includes('lier') || text.includes('compte') || text.includes('pseudo')) {
    return {
      response:
        `Pour lier ton compte Roblox à Discord :\n` +
        `1. Rendez-vous dans le salon du dashboard Roblox ou tape la commande \`/link-roblox [TonPseudo]\`.\n` +
        `2. Tu peux aussi cliquer sur le bouton **🔗 Lier mon Compte Roblox** sur le dashboard.\n` +
        `3. Ton pseudo Roblox et ta photo de profil apparaîtront directement sur ta carte ID RP !\n\n` +
        `Est-ce que cela fonctionne pour toi ?`,
      shouldPingStaff: false
    };
  }

  // --- Recrutement Staff ---
  if (category.toLowerCase().includes('recrutement') || text.includes('recrutement') || text.includes('candidature') || text.includes('devenir staff')) {
    return {
      response: `Cliquez sur le bouton vert **"Passer le test (20 Questions - 15s/Q)"** ci-dessus pour démarrer votre examen de recrutement Staff pour **Aubagne RP Officiel** ! 📋`,
      shouldPingStaff: false
    };
  }


  // --- Demande de Partenariat ---
  if (category.toLowerCase().includes('partenariat') || text.includes('partenariat') || text.includes('partenaire')) {
    return {
      response:
        `Bonjour ! Pour valider un partenariat avec Aubagne RP :\n` +
        `- Votre serveur Discord doit compter au moins 150-200 membres actifs.\n` +
        `- La thématique doit être compatible (Gaming, Roblox, RP).\n\n` +
        `Merci de me poster le **lien d'invitation permanent** et la **présentation de votre serveur**. Je préviendrai le Responsable Partenariats !`,
      shouldPingStaff: false
    };
  }

  // --- Création de Gang / Organisation ---
  if (category.toLowerCase().includes('gang') || text.includes('gang') || text.includes('orga') || text.includes('mafia') || text.includes('cartel')) {
    return {
      response:
        `Pour officialiser un Gang / Organisation Criminelle :\n` +
        `1. Fournir le nom du Gang et sa couleur officielle.\n` +
        `2. Rédiger une courte présentation (Lore & Histoire).\n` +
        `3. Donner la liste des pseudos Roblox & Discord d'au moins 4 membres fondateurs.\n` +
        `4. Préciser le quartier général / territoire souhaité.\n\n` +
        `Quand ton dossier est prêt, envoie-le ici et je préviendrai la Gestion Illégale !`,
      shouldPingStaff: false
    };
  }

  // --- Création d'Entreprise ---
  if (category.toLowerCase().includes('entreprise') || text.includes('entreprise') || text.includes('magasin') || text.includes('société') || text.includes('commerce')) {
    return {
      response:
        `Pour ouvrir une Entreprise en ville :\n` +
        `• Présenter le nom et l'activité de l'entreprise (Concessionnaire, Bar, Sécurité, Taxi...)\n` +
        `• Fournir les tarifs des prestations/produits\n` +
        `• Avoir au moins 2 employés au démarrage\n\n` +
        `Envoie ta présentation ci-dessous pour l'équipe Mairie / Entreprises !`,
      shouldPingStaff: false
    };
  }

  // --- Prise de Service & Patrouilles ---
  if (text.includes('service') || text.includes('patrouille') || text.includes('heure') || text.includes('stat')) {
    return {
      response:
        `Pour la prise de service :\n` +
        `- Utilise le dashboard \`/dashboard-service\` pour cliquer sur Police, Pompiers, EMS ou ADAC.\n` +
        `- Tes heures sont comptabilisées automatiquement et sauvegardées dans la base de données.\n` +
        `- Clique sur **Mes Stats** pour voir tes heures ou **/service-leaderboard** pour le classement !`,
      shouldPingStaff: false
    };
  }

  // --- 911 & Urgences ---
  if (text.includes('911') || text.includes('urgence') || text.includes('police') || text.includes('pompier') || text.includes('ems')) {
    return {
      response:
        `Pour passer un appel d'urgence 911 en ville :\n` +
        `1. Utilise la commande \`/911\` ou va sur le \`/dashboard-911\`.\n` +
        `2. Entre la localisation et la raison de l'urgence.\n` +
        `3. Les agents en service recevront l'alerte avec un bouton de prise en charge !`,
      shouldPingStaff: false
    };
  }

  // --- Thanks / Closing ---
  if (text.includes('merci') || text.includes('c\'est bon') || text.includes('super') || text.includes('parfait') || text.includes('ok merci')) {
    return {
      response: `Avec plaisir ! Si tout est bon pour toi, un membre du staff ou toi-même pouvez cliquer sur **🔒 Fermer le ticket** ci-dessus. Bon jeu sur Aubagne RP ! 😊`,
      shouldPingStaff: false,
      isResolved: true
    };
  }

  // --- Dynamic Natural Fallback ---
  const fallbacks = [
    `J'ai bien noté ton message concernant **${category}** ! Peux-tu m'en dire un peu plus afin que je t'aide au mieux ? Si c'est trop complexe, dis-moi simplement "Staff" et je passe la main.`,
    `D'accord, je comprends. Pourrais-tu me donner quelques détails supplémentaires sur ta demande ? (Ou dis "Staff" si tu veux parler directement à un modérateur humain).`,
    `Très bien ! Je suis là pour t'accompagner. Précise-moi ce dont tu as besoin ou demande l'intervention du Staff si nécessaire.`
  ];

  const randomFallback = fallbacks[Math.floor(Math.random() * fallbacks.length)];

  return {
    response: randomFallback,
    shouldPingStaff: false
  };
}

module.exports = {
  processAIConversation
};
